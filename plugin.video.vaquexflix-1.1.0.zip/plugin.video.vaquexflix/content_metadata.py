"""Normalize published title/episode metadata without borrowing related plots."""
import html
import json
import re
from html.parser import HTMLParser


def clean(value):
    value = str(value or '')
    for _ in range(3):
        decoded = html.unescape(value)
        if decoded == value:
            break
        value = decoded
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]*>', ' ', value)).strip()


def genres(value):
    values = value if isinstance(value, list) else [value]
    result = []
    for entry in values:
        name = clean(entry.get('name') if isinstance(entry, dict) else entry)
        if name and not name.isdigit() and name not in result:
            result.append(name)
    return result


def fields(obj):
    date = obj.get('startDate') or obj.get('air_date') or obj.get('release_date') or obj.get('datePublished') or obj.get('year') or ''
    year = re.match(r'^(\d{4})(?:\b|$)', str(date))
    plot = clean(obj.get('overview') or obj.get('description') or obj.get('plot'))
    if re.match(r'^Ver\b.*\b(?:online|gratis|completo|cap[ií]tulo)\b', plot, re.I):
        plot = ''
    return {'plot': plot, 'year': year.group(1) if year else '',
            'genres': genres(obj.get('genres') or obj.get('genre') or [])}


class StructuredParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.documents, self.script = [], None

    def handle_starttag(self, tag, attrs):
        if tag == 'script' and dict(attrs).get('type') == 'application/ld+json':
            self.script = []

    def handle_data(self, value):
        if self.script is not None:
            self.script.append(value)

    def handle_endtag(self, tag):
        if tag == 'script' and self.script is not None:
            try:
                self.documents.append(json.loads(''.join(self.script)))
            except ValueError:
                pass
            self.script = None


def from_page(page, episode=False):
    parser = StructuredParser()
    parser.feed(page)
    nodes = list(parser.documents)
    result = {}
    for node in nodes:
        if isinstance(node, list):
            nodes.extend(node)
        elif isinstance(node, dict):
            nodes.extend(node.get('@graph', []))
            kind = node.get('@type', [])
            kind = [kind] if isinstance(kind, str) else kind
            wanted = ('TVEpisode',) if episode else ('TVSeries', 'Movie')
            if any(t in kind for t in wanted):
                result = fields(node)
                break
    if not episode:
        badges = re.findall(r'<a\b[^>]*href=["\'][^"\']*/genero/[^"\']+["\'][^>]*>\s*<span\b[^>]*class=["\'][^"\']*badge[^"\']*["\'][^>]*>(.*?)</span>', page, re.S | re.I)
        if badges:
            result['genres'] = genres(badges)
    # FuegoCine publishes these fields in the post body instead of JSON-LD.
    synopsis = re.search(r'<p\b[^>]*id=["\']tmdb-synopsis["\'][^>]*>(.*?)</p>', page, re.S | re.I)
    if synopsis and not episode:
        result['plot'] = clean(synopsis.group(1))
        for attribute, key in (('data-year', 'year'), ('data-genres', 'genres')):
            match = re.search(attribute + r'=["\']([^"\']+)', page)
            if match:
                value = clean(match.group(1))
                if key == 'genres':
                    result[key] = genres(value.split(','))
                elif re.fullmatch(r'\d{4}', value):
                    result[key] = value
    return {key: value for key, value in result.items() if value}
