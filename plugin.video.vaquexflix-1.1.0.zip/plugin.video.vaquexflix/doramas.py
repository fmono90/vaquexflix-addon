# -*- coding: utf-8 -*-
"""Consultas independientes de DoramasYT y DoramasFlix (sin integración Kodi).

Uso: python doramasyt_doramasflix.py {yt|flix} {catalog|search|detail|episode|embed} ...
Solo devuelve metadatos y enlaces de reproductores publicados por los sitios.
Las acciones internas de DoramasFlix pueden cambiar al desplegar una versión nueva.
"""

from __future__ import annotations

import argparse
import http.cookiejar
import json
import re
import sys
import time
import content_metadata
from provider_cache import PageCache

_PAGE_CACHE = PageCache()
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urljoin, urlparse, parse_qs
from urllib.request import HTTPCookieProcessor, Request, build_opener


USER_AGENT = "Mozilla/5.0"
YT = "https://www.doramasyt.com"
FLIX = "https://doramasflix.io"
FLIX_GRAPHQL = "https://user-api.fluxcedene.net/graphql"
FLIX_ACTIONS = {
    "search": "40f2b52de618b2460ce1d8676868e64a6774f2429c",
    "episodes": "4053123812c621a321f75a5d312ba2ca9a45d65e3f",
    "links": "40aea86e91b4fa6a9ea1d62d82adfde4fb4ec48d33",
    "movie_links": "40fc0c7365f478577476ba6c619b652aaa46d9e2d8",
}


class SourceError(Exception):
    pass


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


class _HTML(HTMLParser):
    """Extrae los elementos necesarios sin dependencias externas."""

    def __init__(self, base: str):
        super().__init__(convert_charrefs=True)
        self.base = base
        self.links = []
        self.players = []
        self.scripts = []
        self.csrf = ""
        self.ajax = ""
        self.player_key = ""
        self.title = ""
        self._link = None
        self._player = None
        self._h1 = 0
        self._h3 = 0
        self._script = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = set((attrs.get("class") or "").split())
        if tag == "a" and attrs.get("href"):
            self._link = {"url": urljoin(self.base, attrs["href"]),
                          "title": "", "heading": "", "poster": ""}
        elif tag == "img" and self._link:
            image = attrs.get("data-src") or attrs.get("src") or ""
            if image:
                self._link["poster"] = urljoin(self.base, image)
            self._link["alt"] = attrs.get("alt") or ""
        elif tag == "meta" and attrs.get("name") == "csrf-token":
            self.csrf = attrs.get("content") or ""
        elif tag == "section" and "caplist" in classes:
            self.ajax = attrs.get("data-ajax") or ""
        elif tag == "div" and "player" in classes:
            self.player_key = attrs.get("data-key") or ""
        elif tag == "button" and "play-video" in classes:
            self._player = {"name": "", "token": attrs.get("data-player") or "",
                            "uses_api": attrs.get("data-usa-api") == "1"}
        elif tag == "script":
            self._script = True
        if tag == "h1":
            self._h1 += 1
        if tag == "h3" and self._link:
            self._h3 += 1

    def handle_endtag(self, tag):
        if tag == "a" and self._link:
            self._link["title"] = _clean(self._link["title"])
            self._link["heading"] = _clean(self._link["heading"])
            self.links.append(self._link)
            self._link = None
        elif tag == "button" and self._player:
            self._player["name"] = _clean(self._player["name"])
            self.players.append(self._player)
            self._player = None
        elif tag == "script":
            self._script = False
        if tag == "h1" and self._h1:
            self._h1 -= 1
        if tag == "h3" and self._h3:
            self._h3 -= 1

    def handle_data(self, data):
        if self._link:
            self._link["title"] += data
            if self._h3:
                self._link["heading"] += data
        if self._player:
            self._player["name"] += data
        if self._h1:
            self.title += data
        if self._script and "self.__next_f.push([1," in data:
            self.scripts.append(data)


def _parse(html: str, url: str) -> _HTML:
    parser = _HTML(url)
    parser.feed(html)
    parser.title = _clean(parser.title)
    return parser


def _flight(parser: _HTML) -> str:
    chunks = []
    for script in parser.scripts:
        match = re.search(r"self\.__next_f\.push\(\[1,(\"(?:\\.|[^\"\\])*\")\]\)", script, re.S)
        if match:
            try:
                chunks.append(json.loads(match.group(1)))
            except ValueError:
                pass
    return "".join(chunks)


def _json_after(source: str, marker: str):
    position = source.find(marker)
    if position < 0:
        return None
    try:
        return json.JSONDecoder().raw_decode(source[position + len(marker):])[0]
    except ValueError:
        return None


class _Client:
    def __init__(self, base: str):
        self.base = base
        self.host = urlparse(base).hostname
        from servidores import nueva_sesion
        self.opener = nueva_sesion()
        # YT embeds CSRF/player tokens bound to this client's cookie session.
        self.page_cache = PageCache() if self.host == urlparse(YT).hostname else _PAGE_CACHE

    def _safe_url(self, url: str) -> str:
        result = urljoin(self.base, url)
        if urlparse(result).hostname != self.host or urlparse(result).scheme != "https":
            raise SourceError("La consulta debe permanecer en %s" % self.host)
        return result

    def request(self, url: str, data: bytes | None = None, headers: dict | None = None) -> str:
        url = self._safe_url(url)
        path = urlparse(url).path
        if data is None and path.startswith(('/dorama/', '/doramas/', '/peliculas/', '/ver/', '/capitulos/')):
            from servidores import tiempo_peticion
            key = (url, tuple(sorted((headers or {}).items())))
            return self.page_cache.get(key, lambda: self._request(url, data, headers), lambda: tiempo_peticion(20))
        return self._request(url, data, headers)

    def _request(self, url, data=None, headers=None):
        url = self._safe_url(url)
        request = Request(url, data=data, headers={"User-Agent": USER_AGENT,
                                                  **(headers or {})})
        try:
            with self.opener.open(request, timeout=20) as response:
                if urlparse(response.url).hostname != self.host:
                    raise SourceError("La consulta salió del dominio esperado")
                return response.read(5_000_000).decode(
                    response.headers.get_content_charset() or "utf-8", errors="replace")
        except HTTPError as exc:
            raise SourceError("HTTP %s en %s" % (exc.code, url)) from exc
        except URLError as exc:
            raise SourceError("No se pudo conectar a %s: %s" % (self.host, exc.reason)) from exc

    def post_form(self, url: str, fields: dict, referer: str) -> dict:
        payload = urlencode(fields).encode("utf-8")
        text = self.request(url, payload, {"Referer": self._safe_url(referer),
                                           "X-Requested-With": "XMLHttpRequest",
                                           "Content-Type": "application/x-www-form-urlencoded"})
        try:
            result = json.loads(text)
        except ValueError as exc:
            raise SourceError("La respuesta de capítulos no es JSON") from exc
        if not isinstance(result, dict):
            raise SourceError("La respuesta de capítulos tiene un formato inesperado")
        return result

    def action(self, page_url: str, action_id: str, argument: dict):
        text = self.request(page_url, json.dumps([argument]).encode("utf-8"), {
            "Next-Action": action_id, "Accept": "text/x-component",
            "Content-Type": "text/plain;charset=UTF-8", "Origin": self.base,
            "Referer": self._safe_url(page_url),
        })
        for line in text.splitlines():
            if line.startswith("1:"):
                try:
                    result = json.loads(line[2:])
                except ValueError as exc:
                    raise SourceError("La acción devolvió datos inválidos") from exc
                if result is None:
                    raise SourceError("La acción ya no responde; puede haber cambiado la versión del sitio")
                return result
        raise SourceError("No se encontró el resultado de la acción")


class DoramasYT:
    name = "DoramasYT"

    def __init__(self):
        self.http = _Client(YT)

    @staticmethod
    def _items(parser: _HTML) -> list[dict]:
        found = {}
        for link in parser.links:
            if re.fullmatch(r"/dorama/[^/]+/?", urlparse(link["url"]).path):
                found.setdefault(link["url"], {"title": link["heading"] or link["title"],
                                                 "url": link["url"], "poster": link["poster"]})
        return list(found.values())

    def _catalog(self, page: int, path: str) -> dict:
        if page < 1:
            raise SourceError("La página debe ser mayor que cero")
        url = YT + path + ("?p=%d" % page if page > 1 else "")
        parser = _parse(self.http.request(url), url)
        last_page = max((int(parse_qs(urlparse(link["url"]).query)["p"][0])
                         for link in parser.links if urlparse(link["url"]).path == path
                         and parse_qs(urlparse(link["url"]).query).get("p")), default=page)
        return {"source": self.name, "page": page, "last_page": last_page,
                "items": self._items(parser)}

    def catalog(self, page: int = 1) -> dict:
        return self._catalog(page, "/doramas")

    def movies(self, page: int = 1) -> dict:
        return self._catalog(page, "/peliculas")

    def catalog_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay)

    def movies_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay, "movies")

    def search(self, query: str) -> dict:
        url = YT + "/buscar?" + urlencode({"q": query})
        return {"source": self.name, "query": query,
                "items": self._items(_parse(self.http.request(url), url))}

    def detail(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser = _parse(self.http.request(url), url)
        if not parser.ajax or not parser.csrf:
            raise SourceError("No se encontró la lista de capítulos en la ficha")
        meta = self.http.post_form(parser.ajax, {"_token": parser.csrf}, url)
        total = len(meta.get("eps") or [])
        per_page = int(meta.get("perpage") or 50)
        if per_page < 1 or not meta.get("paginate_url"):
            raise SourceError("Paginación de capítulos inválida")
        episodes = []
        for page in range(1, (total + per_page - 1) // per_page + 1):
            data = self.http.post_form(meta["paginate_url"],
                                       {"_token": parser.csrf, "p": page}, url)
            for item in data.get("caps") or []:
                episode_url = self.http._safe_url(item.get("url") or "")
                episodes.append({"number": item.get("episodio"), "url": episode_url,
                                 "poster": item.get("thumb") or ""})
        return {"source": self.name, "title": parser.title, "url": url,
                "episodes": episodes, "episode_count": len(episodes)}

    def episode(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser = _parse(self.http.request(url), url)
        if not parser.player_key or not parser.players:
            raise SourceError("No se encontraron opciones de reproducción")
        return {"source": self.name, "title": parser.title, "url": url,
                "player_key": parser.player_key, "players": parser.players}

    def embed(self, episode_url: str, option: int = 1) -> dict:
        episode = self.episode(episode_url)
        if not 1 <= option <= len(episode["players"]):
            raise SourceError("Número de opción fuera de rango")
        player = episode["players"][option - 1]
        if not player["uses_api"]:
            target = player["token"]
        else:
            target = episode["player_key"] + player["token"]
            target += "&player=" + quote(player["name"])
        target = self.http._safe_url(target)
        html = self.http.request(target, headers={"Referer": episode["url"]})
        match = re.search(r'<iframe\b[^>]*\bsrc=["\']([^"\']+)', html, re.I)
        if not match:
            raise SourceError("El reproductor no publicó un iframe")
        embed = urljoin(target, match.group(1))
        if urlparse(embed).scheme not in ("https", "http"):
            raise SourceError("El iframe no contiene una URL válida")
        return {"source": self.name, "server": player["name"], "embed": embed}


class DoramasFlix:
    name = "DoramasFlix"

    def __init__(self):
        self.http = _Client(FLIX)

    @staticmethod
    def _item(item: dict, kind: str = "doramas") -> dict:
        poster = item.get("poster") or item.get("poster_path") or ""
        if poster.startswith("/"):
            poster = "https://image.tmdb.org/t/p/w342" + poster
        return {"title": item.get("name_es") or item.get("name") or "",
                "original_title": item.get("name") or "",
                "url": FLIX + "/" + kind + "/" + item.get("slug", ""), "poster": poster}

    @staticmethod
    def _graphql(field: str, page: int) -> dict:
        if page < 1:
            raise SourceError("La página debe ser mayor que cero")
        if field not in ("paginationDorama", "paginationMovie"):
            raise SourceError("Tipo de catálogo inválido")
        query = ("query Catalog($page:Int,$limit:Int){" + field +
                 "(page:$page,limit:$limit){count pageInfo{pageCount hasNextPage} "
                 "items{_id slug name name_es poster_path poster}}}")
        payload = json.dumps({"query": query, "variables": {"page": page, "limit": 24}}).encode()
        request = Request(FLIX_GRAPHQL, data=payload, headers={
            "User-Agent": USER_AGENT, "Content-Type": "application/json",
            "Origin": FLIX, "Referer": FLIX + "/" +
            ("doramas" if field == "paginationDorama" else "peliculas"),
            "x-brand-host": "doramasflix.io", "x-forwarded-host": "doramasflix.io"})
        try:
            with build_opener().open(request, timeout=20) as response:
                result = json.load(response)
        except (HTTPError, URLError, ValueError) as exc:
            raise SourceError("No se pudo consultar el catálogo GraphQL: %s" % exc) from exc
        data = (result.get("data") or {}).get(field) if isinstance(result, dict) else None
        if not isinstance(data, dict) or "items" not in data:
            raise SourceError("El catálogo GraphQL devolvió un formato inesperado")
        return data

    def catalog(self, page: int = 1) -> dict:
        data = self._graphql("paginationDorama", page)
        info = data.get("pageInfo") or {}
        return {"source": self.name, "page": page, "last_page": info.get("pageCount"),
                "total": data.get("count"), "items": [self._item(x) for x in data["items"]]}

    def movies(self, page: int = 1) -> dict:
        data = self._graphql("paginationMovie", page)
        info = data.get("pageInfo") or {}
        return {"source": self.name, "page": page, "last_page": info.get("pageCount"),
                "total": data.get("count"),
                "items": [self._item(x, "peliculas") for x in data["items"]]}

    def catalog_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay)

    def movies_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay, "movies")

    def search(self, query: str, limit: int = 20) -> dict:
        data = self.http.action(FLIX + "/doramas", FLIX_ACTIONS["search"],
                                {"q": query, "limit": limit})
        items = ((data.get("data") or {}).get("doramas") or []) if isinstance(data, dict) else []
        movies = ((data.get("data") or {}).get("movies") or []) if isinstance(data, dict) else []
        return {"source": self.name, "query": query,
                "items": [self._item(x) for x in items],
                "movies": [self._item(x, "peliculas") for x in movies]}

    def _page_data(self, url: str) -> tuple[_HTML, str]:
        url = self.http._safe_url(url)
        parser = _parse(self.http.request(url), url)
        return parser, _flight(parser)

    def detail(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser, flight = self._page_data(url)
        # The first matching object should contain seasons; other references can
        # contain only the numeric ID, so search for that explicit shape.
        match = re.search(r'\{"serie_id":"([0-9a-f]{24})","seasons":', flight)
        if not match:
            raise SourceError("No se encontraron las temporadas en la ficha")
        series_id = match.group(1)
        season_data = _json_after(flight[match.start():], "")
        seasons = season_data.get("seasons") or [] if isinstance(season_data, dict) else []
        episodes = []
        for season in seasons:
            number = int(season["season_number"])
            page = 1
            while True:
                data = self.http.action(url, FLIX_ACTIONS["episodes"],
                                        {"serie_id": series_id, "season_number": number,
                                         "page": page, "limit": 100,
                                         "brandHost": "doramasflix.io"})
                if not isinstance(data, dict):
                    raise SourceError("La temporada devolvió un formato inesperado")
                for item in data.get("items") or []:
                    still = item.get("still_path") or item.get("backdrop") or ""
                    if still.startswith("/"):
                        still = "https://image.tmdb.org/t/p/w300" + still
                    episodes.append({
                        "season": number,
                        "number": item.get("episode_number"),
                        "title": item.get("name_es") or item.get("name") or "",
                        "url": FLIX + "/capitulos/" + item.get("slug", ""),
                        "poster": still,
                        "plot": item.get("overview") or "",
                        "year": content_metadata.fields(item)["year"],
                    })
                if not (data.get("pageInfo") or {}).get("hasNextPage"):
                    break
                page += 1
        episodes.sort(key=lambda item: (item["season"], item["number"] or 0))
        return {"source": self.name, "title": parser.title, "url": url,
                "series_id": series_id, "seasons": seasons, "episodes": episodes,
                "episode_count": len(episodes)}

    def episode(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser, flight = self._page_data(url)
        match = re.search(r'\{"episode":\{"_id":"([0-9a-f]{24})"', flight)
        if not match:
            raise SourceError("No se encontró el ID del episodio")
        episode_id = match.group(1)
        links = self.http.action(url, FLIX_ACTIONS["links"], {"episode_id": episode_id})
        if not isinstance(links, list):
            raise SourceError("Los servidores devolvieron un formato inesperado")
        players = self._players(links, flight)
        return {"source": self.name, "title": parser.title, "url": url,
                "episode_id": episode_id, "players": players}

    @staticmethod
    def _players(links: list, flight: str) -> list[dict]:
        servers = _json_after(flight, '"listServers":') or []
        server_names = {str(x.get("code_flix")): x.get("name") for x in servers
                        if isinstance(x, dict)}
        languages = _json_after(flight, '"langs":') or []
        language_names = {str(x.get("code_flix")): x.get("name") for x in languages
                          if isinstance(x, dict)}
        return [{"server": server_names.get(str(x.get("server")), str(x.get("server"))),
                 "language": language_names.get(str(x.get("lang")), x.get("lang")), "embed": x.get("link"),
                 "recommended": bool(x.get("is_recommended"))}
                for x in links if isinstance(x, dict) and
                urlparse(str(x.get("link") or "")).scheme in ("http", "https")]

    def movie(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser, flight = self._page_data(url)
        match = re.search(r'\{"movie":\{"_id":"([0-9a-f]{24})"', flight)
        if not match:
            raise SourceError("No se encontró el ID de la película")
        movie_id = match.group(1)
        links = self.http.action(url, FLIX_ACTIONS["movie_links"], {"movie_id": movie_id})
        if not isinstance(links, list):
            raise SourceError("Los servidores devolvieron un formato inesperado")
        return {"source": self.name, "title": parser.title, "url": url,
                "movie_id": movie_id, "players": self._players(links, flight)}

    def movie_embed(self, movie_url: str, option: int = 1) -> dict:
        movie = self.movie(movie_url)
        if not 1 <= option <= len(movie["players"]):
            raise SourceError("Número de opción fuera de rango")
        return {"source": self.name, **movie["players"][option - 1]}

    def embed(self, episode_url: str, option: int = 1) -> dict:
        episode = self.episode(episode_url)
        if not 1 <= option <= len(episode["players"]):
            raise SourceError("Número de opción fuera de rango")
        return {"source": self.name, **episode["players"][option - 1]}


def _catalog_all(source, max_pages: int, delay: float, method: str = "catalog") -> dict:
    if max_pages < 1:
        raise SourceError("max_pages debe ser mayor que cero")
    found = {}
    last_page = None
    scanned = 0
    for page in range(1, max_pages + 1):
        result = getattr(source, method)(page)
        scanned += 1
        last_page = result.get("last_page") or last_page
        if not result["items"]:
            break
        for item in result["items"]:
            found.setdefault(item["url"], item)
        if last_page is not None and page >= last_page:
            break
        if page < max_pages:
            time.sleep(max(0, delay))
    return {"source": source.name, "items": list(found.values()), "count": len(found),
            "pages_scanned": scanned, "last_page": last_page,
            "complete": last_page is not None and scanned >= last_page}




"""Adaptadores de DoramasYT y DoramasFlix para el catalogo de Kodi."""
import base64
import json
import random
from urllib.parse import urlsplit, urlencode, parse_qs
from concurrent.futures import ThreadPoolExecutor


def is_dorama(item):
    host = urlsplit(item.get('url', '')).hostname
    return host in ('www.doramasyt.com', 'doramasyt.com', 'doramasflix.io')


def client(url):
    return DoramasFlix() if urlsplit(url).hostname == 'doramasflix.io' else DoramasYT()


def convert(item, movie=False):
    return dict(title=item['title'], url=item['url'], cover=item.get('poster', ''),
                is_serie=not movie, section='doramas', plot=item.get('plot', ''),
                year=item.get('year', ''), genres=item.get('genres', []),
                media_type='movie' if movie else '')


def parallel(calls):
    def safe(call):
        try:
            return call()
        except Exception as exc:
            import servidores as s
            s.log_resolver('Doramas: ' + str(exc))
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(safe, calls))


def menu():
    source = DoramasYT()
    url = source.http.base + '/doramas'
    parser = _parse(source.http.request(url), url)
    items = source._items(parser)
    covers = [x['poster'] for x in items if x.get('poster')]
    cover = covers[0] if covers else ''
    genres = {}
    for link in parser.links:
        parsed = urlsplit(link['url'])
        if parsed.hostname == urlsplit(url).hostname and parsed.path.startswith('/genero/'):
            slug = parsed.path[len('/genero/'):]
            if slug and '/' not in slug:
                genres[slug] = {'nom': link['title'].strip(), 'posters': []}
    slugs = list(genres)
    def posters(slug):
        result = DoramasYT()._catalog(1, '/genero/' + slug)
        return list(dict.fromkeys(x['poster'] for x in result['items'] if x.get('poster')))
    for slug, pool in zip(slugs, parallel([lambda slug=slug: posters(slug) for slug in slugs])):
        genres[slug]['posters'] = pool or []
    return {'cover': cover, 'covers': covers, 'genres': genres}


def category_covers(menu, excluded=()):
    pools = {'todo': menu.get('covers', [])}
    pools.update({key: data['posters'] for key, data in menu.get('genres', {}).items()})
    candidates = {key: list(dict.fromkeys(p for p in pool if p not in excluded)) for key, pool in pools.items()}
    for pool in candidates.values():
        random.shuffle(pool)
    owners = {}
    def assign(key, visited):
        for poster in candidates[key]:
            if poster in visited:
                continue
            visited.add(poster)
            if poster not in owners or assign(owners[poster], visited):
                owners[poster] = key
                return True
        return False
    for key in sorted(candidates, key=lambda key: len(candidates[key])):
        assign(key, set())
    return {key: poster for poster, key in owners.items()}


def page(number, genre=None):
    if genre:
        if not all(c.isalnum() or c == '-' for c in genre):
            raise ValueError('Categoria de doramas no valida')
        result = DoramasYT()._catalog(number, '/genero/' + genre)
        items = [convert(i) for i in result['items']]
        return items, bool(items) and number < (result.get('last_page') or number)

    calls = []
    for cls in (DoramasYT, DoramasFlix):
        for method in ('catalog', 'movies'):
            def fetch(cls=cls, method=method):
                result = getattr(cls(), method)(number)
                # YT film entries share the series page/episode flow.
                movie = method == 'movies'
                items = [convert(i, movie) for i in result['items']]
                return items, bool(items) and number < (result.get('last_page') or number)
            calls.append(fetch)
    results = [r for r in parallel(calls) if r]
    return [i for items, _ in results for i in items], any(more for _, more in results)


def search(query):
    results = parallel([lambda cls=cls: cls().search(query) for cls in (DoramasYT, DoramasFlix)])
    return [convert(i, key == 'movies') for result in results if result for key in ('items', 'movies') for i in result.get(key, [])]


def episodes(item):
    result = {}
    for ep in client(item['url']).detail(item['url'])['episodes']:
        season, number = str(ep.get('season') or 1), str(ep.get('number') or '')
        if not number:
            continue
        entry = convert({'title': 'T%s:E%s - %s' % (season, number, ep.get('title') or item['title']),
                         'url': ep['url'], 'poster': ep.get('poster') or item.get('cover', ''),
                         'plot': ep.get('plot') or '', 'year': ep.get('year', ''),
                         'genres': item.get('genres', [])})
        entry.update(season=season, episode=number)
        result.setdefault(season, []).append(entry)
    return result


def unwrap_player(url):
    # The provider returns public embed URLs inside its redirect payload.
    if urlsplit(url).hostname != 'embedshortener.co':
        return url
    try:
        token = urlsplit(url).path.rsplit('/', 1)[-1].split('.')[1]
        payload = json.loads(base64.urlsafe_b64decode(token + '=' * (-len(token) % 4)))
        encoded = payload['link']
        target = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8')
        if urlsplit(target).scheme in ('http', 'https') and urlsplit(target).hostname:
            return target
    except (ValueError, KeyError, IndexError, TypeError):
        pass
    return url


def servers(item, experimental=False):
    source = client(item['url'])
    player_url = item['url']
    if isinstance(source, DoramasYT) and '/dorama/' in player_url:
        entries = source.detail(player_url)['episodes']
        if len(entries) != 1:
            raise SourceError('La ficha no contiene un unico video de pelicula')
        player_url = entries[0]['url']
    movie = isinstance(source, DoramasFlix) and '/peliculas/' in item['url']
    data = source.movie(player_url) if movie else source.episode(player_url)
    found = []
    for index, option in enumerate(data['players'], 1):
        name = option.get('server') or option.get('name') or 'Servidor'
        language = option.get('language') or ('Latino' if 'latino' in item['url'].lower() else '')
        label = name + (' | ' + str(language) if language else '')
        url = unwrap_player(option.get('embed') or '')
        if not url:
            url = 'dorama://player?' + urlencode({'url': player_url, 'option': index})
        # Only the known primary player is equivalent to SoloLatino Premium.
        premium = urlsplit(url).hostname == 'player.pelisserieshoy.com'
        found.append({'nombre': label, 'url': url, 'premium': premium, 'language': language})
    premium = [x for x in found if x['premium']]
    return premium if premium and not experimental else found


def resolve(url):
    params = parse_qs(urlsplit(url).query)
    page = params['url'][0]
    if not is_dorama({'url': page}):
        raise SourceError('Fuente de doramas no valida')
    return client(page).embed(page, int(params['option'][0]))['embed']


def metadata(item):
    url = item['url']
    page = client(url).http.request(url)
    episode = bool(item.get('episode')) or '/ver/' in url or '/capitulos/' in url
    result = content_metadata.from_page(page, episode=episode)
    if not episode:
        parser = content_metadata.StructuredParser()
        parser.feed(page)
        for node in parser.documents:
            if not isinstance(node, dict) or node.get('@type') not in ('Movie', 'TVSeries'):
                continue
            movie = node.get('@type') == 'Movie' or any(
                g.lower() in ('pelicula', 'película', 'movie')
                for g in content_metadata.genres(node.get('genre', [])))
            result.update(is_serie=not movie, media_type='movie' if movie else 'series')
            break
    return result
