# -*- coding: utf-8 -*-
import sys, os, time, json, re, hashlib, threading, random, ssl
import urllib.parse, urllib.request, base64
import xbmc, xbmcgui, xbmcaddon, xbmcvfs, xbmcplugin
import servidores
import playback
import watch_history
import stream_metadata
import catalog
import doramas
import queue

def limpiar_texto(value):
    text = servidores.limpiar_texto(value)
    return re.sub(r'(?i)\b(?:fuegocine|fuegolatino|hackstore2?|pelisjuanita|sololatino)\b(?:\.[a-z]+)?', '', text).strip()
fetch_html = servidores.fetch_html
resolver_enlace_directo = servidores.resolver_enlace_directo
_ssl_ctx = servidores._ssl_ctx
UA = servidores.UA
SITE_URL = servidores.SOLOLATINO_BASE

for path_req in ['script.module.six/lib', 'script.module.kodi-six/libs', 'script.module.resolveurl/lib']:
    p = xbmcvfs.translatePath(f'special://home/addons/{path_req}')
    if p and xbmcvfs.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

try:
    import resolveurl
except Exception:
    resolveurl = None

# servidores se importa antes de configurar las rutas de modulos de Kodi.
servidores.resolveurl = resolveurl

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_FILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/userdata.json')
SEARCH_CACHE_FILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/search_cache.json')
SEARCH_CACHE_TTL = 6 * 3600  # Las busquedas guardadas caducan para que aparezca contenido nuevo.
CATEGORIES_FILE = os.path.join(ADDON_PATH, 'resources', 'categories.json')

def cargar_userdata():
    if xbmcvfs.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except Exception: pass
    bak = DATA_FILE + '.bak'
    if xbmcvfs.exists(bak):
        try:
            with open(bak, 'r', encoding='utf-8') as f: return json.load(f)
        except Exception: pass
    return {'favoritos': [], 'historial': {}}

def guardar_userdata(data):
    dir_p = os.path.dirname(DATA_FILE)
    if not xbmcvfs.exists(dir_p): xbmcvfs.mkdirs(dir_p)
    tmp = DATA_FILE + '.tmp'
    bak = DATA_FILE + '.bak'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        if xbmcvfs.exists(DATA_FILE):
            try:
                if xbmcvfs.exists(bak): os.remove(bak)
                os.replace(DATA_FILE, bak)
            except Exception: pass
        os.replace(tmp, DATA_FILE)
    except Exception:
        try:
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception: pass

def cargar_search_cache():
    if xbmcvfs.exists(SEARCH_CACHE_FILE):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {'queries': {}, 'items': {}}

def guardar_search_cache(cache):
    dir_p = os.path.dirname(SEARCH_CACHE_FILE)
    if not xbmcvfs.exists(dir_p): xbmcvfs.mkdirs(dir_p)
    tmp = SEARCH_CACHE_FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False)
        os.replace(tmp, SEARCH_CACHE_FILE)
    except Exception: pass

def cargar_catalogo_categorias():
    if xbmcvfs.exists(CATEGORIES_FILE):
        try:
            with open(CATEGORIES_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except Exception: pass
    return {'peliculas': {}, 'series': {}}

CATALOGO_GENEROS = cargar_catalogo_categorias()
NOMBRES_SECCIONES = {
    'peliculas': 'PELÍCULAS',
    'series': 'SERIES',
    'doramas': 'DORAMAS',
    'busqueda': 'BÚSQUEDA'
}

def configurar_item_video(item, titulo, thumb="", plot="", year="", rating="", is_dorama=False, is_episode=False, genres=None):
    tit_clean = limpiar_texto(titulo)
    plot_clean = limpiar_texto(plot)
    y_clean = limpiar_texto(year)
    r_clean = limpiar_texto(rating)

    if not thumb:
        thumb = os.path.join(ADDON_PATH, 'cara_dora_bk.jpg') if is_dorama else os.path.join(ADDON_PATH, 'cara_bk.jpg')

    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(tit_clean)
        if genres: tag.setGenres(genres)
        if plot_clean: tag.setPlot(plot_clean)
        if str(y_clean).isdigit(): tag.setYear(int(y_clean))
        if r_clean:
            try: tag.setRating(float(str(r_clean).replace('★', '').strip()))
            except: pass
    except Exception:
        info = {'title': tit_clean}
        if genres: info['genre'] = genres
        if plot_clean: info['plot'] = plot_clean
        if str(y_clean).isdigit(): info['year'] = int(y_clean)
        item.setInfo('video', info)
        
    if thumb:
        item.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    if genres: item.setProperty('genre', ' / '.join(genres))
    if y_clean: item.setProperty('year', str(y_clean))
    if r_clean: item.setProperty('rating', str(r_clean))
    if is_episode or (re.match(r'^T\d+:E\d+', tit_clean) and any(x in str(thumb).lower() for x in ['/episodio-', '/backdrop-', '/w300/', 'still'])):
        item.setProperty('is_episode', 'true')

class VaquexflixPlayer(xbmc.Player):
    def __init__(self, ui=None, session=0):
        super().__init__()
        self.ui = ui
        self.session = session

    def _event(self, event):
        if self.ui and self.ui.activa:
            self.ui._eventos_player.put((self.session, event))

    def onAVStarted(self):
        self._event('started')

    def onPlayBackEnded(self):
        self._event('ended')

    def onPlayBackStopped(self):
        self._event('stopped')

    def onPlayBackError(self):
        self._event('error')

class MetadataProgress(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.omitted = False
        self.canceled = False

    def onInit(self):
        self.setFocusId(501)

    def onClick(self, controlId):
        if controlId == 501:
            self.omitted = True
            self.close()
        elif controlId == 502:
            self.canceled = True
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.canceled = True
            self.close()

    def update(self, done, total):
        if not self.omitted and not self.canceled:
            try:
                self.getControl(503).setLabel('Consultando resolución e idiomas: {}/{}'.format(done, total))
            except RuntimeError:
                pass  # La ventana puede estar terminando de abrirse o cerrarse.


class FAQDialog(xbmcgui.WindowXMLDialog):
    def onClick(self, controlId):
        self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in (9, 10, 92, 7, 100, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_SELECT_ITEM):
            self.close()


class VaquexflixUI(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.seccion_actual = "peliculas"
        self.estado = "categorias"
        self.categoria_actual_url = ""
        self.items_actuales = []
        self.items_originales = []
        self.serie_actual = {}
        self.episodios_actuales = []
        self.episodio_index_actual = -1
        self.temporadas_disponibles = []
        self.episodios_por_temporada = {}
        
        self.pagina_actual = 1
        self.hay_mas_paginas = True
        self.cargando_mas = False
        self.vistos_urls = set()
        self.cache_sinopsis = {}
        self.pos_anterior = -1
        self.activa = True
        self.reproduciendo_video = False
        self.en_dialogo_salida = False
        self._en_fullscreen = False
        self.session_reproduccion_activa = 0
        
        self._inicializado = False
        self._last_x_time = 0.0
        self._x_timer = None
        self._eventos_player = queue.Queue()
        self._playback_context = None
        self._closing_session = None
        self._pending_stream = None
        self._metadata_scanner = None
        self.experimental = ADDON.getSetting('experimental') == 'true'
        self._catalog_generation = 0
        self._av_started = False
        self._last_play_time = 0
        self._last_history_save = 0
        self._start_deadline = 0
        self.player = VaquexflixPlayer(self)

    def _set_prop(self, key, value):
        try:
            if hasattr(self, 'setProperty'):
                self.setProperty(key, value)
        except Exception:
            pass

    def onInit(self):
        self._set_prop('fanart_image', os.path.join(ADDON_PATH, 'fanart.jpg'))
        self._set_prop('experimental_enabled', 'true' if self.experimental else 'false')
        self._set_prop('seccion_actual', self.seccion_actual)
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self.getControl(204).setSelected(self.experimental)
        self._actualizar_navegacion_lateral()
        try:
            self.getControl(500).setVisible(True)
        except Exception:
            pass
        if not self._inicializado:
            self._inicializado = True
            xbmc.sleep(100)
            self.actualizar_pie_de_pagina()
            pendiente = getattr(self, 'busqueda_pendiente', None)
            if pendiente:
                self.seccion_actual = "busqueda"
                self._set_prop('seccion_actual', "busqueda")
                self.actualizar_etiqueta(f"BÚSQUEDA: {limpiar_texto(pendiente).upper()}")
                self.cargar_elementos(f"search://{urllib.parse.quote_plus(pendiente)}", reset=True)
            else:
                self.cargar_categorias("peliculas")
            threading.Thread(target=self._monitor_scroll_y_foco, daemon=True).start()
            self.comprobar_actualizacion_en_segundo_plano()
        else:
            self.actualizar_pie_de_pagina()
            lista_ctrl = self.getControl(150 if self.estado == "episodios" else 100)
            if lista_ctrl and self.pos_anterior >= 0:
                try: lista_ctrl.selectItem(self.pos_anterior)
                except Exception: pass

    def _actualizar_navegacion_lateral(self):
        try:
            ctrl_faq = self.getControl(206)
        except Exception:
            ctrl_faq = None
        target_down = self.getControl(205) if self.experimental else (ctrl_faq or self.getControl(204))
        self.getControl(203).controlDown(target_down)
        if ctrl_faq:
            ctrl_faq.controlUp(self.getControl(205 if self.experimental else 203))
            ctrl_faq.controlDown(self.getControl(204))
            self.getControl(204).controlUp(ctrl_faq)
        else:
            self.getControl(204).controlUp(self.getControl(205 if self.experimental else 203))

        target_container = self.getControl(150) if self.estado == "episodios" else self.getControl(100)
        for cid in (201, 202, 203, 204, 205, 206):
            try:
                self.getControl(cid).controlRight(target_container)
            except Exception:
                pass

    def comprobar_actualizacion_en_segundo_plano(self):
        def _worker():
            try:
                xbmc.sleep(3500)
                url_ver = "https://fmono90.github.io/vaquexflix-addon/version.json"
                req = urllib.request.Request(url_ver, headers={'User-Agent': UA})
                with urllib.request.urlopen(req, timeout=6, context=_ssl_ctx) as r:
                    info = json.loads(r.read().decode('utf-8'))
                
                ver_remota = info.get('version', '')
                ver_local = ADDON.getAddonInfo('version')
                
                def _tupla_v(v):
                    return [int(x) if x.isdigit() else 0 for x in re.findall(r'\d+', str(v))]
                
                if ver_remota and _tupla_v(ver_remota) > _tupla_v(ver_local):
                    diag = xbmcgui.Dialog()
                    resp = diag.yesno(
                        "Vaquexflix",
                        f"Hay una actualizacion disponible: v{ver_remota} (actual: v{ver_local}).\n¿Deseas actualizar ahora?",
                        yeslabel="Actualizar",
                        nolabel="Despues"
                    )
                    if resp:
                        zip_url = info.get('zip_url', '')
                        if zip_url:
                            self._instalar_actualizacion_zip(zip_url, ver_remota)
            except Exception:
                pass

        threading.Thread(target=_worker, daemon=True).start()

    def _instalar_actualizacion_zip(self, zip_url, nueva_version):
        prog = xbmcgui.DialogProgress()
        prog.create("Vaquexflix", "Descargando actualizacion...")
        try:
            dest_zip = xbmcvfs.translatePath('special://temp/vaquexflix_update.zip')
            req = urllib.request.Request(zip_url, headers={'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx) as r, open(dest_zip, 'wb') as f:
                tam_total = int(r.headers.get('Content-Length', 0))
                leido = 0
                while True:
                    chunk = r.read(65536)
                    if not chunk: break
                    f.write(chunk)
                    leido += len(chunk)
                    if tam_total > 0:
                        pct = int((leido / tam_total) * 100)
                        prog.update(pct, f"Descargando v{nueva_version}... ({pct}%)")
            
            prog.update(100, "Instalando actualizacion...")
            addons_dir = xbmcvfs.translatePath('special://home/addons/')
            import zipfile
            with zipfile.ZipFile(dest_zip, 'r') as z:
                z.extractall(addons_dir)
            
            try: os.remove(dest_zip)
            except Exception: pass
            
            prog.close()
            try: xbmc.executebuiltin('UpdateLocalAddons')
            except Exception: pass
            xbmcgui.Dialog().ok("Vaquexflix", f"¡Actualizado con éxito a v{nueva_version}!\nEl complemento se cerrará para cargar la nueva versión.")
            self.activa = False
            self.close()
        except Exception:
            prog.close()
            xbmcgui.Dialog().notification("Vaquexflix", "Error al descargar actualizacion", xbmcgui.NOTIFICATION_ERROR, 2000)

    def _pausar_para_dialogo(self):
        was_paused = xbmc.getCondVisibility('Player.Paused')
        if self.player.isPlayingVideo() and not was_paused:
            xbmc.executebuiltin('PlayerControl(Play)', False)
            return True
        return False

    def _mostrar_dialogo_control_reproductor(self, detenido=False):
        if self.en_dialogo_salida or not self.activa or not self._playback_context:
            return
        self.en_dialogo_salida = True
        session = self.session_reproduccion_activa
        paused_here = False
        action = 'continuar'
        try:
            if not detenido:
                paused_here = self._pausar_para_dialogo()
            diag = xbmcgui.Dialog()
            idx = self.episodio_index_actual
            if 0 <= idx < len(self.episodios_actuales):
                opciones = ['Continuar viendo']
                acciones = ['continuar']
                if idx + 1 < len(self.episodios_actuales):
                    opciones.append('Siguiente capítulo: ' + self.episodios_actuales[idx + 1]['title'])
                    acciones.append('siguiente')
                if idx > 0:
                    opciones.append('Capítulo anterior: ' + self.episodios_actuales[idx - 1]['title'])
                    acciones.append('anterior')
                opciones.append('Salir del reproductor')
                acciones.append('salir')
                sel = diag.select('Vaquexflix - ' + self.episodios_actuales[idx]['title'], opciones)
                if 0 <= sel < len(acciones):
                    action = acciones[sel]
            elif diag.yesno('Vaquexflix', '¿Deseas salir del reproductor de video?',
                            yeslabel='Salir', nolabel='Continuar'):
                action = 'salir'
            if not self.activa or session != self.session_reproduccion_activa:
                return
            if action == 'salir':
                self.detener_reproduccion()
            elif action in ('siguiente', 'anterior'):
                target = idx + (1 if action == 'siguiente' else -1)
                self.detener_reproduccion()
                self.reproducir_episodio_por_indice(target)
            elif detenido:
                self._iniciar_stream(self._playback_context, self._last_play_time)
            else:
                if paused_here and xbmc.getCondVisibility('Player.Paused'):
                    xbmc.executebuiltin('PlayerControl(Play)', False)
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                self._en_fullscreen = False
        finally:
            self.en_dialogo_salida = False

    def procesar_eventos_player(self):
        """Un solo consumidor para callbacks, dialogos y progreso de reproduccion."""
        while not self._eventos_player.empty():
            session, event = self._eventos_player.get_nowait()
            if session == self._closing_session and event in ('stopped', 'ended', 'error'):
                xbmc.log('Vaquexflix: cierre confirmado de sesion {}'.format(session), xbmc.LOGINFO)
                self._closing_session = None
                pending, self._pending_stream = self._pending_stream, None
                if pending:
                    self._iniciar_stream(*pending)
                continue
            if session != self.session_reproduccion_activa or not self.reproduciendo_video:
                continue
            if event == 'started':
                self._av_started = True
                self._start_deadline = 0
            elif event == 'error' or (event in ('ended', 'stopped') and not self._av_started):
                self.reproduciendo_video = False
                self.detener_reproduccion()
                xbmcgui.Dialog().notification('Vaquexflix', 'El servidor no pudo iniciar el video. Elige otro servidor.', xbmcgui.NOTIFICATION_ERROR)
            elif event == 'stopped':
                self.reproduciendo_video = False
                self._en_fullscreen = False
                self._guardar_progreso()
                self._mostrar_dialogo_control_reproductor(detenido=True)
            elif event == 'ended':
                self.reproduciendo_video = False
                self._en_fullscreen = False
                self._guardar_progreso(finalizado=True)
                self.on_playback_ended()
        if not self.reproduciendo_video or self.en_dialogo_salida:
            return
        if not self._av_started:
            # El selector de calidad de ISA precede a onAVStarted. El tiempo
            # que el usuario dedica a elegir no es una espera del servidor.
            if self._playback_context.get('ask_quality') and xbmc.getCondVisibility('System.HasModalDialog'):
                self._start_deadline = time.monotonic() + 45
                return
            if self._start_deadline and time.monotonic() > self._start_deadline:
                self.detener_reproduccion()
                xbmcgui.Dialog().notification('Vaquexflix', 'El servidor no entrego el video a tiempo. Prueba otro servidor.', xbmcgui.NOTIFICATION_ERROR, 6000)
            return
        if self.player.isPlayingVideo():
            try:
                self._last_play_time = self.player.getTime()
                self._playback_context['total'] = self.player.getTotalTime()
                if self._playback_context.get('server_key') and not self._playback_context.get('quality_saved'):
                    resolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
                    if resolution.isdigit():
                        data = cargar_userdata()
                        data.setdefault('server_quality', {}).setdefault(self._playback_context['server_key'], {}).update({
                            'label': self._playback_context.get('quality') or resolution + 'p', 'updated': time.time()})
                        guardar_userdata(data)
                        self._playback_context['quality_saved'] = True
                if time.monotonic() - self._last_history_save >= 5:
                    self._guardar_progreso()
            except RuntimeError:
                pass
            is_fs = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            is_osd = xbmc.getCondVisibility('Window.IsActive(videoosd)')
            if is_fs or is_osd:
                self._en_fullscreen = True
            elif self._en_fullscreen and not xbmc.getCondVisibility('System.HasModalDialog'):
                self._en_fullscreen = False
                self._mostrar_dialogo_control_reproductor()

    def _guardar_progreso(self, finalizado=False):
        ctx = self._playback_context
        if not ctx:
            return
        data = cargar_userdata()
        history = data.setdefault('historial', {})
        for alias in ctx.get('history_aliases', []):
            if alias != ctx['url_norm']:
                history.pop(alias, None)
        if finalizado:
            history[ctx['url_norm']] = dict(ctx['history'], time=0, total=int(ctx.get('total', 0)), completed=True, updated=time.time())
        else:
            history[ctx['url_norm']] = dict(ctx['history'], time=int(self._last_play_time), total=int(ctx.get('total', 0)), updated=time.time())
        guardar_userdata(data)
        self._last_history_save = time.monotonic()

    def _iniciar_stream(self, context, offset=0):
        if self._closing_session is not None:
            self._pending_stream = (context, offset)
            xbmcgui.Dialog().notification('Vaquexflix', 'Esperando el cierre del video anterior...', xbmcgui.NOTIFICATION_INFO)
            return
        if self.reproduciendo_video:
            self.detener_reproduccion()
            if self._closing_session is not None:
                self._pending_stream = (context, offset)
                return
        self.session_reproduccion_activa += 1
        self._playback_context = context
        self._last_play_time = offset
        self._av_started = False
        self._en_fullscreen = False
        self.reproduciendo_video = True
        self._start_deadline = time.monotonic() + 45
        self.player = VaquexflixPlayer(self, self.session_reproduccion_activa)
        item = xbmcgui.ListItem(label=context['history']['title'])
        is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama({'url': context.get('url_norm', '')})
        configurar_item_video(item, context['history']['title'], thumb=context['history']['cover'], plot=context['history']['plot'], is_dorama=is_dora)
        item.setProperty('IsPlayable', 'true')
        if offset > 0:
            item.setProperty('StartOffset', str(offset))
        try:
            major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        except (ValueError, IndexError):
            major = 20
        adaptive = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
        ask_quality = ADDON.getSetting('hls_quality') == '1'
        context['ask_quality'] = ask_quality and adaptive and major >= 20
        stream = playback.configure_stream(item, context['stream'], UA, adaptive, major, ask_quality)
        self._guardar_progreso()
        self.player.play(stream, item)

    def _monitor_scroll_y_foco(self):
        while self.activa and not xbmc.Monitor().abortRequested():
            try:
                lista_ctrl = self.getControl(150 if self.estado == "episodios" else 100)
                if lista_ctrl:
                    pos = lista_ctrl.getSelectedPosition()
                    tot = lista_ctrl.size()

                    # 2. Deteccion de cambio de foco para actualizar sinopsis real en ID 303
                    if pos != self.pos_anterior and 0 <= pos < len(self.items_actuales):
                        self.pos_anterior = pos
                        sel = self.items_actuales[pos]
                        self._actualizar_sinopsis_de_elemento(sel)

                    # 3. Scroll infinito continuo
                    if self.estado == "elementos" and self.hay_mas_paginas and not self.cargando_mas:
                        if not self.categoria_actual_url.startswith("local://") and not self.categoria_actual_url.startswith("search://"):
                            if tot > 0 and pos >= (tot - 18):
                                self.cargar_siguiente_pagina()
            except Exception: pass
            xbmc.sleep(250)

    def _actualizar_sinopsis_de_elemento(self, sel):
        def display():
            parts = []
            if sel.get('rating'): parts.append('Rating: ' + str(sel['rating']))
            if sel.get('year'): parts.append('Año: ' + str(sel['year']))
            if sel.get('genres'): parts.append(' / '.join(sel['genres']))
            self.getControl(302).setLabel('  ·  '.join(parts))
            plot = sel.get('plot', '')
            if self.estado == 'episodios':
                progress = watch_history.resume_text(cargar_userdata().get('historial', {}), sel)
                plot += ('[CR][CR]' + progress if progress else '')
            self.actualizar_sinopsis_texto(plot)

        display()
        u = sel.get('url', '')
        if not u or u.startswith(('local://', 'unified://')):
            return
        if not hasattr(self, '_content_metadata_cache'):
            self._content_metadata_cache = {}
        generation = self._catalog_generation
        def selected_control():
            control = self.getControl(150 if self.estado == 'episodios' else 100)
            position = control.getSelectedPosition() if control else -1
            if (self.activa and generation == self._catalog_generation and
                    0 <= position < len(self.items_actuales) and self.items_actuales[position].get('url') == u):
                return control, position
            return None, -1

        def apply(info):
            sel.update({k: v for k, v in info.items() if v or k == 'is_serie'})
            control, position = selected_control()
            if control:
                item = control.getListItem(position)
                configurar_item_video(item, sel['title'], thumb=sel.get('cover', ''), plot=sel.get('plot', ''),
                    year=sel.get('year', ''), rating=sel.get('rating', ''), genres=sel.get('genres', []),
                    is_episode=self.estado == 'episodios', is_dorama=doramas.is_dorama(sel))
                display()

        if u in self._content_metadata_cache:
            apply(self._content_metadata_cache[u])
            return
        def fetch_metadata():
            # Avoid requests for cards crossed rapidly while navigating.
            xbmc.sleep(250)
            if not selected_control()[0]:
                return
            try:
                info = catalog.metadata(sel)
                if len(self._content_metadata_cache) >= 128:
                    self._content_metadata_cache.pop(next(iter(self._content_metadata_cache)))
                self._content_metadata_cache[u] = info
                apply(info)
            except Exception as exc:
                xbmc.log('Vaquexflix: metadatos: ' + type(exc).__name__, xbmc.LOGWARNING)
        threading.Thread(target=fetch_metadata, daemon=True).start()

    def actualizar_etiqueta(self, texto):
        self._titulo_actual = texto
        try: self.getControl(400).setLabel(f"[B]{limpiar_texto(texto)}[/B]")
        except Exception: pass

    def actualizar_sinopsis_texto(self, texto):
        try: self.getControl(303).setText(limpiar_texto(texto))
        except Exception: pass

    def cargar_categorias(self, seccion=None):
        self._catalog_generation += 1
        if seccion: self.seccion_actual = seccion
        if self.seccion_actual == 'doramas' and not self.experimental:
            self.seccion_actual = 'peliculas'
        self._set_prop('seccion_actual', self.seccion_actual)
        self.estado = "categorias"
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()
        self.actualizar_etiqueta(NOMBRES_SECCIONES.get(self.seccion_actual, self.seccion_actual.upper()))
        
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        self.items_actuales = []
        ui_items = []

        menu_loader = None
        catalogo_sec = CATALOGO_GENEROS.get(self.seccion_actual, {})
        if self.seccion_actual == 'doramas':
            menu = getattr(self, '_doramas_menu', None)
            catalogo_sec = menu['genres'] if menu else {}
            if menu is None and not getattr(self, '_doramas_menu_loading', False):
                self._doramas_menu_loading = True
                generation = self._catalog_generation
                def load_menu():
                    try:
                        self._doramas_menu = doramas.menu()
                        if self.activa and generation == self._catalog_generation and self.estado == 'categorias':
                            position = lista_ctrl.getSelectedPosition()
                            focus = self.getFocusId()
                            self.cargar_categorias('doramas')
                            lista_ctrl.selectItem(max(0, position))
                            if focus != 100:
                                self.setFocus(self.getControl(focus))
                    except Exception as exc:
                        xbmc.log('Vaquexflix: categorias Doramas: ' + str(exc), xbmc.LOGWARNING)
                    finally:
                        self._doramas_menu_loading = False
                menu_loader = load_menu
        todos_posters = []
        for g_data in catalogo_sec.values():
            todos_posters.extend(g_data.get('posters', []))

        cover_todo = random.choice(todos_posters) if todos_posters else ""
        if self.seccion_actual == 'doramas':
            menu_covers = (getattr(self, '_doramas_menu', None) or {}).get('covers', [])
            cover_todo = random.choice(menu_covers) if menu_covers else os.path.join(ADDON_PATH, 'resources', 'media', 'icon_dora.png')

        # Favoritos e historial con portadas reales filtrados por seccion actual
        data_u = cargar_userdata()
        is_sec_serie = (self.seccion_actual in ("series", "doramas"))

        recent_hist = watch_history.recent(data_u.get('historial', {}), is_sec_serie)
        if self.seccion_actual == 'doramas':
            recent_hist += watch_history.recent(data_u.get('historial', {}), False)
        recent_hist = catalog.in_section(catalog.visible(recent_hist, self.experimental), self.seccion_actual)
        cover_hist = ""
        if recent_hist:
            first_h = recent_hist[0]
            cover_hist = first_h.get('series', {}).get('cover') or first_h.get('cover', '')

        favs_items = [
            f for f in data_u.get('favoritos', [])
            if f.get('is_serie', any(x in f.get('url', '') for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-'])) == is_sec_serie or self.seccion_actual == 'doramas'
        ]
        favs_items = catalog.in_section(catalog.visible(favs_items, self.experimental), self.seccion_actual)
        cover_fav = favs_items[-1].get('cover', '') if favs_items else ""

        dorama_covers = {}
        if self.seccion_actual == 'doramas' and getattr(self, '_doramas_menu', None):
            dorama_covers = doramas.category_covers(self._doramas_menu, (cover_hist, cover_fav))
            cover_todo = dorama_covers.get('todo', cover_todo)
        tipo_str = "películas" if self.seccion_actual == "peliculas" else self.seccion_actual
        tipo_titulo = NOMBRES_SECCIONES.get(self.seccion_actual, self.seccion_actual.upper())
        self.items_actuales.append({'title': "FAVORITOS", 'url': "local://favoritos", 'cover': cover_fav, 'is_serie': False, 'plot': f"Tus {tipo_str} favoritas guardadas."})
        self.items_actuales.append({'title': "RECIÉN VISTOS", 'url': "local://historial", 'cover': cover_hist, 'is_serie': False, 'plot': f"Reanuda tus {tipo_str} donde las dejaste."})
        self.items_actuales.append({'title': f"TODO ({tipo_titulo})", 'url': f"unified://{self.seccion_actual}", 'cover': cover_todo, 'is_serie': False, 'plot': f"Catálogo completo de {tipo_str}."})

        # Cargar categorias con contenido de generos
        for g_key, g_info in catalogo_sec.items():
            posters_gen = g_info.get('posters', [])
            if not posters_gen: continue
            
            portada_azar = (dorama_covers.get(g_key, '') if self.seccion_actual == 'doramas' else random.choice(posters_gen))
            url_cat = (f"unified://doramas?genre={urllib.parse.quote(g_key)}" if self.seccion_actual == 'doramas'
                       else f"{SITE_URL}/{self.seccion_actual}?genero={g_key}")
            nom_cat = limpiar_texto(g_info.get('nom', g_key.capitalize()))
            self.items_actuales.append({
                'title': nom_cat,
                'url': url_cat,
                'cover': portada_azar,
                'is_serie': False,
                'plot': f"Explora {tipo_str} del género {nom_cat}."
            })

        self.items_originales = list(self.items_actuales)
        for obj in self.items_actuales:
            item = xbmcgui.ListItem(label=obj['title'])
            is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
            configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), is_dorama=is_dora)
            ui_items.append(item)

        lista_ctrl.addItems(ui_items)
        xbmc.sleep(40)
        self.setFocus(lista_ctrl)
        lista_ctrl.selectItem(0)
        self.pos_anterior = 0
        if self.items_actuales:
            self.actualizar_sinopsis_texto(self.items_actuales[0].get('plot', ''))
        if menu_loader:
            threading.Thread(target=menu_loader, daemon=True).start()

    def _parsear_tarjetas(self, html_code):
        return servidores.sololatino_parsear_tarjetas(html_code, self.seccion_actual, self.vistos_urls)

    def _buscar_contenido(self, query, experimental=None, section='all'):
        experimental = self.experimental if experimental is None else experimental
        q_raw = query.strip()
        if not q_raw: return []
        q_norm = limpiar_texto(q_raw).lower()

        cache = cargar_search_cache()
        queries_cache = cache.setdefault('queries', {})
        items_cache = cache.setdefault('items', {})

        cache_key = 'v2:' + section + ':' + ('experimental:' if experimental else 'normal:') + q_norm
        cached = queries_cache.get(cache_key)
        # Formato antiguo (lista sin fecha) se considera caducado.
        if isinstance(cached, dict) and time.time() - cached.get('t', 0) < SEARCH_CACHE_TTL:
            return catalog.merge(catalog.in_section(catalog.visible(cached.get('items', []), experimental), section))

        # Búsqueda unificada en SoloLatino + HackStore2 + PelisJuanita + FuegoCine
        items_encontrados = catalog.search(q_raw, experimental=experimental, section=section)

        # Fallback a caché local si la red falla
        if not items_encontrados and items_cache:
            palabras = [p for p in re.findall(r'\w+', q_norm) if len(p) > 2]
            locales = []
            for u_item, it in items_cache.items():
                tit = (it.get('title') or '').lower()
                if q_norm in tit or any(p in tit for p in palabras):
                    locales.append(it)
            if locales:
                items_encontrados = catalog.in_section(catalog.visible(locales, experimental), section)

        # Almacenar en caché para acceso ultra-rápido posterior
        for it in items_encontrados:
            items_cache[it['url']] = it

        if items_encontrados:
            now = time.time()
            for k in [k for k, v in queries_cache.items() if not isinstance(v, dict) or now - v.get('t', 0) >= SEARCH_CACHE_TTL]:
                del queries_cache[k]
            queries_cache[cache_key] = {'t': now, 'items': items_encontrados}
            guardar_search_cache(cache)

        return items_encontrados

    def _cargar_pagina_unificada(self, number):
        generation = self._catalog_generation
        experimental = self.experimental
        section = self.categoria_actual_url.split('://', 1)[1]
        self.cargando_mas = True
        def load():
            try:
                found, more = catalog.page(section, number, experimental=experimental)
                if not self.activa or generation != self._catalog_generation or self.estado != 'elementos':
                    return
                control = self.getControl(100)
                before = len(self.items_actuales)
                self.items_actuales = catalog.merge(self.items_actuales + found)
                self.items_originales = list(self.items_actuales)
                self.pagina_actual = number
                self.hay_mas_paginas = more
                # Si una fuente repite la ultima pagina, no consultarla sin fin.
                if len(self.items_actuales) == before:
                    self._empty_catalog_pages = getattr(self, '_empty_catalog_pages', 0) + 1
                    if self._empty_catalog_pages >= 3:
                        self.hay_mas_paginas = False
                else:
                    self._empty_catalog_pages = 0
                # Keep the existing entries; Kodi addItems still rebinds its native list.
                ui_items = []
                for obj in self.items_actuales[before:]:
                    item = xbmcgui.ListItem(label=obj['title'])
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora)
                    ui_items.append(item)
                if ui_items:
                    # Both messages are queued in order by Kodi: bind, then restore.
                    # Capture here, after network work, so recent navigation is kept.
                    position = control.getSelectedPosition() if before else -1
                    control.addItems(ui_items)
                    if position >= 0:
                        control.selectItem(position)
                if number == 1 and self.items_actuales:
                    control.selectItem(0)
                    self.pos_anterior = 0
                    self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
                    self.setFocus(control)
                elif number == 1:
                    xbmcgui.Dialog().notification('Vaquexflix', 'No hay contenido disponible', xbmcgui.NOTIFICATION_WARNING)
            except Exception as exc:
                xbmc.log('Vaquexflix: catalogo unificado ({})'.format(type(exc).__name__), xbmc.LOGWARNING)
            finally:
                if generation == self._catalog_generation:
                    self.cargando_mas = False
        threading.Thread(target=load, daemon=True).start()

    def cargar_elementos(self, url_target, reset=True):
        self.estado = "elementos"
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return

        if reset:
            self._catalog_generation += 1
            lista_ctrl.reset()
            self.items_actuales = []
            self.items_originales = []
            self.vistos_urls.clear()
            self.pagina_actual = 1
            self._empty_catalog_pages = 0
            self.hay_mas_paginas = True
            self.cargando_mas = False
            self.pos_anterior = -1
            self.categoria_actual_url = url_target

        if url_target.startswith('unified://'):
            self._cargar_pagina_unificada(1)
            return

        if url_target.startswith("local://"):
            data = cargar_userdata()
            is_sec_serie = (self.seccion_actual in ("series", "doramas"))
            tipo_str = self.seccion_actual
            elementos = []
            if "favoritos" in url_target:
                for f in data.get('favoritos', []):
                    u_f = f.get('url', '')
                    f_is_serie = f.get('is_serie', any(x in u_f for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))
                    if f_is_serie == is_sec_serie or self.seccion_actual == 'doramas':
                        elementos.append(f)
            elif "historial" in url_target:
                elementos = watch_history.recent(data.get('historial', {}), is_sec_serie)
                if self.seccion_actual == 'doramas':
                    elementos += watch_history.recent(data.get('historial', {}), False)

            elementos = catalog.in_section(catalog.visible(elementos, self.experimental), self.seccion_actual)
            if not elementos:
                elementos = [{
                    'title': "Ninguno",
                    'url': "",
                    'cover': "",
                    'is_serie': is_sec_serie,
                    'plot': f"No tienes {tipo_str} en esta seccion todavia."
                }]

            self.items_actuales = elementos
            self.items_originales = list(elementos)
            self.hay_mas_paginas = False
            ui_items = []
            for f in elementos:
                label_txt = f['title']
                if "historial" in url_target and not f.get('is_serie') and f['title'] != "Ninguno":
                    h_entry = data.get('historial', {}).get(f.get('url', ''), {})
                    t_sec = h_entry.get('time', 0)
                    if t_sec > 0:
                        m, s = divmod(t_sec, 60)
                        label_txt = f"{f['title']} ({m:02d}:{s:02d})"
                item = xbmcgui.ListItem(label=label_txt)
                is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(f)
                f_cover = f.get('series', {}).get('cover') or f.get('cover', '')
                configurar_item_video(item, label_txt, thumb=f_cover, plot=f.get('plot', ''), is_dorama=is_dora)
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            if reset and ui_items:
                xbmc.sleep(40)
                try: self.setFocus(lista_ctrl)
                except Exception: pass
                lista_ctrl.selectItem(0)
                self.pos_anterior = 0
                self.actualizar_sinopsis_texto(elementos[0].get('plot', ''))
            return

        if url_target.startswith("search://") or "/buscar" in url_target or "/api/search/suggest" in url_target:
            query = ''
            section = 'all'
            if url_target.startswith("search://"):
                query = urllib.parse.unquote_plus(url_target.replace('search://', '').split('?', 1)[0])
                section = urllib.parse.parse_qs(urllib.parse.urlsplit(url_target).query).get('section', ['all'])[0]
            elif "q=" in url_target:
                query = urllib.parse.parse_qs(urllib.parse.urlparse(url_target).query).get('q', [''])[0]

            self.seccion_actual = section if section != 'all' else "busqueda"
            self.actualizar_etiqueta(f"BÚSQUEDA: {limpiar_texto(query).upper()}")
            self.hay_mas_paginas = False

            generation = self._catalog_generation
            experimental = self.experimental
            def _hilo_busqueda():
                self.cargando_mas = True
                xbmcgui.Dialog().notification("Vaquexflix", "Buscando contenido...", xbmcgui.NOTIFICATION_INFO, 1200)
                nuevos = self._buscar_contenido(query, experimental, section)
                if not self.activa or generation != self._catalog_generation:
                    return
                self.items_actuales = nuevos
                self.items_originales = list(nuevos)

                ui_items = []
                for obj in nuevos:
                    label = obj['title'] + (' [Dorama]' if section == 'all' and doramas.is_dorama(obj) else '')
                    item = xbmcgui.ListItem(label=label)
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora)
                    ui_items.append(item)

                lista_ctrl.addItems(ui_items)
                if reset and ui_items:
                    xbmc.sleep(40)
                    try: self.setFocus(lista_ctrl)
                    except Exception: pass
                    cur_p = lista_ctrl.getSelectedPosition()
                    if cur_p <= 0:
                        lista_ctrl.selectItem(0)
                        self.pos_anterior = 0
                        if self.items_actuales:
                            self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

                self.cargando_mas = False
                if not nuevos and reset:
                    xbmcgui.Dialog().notification("Vaquexflix", "No se encontraron elementos.", xbmcgui.NOTIFICATION_WARNING)

            threading.Thread(target=_hilo_busqueda, daemon=True).start()
            return

        generation = self._catalog_generation
        def _hilo_fetch_inicial():
            self.cargando_mas = True
            pag = 1
            acumulados = 0
            xbmcgui.Dialog().notification("Vaquexflix", "Cargando contenido...", xbmcgui.NOTIFICATION_INFO, 1200)

            while pag <= 3 and self.hay_mas_paginas:
                sep = '&' if '?' in url_target else '?'
                url_pag = url_target if pag == 1 else f"{url_target}{sep}page={pag}"
                html_res, _ = fetch_html(url_pag)
                if not self.activa or generation != self._catalog_generation:
                    return
                if not html_res:
                    self.hay_mas_paginas = False
                    break

                nuevos = self._parsear_tarjetas(html_res)
                if not nuevos:
                    self.hay_mas_paginas = False
                    break

                self.items_actuales.extend(nuevos)
                self.items_originales = list(self.items_actuales)
                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=obj['title'])
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora)
                    ui_items.append(item)

                pos_guardada = lista_ctrl.getSelectedPosition()
                if pos_guardada < 0:
                    pos_guardada = self.pos_anterior

                lista_ctrl.addItems(ui_items)
                acumulados += len(nuevos)

                if pag == 1 and reset and ui_items:
                    cur_p = lista_ctrl.getSelectedPosition()
                    if cur_p <= 0 and pos_guardada <= 0:
                        self.setFocus(lista_ctrl)
                        lista_ctrl.selectItem(0)
                        self.pos_anterior = 0
                        if self.items_actuales:
                            self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
                    elif pos_guardada > 0:
                        try:
                            lista_ctrl.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass
                else:
                    if pos_guardada > 0:
                        try:
                            lista_ctrl.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass

                self.pagina_actual = pag
                pag += 1

            self.cargando_mas = False
            if acumulados == 0 and reset:
                xbmcgui.Dialog().notification("Vaquexflix", "No se encontraron elementos.", xbmcgui.NOTIFICATION_WARNING)

        threading.Thread(target=_hilo_fetch_inicial, daemon=True).start()

    def cargar_siguiente_pagina(self):
        if not self.hay_mas_paginas or self.cargando_mas or self.categoria_actual_url.startswith("local://") or self.categoria_actual_url.startswith("search://"):
            return

        self.cargando_mas = True
        prox_pag = self.pagina_actual + 1

        if self.categoria_actual_url.startswith('unified://'):
            self._cargar_pagina_unificada(prox_pag)
            return

        generation = self._catalog_generation
        def _hilo_mas():
            try:
                sep = '&' if '?' in self.categoria_actual_url else '?'
                url_pag = f"{self.categoria_actual_url}{sep}page={prox_pag}"
                html_res, _ = fetch_html(url_pag)
                if not self.activa or generation != self._catalog_generation:
                    return
                if not html_res:
                    self.hay_mas_paginas = False
                    self.cargando_mas = False
                    return

                nuevos = self._parsear_tarjetas(html_res)
                if not nuevos:
                    self.hay_mas_paginas = False
                    self.cargando_mas = False
                    return

                lista_ctrl = self.getControl(100)
                if not lista_ctrl:
                    self.cargando_mas = False
                    return

                self.items_actuales.extend(nuevos)
                self.items_originales = list(self.items_actuales)
                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=obj['title'])
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora)
                    ui_items.append(item)

                pos_guardada = lista_ctrl.getSelectedPosition()
                if pos_guardada < 0:
                    pos_guardada = self.pos_anterior

                lista_ctrl.addItems(ui_items)

                if pos_guardada > 0:
                    try:
                        lista_ctrl.selectItem(pos_guardada)
                        self.pos_anterior = pos_guardada
                    except Exception: pass

                self.pagina_actual = prox_pag
            except Exception: pass
            finally:
                if generation == self._catalog_generation:
                    self.cargando_mas = False

        threading.Thread(target=_hilo_mas, daemon=True).start()

    def cargar_temporadas(self, serie_obj):
        self._catalog_generation += 1
        if serie_obj.get('legacy_episode'):
            candidates = catalog.search(serie_obj['title'], experimental=self.experimental)
            matches = [c for c in candidates if c.get('is_serie') and
                       servidores.titulo_coincide(c['title'], serie_obj['title'])]
            if len(matches) != 1:
                xbmcgui.Dialog().notification('Vaquexflix', 'No se pudo identificar la serie del historial antiguo. Búscala en el catálogo.', xbmcgui.NOTIFICATION_WARNING)
                return
            parent = matches[0]
            data = cargar_userdata()
            for entry_key in serie_obj.get('history_keys', []):
                if entry_key in data.get('historial', {}):
                    data['historial'][entry_key]['series'] = parent
            guardar_userdata(data)
            serie_obj = parent
        if self.estado == 'elementos':
            self._titulo_catalogo = getattr(self, '_titulo_actual', 'SERIES')
        self.estado = "temporadas"
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', serie_obj.get('cover', '') if serie_obj else '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()
        self.serie_actual = serie_obj
        self.actualizar_etiqueta(limpiar_texto(serie_obj['title']).upper())
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        try:
            if self.experimental and not serie_obj.get('_expanded'):
                serie_obj = catalog.expand(serie_obj)
                serie_obj['_expanded'] = True
                self.serie_actual = serie_obj
            self.episodios_por_temporada = catalog.episodes(serie_obj, experimental=self.experimental)
        except Exception as exc:
            xbmc.log(f'Vaquexflix error al cargar episodios: {exc}', xbmc.LOGERROR)
            self.episodios_por_temporada = {}

        self.temporadas_disponibles = sorted(self.episodios_por_temporada.keys(), key=lambda x: int(x) if str(x).isdigit() else 0)
        self.items_actuales = []
        ui_items = []
        for t_key in self.temporadas_disponibles:
            label = f"Temporada {t_key}"
            num_eps = len(self.episodios_por_temporada[t_key])
            t_plot = f"{serie_obj['title']} - Temporada {t_key} ({num_eps} episodios)"
            self.items_actuales.append({
                'title': label,
                'season': t_key,
                'cover': serie_obj.get('cover', ''),
                'plot': t_plot,
                'is_serie': True
            })
            item = xbmcgui.ListItem(label=label)
            is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(serie_obj)
            configurar_item_video(item, label, thumb=serie_obj.get('cover', ''), plot=t_plot, is_dorama=is_dora)
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self.actualizar_sinopsis_texto(self.items_actuales[0]['plot'])
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "No hay episodios disponibles.", xbmcgui.NOTIFICATION_WARNING)

    def cargar_episodios(self, num_temp):
        self.estado = "episodios"
        self._set_prop('vista_episodios', 'true')
        self._set_prop('serie_cover', self.serie_actual.get('cover', '') if self.serie_actual else '')
        try:
            self.getControl(100).setVisible(False)
            self.getControl(150).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()

        lista_ctrl = self.getControl(150)
        if not lista_ctrl: return
        lista_ctrl.reset()

        self.episodios_actuales = self.episodios_por_temporada.get(str(num_temp), [])
        self.items_actuales = self.episodios_actuales
        self.actualizar_etiqueta(f"{limpiar_texto(self.serie_actual['title']).upper()} - T{num_temp}")
        ui_items = []
        for ep in self.episodios_actuales:
            item = xbmcgui.ListItem(label=ep['title'])
            is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(ep)
            configurar_item_video(item, ep['title'], thumb=ep.get('cover', ''), plot=ep.get('plot', ''), rating=ep.get('rating', ''), is_dorama=is_dora, is_episode=True)
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.episodios_actuales:
                self._actualizar_sinopsis_de_elemento(self.episodios_actuales[0])

    def reproducir_con_historial(self, titulo, url_video, cover_url="", is_serie=False, plot="", ep_index=-1):
        self.episodio_index_actual = ep_index
        url_norm = url_video.split('?')[0].rstrip('/')
        diag = xbmcgui.Dialog()
        prog = xbmcgui.DialogProgress()
        prog.create("Vaquexflix", "Conectando con el servidor...")
        try:
            candidates = self.episodios_actuales if ep_index >= 0 else self.items_actuales
            selected = next((x for x in candidates if x.get('url') == url_video),
                            {'title': titulo, 'url': url_video, 'cover': cover_url, 'is_serie': is_serie})
            servidores_disp = catalog.servers(selected, self.experimental, self.serie_actual if is_serie else None)
        except Exception as exc:
            xbmc.log(f'Vaquexflix error al obtener servidores: {exc}', xbmc.LOGERROR)
            servidores_disp = []
        prog.close()

        choose_server = self.experimental or doramas.is_dorama(selected)
        if not servidores_disp:
            message = 'No hay servidores disponibles' if choose_server else 'No hay Premium disponible. Puedes activar Experimental para buscar alternativas.'
            diag.notification('Vaquexflix', message, xbmcgui.NOTIFICATION_WARNING, 6000)
            return

        # Sondear cabeceras en paralelo antes de mostrar las opciones.
        quality_cache = cargar_userdata().get('server_quality', {})
        omitted = True
        if choose_server:
            if self._metadata_scanner is None:
                self._metadata_scanner = stream_metadata.Scanner(servidores.resolver_stream,
                    servidores.nueva_sesion, lambda url: servidores.CALIDADES_HLS.get(url, ''),
                    servidores.presupuesto_sondeo)
            probe = MetadataProgress('metadata.xml', ADDON_PATH, 'Default', '720p')
            probe.show()
            def probe_progress(done, total):
                probe.update(done, total)
                return self.activa and not probe.omitted and not probe.canceled
            try:
                measured = self._metadata_scanner.scan(servidores_disp, quality_cache, seconds=6 if doramas.is_dorama(selected) else 15, progress=probe_progress)
            finally:
                probe.close()
            canceled = probe.canceled or not self.activa
            omitted = probe.omitted
            if measured:
                data = cargar_userdata()
                cache = data.setdefault('server_quality', {})
                cache.update(measured)
                # Solo persistir metadatos, nunca URLs firmadas ni cookies.
                data['server_quality'] = dict(sorted(cache.items(), key=lambda pair: pair[1].get('updated', 0), reverse=True)[:256])
                guardar_userdata(data)
                quality_cache.update(measured)
            if canceled:
                return
        def server_key(server):
            return stream_metadata.cache_key(server['url'])
        idx = 0
        if choose_server and len(servidores_disp) > 1:
            nombres = []
            for server in servidores_disp:
                meta = quality_cache.get(server_key(server), {})
                if time.time() - meta.get('updated', 0) > 21600:
                    meta = {}
                clean = dict(server, nombre=re.sub(r'\s*\((?:lat|esp|eng|sub)\)', '', server['nombre'], flags=re.I))
                nombres.append(servidores.etiqueta_servidor(clean, stream_metadata.quality_label(meta))
                               + ' | ' + stream_metadata.audio_label(meta, server))
                if omitted:
                    nombres[-1] = servidores.etiqueta_servidor(clean).rsplit(' - ', 1)[0]
            idx = diag.select(f"Vaquexflix - {limpiar_texto(titulo)}", nombres)
            if idx == -1: return

        url_target = servidores_disp[idx]['url']
        xbmc.log('Vaquexflix: seleccion {} / {} / {}'.format(
            limpiar_texto(titulo), servidores_disp[idx]['nombre'],
            urllib.parse.urlsplit(url_target).hostname), xbmc.LOGINFO)
        prog.create("Vaquexflix", "Resolviendo enlace de video...")
        stream_final = None
        error_servidor = 'No se pudo reproducir este servidor'
        try:
            stream_final = (self._metadata_scanner.resolved(url_target) if choose_server and self._metadata_scanner else None) or servidores.resolver_stream(url_target)
        except servidores.ServidorNoDisponible as exc:
            error_servidor = str(exc)
            xbmc.log('Vaquexflix: ' + error_servidor, xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log(f'Vaquexflix error al resolver stream: {exc}', xbmc.LOGERROR)

        if prog.iscanceled():
            prog.close()
            return
        prog.close()

        if not stream_final:
            xbmc.log('Vaquexflix: resolucion fallida para ' + servidores_disp[idx]['nombre'], xbmc.LOGWARNING)
            diag.notification("Vaquexflix", error_servidor, xbmcgui.NOTIFICATION_ERROR, 7000)
            return

        data_user = cargar_userdata()
        segundo_reanudar = 0
        historial = data_user.get('historial', {})
        saved_progress = watch_history.entry_for(historial, selected)
        if saved_progress:
            seg = saved_progress.get('time', 0)
            m, s = divmod(int(seg), 60)
            if seg > 20:
                if diag.yesno("Vaquexflix", f"Deseas reanudar desde {m:02d}:{s:02d}?", nolabel="Inicio", yeslabel="Reanudar"):
                    segundo_reanudar = seg

        tit_hist = re.sub(r'\s*\(\d+:\d+\)', '', limpiar_texto(titulo)).strip()
        quality = servidores.CALIDADES_HLS.get(stream_final.split('|')[0], '')
        if quality and not omitted:
            data_user.setdefault('server_quality', {}).setdefault(server_key(servidores_disp[idx]), {}).update({'label': quality, 'updated': time.time()})
            guardar_userdata(data_user)
            diag.notification('Vaquexflix - Calidad disponible', quality, xbmcgui.NOTIFICATION_INFO, 4000)
        series_info = dict(self.serie_actual) if is_serie and ep_index >= 0 and self.serie_actual else {}
        poster_serie = series_info.get('cover', '') if series_info else ''
        hist_cover = poster_serie if (is_serie and poster_serie) else cover_url
        self._iniciar_stream({
            'stream': stream_final, 'url_norm': url_norm,
            'history_aliases': [watch_history.key(v['url']) for v in catalog.variants(selected)],
            'server_key': server_key(servidores_disp[idx]), 'quality': quality,
            'history': dict({'title': tit_hist, 'cover': hist_cover, 'episode_cover': cover_url, 'is_serie': is_serie, 'plot': plot,
                             'year': selected.get('year', ''), 'variants': catalog.variants(selected)},
                            **({'series': series_info} if series_info else {})),
        }, segundo_reanudar)

    def detener_reproduccion(self):
        if self._av_started and self.reproduciendo_video:
            self._guardar_progreso()
        was_active = self.reproduciendo_video
        self.reproduciendo_video = False
        self._en_fullscreen = False
        session = self.session_reproduccion_activa
        self.session_reproduccion_activa += 1
        try:
            if self._closing_session is None and (was_active or self.player.isPlaying()):
                self._closing_session = session
                xbmc.log('Vaquexflix: cierre solicitado de sesion {}'.format(session), xbmc.LOGINFO)
                # No bloquear Python esperando al hilo de video durante el cierre.
                xbmc.executebuiltin('PlayerControl(Stop)', False)
        except Exception:
            pass
        if self.estado == 'episodios' and 0 <= self.pos_anterior < len(self.episodios_actuales):
            self._actualizar_sinopsis_de_elemento(self.episodios_actuales[self.pos_anterior])

    # (se ha removido el duplicado _mostrar_dialogo_control_reproductor)

    def _confirmar_cambio_episodio(self, idx):
        if self.en_dialogo_salida:
            return
        self.en_dialogo_salida = True
        paused_here = self._pausar_para_dialogo()
        try:
            if xbmcgui.Dialog().yesno('Vaquexflix', '¿Deseas reproducir este episodio?\n' + self.episodios_actuales[idx]['title'], yeslabel='Reproducir', nolabel='Cancelar'):
                self.detener_reproduccion()
                self.reproducir_episodio_por_indice(idx)
            elif paused_here and xbmc.getCondVisibility('Player.Paused'):
                xbmc.executebuiltin('PlayerControl(Play)', False)
        finally:
            self.en_dialogo_salida = False

    def reproducir_episodio_por_indice(self, idx):
        if 0 <= idx < len(self.episodios_actuales):
            ep = self.episodios_actuales[idx]
            self.pos_anterior = idx
            lista_ctrl = self.getControl(150 if self.estado == "episodios" else 100)
            if lista_ctrl and self.estado == "episodios":
                try: lista_ctrl.selectItem(idx)
                except Exception: pass
            self.reproducir_con_historial(
                ep['title'], ep['url'], cover_url=ep.get('cover', ''), is_serie=True, plot=ep.get('plot', ''), ep_index=idx
            )

    def on_playback_ended(self):
        self.reproduciendo_video = False
        self._en_fullscreen = False
        if self.episodio_index_actual >= 0 and self.episodios_actuales:
            sig_idx = self.episodio_index_actual + 1
            if sig_idx < len(self.episodios_actuales):
                sig_ep = self.episodios_actuales[sig_idx]
                if not self.activa: return
                resp = xbmcgui.Dialog().yesno(
                    "Vaquexflix",
                    f"Deseas reproducir el siguiente episodio?\n{sig_ep['title']}",
                    yeslabel="Reproducir",
                    nolabel="Cancelar"
                )
                if resp:
                    self.reproducir_episodio_por_indice(sig_idx)

    def alternar_favorito(self, item_obj):
        data = cargar_userdata()
        favs = data.setdefault('favoritos', [])
        u = item_obj.get('url', '')
        url_norm = u.split('?')[0].rstrip('/')
        idx = next((i for i, f in enumerate(favs) if f.get('url', '').split('?')[0].rstrip('/') == url_norm), -1)
        is_serie = item_obj.get('is_serie', any(x in u for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))

        if idx >= 0:
            favs.pop(idx)
            xbmcgui.Dialog().notification("Vaquexflix", "Eliminado de Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
        else:
            raw_tit = item_obj.get('title', 'Video')
            tit_clean = re.sub(r'\s*\(\d+:\d+\)', '', limpiar_texto(raw_tit)).strip()
            favs.append({
                'title': tit_clean,
                'url': u,
                'cover': item_obj.get('cover', ''),
                'is_serie': is_serie,
                'plot': item_obj.get('plot', ''),
                'year': item_obj.get('year', ''), 'variants': catalog.variants(item_obj)
            })
            xbmcgui.Dialog().notification("Vaquexflix", "Anadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
        guardar_userdata(data)
        if self.categoria_actual_url == "local://favoritos":
            self.cargar_elementos("local://favoritos", reset=True)

    def eliminar_del_historial(self, item_obj):
        url_norm = item_obj.get('url', '').split('?')[0].rstrip('/')
        data = cargar_userdata()
        historial = data.get('historial', {})
        encontrado = False
        for k in list(historial.keys()):
            if k in item_obj.get('history_keys', []) or k.split('?')[0].rstrip('/') == url_norm or k == item_obj.get('url', ''):
                del historial[k]
                encontrado = True
        if encontrado:
            guardar_userdata(data)
            xbmcgui.Dialog().notification("Vaquexflix", "Eliminado de Recien Vistos", xbmcgui.NOTIFICATION_INFO, 1500)
            if self.categoria_actual_url == "local://historial":
                self.cargar_elementos("local://historial", reset=True)
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "No se encontro en el historial", xbmcgui.NOTIFICATION_INFO, 1200)

    def mostrar_menu_ordenar(self):
        if self.estado not in ["elementos"] or not self.items_actuales:
            return
        opciones = [
            "Por defecto (Metadata original)",
            "Ano (Mas recientes primero)",
            "Ano (Mas antiguos primero)",
            "Alfabetico (A - Z)",
            "Alfabetico (Z - A)",
            "Calificacion (Mayor a menor)"
        ]
        diag = xbmcgui.Dialog()
        sel = diag.select("Vaquexflix - Ordenar contenido", opciones)
        if sel == -1: return

        if sel == 0:
            if self.items_originales:
                self.items_actuales = list(self.items_originales)
        elif sel == 1:
            self.items_actuales.sort(
                key=lambda x: int(re.sub(r'\D', '', str(x.get('year', 0))) or 0),
                reverse=True
            )
        elif sel == 2:
            self.items_actuales.sort(
                key=lambda x: int(re.sub(r'\D', '', str(x.get('year', 9999))) or 9999)
            )
        elif sel == 3:
            self.items_actuales.sort(
                key=lambda x: limpiar_texto(x.get('title', '')).lower()
            )
        elif sel == 4:
            self.items_actuales.sort(
                key=lambda x: limpiar_texto(x.get('title', '')).lower(),
                reverse=True
            )
        elif sel == 5:
            def _get_rating(x):
                r = str(x.get('rating', '0')).replace('★', '').replace(',', '.').strip()
                try: return float(r)
                except: return 0.0
            self.items_actuales.sort(key=_get_rating, reverse=True)

        lista_ctrl = self.getControl(100)
        if lista_ctrl:
            lista_ctrl.reset()
            ui_items = []
            for obj in self.items_actuales:
                item = xbmcgui.ListItem(label=obj['title'])
                is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora)
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

    def actualizar_pie_de_pagina(self):
        txt = "[B][X][/B] Buscar   [B][Y][/B] Ordenar   [B][XX / C][/B] Favorito/Quitar   [B][A / Enter][/B] Seleccionar   [B][B / Esc][/B] Volver"
        try:
            self.getControl(500).setVisible(True)
        except Exception:
            pass
        try:
            ctrl = self.getControl(501)
            if ctrl:
                ctrl.setLabel(txt)
        except Exception:
            pass

    def _on_x_pressed(self):
        now = time.time()
        if (now - self._last_x_time) < 0.42:
            self._last_x_time = 0.0
            if self._x_timer:
                self._x_timer.cancel()
                self._x_timer = None
            self._ejecutar_accion_secundaria()
        else:
            self._last_x_time = now
            if self._x_timer:
                self._x_timer.cancel()
            self._x_timer = threading.Timer(0.38, self._ejecutar_single_x)
            self._x_timer.start()

    def _ejecutar_single_x(self):
        self._x_timer = None
        if self.activa and not self.reproduciendo_video and not self.player.isPlaying():
            self.abrir_busqueda()

    def _ejecutar_accion_secundaria(self):
        if self.estado in ["elementos"]:
            lista_ctrl = self.getControl(100)
            if lista_ctrl:
                idx = lista_ctrl.getSelectedPosition()
                if 0 <= idx < len(self.items_actuales):
                    sel = self.items_actuales[idx]
                    if not sel.get('url'):
                        return
                    if self.categoria_actual_url == "local://historial":
                        self.eliminar_del_historial(sel)
                    else:
                        self.alternar_favorito(sel)

    def abrir_busqueda(self, global_search=False):
        section = 'all' if global_search or self.seccion_actual == 'busqueda' else self.seccion_actual
        kb = xbmc.Keyboard('', 'Buscar en todo' if section == 'all' else 'Buscar en ' + section.title())
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            txt = kb.getText().strip()
            if txt:
                self.seccion_actual = section if section != 'all' else "busqueda"
                self._set_prop('seccion_actual', self.seccion_actual)
                self.actualizar_etiqueta(f"BÚSQUEDA: {limpiar_texto(txt).upper()}")
                url_busqueda = f"search://{urllib.parse.quote_plus(txt)}?section={section}"
                self.cargar_elementos(url_busqueda, reset=True)

    def onClick(self, controlId):
        if controlId in (100, 150):
            lista_ctrl = self.getControl(controlId)
            idx = lista_ctrl.getSelectedPosition()

            if self.estado == "categorias":
                if 0 <= idx < len(self.items_actuales):
                    cat_sel = self.items_actuales[idx]
                    self.actualizar_etiqueta(cat_sel['title'].upper())
                    self.cargar_elementos(cat_sel['url'], reset=True)
            elif self.estado == "elementos":
                if 0 <= idx < len(self.items_actuales):
                    sel = self.items_actuales[idx]
                    u = sel.get('url', '')
                    if not u:
                        return
                    if doramas.is_dorama(sel) and not sel.get('media_type') and not sel.get('episode'):
                        try:
                            sel.update(doramas.metadata(sel))
                        except Exception as exc:
                            xbmc.log('Vaquexflix: tipo de dorama: ' + str(exc), xbmc.LOGWARNING)
                    if sel.get('history_keys') and sel.get('is_serie'):
                        self.cargar_temporadas(sel)
                    elif '/episodio-' in u or '/temporada-' in u or ('season' in sel and 'episode' in sel):
                        self.reproducir_con_historial(sel['title'], u, cover_url=sel.get('cover', ''), is_serie=True, plot=sel.get('plot', ''), ep_index=-1)
                    elif sel.get('is_serie', False):
                        self.cargar_temporadas(sel)
                    else:
                        self.reproducir_con_historial(sel['title'], u, cover_url=sel.get('cover', ''), is_serie=False, plot=sel.get('plot', ''), ep_index=-1)
            elif self.estado == "temporadas":
                if 0 <= idx < len(self.temporadas_disponibles):
                    self.cargar_episodios(self.temporadas_disponibles[idx])
            elif self.estado == "episodios":
                if 0 <= idx < len(self.episodios_actuales):
                    ep = self.episodios_actuales[idx]
                    self.reproducir_con_historial(ep['title'], ep['url'], cover_url=ep.get('cover', ''), is_serie=True, plot=ep.get('plot', ''), ep_index=idx)

        elif controlId == 201: self.abrir_busqueda(global_search=True)
        elif controlId == 202: self.cargar_categorias("peliculas")
        elif controlId == 203: self.cargar_categorias("series")
        elif controlId == 205: self.cargar_categorias("doramas")
        elif controlId == 206: self.mostrar_faq()
        elif controlId == 204:
            self.experimental = not self.experimental
            ADDON.setSetting('experimental', 'true' if self.experimental else 'false')
            self._set_prop('experimental_enabled', 'true' if self.experimental else 'false')
            self.getControl(204).setSelected(self.experimental)
            self._actualizar_navegacion_lateral()
            target = getattr(self, 'categoria_actual_url', '')
            self._catalog_generation += 1
            self.cargando_mas = False
            if not self.experimental and self.seccion_actual == 'doramas':
                self.cargar_categorias('peliculas')
            elif self.estado == 'elementos' and target:
                self.cargar_elementos(target)
            else:
                self.cargar_categorias(self.seccion_actual if self.seccion_actual in ('series', 'doramas') else 'peliculas')
            xbmcgui.Dialog().notification('Vaquexflix', 'Experimental: catálogo completo' if self.experimental else 'Modo normal: solo Premium', xbmcgui.NOTIFICATION_INFO, 3000)

    def mostrar_faq(self):
        faq_img = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'faq.png')
        if not os.path.exists(faq_img):
            faq_img = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'faq.jpg')
        if os.path.exists(faq_img):
            diag = FAQDialog('faq_dialog.xml', ADDON_PATH, 'Default', '720p')
            diag.doModal()
            del diag
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "Guía visual en preparación (faq.png)", xbmcgui.NOTIFICATION_INFO, 3500)

    def onFocus(self, controlId):
        if controlId == 204:
            self.actualizar_sinopsis_texto('Experimental: catalogo completo y servidores adicionales. Desactivado: catalogo principal con Premium. Doramas solo esta disponible en Experimental.')
        elif controlId == 206:
            self.actualizar_sinopsis_texto('Ayuda / Guía: conoce el funcionamiento del complemento y cómo usar el Modo Experimental.')
        elif controlId in (100, 150) and 0 <= self.pos_anterior < len(self.items_actuales):
            self._actualizar_sinopsis_de_elemento(self.items_actuales[self.pos_anterior])

    def onAction(self, action):
        aid = action.getId()
        btn_code = action.getButtonCode()

        # 1. Controles durante la reproduccion activa de video
        if self.reproduciendo_video or self.player.isPlaying():
            # Siguiente capitulo directo
            if aid in [xbmcgui.ACTION_NEXT_ITEM, 14, 86, 88]:
                if self.episodio_index_actual >= 0 and (self.episodio_index_actual + 1) < len(self.episodios_actuales):
                    self._confirmar_cambio_episodio(self.episodio_index_actual + 1)
                    return
            # Capitulo anterior directo
            elif aid in [xbmcgui.ACTION_PREV_ITEM, 15, 87, 89]:
                if self.episodio_index_actual > 0:
                    self._confirmar_cambio_episodio(self.episodio_index_actual - 1)
                    return
            # Confirmacion / menu al salir del reproductor de video
            elif aid in [10, 92, 9, 13, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP]:
                self._mostrar_dialogo_control_reproductor()
                return

        # Long press maps to mouse right-click/context menu in Kodi.
        if aid == 101 and not self.reproduciendo_video and not self.player.isPlaying():
            if self.getFocusId() == 100 and self.estado == 'elementos':
                control = self.getControl(100)
                position = control.getSelectedPosition()
                if 0 <= position < len(self.items_actuales):
                    selected = self.items_actuales[position]
                    if selected.get('url'):
                        self.alternar_favorito(selected)
                return

        # 2. Tecla 'C' en teclado: Favorito / Quitar directo
        if btn_code in [99, 67, 61507] and not self.player.isPlaying():
            self._ejecutar_accion_secundaria()
            return

        # 3. Boton X en gamepad O teclas X / F en teclado (Buscar / Doble X: Favorito o Quitar)
        es_boton_x = (
            aid in [117, 11] or
            btn_code in [120, 88, 61528, 102, 70, 61510]
        )
        if es_boton_x and not self.player.isPlaying():
            self._on_x_pressed()
            return

        # 4. Boton Y en gamepad O teclas Y / O en teclado (Ordenar contenido)
        es_boton_y = (
            aid in [18, 19, 27, 34, 175] or
            btn_code in [121, 89, 61529, 111, 79, 61519]
        )
        if es_boton_y and not self.player.isPlaying():
            self.mostrar_menu_ordenar()
            return

        # 5. Navegacion atras / Volver (B en gamepad, Esc en teclado)
        if aid in [10, 92, 9, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            if self.reproduciendo_video or self.player.isPlaying():
                self._mostrar_dialogo_control_reproductor()
                return

            if self.estado == "episodios":
                self.cargar_temporadas(self.serie_actual)
            elif self.estado == "temporadas":
                self.actualizar_etiqueta(getattr(self, '_titulo_catalogo', 'SERIES'))
                self.cargar_elementos(self.categoria_actual_url, reset=True)
            elif self.estado == "elementos":
                self.cargar_categorias(self.seccion_actual if self.seccion_actual != "busqueda" else "peliculas")
            else:
                if xbmcgui.Dialog().yesno("Vaquexflix", "Deseas salir del complemento?", yeslabel="Salir", nolabel="Cancelar"):
                    self.activa = False
                    self.detener_reproduccion()
                    self.close()
            return

        super().onAction(action)

def _parse_argv_params_tmdbhelper():
    params = {}
    try:
        if len(sys.argv) >= 3 and sys.argv[2].startswith('?'):
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        elif len(sys.argv) > 1:
            raw = sys.argv[1][1:] if sys.argv[1].startswith('?') else sys.argv[1]
            params = dict(urllib.parse.parse_qsl(raw))
    except Exception:
        params = {}
    return params

if __name__ == '__main__':
    _tmdbh_params = _parse_argv_params_tmdbhelper()
    if len(sys.argv) >= 2 and sys.argv[1].isdigit():
        try:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False,
                                       updateListing=False, cacheToDisc=False)
        except Exception:
            pass
    ui = VaquexflixUI('main.xml', ADDON_PATH, 'Default', '720p')
    _tmdbh_query = _tmdbh_params.get('query') or _tmdbh_params.get('title')
    if _tmdbh_params.get('action') == 'search' and _tmdbh_query:
        ui.busqueda_pendiente = urllib.parse.unquote_plus(_tmdbh_query)
    ui.show()
    monitor = xbmc.Monitor()
    try:
        while ui.activa and not monitor.waitForAbort(0.1):
            ui.procesar_eventos_player()
    finally:
        ui.activa = False
        if ui._metadata_scanner:
            ui._metadata_scanner.close()
        ui.detener_reproduccion()
        if ui._x_timer:
            ui._x_timer.cancel()
        ui.close()
        del ui
