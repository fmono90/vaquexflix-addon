"""Configuracion de streams compartida por el reproductor y las pruebas.

Sin dependencias de Kodi al importar: funciona tambien en Python de Batocera.
"""
from urllib.parse import parse_qsl, urlencode, urlsplit


def split_stream(stream, user_agent):
    url, _, options = stream.partition('|')
    headers = dict(parse_qsl(options, keep_blank_values=True))
    if urlsplit(url).scheme in ('http', 'https'):
        headers.setdefault('User-Agent', user_agent)
    return url, headers


def configure_stream(item, stream, user_agent, adaptive=False, kodi_major=20, ask_quality=False):
    url, headers = split_stream(stream, user_agent)
    path = urlsplit(url).path.lower()
    if path.endswith('.bin'):
        headers.setdefault('ext', '.mp4')
    extension = headers.get('ext', '').lower()
    is_hls = path.endswith('.m3u8') or extension == '.m3u8'
    if path.endswith(('.mp4', '.bin')) or extension == '.mp4':
        item.setMimeType('video/mp4')
        item.setContentLookup(False)
    elif path.endswith('.mkv') or extension == '.mkv':
        item.setMimeType('video/x-matroska')
        item.setContentLookup(False)
    if is_hls:
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setContentLookup(False)
    if is_hls and adaptive:
        item.setProperty('inputstream', 'inputstream.adaptive')
        if ask_quality and kodi_major >= 20:
            item.setProperty('inputstream.adaptive.stream_selection_type', 'ask-quality')
        if kodi_major <= 20:
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # Las opciones de curl no son cabeceras HTTP de InputStream Adaptive.
        http_headers = {k: v for k, v in headers.items()
                        if k.lower() not in ('verifypeer', 'ext')}
        encoded = urlencode(http_headers)
        item.setProperty('inputstream.adaptive.manifest_headers', encoded)
        item.setProperty('inputstream.adaptive.stream_headers', encoded)
        item.setPath(url)
        return url
    host = (urlsplit(url).hostname or '').lower()
    direct_file = path.endswith(('.mp4', '.mkv')) or extension in ('.mp4', '.mkv')
    problematic_host = (host == 'files.eintim.me' or host == '1a-1791.com'
                        or host.endswith('.rumble.cloud')
                        or host.endswith('.sssrr.org')
                        or host in ('drive.usercontent.google.com', 'drive.google.com'))
    if not is_hls and direct_file and problematic_host:
        # El lector HTTP de FFmpeg maneja sus propios seeks y su callback de
        # interrupcion. Evita el camino CurlFile/FileCache que queda esperando
        # al cerrar estos archivos remotos. Es interno de Kodi, sin otro addon.
        item.setProperty('inputstream', 'inputstream.ffmpeg')
        item.setContentLookup(False)
        headers.pop('ext', None)
    result = url + ('|' + urlencode(headers) if headers else '')
    item.setPath(result)
    return result
