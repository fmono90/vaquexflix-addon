"""Bounded public-page cache; deduplicates reads without persisting data to disk."""
import threading
import time
from collections import OrderedDict


class PageCache:
    def __init__(self, ttl=120, max_bytes=12 * 1024 * 1024):
        self.ttl, self.max_bytes = ttl, max_bytes
        self.values = OrderedDict()
        self.pending = {}
        self.lock = threading.Lock()

    def get(self, key, fetch, check=lambda: None):
        while True:
            check()
            with self.lock:
                hit = self.values.get(key)
                if hit and time.monotonic() - hit[0] < self.ttl:
                    self.values.move_to_end(key)
                    return hit[1]
                event = self.pending.get(key)
                if event is None:
                    event = self.pending[key] = threading.Event()
                    break
            event.wait(.05)
        try:
            value = fetch()
            size = len(value.encode('utf-8'))
            if size <= self.max_bytes:
                with self.lock:
                    self.values[key] = (time.monotonic(), value, size)
                    while len(self.values) > 32 or sum(v[2] for v in self.values.values()) > self.max_bytes:
                        self.values.popitem(last=False)
            return value
        finally:
            with self.lock:
                self.pending.pop(key, None)
                event.set()
