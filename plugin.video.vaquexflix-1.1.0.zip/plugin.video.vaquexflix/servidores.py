# -*- coding: utf-8 -*-
"""
Motor unificado de servidores y proveedores para Vaquexflix.
Gestiona proveedores de contenido (SoloLatino, HackStore2, FuegoCine) y resolutores de video.
"""
import base64
import codecs
import hashlib
import http.cookiejar
from html.parser import HTMLParser
import html
import json
import os
import re
import ssl
import sys
import time
import threading
import content_metadata
from contextlib import contextmanager
import urllib.parse
import urllib.request

try:
    _ssl_ctx = ssl.create_default_context()
    _ssl_ctx.check_hostname = False
    _ssl_ctx.verify_mode = ssl.CERT_NONE
except Exception:
    _ssl_ctx = None

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

SOLOLATINO_BASE = "https://sololatino.net"
FUEGOCINE_BASE = "https://www.fuegocine.com"
FUEGOCINE_PAGE_SIZE = 20

HACKSTORE_API = 'https://tmdb.hackstore2.com'
HACKSTORE_SITE = 'https://hackstore2.com'
HACKSTORE_PAGE_SIZE = 24
HACKSTORE_KINDS = ('movie', 'tvshow', 'anime')

PELISJUANITA_API = 'https://tmdb.pelisjuanita.org'
PELISJUANITA_SITE = 'https://pelisjuanita.org'
PELISJUANITA_PAGE_SIZE = 24
PELISJUANITA_KINDS = ('movie', 'tvshow', 'anime')

# Importación condicional de ResolveURL si está disponible en Kodi
try:
    import resolveurl
except Exception:
    resolveurl = None


# =====================================================================
# UTILIDADES GENERALES Y LIMPIEZA
# =====================================================================

def limpiar_texto(texto):
    if not texto:
        return ""
    decoded = str(texto)
    for _ in range(3):
        updated = html.unescape(decoded)
        if updated == decoded:
            break
        decoded = updated
    t = decoded.replace('★', '').replace('☆', '').replace('•', '-').replace('⭐', '').replace('🕒', '')
    t = t.replace('✅', '').replace('✔', '').replace('⚡', '')
    return re.sub(r'[^\x20-\x7E\u00A0-\u017F]', '', t).strip()

class SynopsisParser(HTMLParser):
    """Read complete structured descriptions before abbreviated SEO metadata."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.structured = []
        self.meta = []
        self.script = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' and attrs.get('type', '').lower() == 'application/ld+json':
            self.script = []
        elif tag == 'meta' and (attrs.get('name') == 'description' or attrs.get('property') == 'og:description'):
            self.meta.append(attrs.get('content', ''))

    def handle_data(self, data):
        if self.script is not None:
            self.script.append(data)

    def handle_endtag(self, tag):
        if tag == 'script' and self.script is not None:
            try:
                self.structured.append(json.loads(''.join(self.script)))
            except (ValueError, TypeError):
                pass
            self.script = None


def extraer_sinopsis(page):
    parser = SynopsisParser()
    parser.feed(page)
    candidates = []
    for document in parser.structured:
        nodes = document if isinstance(document, list) else [document]
        for node in nodes:
            if isinstance(node, dict):
                candidates.extend(node.get('@graph', [node]))
    structured_text = ""
    for node in candidates:
        if not isinstance(node, dict):
            continue
        types = node.get('@type', [])
        types = [types] if isinstance(types, str) else types
        if any(t in ('Movie', 'TVSeries', 'TVEpisode') for t in types) and node.get('description'):
            structured_text = limpiar_texto(node['description'])
            break
    # Body synopsis is preferred over a search-engine excerpt.
    body = re.search(r'<p\b[^>]*class=["\'][^"\']*leading-relaxed[^"\']*["\'][^>]*>(.*?)</p>', page, re.S | re.I)
    if body:
        body_text = limpiar_texto(re.sub(r'<[^>]+>', ' ', body.group(1)))
        # Some pages truncate JSON-LD too. Only substitute matching text,
        # never an unrelated paragraph or another episode's description.
        prefix = structured_text.rstrip('. \u2026')
        if not prefix or (len(body_text) > len(structured_text) and
                          body_text.casefold().startswith(prefix.casefold())):
            return body_text
    if structured_text:
        return structured_text
    text = next((value for value in parser.meta if value), '')
    return limpiar_texto(re.sub(r'^Ver\s+.*?\s+online\.\s*', '', text, flags=re.I))


def log_resolver(message):
    try:
        import xbmc
        xbmc.log('Vaquexflix: ' + message, xbmc.LOGWARNING)
    except ImportError:
        pass


class ServidorNoDisponible(RuntimeError):
    """Motivo confirmado por el proveedor que puede mostrarse al usuario."""


_sondeo = threading.local()


@contextmanager
def presupuesto_sondeo(deadline, cancel=None):
    previous = getattr(_sondeo, 'deadline', None)
    previous_cancel = getattr(_sondeo, 'cancel', None)
    _sondeo.deadline = deadline
    _sondeo.cancel = cancel
    try:
        yield
    finally:
        _sondeo.deadline = previous
        _sondeo.cancel = previous_cancel


def tiempo_peticion(timeout):
    cancel = getattr(_sondeo, 'cancel', None)
    if cancel is not None and cancel.is_set():
        raise TimeoutError('Sondeo omitido')
    deadline = getattr(_sondeo, 'deadline', None)
    if deadline is None:
        return timeout
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('Sondeo de metadatos finalizado')
    return min(timeout, remaining, 6)


def abrir_url(request, timeout=15, **kwargs):
    return urllib.request.urlopen(request, timeout=tiempo_peticion(timeout), **kwargs)


def nueva_sesion():
    # Conservar cookies durante redirecciones sin enviarlas a dominios ajenos.
    jar = http.cookiejar.CookieJar()
    context = ssl.create_default_context()
    # Kodi 21 incorpora Python 3.8; no anuncia HTTP/1.1 automaticamente.
    if hasattr(context, 'set_alpn_protocols'):
        context.set_alpn_protocols(['http/1.1'])
    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar), urllib.request.HTTPSHandler(context=context))
    original_open = opener.open
    def open_bounded(request, data=None, timeout=15):
        return original_open(request, data=data, timeout=tiempo_peticion(timeout))
    opener.open = open_bounded
    return opener


def url_con_cabeceras(url, headers, opener=None):
    req = urllib.request.Request(url)
    if opener:
        for handler in opener.handlers:
            if isinstance(handler, urllib.request.HTTPCookieProcessor):
                handler.cookiejar.add_cookie_header(req)
        if req.get_header('Cookie'):
            headers = dict(headers, Cookie=req.get_header('Cookie'))
    return url + '|' + urllib.parse.urlencode(headers)


CALIDADES_HLS = {}


def calidad_hls(manifest):
    heights = set()
    for line in manifest.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            match = re.search(r'RESOLUTION=\d+x(\d+)', line)
            if match:
                heights.add(int(match.group(1)))
    if not heights:
        return ''
    values = ' / '.join('{}p'.format(h) for h in sorted(heights))
    return ('Multirresolucion: ' if len(heights) > 1 else '') + values


def etiqueta_servidor(server, verified=''):
    name = re.sub(r'\b(?:Multicalidad|FHD|FullHD|HD|SD)\b|\(?\b\d{3,4}p\b\)?', '', server['nombre'], flags=re.I)
    name = re.sub(r'\s+', ' ', name).strip()
    return '{} - {}'.format(name, verified or 'Resolucion sin verificar')


def procesar_hls_local(master_url, referer, opener=None, timeout=15):
    """Validar y conservar el master con todos sus audios y variantes.

    No convertir el master en una lista de audio o de I-frames ni escribir
    cabeceras Kodi dentro de las URI de los segmentos.
    """
    opener = opener or nueva_sesion()
    headers = {'User-Agent': UA, 'Referer': referer,
               'Origin': '{0.scheme}://{0.netloc}'.format(urllib.parse.urlsplit(referer))}
    try:
        req = urllib.request.Request(master_url, headers=headers)
        with opener.open(req, timeout=timeout) as response:
            manifest = response.read(2 * 1024 * 1024).decode('utf-8-sig', 'replace')
            final_url = response.geturl()
        if not manifest.lstrip().startswith('#EXTM3U'):
            log_resolver('HLS: el servidor devolvio una pagina en lugar del manifiesto')
            return None
        CALIDADES_HLS[final_url] = calidad_hls(manifest)
        if not urllib.parse.urlsplit(final_url).path.lower().endswith('.m3u8'):
            headers['ext'] = '.m3u8'
        return url_con_cabeceras(final_url, headers, opener)
    except Exception as exc:
        reason = getattr(exc, 'reason', type(exc).__name__)
        log_resolver('HLS: fallo de acceso ({})'.format(reason))
        return None


def fetch_html(url, cookies="", referer="", timeout=10):
    try:
        headers = {
            'User-Agent': UA,
            'Referer': referer or f"{SOLOLATINO_BASE}/",
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8'
        }
        if cookies:
            headers['Cookie'] = cookies
        req = urllib.request.Request(url, headers=headers)
        with abrir_url(req, timeout=timeout, context=_ssl_ctx) as r:
            return r.read().decode('utf-8', errors='ignore'), r.headers.get_all('Set-Cookie') or []
    except Exception:
        return "", []


def unpack_js(p, a, c, k, e=None, d=None):
    def _baseN(num, b):
        chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        res = ""
        while num > 0:
            res = chars[num % b] + res
            num //= b
        return res or "0"
    if not 2 <= a <= 62 or not 0 <= c <= 100000:
        raise ValueError('Parametros del packer invalidos')
    lookup = {}
    for i in range(c):
        key = _baseN(i, a)
        lookup[key] = k[i] if i < len(k) and k[i] else key
    def _replace(match):
        w = match.group(0)
        return lookup.get(w, w)
    return re.sub(r'\b\w+\b', _replace, p)


# =====================================================================
# CRIPTOGRAFÍA AES Y HASHING (Para SoloLatino / Embed69 / PelisSeriesHoy)
# =====================================================================

class MiniAES:
    SBOX = [
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
    ]
    INV_SBOX = [0] * 256
    RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]

    @classmethod
    def _init_tables(cls):
        if cls.INV_SBOX[0] != 0 or cls.INV_SBOX[1] != 0:
            return
        for i in range(256):
            cls.INV_SBOX[cls.SBOX[i]] = i

    @staticmethod
    def _xt(a):
        return ((a << 1) ^ 0x1b) & 0xff if (a & 0x80) else (a << 1)

    @classmethod
    def _mul(cls, a, b):
        res = 0
        while b:
            if b & 1:
                res ^= a
            a = cls._xt(a)
            b >>= 1
        return res

    def __init__(self, key):
        self._init_tables()
        self.key = key
        self.Nk = len(key) // 4
        self.Nr = self.Nk + 6
        self.w = self._key_expansion()

    def _key_expansion(self):
        w = [0] * (4 * (self.Nr + 1))
        for i in range(self.Nk):
            w[i] = (self.key[4*i] << 24) | (self.key[4*i+1] << 16) | (self.key[4*i+2] << 8) | self.key[4*i+3]
        for i in range(self.Nk, 4 * (self.Nr + 1)):
            temp = w[i - 1]
            if i % self.Nk == 0:
                rw = ((temp << 8) & 0xffffffff) | (temp >> 24)
                sub = (self.SBOX[(rw >> 24) & 0xff] << 24) | (self.SBOX[(rw >> 16) & 0xff] << 16) | (self.SBOX[(rw >> 8) & 0xff] << 8) | self.SBOX[rw & 0xff]
                temp = sub ^ (self.RCON[i // self.Nk] << 24)
            elif self.Nk > 6 and (i % self.Nk == 4):
                temp = (self.SBOX[(temp >> 24) & 0xff] << 24) | (self.SBOX[(temp >> 16) & 0xff] << 16) | (self.SBOX[(temp >> 8) & 0xff] << 8) | self.SBOX[temp & 0xff]
            w[i] = w[i - self.Nk] ^ temp
        return w

    def encrypt_block(self, block):
        state = list(block)
        for rnd in range(self.Nr + 1):
            if rnd:
                state = [self.SBOX[x] for x in state]
                state = [state[r + 4 * ((c + r) % 4)] for c in range(4) for r in range(4)]
                if rnd != self.Nr:
                    for c in range(4):
                        a = state[4*c:4*c+4]
                        total = a[0] ^ a[1] ^ a[2] ^ a[3]
                        state[4*c:4*c+4] = [a[r] ^ total ^ self._xt(a[r] ^ a[(r+1) % 4]) for r in range(4)]
            state = [value ^ ((self.w[4*rnd + i//4] >> (24 - 8*(i % 4))) & 255)
                     for i, value in enumerate(state)]
        return bytes(state)

    def transform_ctr(self, data, counter):
        result = bytearray()
        for start in range(0, len(data), 16):
            block = self.encrypt_block(counter.to_bytes(16, 'big'))
            result.extend(a ^ b for a, b in zip(data[start:start+16], block))
            counter = (counter + 1) % (1 << 128)
        return bytes(result)

    def decrypt_block(self, block):
        state = [[block[r + 4 * c] for c in range(4)] for r in range(4)]
        for c in range(4):
            w = self.w[self.Nr * 4 + c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        for rnd in range(self.Nr - 1, 0, -1):
            state[1] = state[1][3:] + state[1][:3]
            state[2] = state[2][2:] + state[2][:2]
            state[3] = state[3][1:] + state[3][:1]
            for r in range(4):
                for c in range(4):
                    state[r][c] = self.INV_SBOX[state[r][c]]
            for c in range(4):
                w = self.w[rnd * 4 + c]
                state[0][c] ^= (w >> 24) & 0xff
                state[1][c] ^= (w >> 16) & 0xff
                state[2][c] ^= (w >> 8) & 0xff
                state[3][c] ^= w & 0xff
            for c in range(4):
                u = [state[r][c] for r in range(4)]
                state[0][c] = self._mul(u[0], 0x0e) ^ self._mul(u[1], 0x0b) ^ self._mul(u[2], 0x0d) ^ self._mul(u[3], 0x09)
                state[1][c] = self._mul(u[0], 0x09) ^ self._mul(u[1], 0x0e) ^ self._mul(u[2], 0x0b) ^ self._mul(u[3], 0x0d)
                state[2][c] = self._mul(u[0], 0x0d) ^ self._mul(u[1], 0x09) ^ self._mul(u[2], 0x0e) ^ self._mul(u[3], 0x0b)
                state[3][c] = self._mul(u[0], 0x0b) ^ self._mul(u[1], 0x0d) ^ self._mul(u[2], 0x09) ^ self._mul(u[3], 0x0e)
        state[1] = state[1][3:] + state[1][:3]
        state[2] = state[2][2:] + state[2][:2]
        state[3] = state[3][1:] + state[3][:1]
        for r in range(4):
            for c in range(4):
                state[r][c] = self.INV_SBOX[state[r][c]]
        for c in range(4):
            w = self.w[c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        return bytes(state[r][c] for c in range(4) for r in range(4))

    def decrypt_cbc(self, ciphertext, iv):
        plaintext = bytearray()
        prev = iv
        for i in range(0, len(ciphertext), 16):
            blk = ciphertext[i:i+16]
            dec = self.decrypt_block(blk)
            plaintext.extend(dec[j] ^ prev[j] for j in range(16))
            prev = blk
        pad = plaintext[-1]
        if 1 <= pad <= 16:
            return bytes(plaintext[:-pad])
        return bytes(plaintext)


def fnv1a_32(val_str):
    h = 2166136261
    for ch in val_str:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return f'{h:x}'


# =====================================================================
# RESOLVERS DE VIDEO
# =====================================================================

def resolver_pelisserieshoy(url_player):
    try:
        headers_get = {'User-Agent': UA, 'Referer': f"{SOLOLATINO_BASE}/"}
        req_p = urllib.request.Request(url_player, headers=headers_get)
        with abrir_url(req_p, timeout=8, context=_ssl_ctx) as r_p:
            html_p = r_p.read(2 * 1024 * 1024).decode('utf-8', errors='ignore')

        m_tok = re.search(r"const\s+_t\s*=\s*'([^']+)'", html_p)
        m_qk = re.search(r'var\s+_qk\s*=\s*(\[[^\]]+\]);', html_p)
        m_qc = re.search(r'var\s+_qc\s*=\s*[\"\']([^\"\']+)[\"\'];', html_p)
        m_src = re.search(r'var\s+_qsrc\s*=\s*[\"\']([^\"\']+)[\"\'];', html_p)
        if not (m_tok and m_qk and m_qc):
            return None

        tok = m_tok.group(1)
        qk = json.loads(m_qk.group(1))
        rt = qk[1] + qk[3] + qk[0] + qk[2]
        qc = m_qc.group(1)
        tk = fnv1a_32(f'{rt}|clk|{qc}')
        qsrc = m_src.group(1) if m_src else ""

        url_s = 'https://player.pelisserieshoy.com/s.php'
        headers_post = {
            'User-Agent': UA,
            'Referer': url_player,
            'Origin': 'https://player.pelisserieshoy.com',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        body_scan = {'a': '1', 'tok': tok, 'rt': rt, 'tk': tk}
        if qsrc:
            body_scan['src'] = qsrc
        req_scan = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_scan).encode('utf-8'), headers=headers_post)
        with abrir_url(req_scan, timeout=7, context=_ssl_ctx) as r_scan:
            scan_json = json.loads(r_scan.read(2 * 1024 * 1024).decode('utf-8'))
            servers = scan_json.get('s', [])

        body_click = {'a': 'click', 'tok': tok, 'rt': rt, 'tk': tk}
        if qsrc:
            body_click['src'] = qsrc
        try:
            req_click = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_click).encode('utf-8'), headers=headers_post)
            with abrir_url(req_click, timeout=7, context=_ssl_ctx) as r_click:
                pass
        except Exception:
            pass

        def _srv_priority(item):
            nom = item[0].lower()
            if 'player+' in nom or 'player' in nom:
                return 0
            if 'premium' in nom:
                return 1
            if 'vip' in nom:
                return 2
            return 3

        servers_sorted = sorted(servers, key=_srv_priority)

        for srv_nombre, v_target in servers_sorted:
            try:
                body_play = {'a': '2', 'v': v_target, 'tok': tok, 'rt': rt, 'tk': tk}
                if qsrc:
                    body_play['src'] = qsrc
                req_play = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_play).encode('utf-8'), headers=headers_post)
                with abrir_url(req_play, timeout=7, context=_ssl_ctx) as r_play:
                    data = json.loads(r_play.read(2 * 1024 * 1024).decode('utf-8'))
                    raw_u = data.get('u') or data.get('stream')
                    if not raw_u:
                        continue
                    u_full = raw_u if raw_u.startswith('http') else 'https://player.pelisserieshoy.com' + raw_u

                    if 'p.php' in u_full:
                        try:
                            req_cdn = urllib.request.Request(u_full, headers={'User-Agent': UA, 'Referer': url_player})
                            req_cdn.get_method = lambda: 'HEAD'
                            with abrir_url(req_cdn, timeout=7, context=_ssl_ctx) as r_cdn:
                                if r_cdn.url and r_cdn.url.startswith('http') and 'p.php' not in r_cdn.url:
                                    return r_cdn.url
                        except Exception:
                            pass
                        return u_full
                    elif u_full.startswith('http'):
                        return u_full
            except Exception:
                continue
        return None
    except Exception:
        return None


def resolver_embed69_hosts(url_embed):
    hosts = []
    try:
        req = urllib.request.Request(url_embed, headers={'User-Agent': UA, 'Referer': f"{SOLOLATINO_BASE}/"})
        with abrir_url(req, timeout=8, context=_ssl_ctx) as r:
            html_e = r.read(2 * 1024 * 1024).decode('utf-8', errors='ignore')

        m_c = re.search(r"const\s+POW_CHALLENGE\s*=\s*['\"]([^'\"]+)", html_e)
        m_d = re.search(r"const\s+POW_DIFFICULTY\s*=\s*(\d+)", html_e)
        m_s = re.search(r"const\s+POW_SALT\s*=\s*['\"]([^'\"]+)", html_e)
        if m_c and m_d and m_s:
            c, d, salt = m_c.group(1), int(m_d.group(1)), m_s.group(1)
            prefix = '0' * d
            nonce = 0
            aes_key_bytes = None
            while nonce < 500000:
                if hashlib.sha256(f'{c}{nonce}'.encode('utf-8')).hexdigest().startswith(prefix):
                    aes_key_bytes = hashlib.sha256(f'{c}{nonce}{salt}'.encode('utf-8')).digest()
                    break
                nonce += 1

            m_links = re.search(r'let\s+dataLink\s*=\s*(\[\{.*?\}\]);', html_e, re.DOTALL)
            if m_links and aes_key_bytes:
                cipher = MiniAES(aes_key_bytes)
                for grp in json.loads(m_links.group(1)):
                    lang = grp.get('video_language', 'LAT')
                    for srv in grp.get('sortedEmbeds', []):
                        try:
                            raw = base64.b64decode(srv['link'])
                            iv, ct = raw[:16], raw[16:]
                            dec = cipher.decrypt_cbc(ct, iv)
                            url_host = dec.decode('utf-8', errors='ignore').replace('`', '').strip()
                            s_name = srv.get('servername', 'Servidor')
                            hosts.append({'nombre': f"{s_name} ({lang})", 'url': url_host})
                        except Exception:
                            pass
    except Exception:
        pass
    return hosts


def resolver_ok_ru(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': UA})
        with abrir_url(req, timeout=7, context=_ssl_ctx) as r:
            h = r.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        m = re.search(r'data-options=[\'"]([^\'"]+)[\'"]', h)
        if not m:
            return None
        d = json.loads(html.unescape(m.group(1)))
        meta = d.get('flashvars', {}).get('metadata')
        if isinstance(meta, str):
            meta = json.loads(meta)
        if not isinstance(meta, dict):
            return None
        videos = meta.get('videos', [])
        prio = {'full': 5, 'hd': 4, 'sd': 3, 'low': 2, 'lowest': 1, 'mobile': 0}
        videos.sort(key=lambda v: prio.get(v.get('name'), 0), reverse=True)
        if videos and videos[0].get('url'):
            v_url = videos[0].get('url')
            return f"{v_url}|User-Agent={urllib.parse.quote(UA)}&verifypeer=false"
        hls = meta.get('hlsManifestUrl')
        if hls:
            return f"{hls}|User-Agent={urllib.parse.quote(UA)}&verifypeer=false"
    except Exception:
        pass
    return None


def resolver_vids_st(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': UA, 'Referer': 'https://www.fuegocine.com/'})
        with abrir_url(req, timeout=7, context=_ssl_ctx) as r:
            h = r.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        m = re.search(r'const\s+url\s*=\s*[\'"]([^\'"]+m3u8[^\'"]*)[\'"]', h)
        if m:
            clean_url = m.group(1).replace(r'\/', '/')
            return f"{clean_url}|User-Agent={urllib.parse.quote(UA)}&Referer=https://vids.st/&verifypeer=false"
    except Exception:
        pass
    return None


class DriveConfirmationParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.action = None
        self.inputs = {}
        self.link = None
        self.in_form = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'form' and attrs.get('id') == 'download-form':
            self.action = attrs.get('action')
            self.in_form = True
        elif tag == 'input' and self.in_form and attrs.get('name'):
            self.inputs[attrs['name']] = attrs.get('value', '')
        elif tag == 'a' and attrs.get('id') == 'uc-download-link':
            self.link = attrs.get('href')

    def handle_endtag(self, tag):
        if tag == 'form':
            self.in_form = False


def resolver_google_drive(url):
    m_id = re.search(r'/d/([a-zA-Z0-9_-]+)', url) or re.search(r'[?&]id=([a-zA-Z0-9_-]+)', url)
    if not m_id:
        return None
    opener = nueva_sesion()
    target = 'https://drive.usercontent.google.com/download?' + urllib.parse.urlencode({
        'id': m_id.group(1), 'export': 'download', 'authuser': '0'})
    headers = {'User-Agent': UA}
    try:
        for _ in range(3):
            # Probar la misma descarga abierta que pedira el reproductor.
            # Un rango pequeno puede venir de cache aun con la cuota agotada.
            # Solo leemos el prefijo y cerramos; no descargamos el archivo.
            req = urllib.request.Request(target, headers=dict(headers, Range='bytes=0-'))
            with opener.open(req, timeout=12) as response:
                ct = response.headers.get('Content-Type', '').lower().split(';')[0]
                prefix = response.read(2048)
                final_url = response.geturl()
                probe = prefix.lstrip().lower()
                is_html = ct in ('text/html', 'application/xhtml+xml') or probe.startswith((b'<!doctype html', b'<html'))
                if not is_html and prefix and (ct.startswith(('video/', 'audio/')) or ct in ('application/octet-stream', 'application/x-matroska')):
                    # Drive usa /download sin extension: evitar que Kodi haga
                    # otra deteccion HEAD o interprete la URL como una pagina.
                    if ct == 'video/mp4' or prefix[4:8] == b'ftyp':
                        headers['ext'] = '.mp4'
                    elif (ct in ('video/x-matroska', 'application/x-matroska')
                          or (prefix.startswith(b'\x1aE\xdf\xa3') and b'matroska' in prefix)):
                        headers['ext'] = '.mkv'
                    return url_con_cabeceras(final_url, headers, opener)
                if not is_html:
                    return None
                body = (prefix + response.read(256 * 1024)).decode('utf-8', 'replace')
            if any(x in body.lower() for x in ('quota exceeded', 'downloadquotaexceeded', 'cuota', 'too many users')):
                log_resolver('Google Drive: cuota de descarga agotada')
                raise ServidorNoDisponible('Google Drive: cuota de descarga agotada. Elige otro servidor o prueba mas tarde.')
            parser = DriveConfirmationParser()
            parser.feed(body)
            next_url = parser.link
            if parser.action:
                action = urllib.parse.urljoin(final_url, parser.action)
                parts = urllib.parse.urlsplit(action)
                params = dict(urllib.parse.parse_qsl(parts.query))
                params.update(parser.inputs)
                next_url = urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(params)))
            if not next_url:
                return None
            target = urllib.parse.urljoin(final_url, next_url)
            if urllib.parse.urlsplit(target).hostname not in ('drive.google.com', 'drive.usercontent.google.com'):
                return None
    except ServidorNoDisponible:
        raise
    except Exception as exc:
        log_resolver('Google Drive: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def extraer_url_hls(page):
    # Desescapar solo separadores conocidos; no alterar los tokens firmados.
    page = html.unescape(page.replace(r'\/', '/').replace(r'\u0026', '&'))
    match = re.search(r'https?://[^\s\'"<>\\]+\.m3u8(?:\?[^\s\'"<>\\]*)?', page, re.I)
    if match:
        return match.group(0)
    return None


def extraer_fuentes_hls(page, referer):
    """Respetar la prioridad de links del reproductor y validar cada variante."""
    cleaned = html.unescape(page.replace(r'\/', '/').replace(r'\u0026', '&'))
    found = re.search(r'\b(?:var|let|const)\s+links\s*=\s*(\{[^{}]+\})', cleaned)
    if found:
        try:
            links = json.loads(found.group(1))
            return [urllib.parse.urljoin(referer, links[key]) for key in ('hls4', 'hls3', 'hls2')
                    if isinstance(links.get(key), str) and links[key]]
        except ValueError:
            pass
    media = extraer_url_hls(cleaned)
    return [media] if media else []


def resolver_host_hls(embed_url, timeout=15):
    opener = nueva_sesion()
    host = urllib.parse.urlsplit(embed_url)
    referer = '{}://{}/'.format(host.scheme, host.netloc)
    try:
        if host.path.lower().endswith('.m3u8'):
            return procesar_hls_local(embed_url, referer, opener, timeout=timeout)
        req = urllib.request.Request(embed_url, headers={'User-Agent': UA, 'Referer': referer})
        with opener.open(req, timeout=timeout) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = response.geturl()
        # Redireccion explicita de VOE; no ejecutar JavaScript de la pagina.
        redirect = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
        if redirect:
            req = urllib.request.Request(html.unescape(redirect.group(1)), headers={'User-Agent': UA, 'Referer': referer})
            with opener.open(req, timeout=timeout) as response:
                page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                referer = response.geturl()
        if 'countries are not allowed' in page.lower():
            raise ServidorNoDisponible('Este servidor restringe el acceso desde tu ubicacion. Elige otro servidor.')
        if 'confirm you' in page.lower() and 'human to start the video' in page.lower():
            raise ServidorNoDisponible('Este servidor exige verificacion humana en su web. Elige otro servidor en Kodi.')
        if 'file is no longer available as it expired or has been deleted' in page.lower():
            raise ServidorNoDisponible('El servidor indica que el archivo expiro o fue eliminado. Elige otro servidor.')
        sources = extraer_fuentes_hls(page, referer)
        if not sources:
            # El packer usa e,d o e,r dependiendo del proveedor.
            pattern = r"eval\(function\(p,a,c,k,e,[dr]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
            for match in re.finditer(pattern, page, re.S):
                p, a, c, k = match.groups()
                sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), referer)
                if sources:
                    break
        for media in sources[:3]:
            stream = procesar_hls_local(media, referer, opener, timeout=timeout)
            if stream:
                return stream
        log_resolver('HLS: no se encontro un manifiesto en ' + host.netloc)
    except ServidorNoDisponible:
        raise
    except Exception as exc:
        log_resolver('HLS: {} en {}'.format(getattr(exc, 'reason', type(exc).__name__), host.netloc))
    return None


def resolver_goodstream(embed_url):
    return resolver_host_hls(embed_url)


def resolver_vimeos(embed_url):
    return resolver_host_hls(embed_url)


def resolver_altcha(challenge, max_seconds=8):
    """Implementar el calculo publico ALTCHA v2 con coste y tiempo acotados."""
    params = challenge['parameters']
    cost = params.get('cost')
    length = params.get('keyLength', 32)
    prefix = params.get('keyPrefix', '')
    if (params.get('algorithm') != 'PBKDF2/SHA-256'
            or not isinstance(cost, int) or not 1 <= cost <= 100000
            or not isinstance(length, int) or not 16 <= length <= 64
            or not isinstance(prefix, str) or not re.fullmatch(r'[0-9a-f]{1,4}', prefix)):
        raise ServidorNoDisponible('VOE solicita una verificacion no compatible.')
    nonce = bytes.fromhex(params['nonce'])
    salt = bytes.fromhex(params['salt'])
    if not 1 <= len(nonce) <= 128 or not 1 <= len(salt) <= 128:
        raise ValueError('ALTCHA: parametros invalidos')
    started = time.monotonic()
    deadline = getattr(_sondeo, 'deadline', None)
    if deadline is not None:
        max_seconds = min(max_seconds, max(0, deadline - started))
    for counter in range(10000):
        cancel = getattr(_sondeo, 'cancel', None)
        if cancel is not None and cancel.is_set():
            break
        if time.monotonic() - started >= max_seconds:
            break
        derived = hashlib.pbkdf2_hmac('sha256', nonce + counter.to_bytes(4, 'big'),
                                      salt, cost, length).hex()
        if derived.startswith(prefix):
            solution = {'counter': counter, 'derivedKey': derived,
                        'time': round((time.monotonic() - started) * 1000, 1)}
            return base64.b64encode(json.dumps({'challenge': challenge, 'solution': solution}).encode()).decode('ascii')
    raise ServidorNoDisponible('VOE: la verificacion excedio el tiempo de espera. Prueba otro servidor.')


class VoeGateParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.challenge = None
        self.fields = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'altcha-widget':
            self.challenge = attrs.get('challenge')
        elif tag == 'input' and attrs.get('name') in ('_token', 'access'):
            self.fields[attrs['name']] = attrs.get('value', '')


def extraer_fuente_voe(page):
    # La variable source visible en el HTML apunta a un video de demostracion.
    # Usar exclusivamente la configuracion JSON del reproductor real.
    for raw in re.findall(r'<script\b[^>]*type=[\'"]application/json[\'"][^>]*>(.*?)</script>', page, re.S | re.I):
        try:
            data = json.loads(raw)
            if not isinstance(data, list) or not data or not isinstance(data[0], str):
                continue
            encoded = codecs.decode(data[0], 'rot_13')
            for marker in ('@$', '^^', '~@', '%?', '*~', '!!', '#&'):
                encoded = encoded.replace(marker, '')
            shifted = base64.b64decode(encoded, validate=True).decode('utf-8')
            decoded = ''.join(chr(ord(c) - 3) for c in shifted)[::-1]
            config = json.loads(base64.b64decode(decoded, validate=True))
            if not isinstance(config, dict):
                continue
            source = config.get('source')
            if isinstance(source, str) and source.startswith(('https://', 'http://')):
                return source
        except (ValueError, TypeError, UnicodeError):
            continue
    return None


def resolver_voe(embed_url):
    opener = nueva_sesion()
    headers = {'User-Agent': UA, 'Referer': 'https://voe.sx/'}
    try:
        with opener.open(urllib.request.Request(embed_url, headers=headers), timeout=12) as r:
            page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            url = r.geturl()
        redirect = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
        if redirect:
            with opener.open(urllib.request.Request(html.unescape(redirect.group(1)), headers=headers), timeout=12) as r:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                url = r.geturl()
        gate = VoeGateParser()
        gate.feed(page)
        if gate.challenge:
            challenge_url = urllib.parse.urljoin(url, gate.challenge)
            if urllib.parse.urlsplit(challenge_url).netloc != urllib.parse.urlsplit(url).netloc or '_token' not in gate.fields:
                raise ValueError('VOE: formulario inesperado')
            headers['Referer'] = url
            with opener.open(urllib.request.Request(challenge_url, headers=headers), timeout=12) as r:
                challenge = json.loads(r.read(64 * 1024))
            gate.fields['altcha'] = resolver_altcha(challenge)
            request = urllib.request.Request(url, headers=headers,
                data=urllib.parse.urlencode(gate.fields).encode('utf-8'))
            with opener.open(request, timeout=12) as r:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                url = r.geturl()
            if '<altcha-widget' in page:
                raise ServidorNoDisponible('VOE no acepto la verificacion. Prueba otro servidor.')
        source = extraer_fuente_voe(page)
        if source:
            return procesar_hls_local(source, url, opener)
        log_resolver('VOE: no se encontro la configuracion de video')
    except ServidorNoDisponible:
        raise
    except Exception as exc:
        log_resolver('VOE: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_playmate(embed_url):
    """API usada por el reproductor publico de Playmate; sx es el master."""
    opener = nueva_sesion()
    parts = urllib.parse.urlsplit(embed_url)
    code = parts.path.rstrip('/').split('/')[-1]
    root = '{}://{}'.format(parts.scheme, parts.netloc)
    headers = {'User-Agent': UA, 'Referer': embed_url}
    try:
        with opener.open(urllib.request.Request(embed_url, headers=headers), timeout=12) as r:
            r.read(1024 * 1024)
        request = urllib.request.Request(root + '/api/s',
            data=json.dumps({'c': code, 'd': 'desktop'}).encode('utf-8'),
            headers=dict(headers, **{'Content-Type': 'application/json'}))
        with opener.open(request, timeout=12) as r:
            data = json.loads(r.read(256 * 1024))
        media = data.get('sx', '')
        if isinstance(media, str) and media.startswith(('https://', 'http://')):
            return procesar_hls_local(media, embed_url, opener)
        log_resolver('PM: la API no devolvio un video disponible')
    except Exception as exc:
        log_resolver('PM: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_unlimplay(embed_url):
    """UA agrupa hosts por idioma y publica un extractor HLS propio."""
    opener = nueva_sesion()
    try:
        parts = urllib.parse.urlsplit(embed_url)
        episode = re.search(r'/embed/tv/\d+/(\d+)/(\d+)/?$', parts.path)
        if episode:
            # El frontend redirigido puede perder temporada/episodio de la
            # ruta y devolver solo searched_names. Su API acepta estos campos.
            params = dict(urllib.parse.parse_qsl(parts.query))
            params.setdefault('season', episode.group(1))
            params.setdefault('episode', episode.group(2))
            # /play/ redirige a /f/ descartando el query; usar el destino
            # publicado para conservar esos parametros desde la primera GET.
            path = parts.path.replace('/play/embed/', '/f/embed/', 1)
            embed_url = urllib.parse.urlunsplit(parts._replace(path=path, query=urllib.parse.urlencode(params)))
        req = urllib.request.Request(embed_url, headers={'User-Agent': UA})
        with opener.open(req, timeout=12) as r:
            page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = r.geturl()
        endpoint = re.search(r'const\s+ULP_EXTRACT_URL\s*=\s*("[^"\n]+")', page)
        token = re.search(r'const\s+ULP_SESSION_TOKEN\s*=\s*("[^"\n]+")', page)
        found = re.search(r'finalizePlayer\(\s*(\{"searched_names".*?\})\s*\);', page, re.S)
        if not (endpoint and token and found):
            log_resolver('UA: no se encontro la lista de servidores')
            return None
        endpoint = json.loads(endpoint.group(1))
        if urllib.parse.urlsplit(endpoint).hostname != urllib.parse.urlsplit(referer).hostname:
            return None
        data = json.loads(found.group(1))
        # FuegoCine anuncia UA latino: no cambiar silenciosamente el idioma.
        # Algunos titulos solo tienen video en el ultimo host (Fastream).
        # Recorrer las alternativas con el mismo limite global de tiempo.
        candidates = [url for name, url in data.get('latino', {}).items()
                      if 'vidhide' not in name.lower() and urllib.parse.urlsplit(url).hostname != 'morencius.com'][:8]
        deadline = time.monotonic() + 35
        for host_url in candidates:
            if time.monotonic() >= deadline:
                break
            try:
                # Fastream firma enlaces para la conexion que extrae el video.
                # El extractor remoto de UA puede entregar una firma rechazada
                # desde Kodi; resolver localmente con su propia sesion.
                if urllib.parse.urlsplit(host_url).hostname == 'fastream.to':
                    stream = resolver_host_hls(host_url, timeout=min(6, max(1, (deadline - time.monotonic()) / 2)))
                    if stream:
                        return stream
                request = urllib.request.Request(endpoint,
                    data=json.dumps({'url': host_url}).encode('utf-8'),
                    headers={'User-Agent': UA, 'Referer': referer,
                             'Content-Type': 'application/json',
                             'X-ULP-Token': json.loads(token.group(1))})
                with opener.open(request, timeout=min(8, max(1, deadline - time.monotonic()))) as r:
                    extracted = json.loads(r.read(256 * 1024))
                streams = extracted.get('streams', [])
                if not isinstance(streams, list):
                    continue
                for media in streams[:3]:
                    if time.monotonic() >= deadline:
                        break
                    if not isinstance(media, str) or not media.startswith(('https://', 'http://')):
                        continue
                    stream = procesar_hls_local(media, extracted.get('referer') or host_url,
                        opener, timeout=min(6, max(1, deadline - time.monotonic())))
                    if stream:
                        return stream
            except Exception as exc:
                log_resolver('UA: fallo en un host ({})'.format(type(exc).__name__))
        log_resolver('UA: ningun manifiesto latino accesible')
    except Exception as exc:
        log_resolver('UA: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def hydrax_transform(data, seed):
    # Protocolo publico del player, contrastado con ResolveURL:
    # github.com/Gujal00/ResolveURL/blob/master/script.module.resolveurl/lib/resolveurl/plugins/abyss.py
    seed = str(seed)
    numeric = seed.replace('.', '', 1).replace(':', '').replace('-', '').isdigit()
    material = bytes(int(c) if c.isdigit() else ord(c) for c in seed) if numeric else seed.encode('utf-8')
    key = hashlib.md5(material).hexdigest().encode('ascii')
    return MiniAES(key).transform_ctr(data, int.from_bytes(key[:16], 'big'))


def resolver_hydrax(url):
    opener = nueva_sesion()
    headers = {'User-Agent': UA, 'Referer': url}
    with opener.open(urllib.request.Request(url, headers=headers), timeout=10) as response:
        page = response.read(1024 * 1024).decode('utf-8', 'replace')
    match = re.search(r'(?:const|var)\s+datas\s*=\s*"([^"]+)"', page)
    if not match:
        raise ServidorNoDisponible('VIP/Hydrax no entrego la configuracion del video.')
    # El player usa atob: cada byte representa un caracter, no texto UTF-8.
    data = json.loads(base64.b64decode(match.group(1)).decode('latin-1'))
    media = data.get('media')
    if isinstance(media, str):
        seed = '{user_id}:{slug}:{md5_id}'.format(**data)
        media = json.loads(hydrax_transform(bytes(ord(c) & 255 for c in media), seed))
    mp4 = media.get('mp4', {})
    sources = sorted((x for x in mp4.get('sources', []) if x.get('status') and x.get('size')),
                     key=lambda x: int(x['size']), reverse=True)
    if not sources:
        raise ServidorNoDisponible('VIP/Hydrax: no hay archivos de video disponibles.')
    source = sources[0]
    domain = next((d for d in mp4.get('domains', []) if d.startswith(source.get('sub', '') + '.')), None)
    if not domain:
        raise ServidorNoDisponible('VIP/Hydrax: falta el servidor del archivo.')
    path = '/mp4/{}/{}/{}?v={}'.format(data['md5_id'], source['res_id'], source['size'], data['slug'])
    token = base64.b64encode(base64.b64encode(hydrax_transform(path.encode('utf-8'), source['size']))).decode('ascii')
    target = 'https://{}/sora/{}/{}'.format(domain, source['size'], token)
    with opener.open(urllib.request.Request(target, headers=dict(headers, Range='bytes=0-1023')), timeout=10) as response:
        prefix = response.read(32)
        if response.status != 206 or prefix[4:8] != b'ftyp':
            raise ServidorNoDisponible('VIP/Hydrax no entrego un MP4 con soporte para adelantar.')
    # La URL carece de extension. No enviar Range fijo al reproductor.
    labels = sorted({x.get('label', '') for x in sources if re.fullmatch(r'\d+p', x.get('label', ''))},
                    key=lambda value: int(value[:-1]))
    CALIDADES_HLS[target] = ('Multirresolucion: {} (auto: {})'.format(' / '.join(labels), source.get('label', ''))
                            if len(labels) > 1 else source.get('label', ''))
    return url_con_cabeceras(target, dict(headers, ext='.mp4'), opener)


def resolver_menu_antiguo(url):
    opener = nueva_sesion()
    with opener.open(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=8) as response:
        page = response.read(1024 * 1024).decode('utf-8', 'replace')
    targets = re.findall(r"go_to_player\(['\"](https?://[^'\"]+)['\"]", page)
    supported = ('goodstream.one', 'vimeos.net', 'voe.sx', 'hglink.to', 'playmate.to', 'fastream.to', 'player.pelisserieshoy.com', 'abyssplayer.com', 'playhydrax.com')
    for target in list(dict.fromkeys(targets))[:8]:
        if urllib.parse.urlsplit(target).hostname not in supported:
            continue
        try:
            stream = resolver_enlace_directo(html.unescape(target))
            if stream:
                return stream
        except ServidorNoDisponible:
            pass
    raise ServidorNoDisponible('Este menu antiguo no ofrece un enlace compatible disponible. Elige Premium, StreamWish o VOE.')


def resolver_upns(url):
    parts = urllib.parse.urlsplit(url)
    if not parts.fragment:
        return None
    endpoint = '{}://{}/api/v1/video?{}'.format(parts.scheme, parts.netloc,
        urllib.parse.urlencode({'id': parts.fragment, 'w': 1920, 'h': 1080, 'r': 'fuegocine.com'}))
    try:
        with nueva_sesion().open(urllib.request.Request(endpoint, headers={'User-Agent': UA, 'Referer': url}), timeout=8) as response:
            data = json.loads(response.read(1024 * 1024))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise ServidorNoDisponible('US: el servidor informa que el video no existe o fue eliminado.')
        raise
    source = data.get('hls') or data.get('file') or data.get('url')
    if isinstance(source, str) and '.m3u8' in source:
        return procesar_hls_local(source, url)
    raise ServidorNoDisponible('US no ofrece un enlace de video compatible con el addon.')


def resolver_filemoon(url):
    parsed = urllib.parse.urlsplit(url)
    # The same public file codes now use the Byse frontend on the current host.
    host = 'bysefujedu.com' if parsed.hostname == 'filemoon.sx' else parsed.netloc
    code = parsed.path.rstrip('/').rsplit('/', 1)[-1]
    if not re.fullmatch(r'[a-zA-Z0-9]+', code):
        raise ServidorNoDisponible('Filemoon: enlace de video no valido.')
    endpoint = 'https://{}/api/videos/{}/embed/settings'.format(host, code)
    request = urllib.request.Request(endpoint, headers={'User-Agent': UA, 'Referer': url})
    try:
        with nueva_sesion().open(request, timeout=8) as response:
            settings = json.loads(response.read(256 * 1024))
    except Exception as exc:
        log_resolver('Filemoon: no se pudo consultar la configuracion: ' + type(exc).__name__)
        raise ServidorNoDisponible('Filemoon no pudo verificar este enlace. Prueba otro servidor.') from exc
    if settings.get('captcha_required'):
        raise ServidorNoDisponible('Filemoon exige verificacion CAPTCHA en su web. Este enlace aun no puede reproducirse directamente en Kodi.')
    stream = resolver_host_hls(url)
    if stream:
        return stream
    raise ServidorNoDisponible('El nuevo reproductor de Filemoon aun no entrega un enlace compatible con este addon.')


def resolver_dood(url):
    import secrets
    opener = nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': UA, 'Referer': url})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    endpoint = re.search(r'''['"](/pass_md5/[^'"]+)''', page)
    token = re.search(r'[?&]token=([a-zA-Z0-9]+)&expiry=', page)
    if not endpoint or not token:
        raise ServidorNoDisponible('Dood no entrega el enlace de este video o requiere verificacion en su web.')
    request = urllib.request.Request(urllib.parse.urljoin(referer, endpoint.group(1)),
                                     headers={'User-Agent': UA, 'Referer': referer})
    with opener.open(request, timeout=12) as response:
        prefix = response.read(8192).decode('utf-8', 'replace').strip()
    if not prefix.startswith(('https://', 'http://')) or '<' in prefix:
        raise ServidorNoDisponible('Dood no autorizo la reproduccion de este enlace.')
    media = prefix + secrets.token_hex(5) + '?token=' + token.group(1) + '&expiry=' + str(int(time.time() * 1000))
    return media + '|User-Agent=' + urllib.parse.quote(UA) + '&Referer=' + urllib.parse.quote(referer)


def extraer_streamtape(page, referer):
    assignment = re.search(r"getElementById\(['\"]robotlink['\"]\)\.innerHTML\s*=\s*(.*?);", page, re.S)
    if not assignment:
        return None
    expression = assignment.group(1)
    # Only read string literals and numeric substring operations; never execute JS.
    tokens = list(re.finditer(r"(['\"])((?:\\.|(?!\1).)*)\1", expression))
    values = []
    for index, token in enumerate(tokens):
        value = token.group(2).replace(r'\/', '/')
        tail = expression[token.end():tokens[index + 1].start() if index + 1 < len(tokens) else len(expression)]
        for offset in re.findall(r'\.substring\(\s*(\d+)\s*\)', tail):
            value = value[int(offset):]
        values.append(value)
    media = urllib.parse.urljoin(referer, html.unescape(''.join(values)))
    parsed = urllib.parse.urlsplit(media)
    if parsed.hostname != urllib.parse.urlsplit(referer).hostname or parsed.path != '/get_video':
        return None
    return media + '&stream=1'


def resolver_streamtape(url):
    opener = nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': UA, 'Referer': url})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    media = extraer_streamtape(page, referer)
    if not media:
        raise ServidorNoDisponible('Streamtape no entrega un enlace reproducible para este video.')
    return media + '|User-Agent=' + urllib.parse.quote(UA) + '&Referer=' + urllib.parse.quote(referer)


def resolver_mixdrop(url):
    opener = nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': UA, 'Referer': url})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    pattern = r"eval\(function\(p,a,c,k,e,[dr]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
    scripts = [page]
    for match in re.finditer(pattern, page, re.S):
        packed, radix, count, words = match.groups()
        scripts.append(unpack_js(packed, int(radix), int(count), words.split('|')))
    for script in scripts:
        match = re.search(r'MDCore\.wurl\s*=\s*[\'"]([^\'"]+)', script)
        if match:
            media = urllib.parse.urljoin(referer, match.group(1).replace(r'\/', '/'))
            return media + '|User-Agent=' + urllib.parse.quote(UA) + '&Referer=' + urllib.parse.quote(referer)
    raise ServidorNoDisponible('Mixdrop no entrega un video en este enlace; puede haber sido retirado.')


def resolver_enlace_directo(url_target):
    """
    Resuelve el stream final reproducible por Kodi para cualquier servidor.
    Soporta GoodStream, Vimeos, Google Drive, OK.RU, VIDS.ST, PelisSeriesHoy, HLS/MP4 y ResolveURL.
    """
    if not url_target:
        return None

    # Desenvolver enlaces encapsulados en parámetros como ?link= o ?r= (Base64)
    parsed = urllib.parse.urlparse(url_target)
    if 'link=' in url_target:
        q_link = urllib.parse.parse_qs(parsed.query).get('link', [''])[0]
        if q_link and q_link.startswith('http'):
            url_target = q_link
            parsed = urllib.parse.urlparse(url_target)

    # Redirecciones base64 comunes (p. ej. blogfc13.blogspot.com/?m=1.html?r=...)
    m_b64 = re.search(r'[?&]r=([a-zA-Z0-9+/=]{16,})', url_target)
    if m_b64:
        try:
            unwrapped = base64.b64decode(m_b64.group(1)).decode('utf-8', errors='ignore').strip()
            if unwrapped.startswith('http'):
                url_target = unwrapped
                parsed = urllib.parse.urlparse(url_target)
        except Exception:
            pass

    host = parsed.hostname or ''
    if host in ('filemoon.sx', 'bysefujedu.com'):
        return resolver_filemoon(url_target)
    if host in ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com', 'playmogo.com'):
        return resolver_dood(url_target)
    if host in ('streamtape.com', 'streamtape.to', 'streamtape.net', 'streamtape.cc'):
        return resolver_streamtape(url_target)
    if host in ('mixdrop.is', 'mixdrop.co', 'mixdrop.to', 'mixdrop.ag', 'mixdrop.bz', 'm1xdrop.bz'):
        return resolver_mixdrop(url_target)
    if host in ('uqload.ws', 'uqload.com', 'uqload.to', 'uqload.net', 'uqload.io'):
        return resolver_host_hls(url_target)

    # 1. GoodStream (HackStore2 / PelisJuanita)
    if parsed.hostname == 're.sololatino.net':
        return resolver_menu_antiguo(url_target)
    if parsed.hostname == 'fuegocineplayer.upns.online':
        return resolver_upns(url_target)
    if parsed.hostname in ('playhydrax.com', 'abyssplayer.com'):
        return resolver_hydrax(url_target)
    if 'goodstream' in url_target:
        return resolver_goodstream(url_target)

    # 2. Vimeos
    if parsed.hostname in ('unlimplay.com', 'www.unlimplay.com'):
        return resolver_unlimplay(url_target)
    if parsed.hostname in ('playmate.to', 'www.playmate.to'):
        return resolver_playmate(url_target)
    if 'vimeos' in url_target:
        return resolver_vimeos(url_target)

    if parsed.hostname == 'hglink.to':
        # Alias actual del mismo servicio StreamWish (ResolveURL upstream).
        return resolver_host_hls(urllib.parse.urlunparse(parsed._replace(netloc='hanerix.com')), timeout=6)
    if parsed.hostname == 'voe.sx':
        return resolver_voe(url_target)
    if parsed.hostname in ('morencius.com', 'embedwish.com', 'fastream.to', 'flaswish.com'):
        return resolver_host_hls(url_target)

    # 3. Google Drive
    if 'drive.google.com' in url_target or 'drive.usercontent.google.com' in url_target:
        return resolver_google_drive(url_target)

    # 4. OK.RU
    if 'ok.ru' in url_target:
        st_ok = resolver_ok_ru(url_target)
        if st_ok:
            return st_ok

    # 5. VIDS.ST (VST)
    if 'vids.st' in url_target:
        st_vst = resolver_vids_st(url_target)
        if st_vst:
            return st_vst

    # 6. Comprobar si ya es un stream de video directo (.m3u8, .mp4, .mpd)
    if parsed.path.lower().endswith(('.m3u8', '.mp4', '.mpd')) or '.m3u8' in url_target:
        sep = '&' if '|' in url_target else '|'
        ref = f"{parsed.scheme}://{parsed.netloc}/"
        return f"{url_target}{sep}User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote(ref)}"

    # 7. Servidor PelisSeriesHoy
    if 'pelisserieshoy' in url_target:
        st = resolver_pelisserieshoy(url_target)
        if st:
            return st

    # 8. ResolveURL si está disponible
    if resolveurl and getattr(_sondeo, 'deadline', None) is None:
        try:
            if resolveurl.relevant_resolvers(url_target):
                st = resolveurl.resolve(url_target)
                if st:
                    return st
        except Exception:
            pass

    # 9. Scraper directo con desempaquetado unpack_js
    try:
        html_src, _ = fetch_html(url_target, referer=f"{parsed.scheme}://{parsed.netloc}/")
        if html_src:
            lowered = html_src.lower()
            if any(message in lowered for message in ('video not found', 'file was deleted', 'file has been deleted')):
                raise ServidorNoDisponible('El servidor indica que el video fue eliminado o no existe.')
            m_pack = re.findall(r'eval\(function\((p,a,c,k,e,d|p,a,c,k,e,r)\)\{.*?return p\}\((.*?)\)\)', html_src, re.DOTALL)
            for _, raw_args in m_pack:
                try:
                    m_params = re.search(r"'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)", raw_args, re.DOTALL)
                    if m_params:
                        p_val, a_val, c_val, k_val = m_params.group(1), int(m_params.group(2)), int(m_params.group(3)), m_params.group(4).split('|')
                        unpacked = unpack_js(p_val, a_val, c_val, k_val)
                        m_m3u8 = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', unpacked)
                        if m_m3u8:
                            return f"{m_m3u8.group(1)}|User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote(url_target)}"
                except Exception:
                    pass

            m_src = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', html_src)
            if m_src:
                return f"{m_src.group(1)}|User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote(url_target)}"
    except ServidorNoDisponible:
        raise
    except Exception:
        pass

    return None


# =====================================================================
# PROVEEDOR 1: SOLOLATINO (Catálogo, Búsqueda, Episodios, Servidores)
# =====================================================================

def extraer_caratula_de_bloque_sololatino(bloque):
    m_tmdb = re.search(r'src=[\"\'](https?://image\.tmdb\.org/[^\"\']+)[\"\']', bloque)
    if m_tmdb and 'no-poster' not in m_tmdb.group(1):
        return m_tmdb.group(1)

    m_img = re.search(r'<img[^>]+?src=[\"\'](https?://[^\"\']+)[\"\']', bloque)
    if m_img:
        url_i = m_img.group(1)
        if 'no-poster' not in url_i:
            return url_i

    all_imgs = re.findall(r'src=[\"\'](https?://[^\"\']+)[\"\']', bloque)
    for u in all_imgs:
        if 'no-poster' not in u and ('tmdb.org' in u or 'media' in u or '.jpg' in u or '.png' in u):
            return u
    return ""


def sololatino_parsear_tarjetas(html_code, seccion_actual="peliculas", vistos_urls=None):
    if vistos_urls is None:
        vistos_urls = set()
    items_encontrados = []
    bloques = re.findall(r'<div[^>]*class=[\"\'][^\"\']*\bcard\b[^\"\']*[\"\'].*?</a>.*?</div>', html_code, re.DOTALL | re.IGNORECASE)
    for bloque in bloques:
        m_link = re.search(r'href=[\"\']([^\"\']+/(pelicula|peliculas|serie|series|tv|anime)/[^\"\']+)[\"\']', bloque, re.IGNORECASE)
        if not m_link:
            continue

        href = urllib.parse.urljoin(SOLOLATINO_BASE, m_link.group(1))
        is_serie = any(x in href for x in ['/serie/', '/series/', '/tv/', '/anime/'])

        if seccion_actual == "series" and not is_serie:
            continue
        if seccion_actual == "peliculas" and is_serie:
            continue
        if href in vistos_urls:
            continue

        vistos_urls.add(href)
        img_url = extraer_caratula_de_bloque_sololatino(bloque)

        m_title = re.search(r'alt=[\"\']([^\"\']+)[\"\']', bloque) or re.search(r'class=[\"\']card__title[\"\'][^>]*>([^<]+)<', bloque)
        titulo = limpiar_texto(m_title.group(1) if m_title else "Sin titulo")

        m_year = re.search(r'class=[\"\']card__year[\"\'][^>]*>([^<]+)<', bloque)
        year_str = limpiar_texto(m_year.group(1).strip() if m_year else "")

        m_rat = re.search(r'class=[\"\']card__rating[\"\'][^>]*>([^<]+)<', bloque)
        rating_str = limpiar_texto(m_rat.group(1).strip() if m_rat else "")

        items_encontrados.append({
            'title': titulo,
            'url': href,
            'cover': img_url,
            'is_serie': is_serie,
            'year': year_str,
            'rating': rating_str,
            'plot': "",
            'source': 'sololatino'
        })
    return items_encontrados


def sololatino_buscar(query):
    q_raw = query.strip()
    if not q_raw:
        return []
    q_norm = limpiar_texto(q_raw).lower()

    def _fetch_q(q):
        try:
            u = f"{SOLOLATINO_BASE}/api/search/suggest?q={urllib.parse.quote_plus(q)}"
            html_res, _ = fetch_html(u)
            if not html_res:
                return []
            data = json.loads(html_res)
            return data if isinstance(data, list) else []
        except Exception:
            return []

    data = _fetch_q(q_raw)
    validos = [x for x in data if isinstance(x, dict) and x.get('type') != 'person' and '/persona/' not in x.get('url', '')]

    # Palabras clave si no hay resultados directos (control de rate-limiting)
    if not validos:
        stop_words = {'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'de', 'del', 'en', 'y', 'a', 'the', 'of', 'in', 'and'}
        palabras = [p for p in re.findall(r'\w+', q_norm) if len(p) > 2 and p not in stop_words]
        if palabras:
            palabras_clave = sorted(palabras, key=len, reverse=True)[:2]
            vistos = set()
            candidatos = []
            for p in palabras_clave:
                time.sleep(0.15)
                sub_data = _fetch_q(p)
                for x in sub_data:
                    if not isinstance(x, dict) or x.get('type') == 'person' or '/persona/' in x.get('url', ''):
                        continue
                    u = x.get('url', '')
                    if u and u not in vistos:
                        vistos.add(u)
                        candidatos.append(x)
                if len(candidatos) >= 4:
                    break

            def _coincidencias(item):
                tit = (item.get('title') or '').lower()
                return sum(1 for pal in palabras if pal in tit)
            candidatos.sort(key=_coincidencias, reverse=True)
            validos = candidatos

    items_encontrados = []
    vistos = set()
    for obj in validos:
        raw_url = obj.get('url', '')
        if not raw_url:
            continue
        href = urllib.parse.urljoin(SOLOLATINO_BASE, raw_url)
        if href in vistos:
            continue
        vistos.add(href)

        tipo = obj.get('type', '')
        is_serie = any(x in href for x in ['/serie/', '/series/', '/tv/', '/anime/']) or tipo in ['series', 'tv', 'anime']
        titulo = limpiar_texto(obj.get('title') or "Sin titulo")
        year_val = obj.get('year', '')
        year_str = str(year_val).strip() if year_val is not None else ""
        poster = obj.get('poster') or ""

        items_encontrados.append({
            'title': titulo,
            'url': href,
            'cover': poster,
            'is_serie': is_serie,
            'year': year_str,
            'rating': "",
            'plot': "",
            'source': 'sololatino'
        })
    return items_encontrados


def sololatino_obtener_servidores(url_pagina, premium_only=False):
    servidores = []
    try:
        html_csrf, cookies = fetch_html(f"{SOLOLATINO_BASE}/sanctum/csrf-cookie")
        cookie_str = "; ".join([c.split(';')[0] for c in cookies])
        xsrf_token = ""
        for c in cookies:
            m = re.search(r'XSRF-TOKEN=([^;]+)', c)
            if m:
                xsrf_token = urllib.parse.unquote(m.group(1))

        html_page, _ = fetch_html(url_pagina, cookie_str)
        btns = re.findall(r'<button[^>]*data-player-token=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</button>', html_page, re.DOTALL)

        headers_api = {
            'Content-Type': 'application/json', 'Accept': 'application/json',
            'X-XSRF-TOKEN': xsrf_token, 'Cookie': cookie_str,
            'Origin': SOLOLATINO_BASE, 'Referer': url_pagina, 'User-Agent': UA
        }

        # Consultar cada boton una sola vez. PREMIUM no oculta los otros hosts.
        vistos = set()
        for tok, label in btns:
            try:
                req_api = urllib.request.Request(
                    f"{SOLOLATINO_BASE}/api/player-url",
                    data=json.dumps({'t': tok}).encode('utf-8'), headers=headers_api)
                with abrir_url(req_api, timeout=7, context=_ssl_ctx) as r_api:
                    url_player = json.loads(r_api.read().decode('utf-8')).get('url')
                if not url_player or url_player in vistos:
                    continue
                vistos.add(url_player)
                if premium_only and 'pelisserieshoy' not in url_player:
                    continue
                if 'pelisserieshoy' in url_player:
                    servidores.append({'nombre': 'PREMIUM (Mediafire - Alta Velocidad)', 'url': url_player})
                elif 'embed69' in url_player or 'xupalace' in url_player:
                    sub = resolver_embed69_hosts(url_player)
                    servidores.extend(sub or [{'nombre': 'Servidor Alternativo', 'url': url_player}])
                else:
                    nombre = limpiar_texto(re.sub(r'<[^>]+>', ' ', html.unescape(label)))
                    servidores.append({'nombre': nombre or urllib.parse.urlsplit(url_player).hostname,
                                       'url': url_player})
            except Exception as exc:
                log_resolver('SoloLatino: fallo al obtener un servidor ({})'.format(type(exc).__name__))
        servidores.sort(key=lambda item: 'pelisserieshoy' not in item['url'])

    except Exception:
        pass

    if not servidores:
        try:
            html_p, _ = fetch_html(url_pagina)
            m_id = re.search(r'(tt\d{7,10}(?:-\d+x\d+)?)', html_p) or re.search(r'data-id=[\"\']([^\"\']+)[\"\']', html_p)
            if m_id:
                servidores.append({'nombre': 'PREMIUM (Mediafire - Alta Velocidad)', 'url': f'https://player.pelisserieshoy.com/f/{m_id.group(1)}'})
        except Exception:
            pass

    return servidores


def sololatino_obtener_temporadas_episodios(serie_url, serie_obj=None):
    html_page, _ = fetch_html(serie_url)
    if not html_page:
        return {}

    episodios_por_temporada = {}
    pattern_ep = r'<a[^>]+href=[\"\']([^\"\']+/temporada-(\d+)/episodio-(\d+)[^\"\']*)[\"\'][^>]*>(.*?)</a>'
    matches = re.findall(pattern_ep, html_page, re.DOTALL | re.IGNORECASE)
    cover_base = serie_obj.get('cover', '') if serie_obj else ''

    for href, num_t, num_e, inner in matches:
        m_name = re.search(r'<p[^>]*class=[\"\'][^\"\']*text-sm[^\"\']*font-semibold[^\"\']*[\"\'][^>]*>\s*(.*?)\s*</p>', inner, re.DOTALL)
        raw_name = limpiar_texto(m_name.group(1).strip() if m_name else "")

        m_plot = re.search(r'<p[^>]*class=[\"\'][^\"\']*line-clamp-2[^\"\']*[\"\'][^>]*>\s*(.*?)\s*</p>', inner, re.DOTALL)
        raw_plot = limpiar_texto(m_plot.group(1).strip() if m_plot else "")

        m_thumb = re.search(r'<img[^>]+?src=[\"\'](https?://[^\"\']+)[\"\']', inner)
        thumb = m_thumb.group(1) if m_thumb else cover_base

        ep_label = f"T{num_t}:E{num_e} - {raw_name}" if raw_name else f"T{num_t}:E{num_e} Episodio {num_e}"
        episodios_por_temporada.setdefault(str(num_t), []).append({
            'title': ep_label,
            'name': raw_name,
            'url': urllib.parse.urljoin(SOLOLATINO_BASE, href),
            'cover': thumb,
            'season': str(num_t),
            'episode': str(num_e),
            'plot': raw_plot,
            'is_serie': True,
            'source': 'sololatino'
        })
    return episodios_por_temporada


# =====================================================================
# PROVEEDOR 2: HACKSTORE2 (API REST TMDB, Catálogo, Episodios, Servidores)
# =====================================================================

def hackstore_api(path, params=None):
    url = HACKSTORE_API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Accept': 'application/json,text/html;q=0.9,*/*;q=0.8',
        'Referer': f"{HACKSTORE_SITE}/",
    })
    with abrir_url(req, timeout=12, context=_ssl_ctx) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def hackstore_parse_url(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != 'hack' or parsed.netloc not in HACKSTORE_KINDS:
        raise ValueError('URL HackStore2 inválida')
    parts = [x for x in parsed.path.split('/') if x]
    if not parts or not parts[0].isdigit():
        raise ValueError('ID HackStore2 inválido')
    kind, tmdb_id = parsed.netloc, int(parts[0])
    if len(parts) == 1:
        return kind, tmdb_id, None, None
    if len(parts) == 3 and parts[1].startswith('temporada-') and parts[2].startswith('episodio-'):
        season, episode = parts[1][10:], parts[2][9:]
        if season.isdigit() and episode.isdigit():
            return kind, tmdb_id, int(season), int(episode)
    raise ValueError('Episodio HackStore2 inválido')


def hackstore_item(obj):
    kind = obj.get('kind', '')
    tmdb_id = obj.get('tmdb_id')
    if kind not in HACKSTORE_KINDS or not isinstance(tmdb_id, int):
        return None
    poster = obj.get('poster_path') or ''
    return {
        'title': limpiar_texto(obj.get('title') or obj.get('original_title') or 'Sin título'),
        'url': f'hack://{kind}/{tmdb_id}',
        'cover': 'https://image.tmdb.org/t/p/w500' + poster if poster else '',
        'is_serie': kind != 'movie',
        'year': str(obj.get('year') or '').strip(),
        'rating': str(obj.get('vote_average') or '').strip(),
        'plot': limpiar_texto(obj.get('overview') or ''),
        'genres': content_metadata.genres(obj.get('genres') or []),
        'source': 'hackstore2',
        'kind': kind,
        'tmdb_id': tmdb_id,
    }


def hackstore_catalog(kind, page=1):
    if kind not in HACKSTORE_KINDS or page < 1:
        raise ValueError('Categoría HackStore2 inválida')
    data = hackstore_api('/v1/items', {'kind': kind, 'page': page, 'limit': HACKSTORE_PAGE_SIZE})
    items = [hackstore_item(obj) for obj in data.get('items', [])]
    return [obj for obj in items if obj], bool(data.get('pagination', {}).get('has_next'))


def hackstore_search(query):
    query = query.strip()
    if not query:
        return []
    try:
        data = hackstore_api('/v1/search', {'q': query, 'limit': 30})
        items = [hackstore_item(obj) for obj in data.get('items', [])]
        return [obj for obj in items if obj]
    except Exception:
        return []


def hackstore_episodes(series_url):
    kind, tmdb_id, _, _ = hackstore_parse_url(series_url)
    if kind == 'movie':
        return {}
    data = hackstore_api(f'/v1/items/{kind}/{tmdb_id}/seasons')
    result = {}
    for season in data.get('seasons', []):
        number = season.get('season')
        if not isinstance(number, int) or not season.get('available_count'):
            continue
        try:
            season_data = hackstore_api(f'/v1/items/{kind}/{tmdb_id}/seasons/{number}').get('season', {})
            entries = []
            for ep in season_data.get('episodes', []):
                ep_number = ep.get('episode')
                if not isinstance(ep_number, int) or not ep.get('playable'):
                    continue
                still = ep.get('still_path') or ''
                ep_tit = limpiar_texto(ep.get('title') or f'Episodio {ep_number}')
                entries.append({
                    'title': f'T{number}:E{ep_number} - {ep_tit}',
                    'name': ep_tit,
                    'url': f'hack://{kind}/{tmdb_id}/temporada-{number}/episodio-{ep_number}',
                    'cover': 'https://image.tmdb.org/t/p/w500' + still if still else '',
                    'season': str(number),
                    'episode': str(ep_number),
                    'plot': limpiar_texto(ep.get('overview') or ''),
                    'year': content_metadata.fields(ep)['year'],
                    'is_serie': True,
                    'source': 'hackstore2',
                })
            if entries:
                entries.sort(key=lambda entry: int(entry['episode']))
                result[str(number)] = entries
        except Exception:
            pass
    return result


def hackstore_servers(video_url):
    result = []
    try:
        kind, tmdb_id, season, episode = hackstore_parse_url(video_url)
        params = {'season': season, 'episode': episode} if season is not None else None
        data = hackstore_api(f'/v1/playback/{kind}/{tmdb_id}', params)
        for embed in data.get('embeds', []):
            url = embed.get('url') or ''
            if not url.startswith(('https://', 'http://')):
                continue
            h_name = embed.get('host') or embed.get('server') or 'Servidor'
            qual = embed.get('quality') or ''
            lang = embed.get('lang') or ''
            if 'goodstream' in url:
                label = f"GoodStream HLS ({lang})".strip()
            elif 'vimeos.net' in url:
                label = f"Vimeos HLS ({lang})".strip()
            else:
                label = f"{h_name} {qual} ({lang})".strip()
            result.append({
                'nombre': limpiar_texto(label),
                'url': url,
                'host': embed.get('host') or ''
            })
        # Priorizar GoodStream y Vimeos
        def _hs_prio(s):
            u = s['url'].lower()
            if 'goodstream.one' in u:
                return 0
            if 'vimeos.net' in u:
                return 1
            return 2
        result.sort(key=_hs_prio)
    except Exception:
        pass
    return result


# =====================================================================
# PROVEEDOR 3: PELISJUANITA (API REST TMDB, Catálogo, Episodios, Servidores)
# =====================================================================

def pelisjuanita_api(path, params=None):
    url = PELISJUANITA_API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Accept': 'application/json,text/html;q=0.9,*/*;q=0.8',
        'Referer': f"{PELISJUANITA_SITE}/",
    })
    with abrir_url(req, timeout=12, context=_ssl_ctx) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def pelisjuanita_parse_url(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != 'juanita' or parsed.netloc not in PELISJUANITA_KINDS:
        raise ValueError('URL PelisJuanita inválida')
    parts = [x for x in parsed.path.split('/') if x]
    if not parts or not parts[0].isdigit():
        raise ValueError('ID PelisJuanita inválido')
    kind, tmdb_id = parsed.netloc, int(parts[0])
    if len(parts) == 1:
        return kind, tmdb_id, None, None
    if len(parts) == 3 and parts[1].startswith('temporada-') and parts[2].startswith('episodio-'):
        season, episode = parts[1][10:], parts[2][9:]
        if season.isdigit() and episode.isdigit():
            return kind, tmdb_id, int(season), int(episode)
    raise ValueError('Episodio PelisJuanita inválido')


def pelisjuanita_item(obj):
    kind = obj.get('kind', '')
    tmdb_id = obj.get('tmdb_id')
    if kind not in PELISJUANITA_KINDS or not isinstance(tmdb_id, int):
        return None
    poster = obj.get('poster_path') or ''
    return {
        'title': limpiar_texto(obj.get('title') or obj.get('original_title') or 'Sin título'),
        'url': f'juanita://{kind}/{tmdb_id}',
        'cover': 'https://image.tmdb.org/t/p/w500' + poster if poster else '',
        'is_serie': kind != 'movie',
        'year': str(obj.get('year') or '').strip(),
        'rating': str(obj.get('vote_average') or '').strip(),
        'plot': limpiar_texto(obj.get('overview') or ''),
        'genres': content_metadata.genres(obj.get('genres') or []),
        'source': 'pelisjuanita',
        'kind': kind,
        'tmdb_id': tmdb_id,
    }


def pelisjuanita_catalog(kind, page=1):
    if kind not in PELISJUANITA_KINDS or page < 1:
        raise ValueError('Categoría PelisJuanita inválida')
    data = pelisjuanita_api('/v1/items', {'kind': kind, 'page': page, 'limit': PELISJUANITA_PAGE_SIZE})
    items = [pelisjuanita_item(obj) for obj in data.get('items', [])]
    return [obj for obj in items if obj], bool(data.get('pagination', {}).get('has_next'))


def pelisjuanita_search(query):
    query = query.strip()
    if not query:
        return []
    try:
        data = pelisjuanita_api('/v1/search', {'q': query, 'limit': 30})
        items = [pelisjuanita_item(obj) for obj in data.get('items', [])]
        return [obj for obj in items if obj]
    except Exception:
        return []


def pelisjuanita_episodes(series_url):
    kind, tmdb_id, _, _ = pelisjuanita_parse_url(series_url)
    if kind == 'movie':
        return {}
    data = pelisjuanita_api(f'/v1/items/{kind}/{tmdb_id}/seasons')
    result = {}
    for season in data.get('seasons', []):
        number = season.get('season')
        if not isinstance(number, int) or not season.get('available_count'):
            continue
        try:
            season_data = pelisjuanita_api(f'/v1/items/{kind}/{tmdb_id}/seasons/{number}').get('season', {})
            entries = []
            for ep in season_data.get('episodes', []):
                ep_number = ep.get('episode')
                if not isinstance(ep_number, int) or not ep.get('playable'):
                    continue
                still = ep.get('still_path') or ''
                ep_tit = limpiar_texto(ep.get('title') or f'Episodio {ep_number}')
                entries.append({
                    'title': f'T{number}:E{ep_number} - {ep_tit}',
                    'name': ep_tit,
                    'url': f'juanita://{kind}/{tmdb_id}/temporada-{number}/episodio-{ep_number}',
                    'cover': 'https://image.tmdb.org/t/p/w500' + still if still else '',
                    'season': str(number),
                    'episode': str(ep_number),
                    'plot': limpiar_texto(ep.get('overview') or ''),
                    'year': content_metadata.fields(ep)['year'],
                    'is_serie': True,
                    'source': 'pelisjuanita',
                })
            if entries:
                entries.sort(key=lambda entry: int(entry['episode']))
                result[str(number)] = entries
        except Exception:
            pass
    return result


def pelisjuanita_servers(video_url):
    result = []
    try:
        kind, tmdb_id, season, episode = pelisjuanita_parse_url(video_url)
        params = {'season': season, 'episode': episode} if season is not None else None
        data = pelisjuanita_api(f'/v1/playback/{kind}/{tmdb_id}', params)
        for embed in data.get('embeds', []):
            url = embed.get('url') or ''
            if not url.startswith(('https://', 'http://')):
                continue
            h_name = embed.get('host') or embed.get('server') or 'Servidor'
            qual = embed.get('quality') or ''
            lang = embed.get('lang') or ''
            if 'goodstream' in url:
                label = f"GoodStream HLS ({lang})".strip()
            elif 'vimeos' in url or 'unlimplay' in url:
                label = f"Vimeos HLS ({lang})".strip()
            else:
                label = f"{h_name} {qual} ({lang})".strip()
            result.append({
                'nombre': limpiar_texto(label),
                'url': url,
                'host': embed.get('host') or ''
            })
        def _pj_prio(s):
            u = s['url'].lower()
            if 'goodstream.one' in u:
                return 0
            if 'vimeos.net' in u:
                return 1
            return 2
        result.sort(key=_pj_prio)
    except Exception:
        pass
    return result


# =====================================================================
# PROVEEDOR 4: FUEGOCINE (Blogger Feed API, Catálogo, Episodios, Servidores)
# =====================================================================

def fuegocine_get(url):
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Accept': 'application/json,text/html;q=0.9,*/*;q=0.8',
        'Referer': f"{FUEGOCINE_BASE}/",
    })
    with abrir_url(req, timeout=15, context=_ssl_ctx) as response:
        return response.read().decode('utf-8', 'replace')


def fuegocine_feed(label=None, query=None, start=1, limit=FUEGOCINE_PAGE_SIZE):
    if label:
        path = '/feeds/posts/default/-/' + urllib.parse.quote(label, safe='-')
    else:
        path = '/feeds/posts/default'
    params = {'alt': 'json', 'start-index': str(start), 'max-results': str(limit)}
    if query:
        params['q'] = query
    url = f"{FUEGOCINE_BASE}{path}?{urllib.parse.urlencode(params)}"
    return json.loads(fuegocine_get(url)).get('feed', {})


def fuegocine_attr(source, name):
    match = re.search(r'\b' + re.escape(name) + r'=[\'\"]([^\'\"]*)[\'\"]', source, re.I)
    return html.unescape(match.group(1)) if match else ''


def fuegocine_entry_item(entry):
    labels = {x.get('term', '') for x in entry.get('category', [])}
    if 'Episode' in labels:
        return None
    url = next((x.get('href', '') for x in entry.get('link', []) if x.get('rel') == 'alternate'), '')
    if not url or urllib.parse.urlparse(url).hostname != 'www.fuegocine.com':
        return None

    content = entry.get('content', {}).get('$t', '')
    summary = re.search(r'<p\b[^>]*id=[\'\"]tmdb-synopsis[\'\"][^>]*>(.*?)</p>', content, re.I | re.S)
    cover = re.search(r'<div\b[^>]*data-post-type=[\'\"][^\'\"]+[\'\"][^>]*>\s*<img\b[^>]*>', content, re.I | re.S)
    image = fuegocine_attr(cover.group(0), 'src') if cover else entry.get('media$thumbnail', {}).get('url', '')
    year = fuegocine_attr(content, 'data-year') or (re.search(r'\((\d{4})\)', entry.get('title', {}).get('$t', '')) or [None, ''])[1]
    rating = fuegocine_attr(content, 'data-imdb')

    # Detección precisa de Serie vs Película (evita bug de clasificar películas de anime como series)
    m_ptype = re.search(r'data-post-type=[\'\"]([^\'\"]+)[\'\"]', content, re.I)
    ptype = m_ptype.group(1).lower() if m_ptype else ''
    title_raw = html.unescape(entry.get('title', {}).get('$t', '')).strip()

    if ptype == 'serie':
        is_serie = True
    elif ptype == 'movie':
        is_serie = False
    elif 'Movie' in labels:
        is_serie = False
    elif 'Serie' in labels or 'temporadas' in title_raw.lower():
        is_serie = True
    else:
        is_serie = False

    return {
        'title': limpiar_texto(title_raw),
        'url': url,
        'cover': image,
        'is_serie': is_serie,
        'year': str(year).strip() if year else '',
        'rating': str(rating).strip() if rating else '',
        'plot': limpiar_texto(re.sub(r'<[^>]+>', '', summary.group(1))) if summary else '',
        'genres': content_metadata.genres(fuegocine_attr(content, 'data-genres').split(',')),
        'source': 'fuegocine',
    }


def fuegocine_catalogo(label, page=1):
    if label not in ('Movie', 'Serie', 'Anime') or page < 1:
        raise ValueError('Categoría no válida')
    feed = fuegocine_feed(label=label, start=(page - 1) * FUEGOCINE_PAGE_SIZE + 1)
    items = [fuegocine_entry_item(e) for e in feed.get('entry', [])]
    return [i for i in items if i]


def fuegocine_buscar(query, limit=30):
    query = query.strip()
    if not query:
        return []
    feed = fuegocine_feed(query=query, limit=limit)
    items = [fuegocine_entry_item(e) for e in feed.get('entry', [])]
    return [i for i in items if i]


def fuegocine_obtener_temporadas_episodios(series_url, limit=450):
    page = fuegocine_get(series_url)
    match = re.search(r'<article\b[^>]*data-post-id=[\'\"](\d+)[\'\"]', page, re.I)
    if not match:
        return {}
    post_id = match.group(1)
    result = {}
    start = 1
    while start <= limit:
        entries = fuegocine_feed(label='id-' + post_id, start=start, limit=min(150, limit - start + 1)).get('entry', [])
        if not entries:
            break
        for entry in entries:
            body = entry.get('content', {}).get('$t', '')
            season = fuegocine_attr(body, 'data-season-number')
            episode = fuegocine_attr(body, 'data-episode-count')
            if not season or not episode:
                title = entry.get('title', {}).get('$t', '')
                numbers = re.search(r'(\d+)\s*x\s*(\d+)', title, re.I)
                if numbers:
                    season, episode = numbers.groups()
            if not season or not episode:
                continue
            url = next((x.get('href', '') for x in entry.get('link', []) if x.get('rel') == 'alternate'), '')
            if not url:
                continue
            synopsis = re.search(r'<p\b[^>]*id=[\'\"]tmdb-synopsis[\'\"][^>]*>(.*?)</p>', body, re.I | re.S)
            title = limpiar_texto(entry.get('title', {}).get('$t', ''))
            item = {
                'title': f"T{season}:E{episode} - {title}",
                'name': title,
                'url': url,
                'season': str(season),
                'episode': str(episode),
                'cover': fuegocine_attr(body, 'data-backdrop'),
                'plot': limpiar_texto(re.sub(r'<[^>]+>', '', synopsis.group(1))) if synopsis else '',
                'is_serie': True,
                'source': 'fuegocine',
            }
            result.setdefault(str(season), []).append(item)
        start += len(entries)
        if len(entries) < 150:
            break

    for values in result.values():
        values.sort(key=lambda x: int(x['episode']) if x['episode'].isdigit() else 0)
    return result


def _es_reproducible_fuego(s_url):
    u = s_url.lower()
    return any(k in u for k in ['drive.google.com', 'drive.usercontent.google.com', 'ok.ru', 'vids.st', 'repfuegocinefree', 'archive.org', '1a-1791.com', '.m3u8', '.mp4'])


def fuegocine_obtener_servidores(page_url):
    page = fuegocine_get(page_url)
    match = re.search(r'\bconst\s+_SV_LINKS\s*=\s*\[(.*?)\]\s*;?', page, re.I | re.S)
    if not match:
        return []
    result = []
    for block in re.findall(r'\{([^{}]*)\}', match.group(1), re.S):
        values = dict((key, html.unescape(value)) for key, value in
                      re.findall(r'\b(lang|name|quality|url)\s*:\s*[\'\"]([^\'\"]*)[\'\"]', block, re.I))
        url = values.get('url', '').strip()
        if url.startswith(('https://', 'http://')):
            nom_raw = values.get('name', 'Servidor')
            qual = values.get('quality', '')
            lang = values.get('lang', '')

            if 'drive.google.com' in url:
                nombre = f"Google Drive {qual} ({lang})"
            elif 'ok.ru' in url:
                nombre = f"OK.RU Alta Velocidad {qual} ({lang})"
            elif 'vids.st' in url or 'vst' in nom_raw.lower():
                nombre = f"VIDS Dual Audio {qual} ({lang})"
            elif 'repfuegocinefree' in url:
                target = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).get('link', [''])[0]
                host = urllib.parse.urlsplit(target).hostname or 'Directo'
                if host.endswith('.rumble.cloud') or host == '1a-1791.com':
                    host = 'Rumble'
                elif host == 'files.eintim.me':
                    host = 'Eintim'
                nombre = f"FuegoCine {host} {qual} ({lang})"
            else:
                nombre = f"{nom_raw} {qual} ({lang})"

            nom_limpio = limpiar_texto(nombre)
            result.append({
                'nombre': nom_limpio or "Servidor FuegoCine",
                'url': url
            })

    result.sort(key=lambda s: not _es_reproducible_fuego(s['url']))
    return result


# =====================================================================
# API PÚBLICA UNIFICADA (Para consumo directo de main.py)
# =====================================================================

def es_url_hackstore(url):
    return str(url).startswith('hack://')


def es_url_pelisjuanita(url):
    return str(url).startswith('juanita://')


def es_url_fuegocine(url):
    return 'fuegocine' in str(url) or 'fuego://' in str(url)

def es_url_pelisflix(url):
    return 'pelisflix' in str(url)


def buscar_unificado(query):
    """
    Busca de forma coordinada en SoloLatino, HackStore2, PelisJuanita y FuegoCine,
    unificando resultados y eliminando duplicados.
    """
    query = query.strip()
    if not query:
        return []

    resultados = []
    urls_vistas = set()

    # 1. SoloLatino
    try:
        for it in sololatino_buscar(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    # 2. HackStore2
    try:
        for it in hackstore_search(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    # 3. PelisJuanita
    try:
        for it in pelisjuanita_search(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    # 4. FuegoCine
    try:
        for it in fuegocine_buscar(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    return resultados


def obtener_episodios(serie_obj):
    """
    Obtiene temporadas y episodios detectando el proveedor (SoloLatino, HackStore2, PelisJuanita o FuegoCine).
    """
    import doramas
    if doramas.is_dorama(serie_obj):
        return doramas.episodes(serie_obj)
    u = serie_obj.get('url', '')
    if es_url_hackstore(u):
        return hackstore_episodes(u)
    elif es_url_pelisjuanita(u):
        return pelisjuanita_episodes(u)
    elif es_url_fuegocine(u):
        return fuegocine_obtener_temporadas_episodios(u)
    elif es_url_pelisflix(u):
        return pelisflix_episodes(u)
    else:
        return sololatino_obtener_temporadas_episodios(u, serie_obj)


def ordenar_servidores_por_calidad(lista_servidores):
    # Drive queda descartado por decision del usuario. Filtrar tambien los
    # enlaces encapsulados en el reproductor de FuegoCine.
    lista_servidores = [s for s in lista_servidores if not (
        'google drive' in s.get('nombre', '').lower() or
        'vidhide' in s.get('nombre', '').lower() or
        urllib.parse.urlsplit(s.get('url', '')).hostname == 'morencius.com' or
        any(host in urllib.parse.unquote(s.get('url', '')).lower()
            for host in ('drive.google.com', 'drive.usercontent.google.com')))]
    def _prio(s):
        nom = s.get('nombre', '').lower()
        u = s.get('url', '').lower()
        # 1. PREMIUM Mediafire (el más rápido y con mayor tasa de éxito comprobada)
        if 'premium' in nom or 'mediafire' in nom or 'pelisserieshoy' in u:
            return 0
        # 3. FuegoCine Directo / Archive.org / Videro
        if 'archive.org' in u or 'directo' in nom or 'videro' in u:
            return 2
        # 4. OK.RU
        if 'ok.ru' in u or 'ok.ru' in nom:
            return 3
        # 5. VIDS Dual Audio
        if 'vids.st' in u or 'vids' in nom:
            return 4
        # 6. GoodStream / Vimeos (HackStore / PelisJuanita)
        if 'goodstream' in u or 'vimeos' in u:
            return 5
        # 7. Otros servidores
        return 6
    lista_servidores.sort(key=_prio)
    return lista_servidores


def titulo_coincide(a, b):
    def normalizar(value):
        import unicodedata
        value = re.sub(r'^T\d+:E\d+\s*-\s*', '', value, flags=re.I)
        value = re.sub(r'\s+\d+x\d+\s*$', '', value, flags=re.I)
        value = re.sub(r'\(\d{4}\)|\s*-?\s*(?:todas?\s+las?\s+)?\btemporadas?\b.*$', '', value, flags=re.I)
        value = ''.join(c for c in unicodedata.normalize('NFKD', value) if not unicodedata.combining(c))
        return re.sub(r'[^a-z0-9]', '', value.lower())
    return bool(normalizar(a)) and normalizar(a) == normalizar(b)


def obtener_servidores_video(url_video, titulo=""):
    """
    Extrae los servidores disponibles según el proveedor:
    - HackStore2: GoodStream, Vimeos (con enriquecimiento prioritario de SoloLatino PREMIUM).
    - PelisJuanita: GoodStream, Vimeos (con enriquecimiento prioritario de SoloLatino PREMIUM).
    - FuegoCine: Google Drive, OK.RU, VIDS, Directos (con enriquecimiento prioritario de SoloLatino PREMIUM).
    - SoloLatino: PREMIUM Mediafire, PelisSeriesHoy.
    """
    servidores = []
    if es_url_hackstore(url_video):
        servidores = hackstore_servers(url_video)
    elif es_url_pelisjuanita(url_video):
        servidores = pelisjuanita_servers(url_video)
    elif es_url_fuegocine(url_video):
        servidores = fuegocine_obtener_servidores(url_video)
    elif es_url_pelisflix(url_video):
        servidores = pelisflix_servers(url_video)
    else:
        servidores = sololatino_obtener_servidores(url_video)

    # Enriquecimiento universal con SoloLatino PREMIUM si tenemos título y no está ya incluido
    tiene_premium = any('premium' in s.get('nombre', '').lower() or 'pelisserieshoy' in s.get('url', '').lower() for s in servidores)
    if titulo and not tiene_premium:
        try:
            tit_clean = re.sub(r'T\d+:E\d+\s*-\s*', '', titulo).strip()
            tit_clean = re.sub(r'\(\d{4}\)', '', tit_clean).strip()
            tit_clean = re.sub(r'\s+\d+x\d+\s*$', '', tit_clean).strip()
            m_ep = re.search(r'T(\d+):E(\d+)', titulo)
            if tit_clean:
                sol_cands = sololatino_buscar(tit_clean)
                sol_cands = [c for c in sol_cands if titulo_coincide(c.get('title', ''), tit_clean)]
                if sol_cands:
                    mejor = sol_cands[0]
                    if m_ep:
                        t_num, e_num = m_ep.group(1), m_ep.group(2)
                        eps_sol = sololatino_obtener_temporadas_episodios(mejor['url'])
                        ep_list = eps_sol.get(str(t_num), [])
                        for ep_it in ep_list:
                            if str(ep_it.get('episode')) == str(e_num):
                                srvs_sol = sololatino_obtener_servidores(ep_it['url'])
                                servidores = srvs_sol + servidores
                                break
                    else:
                        srvs_sol = sololatino_obtener_servidores(mejor['url'])
                        servidores = srvs_sol + servidores
        except Exception:
            pass

    return ordenar_servidores_por_calidad(servidores)



def resolver_stream(url_servidor):
    """
    Resuelve el enlace directo reproducible por Kodi.
    """
    if url_servidor.startswith('dorama://player?'):
        import doramas
        url_servidor = doramas.resolve(url_servidor)
    return resolver_enlace_directo(url_servidor)


import re
import urllib.parse
from html import unescape


PELISFLIX_PELISFLIX_BASE_URL = 'https://pelisflix200.store'

def _pelisflix_pelisflix_fetch(path, params=None):
    url = urllib.parse.urljoin(PELISFLIX_BASE_URL, path)
    if params:
        url += '?' + urllib.parse.urlencode(params)
    html, _ = fetch_html(url)
    return html

def _pelisflix_pelisflix_parse_items(html):
    items = []
    articles = re.findall(r'<article[^>]*>(.*?)</article>', html, re.DOTALL)
    
    for art in articles:
        url_m = re.search(r'<a\s+href="([^"]+)"', art)
        title_m = re.search(r'<h[23][^>]*>(.*?)</h[23]>', art)
        if not title_m:
            title_m = re.search(r'alt="([^"]+)"', art)
            
        img_m = re.search(r'<img\s+[^>]*data-src="([^"]+)"', art)
        if not img_m:
            img_m = re.search(r'<img\s+[^>]*src="([^"]+)"', art)
            
        if url_m and title_m:
            url = url_m.group(1)
            title = limpiar_texto(unescape(re.sub(r'<[^>]+>', '', title_m.group(1))))
            cover = img_m.group(1) if img_m else ''
            
            if not url.startswith('http'):
                url = urllib.parse.urljoin(PELISFLIX_BASE_URL, url)
            if cover and not cover.startswith('http'):
                cover = urllib.parse.urljoin(PELISFLIX_BASE_URL, cover)
                
            is_serie = '/serie/' in url or '/episodio/' in url or '/temporada/' in url
            itemappend({
                'title': title,
                'url': url,
                'cover': cover,
                'is_serie': is_serie,
                'source': 'pelisflix'
            })
    return items

def pelisflix_search(query):
    html = _pelisflix_fetch('/', {'s': query})
    return _pelisflix_parse_items(html)

def pelisflix_catalog(kind, page=1):
    path = '/series' if kind == 'series' else '/peliculas'
    if page > 1:
        path += f'/page/{page}/'
    html = _pelisflix_fetch(path)
    return _pelisflix_parse_items(html)

def pelisflix_episodes(series_url):
    html = _pelisflix_fetch(series_url)
    items = []
    
    # Encontrar paginas de temporadas
    season_urls = set(re.findall(r'<a\s+href="([^"]+/temporada/[^"]+)"', html))
    if not season_urls:
        season_urls = [series_url] # Fallback
        
    vistos = set()
    for s_url in season_urls:
        if not s_url.startswith('http'):
            s_url = urllib.parse.urljoin(PELISFLIX_BASE_URL, s_url)
        s_html = _pelisflix_fetch(s_url) if s_url != series_url else html
        
        # Buscar episodios directamente por url (.../episodio/...-1x1/)
        eps_urls = set(re.findall(r'<a\s+href="([^"]+/episodio/[^"]+-(\d+)x(\d+)/?)"', s_html))
        for url, season, episode in eps_urls:
            if not url.startswith('http'):
                url = urllib.parse.urljoin(PELISFLIX_BASE_URL, url)
            if url in vistos:
                continue
            vistoadd(url)
            itemappend({
                'title': f'{season}x{episode}',
                'url': url,
                'is_serie': True,
                'season': int(season),
                'episode': int(episode),
                'source': 'pelisflix'
            })
            
    grouped = {}
    for item in sorted(items, key=lambda x: (x['season'], x['episode'])):
        s_key = str(item['season'])
        if s_key not in grouped:
            grouped[s_key] = []
        grouped[s_key].append(item)
    return grouped

def pelisflix_servers(url):
    html = _pelisflix_fetch(url)
    import base64
    servidores = []
    urls_vistas = set()
    
    # Data URLs from nupload/iframes
    data_urls = set(re.findall(r'data-url="([^"]+)"', html))
    for data in data_urls:
        try:
            data += '=' * (-len(data) % 4)
            dec = base64.b64decode(data).decode('utf-8')
            if 'nupload.my' in dec:
                u_parsed = urllib.parse.urlsplit(dec)
                qs = urllib.parse.parse_qs(u_parsed.query)
                if 'url' in qs:
                    target = qs['url'][0]
                    if target not in urls_vistas:
                        urls_vistaadd(target)
                        servidoreappend({
                            'nombre': urllib.parse.urlsplit(target).hostname or 'Servidor',
                            'url': target
                        })
        except Exception:
            pass
            
    iframes = re.findall(r'<iframe[^>]*src="([^"]+)"', html)
    for iframe in iframes:
        if iframe not in urls_vistas and 'pelisflix' not in iframe:
            urls_vistaadd(iframe)
            servidoreappend({
                'nombre': urllib.parse.urlsplit(iframe).hostname or 'Servidor',
                'url': iframe
            })

    # Return sorting is not strictly needed as Vaquexflix usually sorts later
    return servidores
