"""Catalogo visible unico; las rutas originales se conservan como alternativas."""
import network
import re
import unicodedata
from difflib import SequenceMatcher
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit, parse_qs
import servidores as s
import doramas
import servidores as cinecalidad
from provider_cache import SearchResults


def title(value):
    value = re.sub(r'\s*-?\s*(?:todas?\s+las?\s+)?temporadas?\b.*$', '', value, flags=re.I)
    return re.sub(r'\s*\(\d{4}(?:\s*-\s*\d{4})?\)\s*$', '', value).strip()

def display_title(item, label=None):
    text = label if label is not None else item.get('title', '')
    import servidores as tubi
    if not tubi.tubi_is_available():
        return re.sub(r'\s*\[US VPN\]\s*', '', text).strip()
    if '[US VPN]' not in text and any(v.get('source') == 'tubi' or tubi.tubi_owns(v.get('url', '')) for v in variants(item)):
        return f"{text} [US VPN]"
    return text


def same(a, b):
    if doramas.is_dorama(a) != doramas.is_dorama(b):
        return False
    if bool(a.get('is_serie')) != bool(b.get('is_serie')):
        return False
    if a.get('tmdb_id') and b.get('tmdb_id'):
        return str(a['tmdb_id']) == str(b['tmdb_id'])
    ya, yb = str(a.get('year') or '')[:4], str(b.get('year') or '')[:4]
    if ya.isdigit() and yb.isdigit() and ya != yb:
        return False
    return s.titulo_coincide(title(a.get('title', '')), title(b.get('title', '')))


def variants(item):
    return item.get('variants') or [{k: v for k, v in item.items() if k not in ('variants', 'history_keys')}]


def merge(items):
    result = []
    for original in items:
        if not original.get('url'):
            continue
        matches = [x for x in result if x['url'] == original['url'] or same(x, original)]
        if len(matches) == 1:
            item = matches[0]
            seen = {v['url'] for v in item['variants']}
            item['variants'].extend(v for v in variants(original) if v['url'] not in seen)
            for field in ('cover', 'plot', 'year', 'rating', 'tmdb_id'):
                if not item.get(field) and original.get(field):
                    item[field] = original[field]
        else:
            item = dict(original, title=title(original['title']), variants=list(variants(original)))
            result.append(item)
    return result


def parallel(calls):
    deadline = getattr(network._sondeo, 'deadline', None)
    cancel = getattr(network._sondeo, 'cancel', None)
    max_request = getattr(network._sondeo, 'max_request', 6)
    def safe(call):
        try:
            with network.presupuesto_sondeo(deadline, cancel, max_request):
                network.tiempo_peticion(15)
                return call()
        except Exception as exc:
            network.log_resolver('Consulta de catalogo no disponible ({})'.format(type(exc).__name__))
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(safe, calls))


def in_section(items, section='all'):
    # Do not resurrect removed providers from older search caches.
    items = [i for i in items if 'gnula' not in (urlsplit(i.get('url', '')).hostname or '')]
    import servidores as tubi
    if not tubi.tubi_is_available():
        cleaned = []
        for i in items:
            v_list = variants(i)
            non_tubi = [v for v in v_list if v.get('source') != 'tubi' and not tubi.tubi_owns(v.get('url', ''))]
            if not non_tubi:
                continue
            if i.get('source') == 'tubi' or tubi.tubi_owns(i.get('url', '')):
                new_item = dict(non_tubi[0])
                new_item['variants'] = non_tubi
                for k in ('cover', 'plot', 'year', 'rating', 'tmdb_id'):
                    if not new_item.get(k) and i.get(k):
                        new_item[k] = i[k]
                cleaned.append(new_item)
            else:
                new_item = dict(i)
                new_item['variants'] = non_tubi
                cleaned.append(new_item)
        items = cleaned
    if section == 'all':
        return items
    if section == 'doramas':
        return [i for i in items if doramas.is_dorama(i)]
    return [i for i in items if not doramas.is_dorama(i) and bool(i.get('is_serie')) == (section == 'series')]


CINECALIDAD_GENRE_MAP = {
    'accion': 'accion',
    'animacion': 'animacion',
    'anime': 'animacion',
    'aventura': 'aventura',
    'ciencia-ficcion': 'ciencia-ficcion',
    'comedia': 'comedia',
    'crimen': 'crimen',
    'drama': 'drama',
    'familia': 'familiar',
    'familiar': 'familiar',
    'fantasia': 'fantasia',
    'misterio': 'misterio',
    'romance': 'romance',
    'suspense': 'suspenso',
    'suspenso': 'suspenso',
    'terror': 'terror',
}

PELISFLIX_GENRE_MAP = {
    'accion': 'accion',
    'animacion': 'animacion',
    'anime': 'animacion',
    'aventura': 'aventura',
    'ciencia-ficcion': 'ciencia-ficcion',
    'comedia': 'comedia',
    'crimen': 'crimen',
    'documental': 'documental',
    'drama': 'drama',
    'familia': 'familia',
    'familiar': 'familia',
    'fantasia': 'fantasia',
    'romance': 'romance',
    'suspense': 'suspense',
    'suspenso': 'suspense',
    'terror': 'terror',
}

FUEGOCINE_GENRE_MAP = {
    'accion': 'Acción',
    'animacion': 'Animación',
    'anime': 'Animación',
    'aventura': 'Aventura',
    'belica': 'Acción',
    'ciencia-ficcion': 'Ciencia ficción',
    'comedia': 'Comedia',
    'crimen': 'Crimen',
    'drama': 'Drama',
    'familia': 'Familia',
    'familiar': 'Familia',
    'fantasia': 'Fantasía',
    'historia': 'Historia',
    'misterio': 'Misterio',
    'romance': 'Romance',
    'suspense': 'Suspenso',
    'suspenso': 'Suspenso',
    'terror': 'Terror',
}

STOPWORDS = {
    'el', 'la', 'lo', 'los', 'las', 'un', 'una', 'unos', 'unas',
    'de', 'del', 'al', 'a', 'en', 'con', 'por', 'para', 'y', 'o', 'u',
    'que', 'su', 'sus', 'se', 'the', 'an', 'in', 'on', 'at', 'of', 'and', 'or', 'to', 'for', 'is'
}


def normalize_search_text(text):
    text = ''.join(c for c in unicodedata.normalize('NFKD', str(text or '')) if not unicodedata.combining(c))
    text = re.sub(r'[^a-z0-9\s]', ' ', text.lower())
    return re.sub(r'\s+', ' ', text).strip()


def relevance_score(item, query):
    norm_q = normalize_search_text(query)
    if not norm_q:
        return 0.0
    q_words = norm_q.split()
    sig_q = [w for w in q_words if w not in STOPWORDS] or q_words

    norm_t = normalize_search_text(title(item.get('title', '')))
    if not norm_t:
        return 0.0
    t_words = norm_t.split()
    t_words_set = set(t_words)

    # 1. Exact match
    if norm_t == norm_q:
        return 1000.0

    # 2. Prefix match
    if norm_t.startswith(norm_q):
        penalty = min(100.0, len(norm_t) - len(norm_q))
        return 900.0 - penalty

    # 3. Substring match
    if norm_q in norm_t:
        penalty = min(150.0, len(norm_t) - len(norm_q))
        return 800.0 - penalty

    matched_sig = [w for w in sig_q if w in t_words_set]
    matched_all = [w for w in q_words if w in t_words_set]
    sig_ratio = len(matched_sig) / len(sig_q) if sig_q else 0.0
    all_ratio = len(matched_all) / len(q_words) if q_words else 0.0

    if not matched_sig:
        norm_plot = normalize_search_text(item.get('plot', ''))
        if norm_q in norm_plot or (sig_q and all(w in norm_plot for w in sig_q)):
            return 20.0
        return 0.0

    if sig_ratio == 1.0:
        indices = [t_words.index(w) for w in matched_sig]
        order_bonus = 50.0 if indices == sorted(indices) else 0.0
        seq_ratio = SequenceMatcher(None, norm_q, norm_t).ratio() * 100.0
        return 500.0 + order_bonus + (all_ratio * 100.0) + seq_ratio

    seq_ratio = SequenceMatcher(None, norm_q, norm_t).ratio() * 100.0
    return (sig_ratio * 300.0) + (all_ratio * 50.0) + seq_ratio


def sort_by_relevance(items, query):
    if not query or not items:
        return list(items)
    scored = [(relevance_score(it, query), it) for it in items]
    has_positive = any(score > 0 for score, _ in scored)
    if has_positive:
        scored = [pair for pair in scored if pair[0] > 0]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [it for _, it in scored]


def search(query, experimental=False, section='all'):
    if not experimental and section == 'doramas':
        return []
    if not experimental and section in ('peliculas', 'series'):
        results = merge(in_section(s.sololatino_buscar(query), section))
        return SearchResults(sort_by_relevance(results, query), [])
    calls = []
    if section != 'doramas':
        calls.append(lambda: s.sololatino_buscar(query))
        if experimental:
            import servidores as tubi
            calls.extend([lambda: s.hackstore_search(query), lambda: s.pelisjuanita_search(query), lambda: s.fuegocine_buscar(query), lambda: s.pelisflix_search(query)])
            if tubi.tubi_is_available():
                calls.append(lambda: tubi.tubi_search(query))
    if experimental and section in ('all', 'doramas'):
        calls.append(lambda: doramas.search(query))
    if experimental and section in ('all', 'peliculas'):
        calls.append(lambda: cinecalidad.cinecalidad_search(query))
    pages = parallel(calls)
    errors = [name for page in pages for name in getattr(page, 'errors', [])]
    if any(page is None for page in pages):
        errors.append('otra fuente')
    merged = merge(in_section([item for page in pages if page for item in page], section))
    ranked = sort_by_relevance(merged, query)
    return SearchResults(ranked, errors)


def page(section, number, experimental=False, primary_source=None):
    parsed_sec = urlsplit('unified://' + section)
    base_section = parsed_sec.netloc or section.split('?', 1)[0]
    genre = parse_qs(parsed_sec.query).get('genre', [None])[0]

    if base_section == 'doramas':
        if not experimental:
            return [], False
        items, more = doramas.page(number, genre)
        return merge(items), more

    is_series = base_section == 'series'

    def primary():
        if primary_source != 'cache':
            if genre:
                url_prim = f"{network.SOLOLATINO_BASE}/{base_section}?genero={genre}" + (f"&page={number}" if number > 1 else "")
            else:
                url_prim = f"{network.SOLOLATINO_BASE}/{base_section}?page={number}" if number > 1 else f"{network.SOLOLATINO_BASE}/{base_section}"
            html, _ = network.fetch_html(url_prim)
            if html:
                items = s.sololatino_parsear_tarjetas(html, base_section)
                return items, bool(items)
            if primary_source == 'live':
                raise network.ServidorNoDisponible('SoloLatino no permite cargar la siguiente pagina. Renueva la verificacion del navegador.')
        if not genre and base_section in ('peliculas', 'series', 'all'):
            import sololatino_index
            cached = sololatino_index.page(base_section, number)
            if cached is not None:
                return cached
            raise network.ServidorNoDisponible('SoloLatino no permite acceder a la web y no hay catalogo guardado disponible.')

    if not experimental:
        items, more = primary()
        return visible(items, False), more

    import servidores as tubi
    calls = [primary]

    if genre:
        # Categorías en experimental: consultar todos los servidores disponibles adaptando el género
        if not is_series:
            c_genre = CINECALIDAD_GENRE_MAP.get(genre)
            if c_genre:
                calls.append(lambda c_genre=c_genre: cinecalidad.cinecalidad_page(number, genre=c_genre))

        pf_genre = PELISFLIX_GENRE_MAP.get(genre)
        if pf_genre:
            calls.append(lambda pf_genre=pf_genre: (s.pelisflix_catalog('series' if is_series else 'peliculas', number, genre=pf_genre), True))

        fc_label = FUEGOCINE_GENRE_MAP.get(genre)
        if fc_label:
            def fc_external(fc_label=fc_label):
                items = s.fuegocine_catalogo_genero(fc_label, number, is_serie=is_series)
                return items, len(items) >= s.FUEGOCINE_PAGE_SIZE
            calls.append(fc_external)

        if tubi.tubi_is_available():
            calls.append(lambda: tubi.tubi_page(base_section, number, genre=genre))
    else:
        # Catálogo general (TODO)
        if tubi.tubi_is_available():
            calls.append(lambda: tubi.tubi_page(base_section, number))
        if not is_series:
            calls.append(lambda: cinecalidad.cinecalidad_page(number))
        for kind in (('tvshow', 'anime') if is_series else ('movie',)):
            calls.extend([lambda kind=kind: s.hackstore_catalog(kind, number),
                          lambda kind=kind: s.pelisjuanita_catalog(kind, number)])
        calls.append(lambda: s.pelisflix_catalog('series' if is_series else 'peliculas', number))
        for label in (('Serie', 'Anime') if is_series else ('Movie',)):
            def external(label=label):
                items = s.fuegocine_catalogo(label, number)
                return items, len(items) >= s.FUEGOCINE_PAGE_SIZE
            calls.append(external)

    pages = [x for x in parallel(calls) if x]
    items_list = [i for items, _ in pages for i in items if bool(i.get('is_serie')) == is_series]
    return merge(in_section(items_list, base_section)), any(more for _, more in pages)


def expand(item, premium_only=False):
    if doramas.is_dorama(item):
        matches = [c for c in doramas.search(title(item['title'])) if same(c, item)]
        return merge([item, matches[0]])[0] if len(matches) == 1 else item
    candidates = s.sololatino_buscar(title(item['title'])) if premium_only else search(title(item['title']), experimental=True, section='series' if item.get('is_serie') else 'peliculas')
    matches = [c for c in candidates if same(c, item)]
    # No adivinar entre remakes cuando faltan fechas o identificadores.
    if len(matches) == 1:
        return merge([item, matches[0]])[0]
    return item


def episodes(series, experimental=False):
    roots = [v for v in variants(series) if experimental or is_primary(v)]
    results = parallel([lambda item=item: s.obtener_episodios(item) for item in roots])
    grouped = {}
    for seasons in results:
        for season, entries in (seasons or {}).items():
            for ep in entries:
                number = str(ep.get('episode', ''))
                if not str(season).isdigit() or not number.isdigit():
                    continue
                key = (str(int(season)), str(int(number)))
                if key in grouped:
                    grouped[key]['variants'].extend(variants(ep))
                else:
                    grouped[key] = dict(ep, variants=list(variants(ep)), season=key[0], episode=key[1])
    result = {}
    for (season, _), ep in sorted(grouped.items(), key=lambda pair: tuple(map(int, pair[0]))):
        result.setdefault(season, []).append(ep)
    return result


def is_primary(item):
    host = urlsplit(item.get('url', '')).hostname or ''
    return host == 'sololatino.net' or host.endswith('.sololatino.net')


def visible(items, experimental=False):
    """Project saved entries into the active catalog without changing user data."""
    if experimental:
        return list(items)
    result = []
    for item in items:
        roots = [dict(v) for v in variants(item) if is_primary(v)]
        if roots:
            projected = dict(item)
            projected.update(roots[0])
            projected['variants'] = roots
            result.append(projected)
    return result


def visible_server(server):
    name = re.sub(r'(?i)\b(?:fuegocine|hackstore2?|pelisjuanita|sololatino|pelisflix)\b(?:\.[a-z]+)?', '', server.get('nombre', ''))
    return dict(server, nombre=re.sub(r'\s+', ' ', name).strip(' -') or 'Servidor')


def servers(item, experimental=False, series=None):
    options = variants(item)
    if doramas.is_dorama(item):
        if not experimental:
            return []
        entries = parallel([lambda v=v: doramas.servers(v, experimental) for v in options if doramas.is_dorama(v)])
        unique = {x['url']: x for batch in entries if batch for x in batch}
        return s.ordenar_servidores_por_calidad(list(unique.values()))
    if not experimental:
        options = [v for v in options if is_primary(v)]
        if not options:
            if series and item.get('season') and item.get('episode'):
                parent = expand(series, premium_only=True)
                roots = [v for v in variants(parent) if is_primary(v)]
                for root in roots:
                    eps = s.obtener_episodios(root).get(str(item['season']), [])
                    options.extend(e for e in eps if str(e.get('episode')) == str(item['episode']))
            elif not item.get('is_serie'):
                options = [v for v in variants(expand(item, premium_only=True)) if is_primary(v)]
        # Solo se consultan los reproductores Premium de la fuente principal.
        calls = [lambda v=v: s.sololatino_obtener_servidores(v['url'], premium_only=True) for v in options]
    else:
        if not item.get('season') and not item.get('episode'):
            options = variants(expand(item))
        def fetch(v):
            url = v['url']
            import servidores as tubi
            if tubi.tubi_owns(url):
                if not tubi.tubi_is_available():
                    return []
                return tubi.tubi_servers(v)
            if cinecalidad.cinecalidad_owns(url):
                return cinecalidad.cinecalidad_servers(v)
            if s.es_url_pelisflix(url):
                return s.pelisflix_servers(url)
            if s.es_url_hackstore(url):
                return s.hackstore_servers(url)
            if s.es_url_pelisjuanita(url):
                return s.pelisjuanita_servers(url)
            if s.es_url_fuegocine(url):
                return s.fuegocine_obtener_servidores(url)
            return s.sololatino_obtener_servidores(url)
        calls = [lambda v=v: fetch(v) for v in options]
    found = parallel(calls) if calls else []
    unique = {}
    for entries in found:
        for server in entries or []:
            if not experimental and urlsplit(server['url']).hostname != 'player.pelisserieshoy.com':
                continue
            unique.setdefault(server['url'], visible_server(server))
    return s.ordenar_servidores_por_calidad(list(unique.values()))


def metadata(item):
    """Enrich only from the selected title/episode, without title-based guessing."""
    import content_metadata
    import servidores as tubi
    if tubi.tubi_owns(item.get('url', '')):
        if not tubi.tubi_is_available():
            return {}
        return tubi.tubi_metadata(item)
    if cinecalidad.cinecalidad_owns(item.get('url', '')):
        return cinecalidad.cinecalidad_metadata(item)
    if doramas.is_dorama(item):
        return doramas.metadata(item)
    url = item.get('url', '')
    if not url.startswith(('https://', 'http://')):
        return {k: v for k, v in content_metadata.fields(item).items() if v}
    page, _ = network.fetch_html(url, referer=url, timeout=5)
    result = content_metadata.from_page(page, episode=bool(item.get('episode')))
    plot = result.get('plot', '')
    if not plot or plot.endswith('...') or plot.endswith('…'):
        full_plot = network.extraer_sinopsis(page)
        if full_plot and len(full_plot) > len(plot):
            result['plot'] = full_plot
    curr_plot = item.get('plot', '')
    res_plot = result.get('plot', '')
    if curr_plot and (res_plot.endswith('...') or res_plot.endswith('…') or len(curr_plot) > len(res_plot)):
        result['plot'] = curr_plot
    return result
