"""Local, isolated curl transport. Cookies and signed URLs never go in logs."""
import json
import re
import secrets
import sys
import time
from urllib.parse import urlsplit, urljoin, urlencode

HOSTS = ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com',
         'playmogo.com', 'dsvplay.com', 'ds2play.com')


def resolve(payload):
    from curl_cffi import requests
    from sololatino_session import BrowserCookieJar
    url = payload['url']
    if urlsplit(url).scheme != 'https' or urlsplit(url).hostname not in HOSTS:
        raise ValueError('Dominio Doodstream no admitido')
    jar = BrowserCookieJar(payload['cookies'])
    jar.load(ignore_discard=True)
    ua = payload['user_agent']
    deadline = time.monotonic() + payload.get('timeout', 20)
    with requests.Session(impersonate='chrome') as session:
        for cookie in jar:
            if (cookie.domain.lstrip('.') in HOSTS and cookie.name in ('cf_clearance', '__cf_bm')
                    and not cookie.is_expired()):
                session.cookies.jar.set_cookie(cookie)

        def get(target, referer):
            # Follow only known player hosts; never forward verification to other sites.
            for _ in range(6):
                if urlsplit(target).scheme != 'https' or urlsplit(target).hostname not in HOSTS:
                    raise ValueError('Redireccion Doodstream no admitida')
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError()
                response = session.get(target, headers={'User-Agent': ua, 'Referer': referer},
                                       timeout=min(12, remaining), allow_redirects=False)
                if response.status_code in (301, 302, 303, 307, 308):
                    target = urljoin(target, response.headers['location'])
                    continue
                if response.status_code != 200:
                    raise ValueError('Doodstream HTTP %s; renueva la verificacion del navegador' % response.status_code)
                return response
            raise ValueError('Demasiadas redirecciones')

        response = get(url, url)
        referer = response.url
        endpoint = re.search(r'''['"](/pass_md5/[^'"]+)''', response.text)
        token = re.search(r'[?&]token=([a-zA-Z0-9]+)&expiry=', response.text)
        if not endpoint or not token:
            raise ValueError('Doodstream no publico el enlace del video')
        prefix = get(urljoin(referer, endpoint.group(1)), referer).text.strip()
        if not prefix.startswith('https://') or '<' in prefix or len(prefix) > 8192:
            raise ValueError('Doodstream devolvio un enlace no valido')
        media = prefix + secrets.token_hex(5) + '?token=' + token.group(1) + '&expiry=' + str(int(time.time()*1000))
        return media + '|' + urlencode({'User-Agent': ua, 'Referer': referer})


if __name__ == '__main__':
    try:
        print(json.dumps({'stream': resolve(json.load(sys.stdin))}))
    except Exception as exc:
        # Network exception strings may contain signed URLs. Return only safe messages.
        message = str(exc) if isinstance(exc, ValueError) else type(exc).__name__
        print(json.dumps({'error': message}))
