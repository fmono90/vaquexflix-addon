"""Use an explicitly configured browser verification for Doodstream only."""
import network
from urllib.request import HTTPCookieProcessor


def resolve_external(url):
    import json
    import os
    import subprocess
    pass
    try:
        import xbmcaddon
        import xbmcvfs
    except ImportError:
        return None
    addon = xbmcaddon.Addon('plugin.video.vaquexflix')
    python = xbmcvfs.translatePath(addon.getSetting('dood_python'))
    if not python:
        return None
    timeout = network.tiempo_peticion(25)
    payload = {'url': url, 'cookies': xbmcvfs.translatePath(addon.getSetting('dood_cookies')),
               'user_agent': addon.getSetting('dood_user_agent').strip() or network.UA,
               'timeout': timeout}
    try:
        result = subprocess.run([python, os.path.join(os.path.dirname(__file__), 'dood_browser.py')],
                                input=json.dumps(payload), text=True, capture_output=True,
                                timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        data = json.loads(result.stdout)
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        raise network.ServidorNoDisponible('Doodstream: el auxiliar no esta disponible o excedio el tiempo de espera.') from exc
    if not data.get('stream'):
        raise network.ServidorNoDisponible('Doodstream: ' + data.get('error', 'no se obtuvo el video'))
    return data['stream']


def configure(opener):
    try:
        import xbmcaddon
        import xbmcvfs
    except ImportError:
        return ''
    addon = xbmcaddon.Addon('plugin.video.vaquexflix')
    path = xbmcvfs.translatePath(addon.getSetting('dood_cookies'))
    agent = addon.getSetting('dood_user_agent').strip()
    if path:
        from sololatino_session import BrowserCookieJar
        jar = BrowserCookieJar(path)
        jar.load(ignore_discard=True)
        for handler in opener.handlers:
            if isinstance(handler, HTTPCookieProcessor):
                for cookie in jar:
                    if (cookie.domain.lstrip('.') in ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com', 'playmogo.com', 'dsvplay.com', 'ds2play.com')
                            and cookie.name in ('cf_clearance', '__cf_bm') and not cookie.is_expired()):
                        handler.cookiejar.set_cookie(cookie)
    return agent
