"""Use an explicitly configured browser verification for DoramaExpress only."""
from urllib.request import HTTPCookieProcessor


def configure(opener):
    try:
        import xbmcaddon
        import xbmcvfs
    except ImportError:
        return ''
    addon = xbmcaddon.Addon('plugin.video.vaquexflix')
    path = xbmcvfs.translatePath(addon.getSetting('doramaexpress_cookies'))
    agent = addon.getSetting('doramaexpress_user_agent').strip()
    if path:
        from sololatino_session import BrowserCookieJar
        jar = BrowserCookieJar(path)
        jar.load(ignore_discard=True)
        for handler in opener.handlers:
            if isinstance(handler, HTTPCookieProcessor):
                for cookie in jar:
                    if (cookie.domain.lstrip('.') in ('doramaexpress.com', 'www.doramaexpress.com')
                            and cookie.name in ('cf_clearance', '__cf_bm') and not cookie.is_expired()):
                        handler.cookiejar.set_cookie(cookie)
    return agent
