'use strict';
// Local cryptography only: no network or downloaded JavaScript.
const crypto = require('crypto');
const fs = require('fs');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
if (input.operation === 'sign') {
  const keys = crypto.generateKeyPairSync('ec', {namedCurve: 'prime256v1'});
  const signature = crypto.sign('sha256', Buffer.from(input.nonce),
    {key: keys.privateKey, dsaEncoding: 'ieee-p1363'});
  process.stdout.write(JSON.stringify({signature: signature.toString('base64url'),
    public_key: keys.publicKey.export({format: 'jwk'})}));
} else if (input.operation === 'decrypt') {
  const p = input.playback;
  let parts = p.key_parts;
  const v = Number(p.version);
  if (Number.isInteger(v) && v >= 1 && v <= 20 && parts[v - 1] && parts[30 - v])
    parts = [parts[v - 1], parts[30 - v]];
  const key = Buffer.concat(parts.map(x => Buffer.from(x, 'base64url')));
  const data = Buffer.from(p.payload, 'base64url');
  const decipher = crypto.createDecipheriv(`aes-${key.length * 8}-gcm`, key, Buffer.from(p.iv, 'base64url'));
  decipher.setAuthTag(data.subarray(-16));
  process.stdout.write(Buffer.concat([decipher.update(data.subarray(0, -16)), decipher.final()]));
} else throw new Error('Unsupported operation');
