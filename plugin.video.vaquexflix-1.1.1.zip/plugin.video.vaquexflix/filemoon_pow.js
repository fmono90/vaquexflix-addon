// Local implementation of Byse's public player proof. No downloaded JS is run.
// Node is optional; stdin/stdout contain one JSON object. No network or files.
'use strict';
const fs = require('fs');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const rol = (a, n) => (a << n | a >>> (32 - n)) >>> 0;
function mix(a) {
  a[0] = (a[0] + a[1]) >>> 0; a[3] = rol(a[3] ^ a[0], 16);
  a[2] = (a[2] + a[3]) >>> 0; a[1] = rol(a[1] ^ a[2], 12);
  a[0] = (a[0] + a[1]) >>> 0; a[3] = rol(a[3] ^ a[0], 8);
  a[2] = (a[2] + a[3]) >>> 0; a[1] = rol(a[1] ^ a[2], 7);
}
function hash(text) {
  const a = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762]);
  for (const c of Buffer.from(text)) { a[0] = rol((a[0] + c) >>> 0, 7); mix(a); }
  for (let i = 0; i < 8; i++) mix(a);
  const mem = new Uint32Array(512);
  for (let i = 0; i < 512; i++) { mix(a); mem[i] = (a[0] ^ a[2]) >>> 0; }
  for (let round = 0; round < 2; round++) for (let i = 0; i < 512; i++) {
    let c = rol((mem[i] + mem[mem[i] & 511]) >>> 0, 13);
    c = (c ^ Math.imul(mem[(i + 1) & 511], 2654435761)) >>> 0;
    mem[i] = c; a[0] = (a[0] ^ c) >>> 0; mix(a);
  }
  const out = [];
  for (let i = 0; i < 8; i++) {
    mix(a); let n = a[0];
    for (let j = 0; j < 64; j++) {
      const v = mem[i * 64 + j];
      n = (rol((n + v) >>> 0, 5) ^ Math.imul(v, 2246822519)) >>> 0;
    }
    out.push((n ^ a[2]) >>> 0);
  }
  return out;
}
if (typeof input.nonce !== 'string' || input.nonce.length > 256 ||
    !Number.isInteger(input.difficulty) || input.difficulty < 0 || input.difficulty > 24) {
  throw Error('Invalid proof parameters');
}
const started = Date.now();
let solution = null;
for (let n = 0; Date.now() - started < Math.min(input.timeout_ms || 8000, 20000); n++) {
  let zeros = 0;
  for (const v of hash(input.nonce + ':' + n)) { zeros += Math.clz32(v); if (v) break; }
  if (zeros >= input.difficulty) { solution = String(n); break; }
}
process.stdout.write(JSON.stringify({solution}));
