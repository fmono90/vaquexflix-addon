"""HTTP, sesiones, presupuestos y utilidades compartidas."""
import http.cookiejar
from html.parser import HTMLParser
import html
import json
import re
import ssl
import urllib.error
import time
import threading
from contextlib import contextmanager
import urllib.parse
import urllib.request


try:
    _ssl_ctx = ssl.create_default_context()
    _ssl_ctx.check_hostname = False
    _ssl_ctx.verify_mode = ssl.CERT_NONE
except Exception:
    _ssl_ctx = None


UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'


SOLOLATINO_BASE = "https://sololatino.net"


def limpiar_texto(texto):
    if not texto:
        return ""
    decoded = str(texto)
    for _ in range(3):
        updated = html.unescape(decoded)
        if updated == decoded:
            break
        decoded = updated
    t = decoded.replace('★', '').replace('☆', '').replace('•', '-').replace('⭐', '').replace('🕒', '')
    t = t.replace('✅', '').replace('✔', '').replace('⚡', '')
    return re.sub(r'[^\x20-\x7E\u00A0-\u017F]', '', t).strip()


class SynopsisParser(HTMLParser):
    """Read complete structured descriptions before abbreviated SEO metadata."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.structured = []
        self.meta = []
        self.script = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' and attrs.get('type', '').lower() == 'application/ld+json':
            self.script = []
        elif tag == 'meta' and (attrs.get('name') == 'description' or attrs.get('property') == 'og:description'):
            self.meta.append(attrs.get('content', ''))

    def handle_data(self, data):
        if self.script is not None:
            self.script.append(data)

    def handle_endtag(self, tag):
        if tag == 'script' and self.script is not None:
            try:
                self.structured.append(json.loads(''.join(self.script)))
            except (ValueError, TypeError):
                pass
            self.script = None


def extraer_sinopsis(page):
    parser = SynopsisParser()
    parser.feed(page)
    candidates = []
    for document in parser.structured:
        nodes = document if isinstance(document, list) else [document]
        for node in nodes:
            if isinstance(node, dict):
                candidates.extend(node.get('@graph', [node]))
    structured_text = ""
    for node in candidates:
        if not isinstance(node, dict):
            continue
        types = node.get('@type', [])
        types = [types] if isinstance(types, str) else types
        if any(t in ('Movie', 'TVSeries', 'TVEpisode') for t in types) and node.get('description'):
            structured_text = limpiar_texto(node['description'])
            break
    # Body synopsis is preferred over a search-engine excerpt.
    body = re.search(r'<p\b[^>]*class=["\'][^"\']*leading-relaxed[^"\']*["\'][^>]*>(.*?)</p>', page, re.S | re.I)
    if body:
        body_text = limpiar_texto(re.sub(r'<[^>]+>', ' ', body.group(1)))
        # Some pages truncate JSON-LD too. Only substitute matching text,
        # never an unrelated paragraph or another episode's description.
        prefix = structured_text.rstrip('. \u2026')
        if not prefix or (len(body_text) > len(structured_text) and
                          body_text.casefold().startswith(prefix.casefold())):
            return body_text
    if structured_text:
        return structured_text
    text = next((value for value in parser.meta if value), '')
    return limpiar_texto(re.sub(r'^Ver\s+.*?\s+online\.\s*', '', text, flags=re.I))


def log_resolver(message):
    try:
        import xbmc
        xbmc.log('Vaquexflix: ' + message, xbmc.LOGWARNING)
    except ImportError:
        pass


class ServidorNoDisponible(RuntimeError):
    """Motivo confirmado por el proveedor que puede mostrarse al usuario."""


_sondeo = threading.local()


@contextmanager
def presupuesto_sondeo(deadline, cancel=None, max_request=6):
    previous = getattr(_sondeo, 'deadline', None)
    previous_cancel = getattr(_sondeo, 'cancel', None)
    previous_limit = getattr(_sondeo, 'max_request', 6)
    _sondeo.deadline = deadline
    _sondeo.cancel = cancel
    _sondeo.max_request = max_request
    try:
        yield
    finally:
        _sondeo.deadline = previous
        _sondeo.cancel = previous_cancel
        _sondeo.max_request = previous_limit


def presupuesto_resolucion(deadline, cancel=None):
    # Preserve each resolver's normal timeout; only the whole operation is bounded.
    return presupuesto_sondeo(deadline, cancel, max_request=float('inf'))


def tiempo_peticion(timeout):
    cancel = getattr(_sondeo, 'cancel', None)
    if cancel is not None and cancel.is_set():
        raise TimeoutError('Sondeo omitido')
    deadline = getattr(_sondeo, 'deadline', None)
    if deadline is None:
        return timeout
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('Sondeo de metadatos finalizado')
    return min(timeout, remaining, getattr(_sondeo, 'max_request', 6))


def abrir_url(request, timeout=15, **kwargs):
    return urllib.request.urlopen(request, timeout=tiempo_peticion(timeout), **kwargs)


def nueva_sesion():
    # Conservar cookies durante redirecciones sin enviarlas a dominios ajenos.
    jar = http.cookiejar.CookieJar()
    context = ssl.create_default_context()
    # Kodi 21 incorpora Python 3.8; no anuncia HTTP/1.1 automaticamente.
    if hasattr(context, 'set_alpn_protocols'):
        context.set_alpn_protocols(['http/1.1'])
    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar), urllib.request.HTTPSHandler(context=context))
    original_open = opener.open
    def open_bounded(request, data=None, timeout=15):
        return original_open(request, data=data, timeout=tiempo_peticion(timeout))
    opener.open = open_bounded
    return opener


def url_con_cabeceras(url, headers, opener=None):
    req = urllib.request.Request(url)
    if opener:
        for handler in opener.handlers:
            if isinstance(handler, urllib.request.HTTPCookieProcessor):
                handler.cookiejar.add_cookie_header(req)
        if req.get_header('Cookie'):
            headers = dict(headers, Cookie=req.get_header('Cookie'))
    return url + '|' + urllib.parse.urlencode(headers)


def _challenge_page(text):
    lower = text.lower()
    # Successful pages can include Cloudflare's challenge-platform script too.
    # Only reject the actual interstitial, not that background script.
    return bool(re.search(r'<title>\s*(?:just a moment|un momento)', lower) or
                re.search(r'id\s*=\s*[\"\']challenge-form[\"\']', lower) or
                'window._cf_chl_opt' in lower)


HAS_CURL_CFFI = False


c_requests = None


def fetch_html(url, cookies="", referer="", timeout=10, data=None, headers_dict=None):
    host = urllib.parse.urlsplit(url).hostname or ''
    if host in ('sololatino.net', 'www.sololatino.net'):
        import sololatino_session
        if sololatino_session.access_error():
            return '', []
    try:
        headers = dict(headers_dict) if headers_dict is not None else {
            'User-Agent': UA,
            'Referer': referer or f"{SOLOLATINO_BASE}/",
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8'
        }
        if cookies and 'Cookie' not in headers:
            headers['Cookie'] = cookies
        req = urllib.request.Request(url, data=data, headers=headers)
        with abrir_url(req, timeout=tiempo_peticion(timeout), context=_ssl_ctx) as r:
            text = r.read().decode('utf-8', errors='ignore')
            if _challenge_page(text):
                log_resolver('Desafio Cloudflare en {} (urllib)'.format(host))
                return '', []
            return text, r.headers.get_all('Set-Cookie') or []
    except Exception as exc:
        log_resolver('HTTP fallo en {} (urllib): {}{}'.format(host, type(exc).__name__,
                     ' status=' + str(exc.code) if hasattr(exc, 'code') else ''))
        return "", []
