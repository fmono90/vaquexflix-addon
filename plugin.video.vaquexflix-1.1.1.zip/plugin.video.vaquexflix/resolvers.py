"""Resolutores de video compartidos por todas las fuentes."""
import base64
import codecs
import hashlib
from html.parser import HTMLParser
import html
import json
import os
import re
import shutil
import subprocess
import uuid
import urllib.error
import time
import urllib.parse
import urllib.request
import network


try:
    import resolveurl
except Exception:
    resolveurl = None


CALIDADES_HLS = {}


def calidad_hls(manifest):
    heights = set()
    for line in manifest.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            match = re.search(r'RESOLUTION=\d+x(\d+)', line)
            if match:
                heights.add(int(match.group(1)))
    if not heights:
        return ''
    values = ' / '.join('{}p'.format(h) for h in sorted(heights))
    return ('Multirresolucion: ' if len(heights) > 1 else '') + values


def etiqueta_servidor(server, verified=''):
    name = re.sub(r'\b(?:Multicalidad|FHD|FullHD|HD|SD)\b|\(?\b\d{3,4}p\b\)?', '', server['nombre'], flags=re.I)
    name = re.sub(r'\s+', ' ', name).strip()
    return '{} - {}'.format(name, verified or 'Calidad de video sin verificar')


def procesar_hls_local(master_url, referer, opener=None, timeout=15):
    """Validar y conservar el master con todos sus audios y variantes.

    No convertir el master en una lista de audio o de I-frames ni escribir
    cabeceras Kodi dentro de las URI de los segmentos.
    """
    opener = opener or network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': referer,
               'Origin': '{0.scheme}://{0.netloc}'.format(urllib.parse.urlsplit(referer))}
    try:
        req = urllib.request.Request(master_url, headers=headers)
        with opener.open(req, timeout=timeout) as response:
            manifest = response.read(2 * 1024 * 1024).decode('utf-8-sig', 'replace')
            final_url = response.geturl()
        if not manifest.lstrip().startswith('#EXTM3U'):
            network.log_resolver('HLS: el servidor devolvio una pagina en lugar del manifiesto')
            return None
        CALIDADES_HLS[final_url] = calidad_hls(manifest)
        if not urllib.parse.urlsplit(final_url).path.lower().endswith('.m3u8'):
            headers['ext'] = '.m3u8'
        return network.url_con_cabeceras(final_url, headers, opener)
    except Exception as exc:
        reason = getattr(exc, 'reason', type(exc).__name__)
        network.log_resolver('HLS: fallo de acceso ({})'.format(reason))
        return None


def unpack_js(p, a, c, k, e=None, d=None):
    def _baseN(num, b):
        chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        res = ""
        while num > 0:
            res = chars[num % b] + res
            num //= b
        return res or "0"
    if not 2 <= a <= 62 or not 0 <= c <= 100000:
        raise ValueError('Parametros del packer invalidos')
    lookup = {}
    for i in range(c):
        key = _baseN(i, a)
        lookup[key] = k[i] if i < len(k) and k[i] else key
    def _replace(match):
        w = match.group(0)
        return lookup.get(w, w)
    return re.sub(r'\b\w+\b', _replace, p)


class MiniAES:
    SBOX = [
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
    ]
    INV_SBOX = [0] * 256
    RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]

    @classmethod
    def _init_tables(cls):
        if cls.INV_SBOX[0] != 0 or cls.INV_SBOX[1] != 0:
            return
        for i in range(256):
            cls.INV_SBOX[cls.SBOX[i]] = i

    @staticmethod
    def _xt(a):
        return ((a << 1) ^ 0x1b) & 0xff if (a & 0x80) else (a << 1)

    @classmethod
    def _mul(cls, a, b):
        res = 0
        while b:
            if b & 1:
                res ^= a
            a = cls._xt(a)
            b >>= 1
        return res

    def __init__(self, key):
        self._init_tables()
        self.key = key
        self.Nk = len(key) // 4
        self.Nr = self.Nk + 6
        self.w = self._key_expansion()

    def _key_expansion(self):
        w = [0] * (4 * (self.Nr + 1))
        for i in range(self.Nk):
            w[i] = (self.key[4*i] << 24) | (self.key[4*i+1] << 16) | (self.key[4*i+2] << 8) | self.key[4*i+3]
        for i in range(self.Nk, 4 * (self.Nr + 1)):
            temp = w[i - 1]
            if i % self.Nk == 0:
                rw = ((temp << 8) & 0xffffffff) | (temp >> 24)
                sub = (self.SBOX[(rw >> 24) & 0xff] << 24) | (self.SBOX[(rw >> 16) & 0xff] << 16) | (self.SBOX[(rw >> 8) & 0xff] << 8) | self.SBOX[rw & 0xff]
                temp = sub ^ (self.RCON[i // self.Nk] << 24)
            elif self.Nk > 6 and (i % self.Nk == 4):
                temp = (self.SBOX[(temp >> 24) & 0xff] << 24) | (self.SBOX[(temp >> 16) & 0xff] << 16) | (self.SBOX[(temp >> 8) & 0xff] << 8) | self.SBOX[temp & 0xff]
            w[i] = w[i - self.Nk] ^ temp
        return w

    def encrypt_block(self, block):
        state = list(block)
        for rnd in range(self.Nr + 1):
            if rnd:
                state = [self.SBOX[x] for x in state]
                state = [state[r + 4 * ((c + r) % 4)] for c in range(4) for r in range(4)]
                if rnd != self.Nr:
                    for c in range(4):
                        a = state[4*c:4*c+4]
                        total = a[0] ^ a[1] ^ a[2] ^ a[3]
                        state[4*c:4*c+4] = [a[r] ^ total ^ self._xt(a[r] ^ a[(r+1) % 4]) for r in range(4)]
            state = [value ^ ((self.w[4*rnd + i//4] >> (24 - 8*(i % 4))) & 255)
                     for i, value in enumerate(state)]
        return bytes(state)

    def transform_ctr(self, data, counter):
        result = bytearray()
        for start in range(0, len(data), 16):
            block = self.encrypt_block(counter.to_bytes(16, 'big'))
            result.extend(a ^ b for a, b in zip(data[start:start+16], block))
            counter = (counter + 1) % (1 << 128)
        return bytes(result)

    def decrypt_block(self, block):
        state = [[block[r + 4 * c] for c in range(4)] for r in range(4)]
        for c in range(4):
            w = self.w[self.Nr * 4 + c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        for rnd in range(self.Nr - 1, 0, -1):
            state[1] = state[1][3:] + state[1][:3]
            state[2] = state[2][2:] + state[2][:2]
            state[3] = state[3][1:] + state[3][:1]
            for r in range(4):
                for c in range(4):
                    state[r][c] = self.INV_SBOX[state[r][c]]
            for c in range(4):
                w = self.w[rnd * 4 + c]
                state[0][c] ^= (w >> 24) & 0xff
                state[1][c] ^= (w >> 16) & 0xff
                state[2][c] ^= (w >> 8) & 0xff
                state[3][c] ^= w & 0xff
            for c in range(4):
                u = [state[r][c] for r in range(4)]
                state[0][c] = self._mul(u[0], 0x0e) ^ self._mul(u[1], 0x0b) ^ self._mul(u[2], 0x0d) ^ self._mul(u[3], 0x09)
                state[1][c] = self._mul(u[0], 0x09) ^ self._mul(u[1], 0x0e) ^ self._mul(u[2], 0x0b) ^ self._mul(u[3], 0x0d)
                state[2][c] = self._mul(u[0], 0x0d) ^ self._mul(u[1], 0x09) ^ self._mul(u[2], 0x0e) ^ self._mul(u[3], 0x0b)
                state[3][c] = self._mul(u[0], 0x0b) ^ self._mul(u[1], 0x0d) ^ self._mul(u[2], 0x09) ^ self._mul(u[3], 0x0e)
        state[1] = state[1][3:] + state[1][:3]
        state[2] = state[2][2:] + state[2][:2]
        state[3] = state[3][1:] + state[3][:1]
        for r in range(4):
            for c in range(4):
                state[r][c] = self.INV_SBOX[state[r][c]]
        for c in range(4):
            w = self.w[c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        return bytes(state[r][c] for c in range(4) for r in range(4))

    def decrypt_cbc(self, ciphertext, iv):
        plaintext = bytearray()
        prev = iv
        for i in range(0, len(ciphertext), 16):
            blk = ciphertext[i:i+16]
            dec = self.decrypt_block(blk)
            plaintext.extend(dec[j] ^ prev[j] for j in range(16))
            prev = blk
        pad = plaintext[-1]
        if 1 <= pad <= 16:
            return bytes(plaintext[:-pad])
        return bytes(plaintext)


def fnv1a_32(val_str):
    h = 2166136261
    for ch in val_str:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return f'{h:x}'


def resolver_pelisserieshoy(url_player):
    try:
        headers_get = {'User-Agent': network.UA, 'Referer': f"{network.SOLOLATINO_BASE}/"}
        req_p = urllib.request.Request(url_player, headers=headers_get)
        with network.abrir_url(req_p, timeout=8, context=network._ssl_ctx) as r_p:
            html_p = r_p.read(2 * 1024 * 1024).decode('utf-8', errors='ignore')

        m_tok = re.search(r"const\s+_t\s*=\s*'([^']+)'", html_p)
        m_qk = re.search(r'var\s+_qk\s*=\s*(\[[^\]]+\]);', html_p)
        m_qc = re.search(r'var\s+_qc\s*=\s*[\"\']([^\"\']+)[\"\'];', html_p)
        m_src = re.search(r'var\s+_qsrc\s*=\s*[\"\']([^\"\']+)[\"\'];', html_p)
        if not (m_tok and m_qk and m_qc):
            return None

        tok = m_tok.group(1)
        qk = json.loads(m_qk.group(1))
        rt = qk[1] + qk[3] + qk[0] + qk[2]
        qc = m_qc.group(1)
        tk = fnv1a_32(f'{rt}|clk|{qc}')
        qsrc = m_src.group(1) if m_src else ""

        url_s = 'https://player.pelisserieshoy.com/s.php'
        headers_post = {
            'User-Agent': network.UA,
            'Referer': url_player,
            'Origin': 'https://player.pelisserieshoy.com',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        body_scan = {'a': '1', 'tok': tok, 'rt': rt, 'tk': tk}
        if qsrc:
            body_scan['src'] = qsrc
        req_scan = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_scan).encode('utf-8'), headers=headers_post)
        with network.abrir_url(req_scan, timeout=7, context=network._ssl_ctx) as r_scan:
            scan_json = json.loads(r_scan.read(2 * 1024 * 1024).decode('utf-8'))
            servers = scan_json.get('s', [])

        body_click = {'a': 'click', 'tok': tok, 'rt': rt, 'tk': tk}
        if qsrc:
            body_click['src'] = qsrc
        try:
            req_click = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_click).encode('utf-8'), headers=headers_post)
            with network.abrir_url(req_click, timeout=7, context=network._ssl_ctx) as r_click:
                pass
        except Exception:
            pass

        def _srv_priority(item):
            nom = item[0].lower()
            if 'player+' in nom or 'player' in nom:
                return 0
            if 'premium' in nom:
                return 1
            if 'vip' in nom:
                return 2
            return 3

        servers_sorted = sorted(servers, key=_srv_priority)

        for srv_nombre, v_target in servers_sorted:
            try:
                body_play = {'a': '2', 'v': v_target, 'tok': tok, 'rt': rt, 'tk': tk}
                if qsrc:
                    body_play['src'] = qsrc
                req_play = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_play).encode('utf-8'), headers=headers_post)
                with network.abrir_url(req_play, timeout=7, context=network._ssl_ctx) as r_play:
                    data = json.loads(r_play.read(2 * 1024 * 1024).decode('utf-8'))
                    raw_u = data.get('u') or data.get('stream')
                    if not raw_u:
                        continue
                    u_full = raw_u if raw_u.startswith('http') else 'https://player.pelisserieshoy.com' + raw_u

                    if 'p.php' in u_full:
                        try:
                            req_cdn = urllib.request.Request(u_full, headers={'User-Agent': network.UA, 'Referer': url_player})
                            req_cdn.get_method = lambda: 'HEAD'
                            with network.abrir_url(req_cdn, timeout=7, context=network._ssl_ctx) as r_cdn:
                                if r_cdn.url and r_cdn.url.startswith('http') and 'p.php' not in r_cdn.url:
                                    return r_cdn.url
                        except Exception:
                            pass
                        return u_full
                    elif u_full.startswith('http'):
                        return u_full
            except Exception:
                continue
        return None
    except Exception:
        return None


def resolver_embed69_hosts(url_embed):
    hosts = []
    try:
        req = urllib.request.Request(url_embed, headers={'User-Agent': network.UA, 'Referer': f"{network.SOLOLATINO_BASE}/"})
        with network.abrir_url(req, timeout=8, context=network._ssl_ctx) as r:
            html_e = r.read(2 * 1024 * 1024).decode('utf-8', errors='ignore')

        m_c = re.search(r"const\s+POW_CHALLENGE\s*=\s*['\"]([^'\"]+)", html_e)
        m_d = re.search(r"const\s+POW_DIFFICULTY\s*=\s*(\d+)", html_e)
        m_s = re.search(r"const\s+POW_SALT\s*=\s*['\"]([^'\"]+)", html_e)
        if m_c and m_d and m_s:
            c, d, salt = m_c.group(1), int(m_d.group(1)), m_s.group(1)
            prefix = '0' * d
            nonce = 0
            aes_key_bytes = None
            while nonce < 500000:
                if hashlib.sha256(f'{c}{nonce}'.encode('utf-8')).hexdigest().startswith(prefix):
                    aes_key_bytes = hashlib.sha256(f'{c}{nonce}{salt}'.encode('utf-8')).digest()
                    break
                nonce += 1

            m_links = re.search(r'let\s+dataLink\s*=\s*(\[\{.*?\}\]);', html_e, re.DOTALL)
            if m_links and aes_key_bytes:
                cipher = MiniAES(aes_key_bytes)
                for grp in json.loads(m_links.group(1)):
                    lang = grp.get('video_language', 'LAT')
                    for srv in grp.get('sortedEmbeds', []):
                        try:
                            raw = base64.b64decode(srv['link'])
                            iv, ct = raw[:16], raw[16:]
                            dec = cipher.decrypt_cbc(ct, iv)
                            url_host = dec.decode('utf-8', errors='ignore').replace('`', '').strip()
                            s_name = srv.get('servername', 'Servidor')
                            hosts.append({'nombre': f"{s_name} ({lang})", 'url': url_host})
                        except Exception:
                            pass
    except Exception:
        pass
    return hosts


def resolver_ok_ru(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': network.UA})
        with network.abrir_url(req, timeout=7, context=network._ssl_ctx) as r:
            h = r.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        if 'Video has not been found' in h:
            raise network.ServidorNoDisponible('OK.ru indica que este video ya no existe.')
        m = re.search(r'data-options=[\'"]([^\'"]+)[\'"]', h)
        if not m:
            return None
        d = json.loads(html.unescape(m.group(1)))
        meta = d.get('flashvars', {}).get('metadata')
        if isinstance(meta, str):
            meta = json.loads(meta)
        if not isinstance(meta, dict):
            return None
        videos = meta.get('videos', [])
        prio = {'full': 5, 'hd': 4, 'sd': 3, 'low': 2, 'lowest': 1, 'mobile': 0}
        videos.sort(key=lambda v: prio.get(v.get('name'), 0), reverse=True)
        if videos and videos[0].get('url'):
            v_url = videos[0].get('url')
            return f"{v_url}|User-Agent={urllib.parse.quote(network.UA)}&verifypeer=false"
        hls = meta.get('hlsManifestUrl')
        if hls:
            return f"{hls}|User-Agent={urllib.parse.quote(network.UA)}&verifypeer=false"
    except network.ServidorNoDisponible:
        raise
    except Exception:
        pass
    return None


def resolver_vids_st(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': 'https://www.fuegocine.com/'})
        with network.abrir_url(req, timeout=7, context=network._ssl_ctx) as r:
            h = r.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        m = re.search(r'const\s+url\s*=\s*[\'"]([^\'"]+m3u8[^\'"]*)[\'"]', h)
        if m:
            clean_url = m.group(1).replace(r'\/', '/')
            return f"{clean_url}|User-Agent={urllib.parse.quote(network.UA)}&Referer=https://vids.st/&verifypeer=false"
    except Exception:
        pass
    return None


class DriveConfirmationParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.action = None
        self.inputs = {}
        self.link = None
        self.in_form = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'form' and attrs.get('id') == 'download-form':
            self.action = attrs.get('action')
            self.in_form = True
        elif tag == 'input' and self.in_form and attrs.get('name'):
            self.inputs[attrs['name']] = attrs.get('value', '')
        elif tag == 'a' and attrs.get('id') == 'uc-download-link':
            self.link = attrs.get('href')

    def handle_endtag(self, tag):
        if tag == 'form':
            self.in_form = False


def resolver_google_drive(url):
    m_id = re.search(r'/d/([a-zA-Z0-9_-]+)', url) or re.search(r'[?&]id=([a-zA-Z0-9_-]+)', url)
    if not m_id:
        return None
    opener = network.nueva_sesion()
    target = 'https://drive.usercontent.google.com/download?' + urllib.parse.urlencode({
        'id': m_id.group(1), 'export': 'download', 'authuser': '0'})
    headers = {'User-Agent': network.UA}
    try:
        for _ in range(3):
            # Probar la misma descarga abierta que pedira el reproductor.
            # Un rango pequeno puede venir de cache aun con la cuota agotada.
            # Solo leemos el prefijo y cerramos; no descargamos el archivo.
            req = urllib.request.Request(target, headers=dict(headers, Range='bytes=0-'))
            with opener.open(req, timeout=12) as response:
                ct = response.headers.get('Content-Type', '').lower().split(';')[0]
                prefix = response.read(2048)
                final_url = response.geturl()
                probe = prefix.lstrip().lower()
                is_html = ct in ('text/html', 'application/xhtml+xml') or probe.startswith((b'<!doctype html', b'<html'))
                if not is_html and prefix and (ct.startswith(('video/', 'audio/')) or ct in ('application/octet-stream', 'application/x-matroska')):
                    # Drive usa /download sin extension: evitar que Kodi haga
                    # otra deteccion HEAD o interprete la URL como una pagina.
                    if ct == 'video/mp4' or prefix[4:8] == b'ftyp':
                        headers['ext'] = '.mp4'
                    elif (ct in ('video/x-matroska', 'application/x-matroska')
                          or (prefix.startswith(b'\x1aE\xdf\xa3') and b'matroska' in prefix)):
                        headers['ext'] = '.mkv'
                    return network.url_con_cabeceras(final_url, headers, opener)
                if not is_html:
                    return None
                body = (prefix + response.read(256 * 1024)).decode('utf-8', 'replace')
            if any(x in body.lower() for x in ('quota exceeded', 'downloadquotaexceeded', 'cuota', 'too many users')):
                network.log_resolver('Google Drive: cuota de descarga agotada')
                raise network.ServidorNoDisponible('Google Drive: cuota de descarga agotada. Elige otro servidor o prueba mas tarde.')
            parser = DriveConfirmationParser()
            parser.feed(body)
            next_url = parser.link
            if parser.action:
                action = urllib.parse.urljoin(final_url, parser.action)
                parts = urllib.parse.urlsplit(action)
                params = dict(urllib.parse.parse_qsl(parts.query))
                params.update(parser.inputs)
                next_url = urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(params)))
            if not next_url:
                return None
            target = urllib.parse.urljoin(final_url, next_url)
            if urllib.parse.urlsplit(target).hostname not in ('drive.google.com', 'drive.usercontent.google.com'):
                return None
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('Google Drive: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def extraer_url_hls(page):
    # Desescapar solo separadores conocidos; no alterar los tokens firmados.
    page = html.unescape(page.replace(r'\/', '/').replace(r'\u0026', '&'))
    match = re.search(r'https?://[^\s\'"<>\\]+\.m3u8(?:\?[^\s\'"<>\\]*)?', page, re.I)
    if match:
        return match.group(0)
    return None


def extraer_fuentes_hls(page, referer):
    """Respetar la prioridad de links del reproductor y validar cada variante."""
    cleaned = html.unescape(page.replace(r'\/', '/').replace(r'\u0026', '&'))
    found = re.search(r'\b(?:var|let|const)\s+links\s*=\s*(\{[^{}]+\})', cleaned)
    if found:
        try:
            links = json.loads(found.group(1))
            return [urllib.parse.urljoin(referer, links[key]) for key in ('hls4', 'hls3', 'hls2')
                    if isinstance(links.get(key), str) and links[key]]
        except ValueError:
            pass

    # 1. Patron sources: [...] (JWPlayer / Plyr / VidHide / StreamWish / etc.)
    m_sources = re.search(r'sources?\s*:\s*\[([^\]]+)\]', cleaned, re.I)
    if m_sources:
        inner = m_sources.group(1)
        matches = re.findall(r'(?:src|file)\s*:\s*["\']?(https?://[^"\'\s,]+(?:\.m3u8|\.mp4)[^"\'\s,]*)', inner, re.I)
        if not matches:
            matches = re.findall(r'https?://[^"\'\s,]+(?:\.m3u8|\.mp4)[^"\'\s,]*', inner, re.I)
        if matches:
            return [urllib.parse.urljoin(referer, m) for m in matches]

    # 2. Patron "hls": "url" (VOE / APIs de reproductores)
    m_hls = re.search(r'["\']hls["\']\s*:\s*["\'](https?://[^"\']+)["\']', cleaned, re.I)
    if m_hls:
        return [urllib.parse.urljoin(referer, m_hls.group(1))]

    # 3. Extraccion directa de URL .m3u8
    media = extraer_url_hls(cleaned)
    if media:
        return [media]

    # 4. Extraccion directa de URL .mp4
    match_mp4 = re.search(r'https?://[^\s\'"<>\\]+\.mp4(?:\?[^\s\'"<>\\]*)?', cleaned, re.I)
    if match_mp4:
        return [match_mp4.group(0)]

    return []


def resolver_host_hls(embed_url, timeout=15):
    opener = network.nueva_sesion()
    host = urllib.parse.urlsplit(embed_url)
    referer = '{}://{}/'.format(host.scheme, host.netloc)
    try:
        if host.path.lower().endswith('.m3u8'):
            return procesar_hls_local(embed_url, referer, opener, timeout=timeout)
        req = urllib.request.Request(embed_url, headers={'User-Agent': network.UA, 'Referer': referer})
        with opener.open(req, timeout=timeout) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = response.geturl()
        # Redireccion explicita de VOE; no ejecutar JavaScript de la pagina.
        redirect = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
        if redirect:
            req = urllib.request.Request(html.unescape(redirect.group(1)), headers={'User-Agent': network.UA, 'Referer': referer})
            with opener.open(req, timeout=timeout) as response:
                page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                referer = response.geturl()
        if 'countries are not allowed' in page.lower():
            raise network.ServidorNoDisponible('Este servidor restringe el acceso desde tu ubicacion. Elige otro servidor.')
        if 'confirm you' in page.lower() and 'human to start the video' in page.lower():
            raise network.ServidorNoDisponible('Este servidor exige verificacion humana en su web. Elige otro servidor en Kodi.')
        if 'file is no longer available as it expired or has been deleted' in page.lower():
            raise network.ServidorNoDisponible('El servidor indica que el archivo expiro o fue eliminado. Elige otro servidor.')
        sources = extraer_fuentes_hls(page, referer)
        if not sources:
            # El packer puede usar cualquier letra para sus argumentos finales.
            pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
            for match in re.finditer(pattern, page, re.S):
                p, a, c, k = match.groups()
                sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), referer)
                if sources:
                    break
        for media in sources[:3]:
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': referer}, opener)
            stream = procesar_hls_local(media, referer, opener, timeout=timeout)
            if stream:
                return stream
        network.log_resolver('HLS: no se encontro un manifiesto en ' + host.netloc)
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('HLS: {} en {}'.format(getattr(exc, 'reason', type(exc).__name__), host.netloc))
    return None


def resolver_goodstream(embed_url):
    return resolver_host_hls(embed_url)


def resolver_vimeos(embed_url):
    return resolver_host_hls(embed_url)


def resolver_altcha(challenge, max_seconds=8):
    """Implementar el calculo publico ALTCHA v2 con coste y tiempo acotados."""
    params = challenge['parameters']
    cost = params.get('cost')
    length = params.get('keyLength', 32)
    prefix = params.get('keyPrefix', '')
    if (params.get('algorithm') != 'PBKDF2/SHA-256'
            or not isinstance(cost, int) or not 1 <= cost <= 100000
            or not isinstance(length, int) or not 16 <= length <= 64
            or not isinstance(prefix, str) or not re.fullmatch(r'[0-9a-f]{1,4}', prefix)):
        raise network.ServidorNoDisponible('VOE solicita una verificacion no compatible.')
    nonce = bytes.fromhex(params['nonce'])
    salt = bytes.fromhex(params['salt'])
    if not 1 <= len(nonce) <= 128 or not 1 <= len(salt) <= 128:
        raise ValueError('ALTCHA: parametros invalidos')
    started = time.monotonic()
    deadline = getattr(network._sondeo, 'deadline', None)
    if deadline is not None:
        max_seconds = min(max_seconds, max(0, deadline - started))
    for counter in range(10000):
        cancel = getattr(network._sondeo, 'cancel', None)
        if cancel is not None and cancel.is_set():
            break
        if time.monotonic() - started >= max_seconds:
            break
        derived = hashlib.pbkdf2_hmac('sha256', nonce + counter.to_bytes(4, 'big'),
                                      salt, cost, length).hex()
        if derived.startswith(prefix):
            solution = {'counter': counter, 'derivedKey': derived,
                        'time': round((time.monotonic() - started) * 1000, 1)}
            return base64.b64encode(json.dumps({'challenge': challenge, 'solution': solution}).encode()).decode('ascii')
    raise network.ServidorNoDisponible('VOE: la verificacion excedio el tiempo de espera. Prueba otro servidor.')


class VoeGateParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.challenge = None
        self.fields = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'altcha-widget':
            self.challenge = attrs.get('challenge')
        elif tag == 'input' and attrs.get('name') in ('_token', 'access'):
            self.fields[attrs['name']] = attrs.get('value', '')


def extraer_fuente_voe(page):
    # La variable source visible en el HTML apunta a un video de demostracion.
    # Usar exclusivamente la configuracion JSON del reproductor real.
    for raw in re.findall(r'<script\b[^>]*type=[\'"]application/json[\'"][^>]*>(.*?)</script>', page, re.S | re.I):
        try:
            data = json.loads(raw)
            if not isinstance(data, list) or not data or not isinstance(data[0], str):
                continue
            encoded = codecs.decode(data[0], 'rot_13')
            for marker in ('@$', '^^', '~@', '%?', '*~', '!!', '#&'):
                encoded = encoded.replace(marker, '')
            shifted = base64.b64decode(encoded, validate=True).decode('utf-8')
            decoded = ''.join(chr(ord(c) - 3) for c in shifted)[::-1]
            config = json.loads(base64.b64decode(decoded, validate=True))
            if not isinstance(config, dict):
                continue
            source = config.get('source')
            if isinstance(source, str) and source.startswith(('https://', 'http://')):
                return source
        except (ValueError, TypeError, UnicodeError):
            continue
    return None


def resolver_voe(embed_url):
    opener = network.nueva_sesion()
    domain = urllib.parse.urlsplit(embed_url).netloc or 'voe.sx'
    headers = {'User-Agent': network.UA, 'Referer': f'https://{domain}/'}
    try:
        with opener.open(urllib.request.Request(embed_url, headers=headers), timeout=12) as r:
            page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            url = r.geturl()
        redirect = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
        if redirect:
            with opener.open(urllib.request.Request(html.unescape(redirect.group(1)), headers=headers), timeout=12) as r:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                url = r.geturl()
        if 'permanentToken' in page:
            redirect2 = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
            if redirect2:
                with opener.open(urllib.request.Request(html.unescape(redirect2.group(1)), headers={'User-Agent': network.UA, 'Referer': url}), timeout=12) as r:
                    page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                    url = r.geturl()
        gate = VoeGateParser()
        gate.feed(page)
        if gate.challenge:
            challenge_url = urllib.parse.urljoin(url, gate.challenge)
            if urllib.parse.urlsplit(challenge_url).netloc != urllib.parse.urlsplit(url).netloc or '_token' not in gate.fields:
                raise ValueError('VOE: formulario inesperado')
            headers['Referer'] = url
            with opener.open(urllib.request.Request(challenge_url, headers=headers), timeout=12) as r:
                challenge = json.loads(r.read(64 * 1024))
            gate.fields['altcha'] = resolver_altcha(challenge)
            request = urllib.request.Request(url, headers=headers,
                data=urllib.parse.urlencode(gate.fields).encode('utf-8'))
            with opener.open(request, timeout=12) as r:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                url = r.geturl()
            if '<altcha-widget' in page:
                raise network.ServidorNoDisponible('VOE no acepto la verificacion. Prueba otro servidor.')
        source = extraer_fuente_voe(page)
        if source:
            return procesar_hls_local(source, url, opener)
        # Fallback a extraccion directa/desempaquetado
        sources = extraer_fuentes_hls(page, url)
        if not sources:
            pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
            for match in re.finditer(pattern, page, re.S):
                p, a, c, k = match.groups()
                sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), url)
                if sources:
                    break
        for media in sources[:3]:
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': url}, opener)
            stream = procesar_hls_local(media, url, opener)
            if stream:
                return stream
        network.log_resolver('VOE: no se encontro la configuracion de video')
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('VOE: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_playmate(embed_url):
    """API usada por el reproductor publico de Playmate; sx es el master."""
    opener = network.nueva_sesion()
    parts = urllib.parse.urlsplit(embed_url)
    code = parts.path.rstrip('/').split('/')[-1]
    root = '{}://{}'.format(parts.scheme, parts.netloc)
    headers = {'User-Agent': network.UA, 'Referer': embed_url}
    try:
        with opener.open(urllib.request.Request(embed_url, headers=headers), timeout=12) as r:
            r.read(1024 * 1024)
        request = urllib.request.Request(root + '/api/s',
            data=json.dumps({'c': code, 'd': 'desktop'}).encode('utf-8'),
            headers=dict(headers, **{'Content-Type': 'application/json'}))
        with opener.open(request, timeout=12) as r:
            data = json.loads(r.read(256 * 1024))
        media = data.get('sx', '')
        if isinstance(media, str) and media.startswith(('https://', 'http://')):
            return procesar_hls_local(media, embed_url, opener)
        network.log_resolver('PM: la API no devolvio un video disponible')
    except Exception as exc:
        network.log_resolver('PM: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_unlimplay(embed_url):
    """UA agrupa hosts por idioma y publica un extractor HLS propio."""
    opener = network.nueva_sesion()
    try:
        parts = urllib.parse.urlsplit(embed_url)
        episode = re.search(r'/embed/tv/\d+/(\d+)/(\d+)/?$', parts.path)
        if episode:
            # El frontend redirigido puede perder temporada/episodio de la
            # ruta y devolver solo searched_names. Su API acepta estos campos.
            params = dict(urllib.parse.parse_qsl(parts.query))
            params.setdefault('season', episode.group(1))
            params.setdefault('episode', episode.group(2))
            # /play/ redirige a /f/ descartando el query; usar el destino
            # publicado para conservar esos parametros desde la primera GET.
            path = parts.path.replace('/play/embed/', '/f/embed/', 1)
            embed_url = urllib.parse.urlunsplit(parts._replace(path=path, query=urllib.parse.urlencode(params)))
        req = urllib.request.Request(embed_url, headers={'User-Agent': network.UA})
        with opener.open(req, timeout=12) as r:
            page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = r.geturl()
        endpoint = re.search(r'const\s+ULP_EXTRACT_URL\s*=\s*("[^"\n]+")', page)
        token = re.search(r'const\s+ULP_SESSION_TOKEN\s*=\s*("[^"\n]+")', page)
        found = re.search(r'finalizePlayer\(\s*(\{"searched_names".*?\})\s*\);', page, re.S)
        if not (endpoint and token and found):
            network.log_resolver('UA: no se encontro la lista de servidores')
            return None
        endpoint = json.loads(endpoint.group(1))
        if urllib.parse.urlsplit(endpoint).hostname != urllib.parse.urlsplit(referer).hostname:
            return None
        data = json.loads(found.group(1))
        # FuegoCine anuncia UA latino: no cambiar silenciosamente el idioma.
        # Algunos titulos solo tienen video en el ultimo host (Fastream).
        # Recorrer las alternativas con el mismo limite global de tiempo.
        candidates = [url for name, url in data.get('latino', {}).items()
                      if 'vidhide' not in name.lower() and urllib.parse.urlsplit(url).hostname != 'morencius.com'][:8]
        deadline = time.monotonic() + 35
        for host_url in candidates:
            if time.monotonic() >= deadline:
                break
            try:
                # Fastream firma enlaces para la conexion que extrae el video.
                # El extractor remoto de UA puede entregar una firma rechazada
                # desde Kodi; resolver localmente con su propia sesion.
                if urllib.parse.urlsplit(host_url).hostname == 'fastream.to':
                    stream = resolver_host_hls(host_url, timeout=min(6, max(1, (deadline - time.monotonic()) / 2)))
                    if stream:
                        return stream
                request = urllib.request.Request(endpoint,
                    data=json.dumps({'url': host_url}).encode('utf-8'),
                    headers={'User-Agent': network.UA, 'Referer': referer,
                             'Content-Type': 'application/json',
                             'X-ULP-Token': json.loads(token.group(1))})
                with opener.open(request, timeout=min(8, max(1, deadline - time.monotonic()))) as r:
                    extracted = json.loads(r.read(256 * 1024))
                streams = extracted.get('streams', [])
                if not isinstance(streams, list):
                    continue
                for media in streams[:3]:
                    if time.monotonic() >= deadline:
                        break
                    if not isinstance(media, str) or not media.startswith(('https://', 'http://')):
                        continue
                    stream = procesar_hls_local(media, extracted.get('referer') or host_url,
                        opener, timeout=min(6, max(1, deadline - time.monotonic())))
                    if stream:
                        return stream
            except Exception as exc:
                network.log_resolver('UA: fallo en un host ({})'.format(type(exc).__name__))
        network.log_resolver('UA: ningun manifiesto latino accesible')
    except Exception as exc:
        network.log_resolver('UA: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def hydrax_transform(data, seed):
    # Protocolo publico del player, contrastado con ResolveURL:
    # github.com/Gujal00/ResolveURL/blob/master/script.module.resolveurl/lib/resolveurl/plugins/abyss.py
    seed = str(seed)
    numeric = seed.replace('.', '', 1).replace(':', '').replace('-', '').isdigit()
    material = bytes(int(c) if c.isdigit() else ord(c) for c in seed) if numeric else seed.encode('utf-8')
    key = hashlib.md5(material).hexdigest().encode('ascii')
    return MiniAES(key).transform_ctr(data, int.from_bytes(key[:16], 'big'))


def resolver_hydrax(url):
    opener = network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': url}
    with opener.open(urllib.request.Request(url, headers=headers), timeout=10) as response:
        page = response.read(1024 * 1024).decode('utf-8', 'replace')
    match = re.search(r'(?:const|var)\s+datas\s*=\s*"([^"]+)"', page)
    if not match:
        raise network.ServidorNoDisponible('VIP/Hydrax no entrego la configuracion del video.')
    # El player usa atob: cada byte representa un caracter, no texto UTF-8.
    data = json.loads(base64.b64decode(match.group(1)).decode('latin-1'))
    media = data.get('media')
    if isinstance(media, str):
        seed = '{user_id}:{slug}:{md5_id}'.format(**data)
        media = json.loads(hydrax_transform(bytes(ord(c) & 255 for c in media), seed))
    mp4 = media.get('mp4', {})
    sources = sorted((x for x in mp4.get('sources', []) if x.get('status') and x.get('size')),
                     key=lambda x: int(x['size']), reverse=True)
    if not sources:
        raise network.ServidorNoDisponible('VIP/Hydrax: no hay archivos de video disponibles.')
    source = sources[0]
    domain = next((d for d in mp4.get('domains', []) if d.startswith(source.get('sub', '') + '.')), None)
    if not domain:
        raise network.ServidorNoDisponible('VIP/Hydrax: falta el servidor del archivo.')
    path = '/mp4/{}/{}/{}?v={}'.format(data['md5_id'], source['res_id'], source['size'], data['slug'])
    token = base64.b64encode(base64.b64encode(hydrax_transform(path.encode('utf-8'), source['size']))).decode('ascii')
    target = 'https://{}/sora/{}/{}'.format(domain, source['size'], token)
    with opener.open(urllib.request.Request(target, headers=dict(headers, Range='bytes=0-1023')), timeout=10) as response:
        prefix = response.read(32)
        if response.status != 206 or prefix[4:8] != b'ftyp':
            raise network.ServidorNoDisponible('VIP/Hydrax no entrego un MP4 con soporte para adelantar.')
    # La URL carece de extension. No enviar Range fijo al reproductor.
    labels = sorted({x.get('label', '') for x in sources if re.fullmatch(r'\d+p', x.get('label', ''))},
                    key=lambda value: int(value[:-1]))
    CALIDADES_HLS[target] = ('Multirresolucion: {} (auto: {})'.format(' / '.join(labels), source.get('label', ''))
                            if len(labels) > 1 else source.get('label', ''))
    return network.url_con_cabeceras(target, dict(headers, ext='.mp4'), opener)


def resolver_menu_antiguo(url):
    opener = network.nueva_sesion()
    with opener.open(urllib.request.Request(url, headers={'User-Agent': network.UA}), timeout=8) as response:
        page = response.read(1024 * 1024).decode('utf-8', 'replace')
    targets = re.findall(r"go_to_player\(['\"](https?://[^'\"]+)['\"]", page)
    supported = ('goodstream.one', 'vimeos.net', 'voe.sx', 'hglink.to', 'playmate.to', 'fastream.to', 'player.pelisserieshoy.com', 'abyssplayer.com', 'playhydrax.com')
    for target in list(dict.fromkeys(targets))[:8]:
        if urllib.parse.urlsplit(target).hostname not in supported:
            continue
        try:
            stream = resolver_enlace_directo(html.unescape(target))
            if stream:
                return stream
        except network.ServidorNoDisponible:
            pass
    raise network.ServidorNoDisponible('Este menu antiguo no ofrece un enlace compatible disponible. Elige Premium, StreamWish o VOE.')


def resolver_upns(url):
    parts = urllib.parse.urlsplit(url)
    if not parts.fragment:
        return None
    endpoint = '{}://{}/api/v1/video?{}'.format(parts.scheme, parts.netloc,
        urllib.parse.urlencode({'id': parts.fragment, 'w': 1920, 'h': 1080, 'r': 'fuegocine.com'}))
    try:
        with network.nueva_sesion().open(urllib.request.Request(endpoint, headers={'User-Agent': network.UA, 'Referer': url}), timeout=8) as response:
            data = json.loads(response.read(1024 * 1024))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise network.ServidorNoDisponible('US: el servidor informa que el video no existe o fue eliminado.')
        raise
    source = data.get('hls') or data.get('file') or data.get('url')
    if isinstance(source, str) and '.m3u8' in source:
        return procesar_hls_local(source, url)
    raise network.ServidorNoDisponible('US no ofrece un enlace de video compatible con el addon.')


def _filemoon_crypto(operation, **payload):
    node = shutil.which('node')
    if not node:
        raise network.ServidorNoDisponible('Filemoon: este reproductor requiere Node.js local.')
    result = subprocess.run([node, os.path.join(os.path.dirname(__file__), 'filemoon_crypto.js')],
                            input=json.dumps(dict(payload, operation=operation)),
                            text=True, capture_output=True, timeout=network.tiempo_peticion(8),
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise network.ServidorNoDisponible('Filemoon: no se pudo verificar o descifrar la respuesta del reproductor.')
    return json.loads(result.stdout)


def _filemoon_attest(api, user_agent):
    challenge = api('/api/videos/access/challenge', {})
    signature = _filemoon_crypto('sign', nonce=challenge['nonce'])
    identity = {'viewer_id': str(uuid.uuid4()), 'device_id': str(uuid.uuid4())}
    result = api('/api/videos/access/attest', dict(identity, **signature,
                 challenge_id=challenge['challenge_id'], nonce=challenge['nonce'],
                 client={'user_agent': user_agent, 'platform': 'Windows', 'languages': ['es-ES']},
                 storage={}, attributes={}))
    if not result.get('token'):
        raise network.ServidorNoDisponible('Filemoon: el reproductor no acepto la sesion.')
    return {key: result.get(key, identity.get(key))
            for key in ('token', 'viewer_id', 'device_id', 'confidence')}


def _filemoon_proof(challenge, timeout=8):
    node = shutil.which('node')
    if not node:
        raise network.ServidorNoDisponible('Filemoon: la comprobacion automatica requiere Node.js local; no se instalo ninguna dependencia.')
    timeout = network.tiempo_peticion(timeout)
    payload = {'nonce': challenge['pow_nonce'], 'difficulty': challenge['pow_difficulty'],
               'timeout_ms': int(timeout * 1000)}
    result = subprocess.run([node, os.path.join(os.path.dirname(__file__), 'filemoon_pow.js')],
                            input=json.dumps(payload), text=True, capture_output=True,
                            timeout=network.tiempo_peticion(timeout + 1),
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise network.ServidorNoDisponible('Filemoon: formato de comprobacion no compatible.')
    solution = json.loads(result.stdout).get('solution')
    if solution is None:
        raise network.ServidorNoDisponible('Filemoon: la comprobacion excedio el tiempo disponible.')
    return solution


def _filemoon_resolve(url):
    network.tiempo_peticion(8)  # Honor scanner cancellation before any request or helper.
    parsed = urllib.parse.urlsplit(url)
    code = parsed.path.rstrip('/').rsplit('/', 1)[-1]
    if not re.fullmatch(r'[A-Za-z0-9]+', code):
        raise network.ServidorNoDisponible('Filemoon: enlace de video no valido.')
    host = 'bysefujedu.com' if parsed.hostname == 'filemoon.sx' else parsed.hostname
    origin = 'https://' + host
    referer = url
    opener = network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': referer, 'Accept': 'application/json'}

    def api(path, body=None):
        endpoint = path if path.startswith('/api/videos/access/') else '/api/videos/' + code + '/embed/' + path
        request = urllib.request.Request(origin + endpoint,
                          data=json.dumps(body).encode() if body is not None else None,
                          headers=dict(headers, **({'Content-Type': 'application/json'} if body is not None else {})))
        with opener.open(request, timeout=8) as response:
            raw = response.read(512 * 1024 + 1)
        if len(raw) > 512 * 1024:
            raise ValueError('Filemoon API response too large')
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError('Filemoon API response is not an object')
        return data

    details = api('details')
    frame = details.get('embed_frame_url', '')
    if frame:
        target = urllib.parse.urlsplit(frame)
        # Follow only the HTTPS player for this exact file, never a local host.
        if (target.scheme != 'https' or not target.hostname or '.' not in target.hostname
                or target.username or target.port not in (None, 443)
                or not re.fullmatch(r'/[A-Za-z0-9]{1,16}/' + re.escape(code), target.path)):
            raise network.ServidorNoDisponible('Filemoon: direccion del reproductor no reconocida.')
        import ipaddress
        try:
            ipaddress.ip_address(target.hostname)
        except ValueError:
            pass
        else:
            raise network.ServidorNoDisponible('Filemoon: direccion del reproductor no reconocida.')
        origin, referer = 'https://' + target.hostname, frame
        headers.update({'Referer': frame, 'Origin': origin,
                        'X-Embed-Origin': parsed.hostname, 'X-Embed-Referer': url,
                        'X-Embed-Parent': url})
    settings = api('settings')
    fingerprint = None
    if frame:
        fingerprint = _filemoon_attest(api, network.UA)
    if settings.get('captcha_required'):
        challenge = api('captcha', {})
        solution = _filemoon_proof(challenge)
        verified = api('captcha/verify', {'pow_token': challenge['pow_token'], 'solution': solution})
        if verified.get('status') != 'ok' or not verified.get('token'):
            raise network.ServidorNoDisponible('Filemoon no acepto la comprobacion automatica; puede requerir verificacion visual en su web.')
        headers['X-Captcha-Token'] = verified['token']
    try:
        try:
            playback = api('playback', {'fingerprint': fingerprint}) if fingerprint else api('playback')
        except urllib.error.HTTPError as exc:
            if exc.code != 405:
                raise
            playback = api('playback', {})
    except urllib.error.HTTPError as exc:
        raise network.ServidorNoDisponible('Filemoon: su API de reproduccion respondio HTTP %s; aun no se obtuvo el video.' % exc.code) from exc
    if isinstance(playback.get('playback'), dict):
        playback = _filemoon_crypto('decrypt', playback=playback['playback'])
    # Accept only explicit sources. Never return the player HTML as a video.
    for source in playback.get('sources', []):
        media = source.get('url', '') if isinstance(source, dict) else ''
        if urllib.parse.urlsplit(media).scheme not in ('http', 'https'):
            continue
        stream = procesar_hls_local(media, referer, opener, timeout=8)
        if stream:
            return stream
    raise network.ServidorNoDisponible('Filemoon: la API no entrego un manifiesto compatible; la comprobacion no garantiza la reproduccion.')


def resolver_filemoon(url):
    try:
        return _filemoon_resolve(url)
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('Filemoon API: ' + type(exc).__name__)
    # Legacy mirrors may still publish a packed JWPlayer page.
    stream = resolver_host_hls(url)
    if stream:
        return stream
    raise network.ServidorNoDisponible('Filemoon no entrego una fuente de video compatible con Kodi.')


def resolver_vidhide(embed_url):
    """Resuelve enlaces embebidos de VidHide y sus variantes (minochinos, vidhidepro, streamhide, etc.)."""
    domain = urllib.parse.urlsplit(embed_url).netloc
    referer = f'https://{domain}/' if domain else embed_url
    opener = network.nueva_sesion()
    try:
        req = urllib.request.Request(embed_url, headers={'User-Agent': network.UA, 'Referer': referer})
        with opener.open(req, timeout=12) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            final_referer = response.geturl()

        sources = extraer_fuentes_hls(page, final_referer)
        if not sources:
            pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
            for match in re.finditer(pattern, page, re.S):
                p, a, c, k = match.groups()
                sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), final_referer)
                if sources:
                    break

        for media in sources[:3]:
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': final_referer}, opener)
            stream = procesar_hls_local(media, final_referer, opener, timeout=12)
            if stream:
                return stream
        network.log_resolver('VidHide: no se encontro fuente de video reproducible en ' + domain)
    except Exception as exc:
        network.log_resolver('VidHide: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_streamwish(embed_url):
    """
    Resuelve StreamWish y sus multiples espejos (strwish, wishfast, sfastwish, hglink, hanerix, embedwish).
    Prueba el enlace original y los espejos activos conocidos con descarte rapido en caso de fallo.
    """
    id_match = re.search(r'/(?:e|v|embed)/([a-zA-Z0-9_-]+)', embed_url)
    raw_id = id_match.group(1) if id_match else None

    mirrors = [embed_url]
    if raw_id:
        extra_mirrors = [
            f'https://strwish.com/e/{raw_id}',
            f'https://wishfast.top/e/{raw_id}',
            f'https://sfastwish.com/e/{raw_id}',
            f'https://hanerix.com/e/{raw_id}',
            f'https://hglink.to/e/{raw_id}',
            f'https://embedwish.com/e/{raw_id}',
        ]
        for m in extra_mirrors:
            if m not in mirrors:
                mirrors.append(m)

    try:
        stream = resolver_host_hls(embed_url)
        if stream:
            return stream
    except Exception:
        pass

    deadline = time.monotonic() + 18
    for mirror in mirrors[1:]:
        if time.monotonic() >= deadline:
            break
        try:
            stream = resolver_host_hls(mirror, timeout=min(6, max(1, deadline - time.monotonic())))
            if stream:
                return stream
        except Exception:
            continue
    network.log_resolver('StreamWish: no se pudo resolver en ningun espejo disponible')
    return None


def desenvolver_embed_shortener(url):
    """
    Desenvolver JWT de embedshortener.co / fkplayer.xyz.
    Decodifica la carga util base64 (payload.embed o link) para obtener el servidor real.
    """
    if not url or not any(x in url.lower() for x in ('embedshortener.', 'fkplayer.', 'shortener')):
        return None
    try:
        path = urllib.parse.urlsplit(url).path
        token = path.rstrip('/').split('/')[-1].split('?')[0].split('#')[0]
        parts = token.split('.')
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        payload_b64 += '=' * ((4 - len(payload_b64) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64).decode('utf-8', 'ignore'))
        if not isinstance(payload, dict):
            return None
        if payload.get('embed') and payload['embed'].startswith('http'):
            return payload['embed']
        if payload.get('link'):
            raw_link = payload['link']
            raw_link += '=' * ((4 - len(raw_link) % 4) % 4)
            decoded = base64.b64decode(raw_link).decode('utf-8', 'ignore')
            if decoded.startswith('http'):
                return decoded
    except Exception:
        pass
    return None


def resolver_pixeldrain(url):
    """Pixeldrain: https://pixeldrain.com/u/{id} -> https://pixeldrain.com/api/file/{id}"""
    m = re.search(r'pixeldrain\.com/(?:u|api/file)/([a-zA-Z0-9]+)', url)
    if m:
        file_id = m.group(1)
        direct = f"https://pixeldrain.com/api/file/{file_id}"
        return f"{direct}|User-Agent={urllib.parse.quote(network.UA)}"
    return None


def resolver_vidara(embed_url):
    """Vidara: /e/<id> o /player/<id> -> consulta la API y extrae streaming_url."""
    m = re.search(r'/(?:e|player)/([^/?#]+)', embed_url)
    if not m:
        return None
    filecode = m.group(1)
    api = f"https://vidara.so/api/stream?filecode={urllib.parse.quote(filecode)}"
    opener = network.nueva_sesion()
    try:
        req = urllib.request.Request(api, headers={'User-Agent': network.UA, 'Referer': embed_url, 'Accept': 'application/json'})
        with opener.open(req, timeout=10) as r:
            data = json.loads(r.read(256 * 1024).decode('utf-8', 'replace'))
        media = data.get('streaming_url') or data.get('file') or data.get('url') or (data.get('data') and (data['data'].get('streaming_url') or data['data'].get('url')))
        if media and isinstance(media, str) and media.startswith('http'):
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': embed_url}, opener)
            return procesar_hls_local(media, embed_url, opener)
    except Exception as exc:
        network.log_resolver('Vidara: fallo ({})'.format(type(exc).__name__))
    return None


def resolver_primeload(embed_url):
    """Primeload: busca espejos StreamWish asociados o blobs base64 con .m3u8."""
    opener = network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': 'https://embedshortener.co/'}
    try:
        req = urllib.request.Request(embed_url, headers=headers)
        with opener.open(req, timeout=10) as r:
            html_text = r.read(1024 * 1024).decode('utf-8', 'replace')
        mirrors = list(dict.fromkeys(re.findall(r'["\'](//[a-z0-9.-]+\.[a-z]{2,}/[A-Za-z0-9_-]{6,}/\d+)["\']', html_text, re.I)))
        for mirror in ['https:' + m for m in mirrors[:4]]:
            try:
                stream = resolver_host_hls(mirror, timeout=6)
                if stream:
                    return stream
            except Exception:
                continue
        for b64 in re.findall(r'atob\(\s*["\']([A-Za-z0-9+/=]{40,})["\']\s*\)', html_text):
            try:
                dec = base64.b64decode(b64).decode('utf-8', 'ignore')
                m3 = extraer_url_hls(dec)
                if m3:
                    return procesar_hls_local(m3, embed_url, opener)
            except Exception:
                pass
    except Exception as exc:
        network.log_resolver('Primeload: fallo ({})'.format(type(exc).__name__))
    return None


def resolver_dood(url):
    import secrets
    from dood_session import configure, resolve_external
    external = resolve_external(url)
    if external:
        return external
    opener = network.nueva_sesion()
    try:
        user_agent = configure(opener) or network.UA
    except (OSError, ValueError) as exc:
        raise network.ServidorNoDisponible('Doodstream: no se pudo leer el archivo de cookies configurado.') from exc
    request = urllib.request.Request(url, headers={'User-Agent': user_agent, 'Referer': url})
    try:
        with opener.open(request, timeout=12) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = response.geturl()
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            raise network.ServidorNoDisponible('Doodstream: acceso HTTP 403 en %s. Configura sus cookies y User-Agent en Ajustes > Doodstream.' % urllib.parse.urlsplit(exc.url).hostname) from exc
        raise
    endpoint = re.search(r'''['"](/pass_md5/[^'"]+)''', page)
    token = re.search(r'[?&]token=([a-zA-Z0-9]+)&expiry=', page)
    if not endpoint or not token:
        raise network.ServidorNoDisponible('Dood no entrega el enlace de este video o requiere verificacion en su web.')
    request = urllib.request.Request(urllib.parse.urljoin(referer, endpoint.group(1)),
                                     headers={'User-Agent': user_agent, 'Referer': referer})
    with opener.open(request, timeout=12) as response:
        prefix = response.read(8192).decode('utf-8', 'replace').strip()
    if not prefix.startswith(('https://', 'http://')) or '<' in prefix:
        raise network.ServidorNoDisponible('Dood no autorizo la reproduccion de este enlace.')
    media = prefix + secrets.token_hex(5) + '?token=' + token.group(1) + '&expiry=' + str(int(time.time() * 1000))
    return network.url_con_cabeceras(media, {'User-Agent': user_agent, 'Referer': referer}, opener)


def extraer_streamtape(page, referer):
    assignment = re.search(r"getElementById\(['\"]robotlink['\"]\)\.innerHTML\s*=\s*(.*?);", page, re.S)
    if not assignment:
        return None
    expression = assignment.group(1)
    # Only read string literals and numeric substring operations; never execute JS.
    tokens = list(re.finditer(r"(['\"])((?:\\.|(?!\1).)*)\1", expression))
    values = []
    for index, token in enumerate(tokens):
        value = token.group(2).replace(r'\/', '/')
        tail = expression[token.end():tokens[index + 1].start() if index + 1 < len(tokens) else len(expression)]
        for offset in re.findall(r'\.substring\(\s*(\d+)\s*\)', tail):
            value = value[int(offset):]
        values.append(value)
    media = urllib.parse.urljoin(referer, html.unescape(''.join(values)))
    parsed = urllib.parse.urlsplit(media)
    if parsed.hostname != urllib.parse.urlsplit(referer).hostname or parsed.path != '/get_video':
        return None
    return media + '&stream=1'


def resolver_streamtape(url):
    opener = network.nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': url})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    media = extraer_streamtape(page, referer)
    if not media:
        raise network.ServidorNoDisponible('Streamtape no entrega un enlace reproducible para este video.')
    return media + '|User-Agent=' + urllib.parse.quote(network.UA) + '&Referer=' + urllib.parse.quote(referer)


def resolver_mixdrop(url):
    opener = network.nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': url})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    pattern = r"eval\(function\(p,a,c,k,e,[dr]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
    scripts = [page]
    for match in re.finditer(pattern, page, re.S):
        packed, radix, count, words = match.groups()
        scripts.append(unpack_js(packed, int(radix), int(count), words.split('|')))
    for script in scripts:
        match = re.search(r'MDCore\.wurl\s*=\s*[\'"]([^\'"]+)', script)
        if match:
            media = urllib.parse.urljoin(referer, match.group(1).replace(r'\/', '/'))
            return media + '|User-Agent=' + urllib.parse.quote(network.UA) + '&Referer=' + urllib.parse.quote(referer)
    raise network.ServidorNoDisponible('Mixdrop no entrega un video en este enlace; puede haber sido retirado.')


def _resolver_opcional(url):
    if resolveurl is None or getattr(network._sondeo, 'deadline', None) is not None:
        return None
    try:
        if resolveurl.relevant_resolvers(url):
            return resolveurl.resolve(url)
    except Exception as exc:
        network.log_resolver('ResolveURL: ' + type(exc).__name__)
    return None


def resolver_enlace_directo(url_target):
    """
    Resuelve el stream final reproducible por Kodi para cualquier servidor.
    Soporta GoodStream, Vimeos, Google Drive, OK.RU, VIDS.ST, PelisSeriesHoy, HLS/MP4 y ResolveURL.
    """
    if not url_target:
        return None

    # 0. Desenvolver acortadores JWT (embedshortener.co / fkplayer.xyz)
    unwrapped_short = desenvolver_embed_shortener(url_target)
    if unwrapped_short:
        url_target = unwrapped_short

    parsed = urllib.parse.urlparse(url_target)

    # Desenvolver enlaces encapsulados en parámetros como ?link= o ?r= (Base64)
    if 'link=' in url_target:
        q_link = urllib.parse.parse_qs(parsed.query).get('link', [''])[0]
        if q_link and q_link.startswith('http'):
            url_target = q_link
            parsed = urllib.parse.urlparse(url_target)

    # Redirecciones base64 comunes (p. ej. blogfc13.blogspot.com/?m=1.html?r=...)
    m_b64 = re.search(r'[?&]r=([a-zA-Z0-9+/=]{16,})', url_target)
    if m_b64:
        try:
            unwrapped = base64.b64decode(m_b64.group(1)).decode('utf-8', errors='ignore').strip()
            if unwrapped.startswith('http'):
                url_target = unwrapped
                parsed = urllib.parse.urlparse(url_target)
        except Exception:
            pass

    host = parsed.hostname or ''
    if 'filemoon' in host or host in ('bysefujedu.com', 'bysevepoin.com', 'bysedikamoum.com'):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_filemoon(url_target)

    # VidHide y clones
    if any(h in host for h in ('vidhide', 'minochinos', 'streamhide', 'dintezuvio', 'movearnpre', 'luluvdo', 'barmonrey', 'fluxcedene', 'cvid.lat', 'rpmvid.com')):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_vidhide(url_target)

    if parsed.hostname in ('morencius.com', 'embedwish.com', 'fastream.to', 'flaswish.com', 'luluvido.com', 'dingtezuni.com', 'callistanise.com'):
        return resolver_host_hls(url_target)

    # StreamWish y espejos
    if any(h in host for h in ('streamwish', 'strwish', 'wishfast', 'sfastwish', 'hglink', 'hanerix', 'hlswish', 'awish', 'filelions', 'wishembed', 'dhcplay', 'hglamioz')) or ('wish' in host and '/e/' in url_target):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_streamwish(url_target)

    # Pixeldrain
    if 'pixeldrain.com' in host:
        return resolver_pixeldrain(url_target)

    # Vidara
    if 'vidara.so' in host:
        return resolver_vidara(url_target)

    # Primeload
    if 'primeload.co' in host:
        return resolver_primeload(url_target)

    if host in ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com', 'playmogo.com', 'dsvplay.com', 'ds2play.com'):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_dood(url_target)
    if host in ('streamtape.com', 'streamtape.to', 'streamtape.net', 'streamtape.cc'):
        return resolver_streamtape(url_target)
    if host in ('mixdrop.is', 'mixdrop.co', 'mixdrop.to', 'mixdrop.ag', 'mixdrop.bz', 'm1xdrop.bz'):
        return resolver_mixdrop(url_target)
    if host in ('uqload.ws', 'uqload.com', 'uqload.to', 'uqload.net', 'uqload.io', 'oneupload.to', 'strm1.uqload.is'):
        return resolver_host_hls(url_target)

    # 1. GoodStream (HackStore2 / PelisJuanita)
    if parsed.hostname == 're.sololatino.net':
        return resolver_menu_antiguo(url_target)
    if parsed.hostname == 'fuegocineplayer.upns.online':
        return resolver_upns(url_target)
    if parsed.hostname in ('playhydrax.com', 'abyssplayer.com', 'player.abyssplayer.com'):
        return resolver_hydrax(url_target)
    if 'goodstream' in url_target:
        return resolver_goodstream(url_target)

    # 2. Vimeos
    if parsed.hostname in ('unlimplay.com', 'www.unlimplay.com'):
        return resolver_unlimplay(url_target)
    if parsed.hostname in ('playmate.to', 'www.playmate.to'):
        return resolver_playmate(url_target)
    if 'vimeos' in url_target:
        return resolver_vimeos(url_target)

    # VOE y clones
    if host.startswith('voe') or 'voe.' in host or 'voex.' in host or 'marissa.' in host or 'tubesquared.' in host:
        return resolver_voe(url_target)
    if parsed.hostname in ('fastream.to',):
        return resolver_host_hls(url_target)

    if host == 'vixeo.io':
        stream = resolver_host_hls(url_target)
        if stream:
            return stream
        raise network.ServidorNoDisponible('Vidsonic no entrego un enlace compatible con Kodi. Elige otro servidor.')

    # 3. Google Drive
    if 'drive.google.com' in url_target or 'drive.usercontent.google.com' in url_target:
        return resolver_google_drive(url_target)

    # 4. OK.RU
    if 'ok.ru' in url_target:
        st_ok = resolver_ok_ru(url_target)
        if st_ok:
            return st_ok

    # 5. VIDS.ST (VST)
    if 'vids.st' in url_target:
        st_vst = resolver_vids_st(url_target)
        if st_vst:
            return st_vst

    # 6. Comprobar si ya es un stream de video directo (.m3u8, .mp4, .mpd)
    if parsed.path.lower().endswith(('.m3u8', '.mp4', '.mpd')) or '.m3u8' in url_target:
        sep = '&' if '|' in url_target else '|'
        ref = f"{parsed.scheme}://{parsed.netloc}/"
        return f"{url_target}{sep}User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(ref)}"

    # 7. Servidor PelisSeriesHoy
    if 'pelisserieshoy' in url_target:
        st = resolver_pelisserieshoy(url_target)
        if st:
            return st

    # 8. ResolveURL si está disponible
    if resolveurl and getattr(network._sondeo, 'deadline', None) is None:
        try:
            if resolveurl.relevant_resolvers(url_target):
                st = resolveurl.resolve(url_target)
                if st:
                    return st
        except Exception:
            pass

    # 9. Scraper directo con desempaquetado unpack_js
    try:
        html_src, _ = network.fetch_html(url_target, referer=f"{parsed.scheme}://{parsed.netloc}/")
        if html_src:
            lowered = html_src.lower()
            if any(message in lowered for message in ('video not found', 'file was deleted', 'file has been deleted')):
                raise network.ServidorNoDisponible('El servidor indica que el video fue eliminado o no existe.')
            m_pack = re.findall(r'eval\(function\((p,a,c,k,e,d|p,a,c,k,e,r)\)\{.*?return p\}\((.*?)\)\)', html_src, re.DOTALL)
            for _, raw_args in m_pack:
                try:
                    m_params = re.search(r"'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)", raw_args, re.DOTALL)
                    if m_params:
                        p_val, a_val, c_val, k_val = m_params.group(1), int(m_params.group(2)), int(m_params.group(3)), m_params.group(4).split('|')
                        unpacked = unpack_js(p_val, a_val, c_val, k_val)
                        m_m3u8 = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', unpacked)
                        if m_m3u8:
                            return f"{m_m3u8.group(1)}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(url_target)}"
                except Exception:
                    pass

            m_src = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', html_src)
            if m_src:
                return f"{m_src.group(1)}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(url_target)}"
    except network.ServidorNoDisponible:
        raise
    except Exception:
        pass

    return None


def resolver_stream(url_servidor):
    """
    Resuelve el enlace directo reproducible por Kodi.
    """
    if url_servidor.startswith('tubi://play?'):
        import servidores as tubi
        return resolver_tubi(url_servidor)
    if url_servidor.startswith('dorama://player?'):
        import doramas
        url_servidor = doramas.resolve(url_servidor)
    return resolver_enlace_directo(url_servidor)


def resolver_tubi(url):
    import servidores as tubi
    if not tubi.tubi_is_available():
        raise network.ServidorNoDisponible('US_VPN: Tubi requiere una conexion VPN (US) activa para reproducirse.')
    params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    page_url = params.get('url', [''])[0]
    data = tubi.tubi_detail(page_url)
    if data.get('needs_login'):
        raise network.ServidorNoDisponible('US_VPN: este titulo requiere iniciar sesion en Tubi.')
    for resource in data.get('video_resources', []):
        if not str(resource.get('type', '')).startswith('hls') or resource.get('drm'):
            continue
        media = resource.get('manifest', {}).get('url', '')
        host = urllib.parse.urlsplit(media).hostname or ''
        if urllib.parse.urlsplit(media).scheme != 'https' or not host.endswith('.tubi.video'):
            continue
        stream = procesar_hls_local(media, tubi.tubi_BASE + '/', timeout=12)
        if stream:
            return stream
    raise network.ServidorNoDisponible('US_VPN: Tubi no entrego un HLS accesible. Comprueba la region/VPN o la disponibilidad del titulo.')
