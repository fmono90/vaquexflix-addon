"""Complete SoloLatino title index with atomic daily background refresh."""
import network
import json
import os
import re
import sqlite3
import threading
import time
import unicodedata
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

SECTIONS = ('peliculas', 'series', 'animes', 'doramas')
REFRESH_SECONDS = 86400
RETRY_SECONDS = 900
LEASE_SECONDS = 3600
_LOCK = threading.Lock()
_WORKER = None
PAGE_SIZE = 30


def database():
    try:
        import xbmcvfs
        root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vaquexflix')
    except ImportError:
        root = ''
    if not root:
        root = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'Kodi', 'userdata', 'addon_data', 'plugin.video.vaquexflix')
    os.makedirs(root, exist_ok=True)
    return os.path.join(root, 'sololatino_catalog.sqlite')


def connect():
    db = sqlite3.connect(database(), timeout=10)
    db.execute('CREATE TABLE IF NOT EXISTS titles (url TEXT PRIMARY KEY, title TEXT, data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS staging (url TEXT PRIMARY KEY, title TEXT, data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)')
    db.commit()
    return db


def normalize(value):
    value = ''.join(c for c in unicodedata.normalize('NFKD', value.lower()) if not unicodedata.combining(c))
    return ' '.join(re.findall(r'[^\W_]+', value, re.UNICODE))


def status():
    with closing(connect()) as db:
        return dict(db.execute('SELECT key,value FROM meta'))


def revision():
    return status().get('updated', 'pending')


def fetch_page(section, number):
    import servidores as s
    url = network.SOLOLATINO_BASE + '/' + section + ('?page=%d' % number if number > 1 else '')
    error = None
    for attempt in range(2):
        try:
            html, _ = network.fetch_html(url, referer=network.SOLOLATINO_BASE, timeout=20)
            if not html:
                raise ValueError('SoloLatino retorno HTML vacio (Cloudflare o conexion fallida)')
            if len(html) > 3000000:
                raise ValueError('Pagina demasiado grande')
            items = s.sololatino_parsear_tarjetas(html, 'all')
            pages = [int(p) for p in re.findall(r'[?&]page=(\d+)', html)]
            if not items:
                raise ValueError('Pagina vacia o formato no reconocido: %s %s' % (section, number))
            return items, max(pages or [1])
        except Exception as exc:
            error = exc
            if not attempt:
                time.sleep(1)
    raise error


def refresh(force=False):
    now = time.time()
    with closing(connect()) as db:
        db.execute('BEGIN IMMEDIATE')
        meta = dict(db.execute('SELECT key,value FROM meta'))
        if now - float(meta.get('lease', '0')) < LEASE_SECONDS:
            return False
        if not force and (now - float(meta.get('updated', '0')) < REFRESH_SECONDS or
                          now - float(meta.get('attempt', '0')) < RETRY_SECONDS):
            return False
        db.executemany('INSERT OR REPLACE INTO meta VALUES (?,?)',
                       [('lease', str(now)), ('attempt', str(now)), ('completed_pages', '0'), ('error', '')])
        db.execute('DELETE FROM staging')
        db.commit()
        try:
            tasks = []
            signatures = set()
            completed = 0
            def store(section, items):
                nonlocal completed
                signature = (section, tuple(sorted(i['url'] for i in items)))
                if signature in signatures:
                    raise ValueError('SoloLatino repitio una pagina; se conserva el indice anterior')
                signatures.add(signature)
                db.executemany('INSERT OR REPLACE INTO staging VALUES (?,?,?)',
                    [(i['url'], normalize(i['title']), json.dumps(i, ensure_ascii=False)) for i in items])
                completed += 1
                db.execute("INSERT OR REPLACE INTO meta VALUES ('completed_pages', ?)", (str(completed),))
                db.commit()
            for section in SECTIONS:
                items, total = fetch_page(section, 1)
                if total > 5000:
                    raise ValueError('Paginacion de SoloLatino no valida')
                store(section, items)
                tasks.extend((section, number) for number in range(2, total + 1))
            db.execute("INSERT OR REPLACE INTO meta VALUES ('total_pages', ?)", (str(len(tasks) + len(SECTIONS)),))
            db.commit()
            def fetch(task):
                # Two requests at a time, with a pause per page.
                time.sleep(.2)
                return task[0], fetch_page(*task)[0]
            with ThreadPoolExecutor(max_workers=2) as pool:
                queue = iter(tasks)
                pending = {pool.submit(fetch, task) for task in [next(queue, None), next(queue, None)] if task}
                while pending:
                    done, pending = wait(pending, return_when=FIRST_COMPLETED)
                    for future in done:
                        section, items = future.result()
                        store(section, items)
                        task = next(queue, None)
                        if task:
                            pending.add(pool.submit(fetch, task))
            # Only a complete scan may remove titles absent from the new catalog.
            db.execute('BEGIN IMMEDIATE')
            db.execute('DELETE FROM titles')
            db.execute('INSERT INTO titles SELECT * FROM staging')
            count = db.execute('SELECT count(*) FROM titles').fetchone()[0]
            db.executemany('INSERT OR REPLACE INTO meta VALUES (?,?)',
                           [('updated', str(time.time())), ('count', str(count)), ('lease', '0'), ('error', '')])
            db.execute('DELETE FROM staging')
            db.commit()
            return True
        except Exception as exc:
            db.rollback()
            db.executemany('INSERT OR REPLACE INTO meta VALUES (?,?)',
                           [('lease', '0'), ('error', type(exc).__name__ + ': ' + str(exc))])
            db.commit()
            raise


def ensure_background():
    global _WORKER
    with _LOCK:
        if _WORKER and _WORKER.is_alive():
            return
        meta = status()
        now = time.time()
        if (now - float(meta.get('updated', '0')) < REFRESH_SECONDS or
                now - float(meta.get('attempt', '0')) < RETRY_SECONDS or
                now - float(meta.get('lease', '0')) < LEASE_SECONDS):
            return
        def run():
            try:
                refresh()
            except Exception as exc:
                pass
                network.log_resolver('Indice SoloLatino: ' + type(exc).__name__)
        _WORKER = threading.Thread(target=run, name='SoloLatinoCatalog', daemon=True)
        _WORKER.start()


def search(query):
    ensure_background()
    words = normalize(query).split()
    with closing(connect()) as db:
        if not db.execute("SELECT value FROM meta WHERE key='updated'").fetchone():
            return None  # First build: the caller can use live suggestions.
        if not words:
            return []
        rows = db.execute('SELECT title,data FROM titles WHERE ' + ' AND '.join('title LIKE ?' for _ in words),
                          ['%' + word + '%' for word in words]).fetchall()
    query_norm = normalize(query)
    rows.sort(key=lambda row: (row[0] != query_norm, not row[0].startswith(query_norm), row[0]))
    return [json.loads(row[1]) for row in rows]


def page(section, number=1):
    """Browse the published snapshot even when the source cannot be reached."""
    if section not in ('peliculas', 'series', 'all') or number < 1:
        raise ValueError('Seccion o pagina de SoloLatino no valida')
    ensure_background()
    with closing(connect()) as db:
        if not db.execute("SELECT value FROM meta WHERE key='updated'").fetchone():
            return None  # Never expose a partial first build.
        series = "(url LIKE '%/serie/%' OR url LIKE '%/series/%' OR url LIKE '%/tv/%' OR url LIKE '%/anime/%')"
        where = '1' if section == 'all' else (series if section == 'series' else 'NOT ' + series)
        rows = db.execute('SELECT data FROM titles WHERE ' + where +
                          ' ORDER BY title, url LIMIT ? OFFSET ?',
                          (PAGE_SIZE + 1, (number - 1) * PAGE_SIZE)).fetchall()
    items = [dict(json.loads(row[0]), catalog_cached=True) for row in rows[:PAGE_SIZE]]
    return items, len(rows) > PAGE_SIZE
