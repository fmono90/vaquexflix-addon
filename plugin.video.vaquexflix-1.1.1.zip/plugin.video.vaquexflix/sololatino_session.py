"""Keep SoloLatino requests in one session; optionally import browser clearance."""
import http.cookiejar
import io
import os
import threading
import time
from http.cookies import SimpleCookie
from urllib.parse import urlsplit

_LOCAL = threading.local()
_ACCESS_LOCK = threading.Lock()
_ACCESS_UNTIL = 0
_ACCESS_ERROR = ''


def access_error():
    with _ACCESS_LOCK:
        return _ACCESS_ERROR if time.monotonic() < _ACCESS_UNTIL else ''


def record_response(response):
    global _ACCESS_UNTIL, _ACCESS_ERROR
    with _ACCESS_LOCK:
        if response.status_code == 403:
            blocked_ip = 'has banned your ip address' in response.text.lower()
            _ACCESS_ERROR = ('SoloLatino bloqueo esta IP (Cloudflare 1006). El sitio debe habilitar el acceso.'
                             if blocked_ip else 'SoloLatino rechazo el acceso. La verificacion del navegador puede necesitar renovarse.')
            _ACCESS_UNTIL = time.monotonic() + (900 if blocked_ip else 60)
        elif response.status_code < 400:
            _ACCESS_ERROR, _ACCESS_UNTIL = '', 0


class BrowserCookieJar(http.cookiejar.MozillaCookieJar):
    def _really_load(self, stream, filename, ignore_discard, ignore_expires):
        # Python 3.8 ignores #HttpOnly_ lines, including cf_clearance.
        lines = []
        for line in stream:
            if line.startswith('#HttpOnly_'):
                line = line[len('#HttpOnly_'):]
            if not line.startswith('#'):
                fields = line.rstrip('\r\n').split('\t')
                if len(fields) == 7 and fields[4] == '0':
                    # Browser exports use zero for session cookies; Python's
                    # Netscape reader expects an empty expiry instead.
                    fields[4] = ''
                    line = '\t'.join(fields) + '\n'
            lines.append(line)
        return super()._really_load(io.StringIO(''.join(lines)), filename,
                                    ignore_discard, ignore_expires)


def browser_settings():
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon('plugin.video.vaquexflix')
        path = xbmcvfs.translatePath(addon.getSetting('sololatino_cookies'))
        return path, addon.getSetting('sololatino_user_agent').strip()
    except ImportError:
        return '', ''


def clearance_cookies(path):
    if not path:
        return []
    jar = BrowserCookieJar(path)
    jar.load(ignore_discard=True)
    # Import only the site's browser verification, never account/login cookies.
    return [cookie for cookie in jar
            if cookie.domain.lstrip('.') in ('sololatino.net', 'www.sololatino.net')
            and cookie.name in ('cf_clearance', '__cf_bm') and not cookie.is_expired()]


def client(requests):
    path, user_agent = browser_settings()
    stamp = os.stat(path).st_mtime_ns if path else None
    key = (path, user_agent, stamp)
    if getattr(_LOCAL, 'key', None) != key or not hasattr(_LOCAL, 'client'):
        imported = clearance_cookies(path)
        previous = getattr(_LOCAL, 'client', None)
        if previous is not None:
            previous.close()
        session = requests.Session(impersonate='chrome')
        for cookie in imported:
            session.cookies.jar.set_cookie(cookie)
        _LOCAL.client, _LOCAL.key = session, key
    return _LOCAL.client, user_agent


def request(requests, url, headers, data, timeout):
    host = urlsplit(url).hostname
    if host not in ('sololatino.net', 'www.sololatino.net'):
        raise ValueError('La sesion de SoloLatino no se comparte con otros sitios')
    if access_error():
        raise RuntimeError(access_error())
    session, user_agent = client(requests)
    headers = dict(headers)
    # Cookie headers would replace cf_clearance; merge caller cookies into the jar.
    for key in list(headers):
        if key.lower() == 'cookie':
            supplied = SimpleCookie()
            supplied.load(headers.pop(key))
            for name, morsel in supplied.items():
                if name not in ('cf_clearance', '__cf_bm'):
                    session.cookies.set(name, morsel.value, domain=host, path='/')
        elif key.lower() == 'user-agent':
            headers.pop(key)
    if user_agent:
        headers['User-Agent'] = user_agent
    response = session.request('POST' if data is not None else 'GET', url,
                               headers=headers, data=data, timeout=timeout)
    record_response(response)
    return response
