"""Configuracion de streams compartida por el reproductor y las pruebas.

Sin dependencias de Kodi al importar: funciona tambien en Python de Batocera.
"""
from urllib.parse import parse_qsl, urlencode, urlsplit
import threading
import time


class Cancelled(Exception):
    pass


def request_with_progress(call, budget_context, keep_waiting, seconds=45):
    """Bound foreground waiting; late workers only write their local result."""
    done, cancel = threading.Event(), threading.Event()
    result = {}
    deadline = time.monotonic() + seconds

    def run():
        try:
            with budget_context(deadline, cancel):
                result['value'] = call()
        except Exception as exc:
            result['error'] = exc
        finally:
            done.set()

    threading.Thread(target=run, name='VaquexflixResolver', daemon=True).start()
    try:
        while True:
            if not keep_waiting():
                raise Cancelled()
            if done.is_set():
                if 'error' in result:
                    raise result['error']
                return result.get('value')
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('El servidor excedio el tiempo de espera')
            done.wait(min(.1, remaining))
    finally:
        cancel.set()


def split_stream(stream, user_agent):
    url, _, options = stream.partition('|')
    headers = dict(parse_qsl(options, keep_blank_values=True))
    if urlsplit(url).scheme in ('http', 'https'):
        headers.setdefault('User-Agent', user_agent)
    return url, headers


def configure_stream(item, stream, user_agent, adaptive=False, kodi_major=20, ask_quality=False, hls_quality=None):
    url, headers = split_stream(stream, user_agent)
    path = urlsplit(url).path.lower()
    if path.endswith('.bin'):
        headers.setdefault('ext', '.mp4')
    extension = headers.get('ext', '').lower()
    is_hls = path.endswith('.m3u8') or extension == '.m3u8'
    if path.endswith(('.mp4', '.bin')) or extension == '.mp4':
        item.setMimeType('video/mp4')
        item.setContentLookup(False)
    elif path.endswith('.mkv') or extension == '.mkv':
        item.setMimeType('video/x-matroska')
        item.setContentLookup(False)
    if is_hls:
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setContentLookup(False)
    if is_hls and adaptive:
        item.setProperty('inputstream', 'inputstream.adaptive')
        mode = str(hls_quality) if hls_quality is not None else ('1' if ask_quality else '0')
        if kodi_major >= 20:
            if mode == '1':
                item.setProperty('inputstream.adaptive.stream_selection_type', 'ask-quality')
            elif mode == '2':
                item.setProperty('inputstream.adaptive.stream_selection_type', 'fixed-res')
        if kodi_major <= 20:
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # Las opciones de curl no son cabeceras HTTP de InputStream Adaptive.
        http_headers = {k: v for k, v in headers.items()
                        if k.lower() not in ('verifypeer', 'ext')}
        encoded = urlencode(http_headers)
        item.setProperty('inputstream.adaptive.manifest_headers', encoded)
        item.setProperty('inputstream.adaptive.stream_headers', encoded)
        item.setPath(url)
        return url
    host = (urlsplit(url).hostname or '').lower()
    direct_file = path.endswith(('.mp4', '.mkv')) or extension in ('.mp4', '.mkv')
    problematic_host = (host == 'files.eintim.me' or host == '1a-1791.com'
                        or host.endswith('.rumble.cloud')
                        or host.endswith('.sssrr.org')
                        or host in ('drive.usercontent.google.com', 'drive.google.com'))
    if not is_hls and direct_file and problematic_host:
        # El lector HTTP de FFmpeg maneja sus propios seeks y su callback de
        # interrupcion. Evita el camino CurlFile/FileCache que queda esperando
        # al cerrar estos archivos remotos. Es interno de Kodi, sin otro addon.
        item.setProperty('inputstream', 'inputstream.ffmpeg')
        item.setContentLookup(False)
        headers.pop('ext', None)
    result = url + ('|' + urlencode(headers) if headers else '')
    item.setPath(result)
    return result


_close_trace_file = None


def stop_close_diagnostic():
    """Cancel only the watchdog installed by this module."""
    global _close_trace_file
    if _close_trace_file is not None:
        import faulthandler
        faulthandler.cancel_dump_traceback_later()
        _close_trace_file.close()
        _close_trace_file = None


def start_close_diagnostic(path, seconds=8):
    """Capture Python stacks even if the GIL is stuck inside a Kodi call.

    Temporary diagnostic: no frame locals, URLs, keys or cookies are written.
    The native watchdog does not depend on a Python worker being scheduled.
    """
    global _close_trace_file
    stop_close_diagnostic()
    try:
        import faulthandler
        _close_trace_file = open(path, 'w', encoding='utf-8')
        faulthandler.dump_traceback_later(seconds, repeat=True, file=_close_trace_file)
        return True
    except (ImportError, OSError, RuntimeError):
        if _close_trace_file is not None:
            _close_trace_file.close()
            _close_trace_file = None
        return False
