"""Browser cookie import and provider HTTP sessions shared by the addon."""
import http.cookiejar
import configparser
import glob
import io
import os
import re
import sqlite3
import sys
import threading
import time
from contextlib import closing
from pathlib import Path
from http.cookies import SimpleCookie
from urllib.parse import urlsplit, unquote
from urllib.request import HTTPCookieProcessor

_LOCAL = threading.local()
_ACCESS_LOCK = threading.Lock()
_ACCESS_UNTIL = 0
_ACCESS_ERROR = ''


def access_error():
    with _ACCESS_LOCK:
        return _ACCESS_ERROR if time.monotonic() < _ACCESS_UNTIL else ''


def record_response(response):
    global _ACCESS_UNTIL, _ACCESS_ERROR
    with _ACCESS_LOCK:
        if response.status_code == 403:
            blocked_ip = 'has banned your ip address' in response.text.lower()
            _ACCESS_ERROR = ('SoloLatino bloqueo esta IP (Cloudflare 1006). El sitio debe habilitar el acceso.'
                             if blocked_ip else 'SoloLatino rechazo el acceso. La verificacion del navegador puede necesitar renovarse.')
            _ACCESS_UNTIL = time.monotonic() + (900 if blocked_ip else 60)
        elif response.status_code < 400:
            _ACCESS_ERROR, _ACCESS_UNTIL = '', 0


class BrowserCookieJar(http.cookiejar.MozillaCookieJar):
    def _really_load(self, stream, filename, ignore_discard, ignore_expires):
        # Python 3.8 ignores #HttpOnly_ lines, including cf_clearance.
        lines = []
        for line in stream:
            if line.startswith('#HttpOnly_'):
                line = line[len('#HttpOnly_'):]
            if not line.startswith('#'):
                fields = line.rstrip('\r\n').split('\t')
                if len(fields) == 7 and fields[4] == '0':
                    # Browser exports use zero for session cookies; Python's
                    # Netscape reader expects an empty expiry instead.
                    fields[4] = ''
                    line = '\t'.join(fields) + '\n'
            lines.append(line)
        return super()._really_load(io.StringIO(''.join(lines)), filename,
                                    ignore_discard, ignore_expires)


def browser_settings(provider='sololatino'):
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon('plugin.video.vaquexflix')
        path = xbmcvfs.translatePath(addon.getSetting(provider + '_cookies'))
        return path, addon.getSetting(provider + '_user_agent').strip()
    except ImportError:
        return '', ''


def clearance_cookies(path, domains=('sololatino.net', 'www.sololatino.net')):
    if not path:
        return []
    jar = BrowserCookieJar(path)
    jar.load(ignore_discard=True)
    # Import only the site's browser verification, never account/login cookies.
    return [cookie for cookie in jar
            if cookie.domain.lstrip('.') in domains
            and cookie.name in ('cf_clearance', '__cf_bm') and not cookie.is_expired()]


def client(requests):
    path, user_agent = browser_settings()
    stamp = os.stat(path).st_mtime_ns if path else None
    key = (path, user_agent, stamp)
    if getattr(_LOCAL, 'key', None) != key or not hasattr(_LOCAL, 'client'):
        imported = clearance_cookies(path)
        previous = getattr(_LOCAL, 'client', None)
        if previous is not None:
            previous.close()
        session = requests.Session(impersonate='chrome')
        for cookie in imported:
            session.cookies.jar.set_cookie(cookie)
        _LOCAL.client, _LOCAL.key = session, key
    return _LOCAL.client, user_agent


def request(requests, url, headers, data, timeout):
    host = urlsplit(url).hostname
    if host not in ('sololatino.net', 'www.sololatino.net'):
        raise ValueError('La sesion de SoloLatino no se comparte con otros sitios')
    if access_error():
        raise RuntimeError(access_error())
    session, user_agent = client(requests)
    headers = dict(headers)
    # Cookie headers would replace cf_clearance; merge caller cookies into the jar.
    for key in list(headers):
        if key.lower() == 'cookie':
            supplied = SimpleCookie()
            supplied.load(headers.pop(key))
            for name, morsel in supplied.items():
                if name not in ('cf_clearance', '__cf_bm'):
                    session.cookies.set(name, morsel.value, domain=host, path='/')
        elif key.lower() == 'user-agent':
            headers.pop(key)
    if user_agent:
        headers['User-Agent'] = user_agent
    response = session.request('POST' if data is not None else 'GET', url,
                               headers=headers, data=data, timeout=timeout)
    record_response(response)
    return response


def configure(opener, provider, domains):
    """Load only this provider's unexpired verification cookies into an opener."""
    path, agent = browser_settings(provider)
    browser = firefox_verification() if provider == 'doramaexpress' else None
    if browser:
        cookies, agent = browser
    else:
        cookies = clearance_cookies(path, domains)
    for handler in opener.handlers:
        if isinstance(handler, HTTPCookieProcessor):
            for cookie in cookies:
                handler.cookiejar.set_cookie(cookie)
    return agent


def _firefox_profiles():
    """Locate the default desktop profile, including the Windows Store edition."""
    if sys.platform != 'win32':
        return []
    roots = []
    if os.environ.get('APPDATA'):
        roots.append(Path(os.environ['APPDATA']) / 'Mozilla' / 'Firefox')
    if os.environ.get('LOCALAPPDATA'):
        roots.extend(Path(p) for p in glob.glob(os.path.join(
            os.environ['LOCALAPPDATA'], 'Packages', 'Mozilla.Firefox_*',
            'LocalCache', 'Roaming', 'Mozilla', 'Firefox')))
    profiles = []
    for root in roots:
        config = configparser.ConfigParser(interpolation=None)
        try:
            config.read(str(root / 'profiles.ini'), encoding='utf-8')
            defaults = {config.get(s, 'Default') for s in config.sections()
                        if s.startswith('Install') and config.has_option(s, 'Default')}
            if not defaults:
                defaults = {config.get(s, 'Path') for s in config.sections()
                            if s.startswith('Profile') and config.get(s, 'Default', fallback='0') == '1'}
            # Multiple installation defaults need explicit selection; do not guess.
            if len(defaults) != 1:
                continue
            profile = Path(defaults.pop())
            profiles.append(profile if profile.is_absolute() else root / profile)
        except (OSError, configparser.Error):
            continue
    return profiles


def firefox_verification():
    """Read only the site's verification from Firefox; never change its database.

    A first-party partitioned cookie may coexist with an obsolete ordinary cookie.
    Container and unrelated partition cookies are intentionally excluded.
    """
    candidates = []
    for profile in _firefox_profiles():
        try:
            config = configparser.ConfigParser(interpolation=None)
            config.read(str(profile / 'compatibility.ini'), encoding='utf-8')
            version = config.get('Compatibility', 'LastVersion', fallback='')
            major = re.match(r'(\d+)\.', version)
            abi = config.get('Compatibility', 'LastOSABI', fallback='')
            if not major or not abi.startswith('WINNT_'):
                continue
            architecture = '; Win64; x64' if 'x86_64' in abi else ''
            agent = ('Mozilla/5.0 (Windows NT 10.0%s; rv:%s.0) '
                     'Gecko/20100101 Firefox/%s.0') % (architecture, major[1], major[1])
            # Honor a manually configured browser UA; resist-fingerprinting needs
            # browser-side integration instead of guessing its spoofed identity.
            prefs = profile / 'prefs.js'
            if prefs.is_file():
                text = prefs.read_text(encoding='utf-8', errors='replace')
                if re.search(r'user_pref\("privacy.resistFingerprinting",\s*true\)', text):
                    continue
                override = re.search(r'user_pref\("general.useragent.override",\s*("(?:[^"\\]|\\.)*")\)', text)
                if override:
                    import json
                    agent = json.loads(override[1])
            uri = (profile / 'cookies.sqlite').resolve().as_uri() + '?mode=ro'
            with closing(sqlite3.connect(uri, uri=True, timeout=0.25)) as db:
                rows = db.execute(
                    'SELECT host,path,isSecure,expiry,name,value,originAttributes,lastAccessed '
                    'FROM moz_cookies WHERE host IN (?,?,?,?) AND name IN (?,?) AND expiry > ?',
                    ('doramaexpress.com', '.doramaexpress.com', 'www.doramaexpress.com',
                     '.www.doramaexpress.com', 'cf_clearance', '__cf_bm', time.time())).fetchall()
            allowed = ('', '^partitionKey=(https,doramaexpress.com)')
            rows = [r for r in rows if unquote(r[6]) in allowed]
            clearances = [r for r in rows if r[4] == 'cf_clearance']
            if not clearances:
                continue
            best = max(clearances, key=lambda r: (r[7], bool(r[6])))
            cookies = []
            for host, path, secure, expiry, name, value, attrs, accessed in rows:
                if attrs != best[6]:
                    continue
                cookies.append(http.cookiejar.Cookie(
                    0, name, value, None, False, host, host.startswith('.'),
                    host.startswith('.'), path, True, bool(secure), expiry,
                    False, None, None, {}))
            candidates.append((best[7], cookies, agent))
        except (OSError, sqlite3.Error, configparser.Error, ValueError):
            continue
    if candidates:
        _, cookies, agent = max(candidates, key=lambda c: c[0])
        return cookies, agent
    return None
