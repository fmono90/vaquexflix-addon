"""Fuentes generales: catalogos, busquedas, episodios y enlaces a reproductores."""
import base64
import html
import json
import os
import re
import urllib.error
import sys
import time
import threading
import content_metadata
import urllib.parse
import urllib.request
from html import unescape
import network
import resolvers


FUEGOCINE_BASE = "https://www.fuegocine.com"


FUEGOCINE_PAGE_SIZE = 20


HACKSTORE_API = 'https://hackstore3.net/wp-api/v1'


HACKSTORE_SITE = 'https://hackstore3.net'


HACKSTORE_PAGE_SIZE = 24


HACKSTORE_KINDS = ('movie', 'tvshow', 'anime')


PELISJUANITA_API = 'https://pelisjuanita.org/api/rest/v1'


PELISJUANITA_SITE = 'https://pelisjuanita.org'


PELISJUANITA_PAGE_SIZE = 24


PELISJUANITA_KINDS = ('movie', 'tvshow', 'anime')


def extraer_caratula_de_bloque_sololatino(bloque):
    m_tmdb = re.search(r'src=[\"\'](https?://image\.tmdb\.org/[^\"\']+)[\"\']', bloque)
    if m_tmdb and 'no-poster' not in m_tmdb.group(1):
        return m_tmdb.group(1)

    m_img = re.search(r'<img[^>]+?src=[\"\'](https?://[^\"\']+)[\"\']', bloque)
    if m_img:
        url_i = m_img.group(1)
        if 'no-poster' not in url_i:
            return url_i

    all_imgs = re.findall(r'src=[\"\'](https?://[^\"\']+)[\"\']', bloque)
    for u in all_imgs:
        if 'no-poster' not in u and ('tmdb.org' in u or 'media' in u or '.jpg' in u or '.png' in u):
            return u
    return ""


def sololatino_parsear_tarjetas(html_code, seccion_actual="peliculas", vistos_urls=None):
    if vistos_urls is None:
        vistos_urls = set()
    items_encontrados = []
    bloques = re.findall(r'<div[^>]*class=[\"\'][^\"\']*\bcard\b[^\"\']*[\"\'].*?</a>.*?</div>', html_code, re.DOTALL | re.IGNORECASE)
    for bloque in bloques:
        m_link = re.search(r'href=[\"\']([^\"\']*/(pelicula|peliculas|serie|series|tv|anime)/[^\"\']+)[\"\']', bloque, re.IGNORECASE)
        if not m_link:
            continue

        href = network.solo_url(urllib.parse.urljoin(network.SOLOLATINO_BASE, m_link.group(1)))
        is_serie = any(x in href for x in ['/serie/', '/series/', '/tv/', '/anime/'])

        if seccion_actual == "series" and not is_serie:
            continue
        if seccion_actual == "peliculas" and is_serie:
            continue
        if href in vistos_urls:
            continue

        vistos_urls.add(href)
        img_url = extraer_caratula_de_bloque_sololatino(bloque)

        m_title = re.search(r'alt=[\"\']([^\"\']+)[\"\']', bloque) or re.search(r'class=[\"\']card__title[\"\'][^>]*>([^<]+)<', bloque)
        titulo = network.limpiar_texto(m_title.group(1) if m_title else "Sin titulo")

        m_year = re.search(r'class=[\"\']card__year[\"\'][^>]*>([^<]+)<', bloque)
        year_str = network.limpiar_texto(m_year.group(1).strip() if m_year else "")

        m_rat = re.search(r'class=[\"\']card__rating[\"\'][^>]*>([^<]+)<', bloque)
        rating_str = network.limpiar_texto(m_rat.group(1).strip() if m_rat else "")

        items_encontrados.append({
            'title': titulo,
            'url': href,
            'cover': img_url,
            'is_serie': is_serie,
            'year': year_str,
            'rating': rating_str,
            'plot': "",
            'source': 'sololatino'
        })
    return items_encontrados


def sololatino_buscar(query):
    if not query.strip():
        return []
    try:
        import catalog_index
        items = catalog_index.search(query)
        if items is not None:
            return items
    except Exception as exc:
        network.log_resolver('Busqueda local SoloLatino: ' + type(exc).__name__)
    return _sololatino_sugerencias(query)


def _sololatino_sugerencias(query):
    q_raw = query.strip()
    if not q_raw:
        return []
    q_norm = network.limpiar_texto(q_raw).lower()

    def _fetch_q(q):
        try:
            u = f"{network.SOLOLATINO_BASE}/api/search/suggest?q={urllib.parse.quote_plus(q)}"
            html_res, _ = network.fetch_html(u)
            if not html_res:
                return []
            data = json.loads(html_res)
            return data if isinstance(data, list) else []
        except Exception:
            return []

    data = _fetch_q(q_raw)
    validos = [x for x in data if isinstance(x, dict) and x.get('type') != 'person' and '/persona/' not in x.get('url', '')]

    # Palabras clave si no hay resultados directos (control de rate-limiting)
    if not validos:
        stop_words = {'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'de', 'del', 'en', 'y', 'a', 'the', 'of', 'in', 'and'}
        palabras = [p for p in re.findall(r'\w+', q_norm) if len(p) > 2 and p not in stop_words]
        if palabras:
            palabras_clave = sorted(palabras, key=len, reverse=True)[:2]
            vistos = set()
            candidatos = []
            for p in palabras_clave:
                time.sleep(0.15)
                sub_data = _fetch_q(p)
                for x in sub_data:
                    if not isinstance(x, dict) or x.get('type') == 'person' or '/persona/' in x.get('url', ''):
                        continue
                    u = x.get('url', '')
                    if u and u not in vistos:
                        vistos.add(u)
                        candidatos.append(x)
                if len(candidatos) >= 4:
                    break

            def _coincidencias(item):
                tit = (item.get('title') or '').lower()
                return sum(1 for pal in palabras if pal in tit)
            candidatos.sort(key=_coincidencias, reverse=True)
            validos = candidatos

    items_encontrados = []
    vistos = set()
    for obj in validos:
        raw_url = obj.get('url', '')
        if not raw_url:
            continue
        href = network.solo_url(urllib.parse.urljoin(network.SOLOLATINO_BASE, raw_url))
        if href in vistos:
            continue
        vistos.add(href)

        tipo = obj.get('type', '')
        is_serie = any(x in href for x in ['/serie/', '/series/', '/tv/', '/anime/']) or tipo in ['series', 'tv', 'anime']
        titulo = network.limpiar_texto(obj.get('title') or "Sin titulo")
        year_val = obj.get('year', '')
        year_str = str(year_val).strip() if year_val is not None else ""
        poster = obj.get('poster') or ""

        items_encontrados.append({
            'title': titulo,
            'url': href,
            'cover': poster,
            'is_serie': is_serie,
            'year': year_str,
            'rating': "",
            'plot': "",
            'source': 'sololatino'
        })
    return items_encontrados


def sololatino_obtener_servidores(url_pagina, premium_only=False):
    for origin in network.solo_origins():
        network.tiempo_peticion(10)
        with network.solo_session_origin(origin):
            result = _sololatino_obtener_servidores(url_pagina, premium_only)
        if result:
            network.solo_origin_success(origin)
            return result
    return []


def _sololatino_extraer_media_id(url_pagina, html_page=""):
    if not html_page:
        return None
    m_ep = re.search(r'/temporada-(\d+)/episodio-(\d+)', url_pagina)
    if m_ep:
        s = int(m_ep.group(1))
        e = int(m_ep.group(2))
        ep_suffix = f"-{s}x{e:02d}"
        m = re.search(r'(tt\d{7,10})', html_page)
        if m:
            return f"{m.group(1)}{ep_suffix}"
        m_serie = re.search(r'https?://[^/]+/serie/([a-zA-Z0-9_-]+)', html_page)
        if m_serie:
            html_serie, _ = network.fetch_html(m_serie.group(0))
            m_tt = re.search(r'(tt\d{7,10})', html_serie)
            if m_tt:
                return f"{m_tt.group(1)}{ep_suffix}"
    else:
        m = re.search(r'(tt\d{7,10}(?:-\d+x\d+)?)', html_page) or re.search(r'imdb\.com/title/(tt\d{7,10})', html_page)
        if m:
            return m.group(1)
        m_data = re.search(r'data-id=[\"\']([^\"\']+)[\"\']', html_page)
        if m_data:
            return m_data.group(1)
    return None


def _sololatino_obtener_servidores(url_pagina, premium_only=False):
    servidores = []
    html_page = ""
    try:
        html_csrf, cookies = network.fetch_html(f"{network.SOLOLATINO_BASE}/sanctum/csrf-cookie")
        cookie_str = "; ".join([c.split(';')[0] for c in cookies])
        html_page, page_cookies = network.fetch_html(url_pagina, cookie_str)
        # Laravel puede renovar la sesión y el token al servir la ficha.
        cookie_values = {}
        for cookie in list(cookies) + list(page_cookies):
            name, sep, value = cookie.split(';', 1)[0].partition('=')
            if sep:
                cookie_values[name] = value
        cookie_str = "; ".join(name + "=" + value for name, value in cookie_values.items())
        xsrf_token = urllib.parse.unquote(cookie_values.get('XSRF-TOKEN', ''))
        btns = re.findall(r'<button[^>]*data-player-token=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</button>', html_page, re.DOTALL)

        headers_api = {
            'Content-Type': 'application/json', 'Accept': 'application/json',
            'X-XSRF-TOKEN': xsrf_token, 'Cookie': cookie_str,
            'Origin': network.SOLOLATINO_BASE, 'Referer': url_pagina, 'User-Agent': network.UA
        }

        # Consultar cada boton una sola vez. PREMIUM no oculta los otros hosts.
        vistos = set()
        for tok, label in btns:
            try:
                r_api_text, _ = network.fetch_html(f"{network.SOLOLATINO_BASE}/api/player-url", data=json.dumps({'t': tok}).encode('utf-8'), headers_dict=headers_api, timeout=7)
                url_player = json.loads(r_api_text).get('url') if r_api_text else None
                if not url_player or url_player in vistos:
                    continue
                vistos.add(url_player)
                premium = urllib.parse.urlsplit(url_player).hostname == 'player.pelisserieshoy.com'
                if premium_only and not premium:
                    continue
                if premium:
                    servidores.append({'nombre': 'PREMIUM (Mediafire - Alta Velocidad)', 'url': url_player})
                elif 'embed69' in url_player or 'xupalace' in url_player:
                    sub = resolvers.resolver_embed69_hosts(url_player)
                    servidores.extend(sub or [{'nombre': 'Servidor Alternativo', 'url': url_player}])
                else:
                    nombre = network.limpiar_texto(re.sub(r'<[^>]+>', ' ', html.unescape(label)))
                    servidores.append({'nombre': nombre or urllib.parse.urlsplit(url_player).hostname,
                                       'url': url_player})
            except Exception as exc:
                network.log_resolver('SoloLatino: fallo al obtener un servidor ({})'.format(type(exc).__name__))
        servidores.sort(key=lambda item: 'pelisserieshoy' not in item['url'])

    except Exception:
        pass

    if not servidores:
        try:
            html_p, _ = network.fetch_html(url_pagina)
            mid = _sololatino_extraer_media_id(url_pagina, html_p or html_page)
            if mid:
                servidores.append({'nombre': 'PREMIUM (Mediafire - Alta Velocidad)', 'url': f'https://player.pelisserieshoy.com/f/{mid}'})
                if not premium_only:
                    sub = resolvers.resolver_embed69_hosts(f'https://embed69.org/f/{mid}')
                    if sub:
                        servidores.extend(sub)
        except Exception:
            pass

    return servidores


def sololatino_obtener_temporadas_episodios(serie_url, serie_obj=None):
    html_page, _ = network.fetch_html(serie_url)
    if not html_page:
        return {}

    episodios_por_temporada = {}
    pattern_ep = r'<a[^>]+href=[\"\']([^\"\']+/temporada-(\d+)/episodio-(\d+)[^\"\']*)[\"\'][^>]*>(.*?)</a>'
    matches = re.findall(pattern_ep, html_page, re.DOTALL | re.IGNORECASE)
    cover_base = serie_obj.get('cover', '') if serie_obj else ''

    for href, num_t, num_e, inner in matches:
        m_name = re.search(r'<p[^>]*class=[\"\'][^\"\']*text-sm[^\"\']*font-semibold[^\"\']*[\"\'][^>]*>\s*(.*?)\s*</p>', inner, re.DOTALL)
        raw_name = network.limpiar_texto(m_name.group(1).strip() if m_name else "")

        m_plot = re.search(r'<p[^>]*class=[\"\'][^\"\']*line-clamp-2[^\"\']*[\"\'][^>]*>\s*(.*?)\s*</p>', inner, re.DOTALL)
        raw_plot = network.limpiar_texto(m_plot.group(1).strip() if m_plot else "")

        m_thumb = re.search(r'<img[^>]+?src=[\"\'](https?://[^\"\']+)[\"\']', inner)
        thumb = m_thumb.group(1) if m_thumb else cover_base

        ep_label = f"T{num_t}:E{num_e} - {raw_name}" if raw_name else f"T{num_t}:E{num_e} Episodio {num_e}"
        episodios_por_temporada.setdefault(str(num_t), []).append({
            'title': ep_label,
            'name': raw_name,
            'url': network.solo_url(urllib.parse.urljoin(network.SOLOLATINO_BASE, href)),
            'cover': thumb,
            'season': str(num_t),
            'episode': str(num_e),
            'plot': raw_plot,
            'is_serie': True,
            'source': 'sololatino'
        })
    return episodios_por_temporada


def hackstore_api(path, params=None):
    url = HACKSTORE_API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        'User-Agent': network.UA,
        'Accept': 'application/json, text/plain, */*',
        'Referer': f"{HACKSTORE_SITE}/",
    })
    with network.abrir_url(req, timeout=12, context=network._ssl_ctx) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def hackstore_parse_url(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != 'hack' or parsed.netloc not in HACKSTORE_KINDS:
        raise ValueError('URL HackStore2 inválida')
    parts = [x for x in parsed.path.split('/') if x]
    if not parts or not parts[0].isdigit():
        raise ValueError('ID HackStore2 inválido')
    kind, post_id = parsed.netloc, int(parts[0])
    if len(parts) == 1:
        return kind, post_id, None, None
    if len(parts) == 3 and parts[1].startswith('temporada-') and parts[2].startswith('episodio-'):
        season, episode = parts[1][10:], parts[2][9:]
        if season.isdigit() and episode.isdigit():
            return kind, post_id, int(season), int(episode)
    raise ValueError('Episodio HackStore2 inválido')


def hackstore_item(obj, kind_hint=None):
    post_id = obj.get('_id') or obj.get('id') or obj.get('tmdb_id')
    if not isinstance(post_id, int):
        return None
    raw_type = obj.get('type') or obj.get('postType') or kind_hint or 'movies'
    kind = 'movie' if 'movie' in raw_type else ('anime' if 'anime' in raw_type else 'tvshow')
    title = obj.get('title') or obj.get('original_title') or 'Sin título'
    images = obj.get('images') or {}
    poster = images.get('poster') or obj.get('poster') or ''
    cover = f"{HACKSTORE_SITE}/wp-content/uploads{poster}" if poster and poster.startswith('/') else (poster if poster.startswith('http') else '')
    year = ''
    if obj.get('release_date'):
        year = str(obj['release_date']).split('-')[0]
    elif obj.get('years') and isinstance(obj['years'], list):
        year = str(obj['years'][0])
    return {
        'title': network.limpiar_texto(title),
        'url': f'hack://{kind}/{post_id}' + ('?' + urllib.parse.urlencode({'slug': obj['slug']}) if obj.get('slug') else ''),
        'cover': cover,
        'is_serie': kind != 'movie',
        'year': year.strip(),
        'rating': str(obj.get('rating') or obj.get('vote_average') or '').strip(),
        'plot': network.limpiar_texto(obj.get('overview') or ''),
        'genres': content_metadata.genres(obj.get('genres') or []),
        'source': 'hackstore2',
        'kind': kind,
        'tmdb_id': post_id,
    }


def hackstore_catalog(kind, page=1):
    if kind not in HACKSTORE_KINDS or page < 1:
        raise ValueError('Categoría HackStore2 inválida')
    post_type = 'movies' if kind == 'movie' else ('animes' if kind == 'anime' else 'tvshows')
    try:
        data = hackstore_api(f'/listing/{post_type}', {
            'page': page,
            'orderBy': 'latest',
            'order': 'desc',
            'postType': post_type,
            'postsPerPage': HACKSTORE_PAGE_SIZE
        })
        raw_posts = data.get('data', {}).get('posts', [])
        items = [hackstore_item(p, kind) for p in raw_posts]
        pagination = data.get('data', {}).get('pagination', {})
        has_next = page < pagination.get('totalPages', 1) if 'totalPages' in pagination else len(raw_posts) >= HACKSTORE_PAGE_SIZE
        return [it for it in items if it], bool(has_next)
    except Exception:
        return [], False


def hackstore_search(query):
    query = query.strip()
    if not query:
        return []
    try:
        data = hackstore_api('/search', {'q': query, 'postType': 'any', 'postsPerPage': 24})
        raw_posts = data.get('data', {}).get('posts', [])
        items = [hackstore_item(p) for p in raw_posts]
        return [it for it in items if it]
    except Exception:
        return []


def hackstore_episodes(series_url):
    kind, series_id, _, _ = hackstore_parse_url(series_url)
    if kind == 'movie':
        return {}
    result = {}
    try:
        data_s1 = hackstore_api('/single/episodes/list', {'_id': series_id, 'season': '1', 'page': 1, 'postsPerPage': 50})
        seasons_list = data_s1.get('data', {}).get('seasons', ['1'])
        seasons_to_fetch = [str(s) for s in seasons_list if str(s).isdigit()]
        if '1' not in seasons_to_fetch:
            seasons_to_fetch.insert(0, '1')

        for s_num in seasons_to_fetch:
            data = data_s1 if s_num == '1' else hackstore_api('/single/episodes/list', {'_id': series_id, 'season': s_num, 'page': 1, 'postsPerPage': 50})
            posts = data.get('data', {}).get('posts', [])
            entries = []
            for ep in posts:
                ep_id = ep.get('_id') or ep.get('id')
                ep_num = ep.get('episode_number') or 1
                still = ep.get('still_path') or ''
                cover = ('https://image.tmdb.org/t/p/w500' + still) if still and still.startswith('/') else ''
                ep_tit = network.limpiar_texto(ep.get('title') or f"Episodio {ep_num}")
                entries.append({
                    'title': f"T{s_num}:E{ep_num} - {ep_tit}",
                    'name': ep_tit,
                    'url': f"hack://{kind}/{series_id}/temporada-{s_num}/episodio-{ep_num}?ep_id={ep_id}",
                    'cover': cover,
                    'season': str(s_num),
                    'episode': str(ep_num),
                    'plot': network.limpiar_texto(ep.get('overview') or ''),
                    'year': content_metadata.fields(ep)['year'],
                    'is_serie': True,
                    'source': 'hackstore2',
                })
            if entries:
                entries.sort(key=lambda x: int(x['episode']))
                result[str(s_num)] = entries
    except Exception:
        pass
    return result


def hackstore_servers(video_url):
    result = []
    try:
        kind, post_id, season, episode = hackstore_parse_url(video_url)
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(video_url).query)
        ep_id = int(qs['ep_id'][0]) if 'ep_id' in qs and qs['ep_id'][0].isdigit() else None
        target_id = ep_id if ep_id is not None else post_id
        data = hackstore_api('/player', {'postId': target_id, 'demo': 0})
        embeds = data.get('data', {}).get('embeds', [])
        for em in embeds:
            url = em.get('url') or ''
            if not url.startswith(('http://', 'https://')):
                continue
            if 'la.movie' in url:
                continue
            h_name = em.get('serverName') or em.get('server') or 'Servidor'
            qual = em.get('quality') or ''
            lang = em.get('lang') or ''
            if 'goodstream' in url:
                label = f"GoodStream HLS ({lang})".strip() if lang else "GoodStream HLS"
            elif 'vimeos.net' in url:
                label = f"Vimeos HLS ({lang})".strip() if lang else "Vimeos HLS"
            else:
                label = f"{h_name} {qual} ({lang})".strip()
            result.append({
                'nombre': network.limpiar_texto(label),
                'url': url,
                'host': em.get('server') or em.get('serverName') or ''
            })
        def _hs_prio(s):
            u = s['url'].lower()
            if 'goodstream.one' in u:
                return 0
            if 'vimeos.net' in u:
                return 1
            return 2
        result.sort(key=_hs_prio)
        if kind == 'movie' and qs.get('slug'):
            existing = {entry['url'] for entry in result}
            result.extend(entry for entry in hackstore_backup_servers(qs['slug'][0]) if entry['url'] not in existing)
    except Exception as exc:
        network.log_resolver('Hackstore: ' + type(exc).__name__)
    return result


def hackstore_backup_servers(slug):
    """Read additional hosts from the matching public movie page."""
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', slug):
        return []
    page_url = 'https://www.hackstore.fo/peliculas/' + slug + '/'
    def read(url, referer):
        req = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': referer})
        with network.abrir_url(req, timeout=12, context=network._ssl_ctx) as response:
            return response.read().decode('utf-8', 'replace')
    soup = cinecalidad_soup(read(page_url, HACKSTORE_SITE + '/'))
    result, seen = [], set()
    for link in soup.select('.player a.playr[data-href]'):
        wrapper = urllib.parse.urljoin(page_url, link.get('data-href', ''))
        parsed = urllib.parse.urlsplit(wrapper)
        if parsed.hostname != 'www.hackstore.fo' or parsed.path != '/play.php':
            continue
        try:
            wrapper_html = read(wrapper, page_url)
            match = re.search(r"window\.location\.href\s*=\s*['\"](https?://[^'\"]+)['\"]", wrapper_html)
            if not match:
                continue
            url = html.unescape(match.group(1))
            if url in seen:
                continue
            seen.add(url)
            lang = link.get('data-lang', '')
            result.append({'nombre': network.limpiar_texto(link.get_text(' ', strip=True) + ' (' + lang + ')'),
                           'url': url, 'host': urllib.parse.urlsplit(url).hostname or ''})
        except Exception as exc:
            network.log_resolver('Hackstore respaldo: ' + type(exc).__name__)
    return result


def pelisjuanita_api(path, params=None):
    url = PELISJUANITA_API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        'User-Agent': network.UA,
        'Accept': 'application/json, text/plain, */*',
        'Referer': f"{PELISJUANITA_SITE}/",
    })
    with network.abrir_url(req, timeout=12, context=network._ssl_ctx) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def pelisjuanita_parse_url(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != 'juanita' or parsed.netloc not in PELISJUANITA_KINDS:
        raise ValueError('URL PelisJuanita inválida')
    parts = [x for x in parsed.path.split('/') if x]
    if not parts or not parts[0].isdigit():
        raise ValueError('ID PelisJuanita inválido')
    kind, item_id = parsed.netloc, int(parts[0])
    if len(parts) == 1:
        return kind, item_id, None, None
    if len(parts) == 3 and parts[1].startswith('temporada-') and parts[2].startswith('episodio-'):
        season, episode = parts[1][10:], parts[2][9:]
        if season.isdigit() and episode.isdigit():
            return kind, item_id, int(season), int(episode)
    raise ValueError('Episodio PelisJuanita inválido')


def pelisjuanita_item(obj, kind_hint=None):
    item_id = obj.get('catalog_item_id') or obj.get('id') or obj.get('tmdb_id')
    if not isinstance(item_id, int):
        return None
    raw_kind = obj.get('kind') or kind_hint or 'movie'
    kind = 'movie' if raw_kind == 'movie' else ('anime' if raw_kind == 'anime' else 'tvshow')
    title = obj.get('title') or obj.get('name') or obj.get('original_title') or 'Sin título'
    slug = obj.get('slug') or ''
    poster = obj.get('poster_path') or ''
    cover = ('https://image.tmdb.org/t/p/w500' + poster) if poster and poster.startswith('/') else (poster if poster.startswith('http') else '')
    year = str(obj.get('year') or (obj.get('release_date') or '')[:4] or '').strip()
    rating = str(obj.get('rating_avg') or obj.get('vote_average') or '').strip()
    item_url = f"juanita://{kind}/{item_id}?slug={urllib.parse.quote(slug)}" if slug else f"juanita://{kind}/{item_id}"
    return {
        'title': network.limpiar_texto(title),
        'url': item_url,
        'cover': cover,
        'is_serie': kind != 'movie',
        'year': year,
        'rating': rating,
        'plot': network.limpiar_texto(obj.get('overview') or ''),
        'genres': content_metadata.genres(obj.get('genres') or []),
        'source': 'pelisjuanita',
        'kind': kind,
        'tmdb_id': obj.get('tmdb_id') or item_id,
    }


def pelisjuanita_catalog(kind, page=1):
    if kind not in PELISJUANITA_KINDS or page < 1:
        raise ValueError('Categoría PelisJuanita inválida')
    api_kind = 'movie' if kind == 'movie' else ('anime' if kind == 'anime' else 'serie')
    try:
        data = pelisjuanita_api('/listing', {'kind': api_kind, 'order': 'recent', 'page': page})
        raw_items = data.get('items', [])
        items = [pelisjuanita_item(it, kind) for it in raw_items]
        pagination = data.get('pagination', {})
        has_next = pagination.get('has_next', len(raw_items) >= PELISJUANITA_PAGE_SIZE)
        return [it for it in items if it], bool(has_next)
    except Exception:
        return [], False


def pelisjuanita_search(query):
    query = query.strip()
    if not query:
        return []
    try:
        data = pelisjuanita_api('/search', {'q': query})
        raw_items = data.get('items', [])
        items = [pelisjuanita_item(it) for it in raw_items]
        return [it for it in items if it]
    except Exception:
        return []


def pelisjuanita_episodes(series_url):
    kind, item_id, _, _ = pelisjuanita_parse_url(series_url)
    if kind == 'movie':
        return {}
    result = {}
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(series_url).query)
        slug = qs.get('slug', [''])[0]
        api_kind = 'anime' if kind == 'anime' else 'serie'
        det = pelisjuanita_api(f'/content/{api_kind}/{urllib.parse.quote(slug)}') if slug else {}
        seasons_info = det.get('episode_seasons', [])
        seasons_to_fetch = [s.get('season') for s in seasons_info if isinstance(s.get('season'), int)] or [1]

        for s_num in seasons_to_fetch:
            ep_data = pelisjuanita_api('/episodes', {'item_id': item_id, 'season': s_num, 'limit': 50, 'page': 1})
            episodes = ep_data.get('episodes', [])
            entries = []
            for ep in episodes:
                ep_num = ep.get('episode') or 1
                still = ep.get('still_path') or ''
                cover = ('https://image.tmdb.org/t/p/w500' + still) if still and still.startswith('/') else ''
                ep_tit = network.limpiar_texto(ep.get('title') or f"Episodio {ep_num}")
                p_url = urllib.parse.quote(ep.get('player_url') or '')
                entries.append({
                    'title': f"T{s_num}:E{ep_num} - {ep_tit}",
                    'name': ep_tit,
                    'url': f"juanita://{kind}/{item_id}/temporada-{s_num}/episodio-{ep_num}?slug={urllib.parse.quote(slug)}&player_url={p_url}",
                    'cover': cover,
                    'season': str(s_num),
                    'episode': str(ep_num),
                    'plot': network.limpiar_texto(ep.get('overview') or ''),
                    'year': content_metadata.fields(ep)['year'],
                    'is_serie': True,
                    'source': 'pelisjuanita',
                })
            if entries:
                entries.sort(key=lambda x: int(x['episode']))
                result[str(s_num)] = entries
    except Exception:
        pass
    return result


def pelisjuanita_servers(video_url):
    result = []
    try:
        kind, item_id, season, episode = pelisjuanita_parse_url(video_url)
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(video_url).query)
        slug = qs.get('slug', [''])[0]
        player_url = qs.get('player_url', [''])[0]
        target_player = player_url
        if not target_player and slug:
            api_kind = 'movie' if kind == 'movie' else ('anime' if kind == 'anime' else 'serie')
            det = pelisjuanita_api(f'/content/{api_kind}/{urllib.parse.quote(slug)}')
            target_player = det.get('item', {}).get('player_url')

        if target_player:
            req = urllib.request.Request(target_player, headers={
                'User-Agent': network.UA,
                'Referer': f"{PELISJUANITA_SITE}/"
            })
            with network.abrir_url(req, timeout=12, context=network._ssl_ctx) as r:
                html = r.read().decode('utf-8', errors='ignore')
                iframes = re.findall(r'<iframe[^>]*src=[\x22\x27]([^\x22\x27]+)[\x22\x27]', html)
                for ifr in iframes:
                    if not ifr.startswith(('http://', 'https://')):
                        continue
                    if 'goodstream' in ifr:
                        label = 'GoodStream HLS (PelisJuanita)'
                    elif 'vimeos' in ifr or 'unlimplay' in ifr:
                        label = 'Vimeos HLS (PelisJuanita)'
                    else:
                        label = 'Servidor PelisJuanita'
                    result.append({
                        'nombre': network.limpiar_texto(label),
                        'url': ifr,
                        'host': 'PelisJuanita'
                    })
        def _pj_prio(s):
            u = s['url'].lower()
            if 'goodstream.one' in u:
                return 0
            if 'vimeos.net' in u:
                return 1
            return 2
        result.sort(key=_pj_prio)
    except Exception:
        pass
    return result


def fuegocine_get(url):
    req = urllib.request.Request(url, headers={
        'User-Agent': network.UA,
        'Accept': 'application/json,text/html;q=0.9,*/*;q=0.8',
        'Referer': f"{FUEGOCINE_BASE}/",
    })
    with network.abrir_url(req, timeout=15, context=network._ssl_ctx) as response:
        return response.read().decode('utf-8', 'replace')


def fuegocine_feed(label=None, query=None, start=1, limit=FUEGOCINE_PAGE_SIZE):
    if label:
        path = '/feeds/posts/default/-/' + urllib.parse.quote(label, safe='-')
    else:
        path = '/feeds/posts/default'
    params = {'alt': 'json', 'start-index': str(start), 'max-results': str(limit)}
    if query:
        params['q'] = query
    url = f"{FUEGOCINE_BASE}{path}?{urllib.parse.urlencode(params)}"
    return json.loads(fuegocine_get(url)).get('feed', {})


def fuegocine_attr(source, name):
    match = re.search(r'\b' + re.escape(name) + r'=[\'\"]([^\'\"]*)[\'\"]', source, re.I)
    return html.unescape(match.group(1)) if match else ''


def fuegocine_entry_item(entry):
    labels = {x.get('term', '') for x in entry.get('category', [])}
    if 'Episode' in labels:
        return None
    url = next((x.get('href', '') for x in entry.get('link', []) if x.get('rel') == 'alternate'), '')
    if not url or urllib.parse.urlparse(url).hostname != 'www.fuegocine.com':
        return None

    content = entry.get('content', {}).get('$t', '')
    summary = re.search(r'<p\b[^>]*id=[\'\"]tmdb-synopsis[\'\"][^>]*>(.*?)</p>', content, re.I | re.S)
    cover = re.search(r'<div\b[^>]*data-post-type=[\'\"][^\'\"]+[\'\"][^>]*>\s*<img\b[^>]*>', content, re.I | re.S)
    image = fuegocine_attr(cover.group(0), 'src') if cover else entry.get('media$thumbnail', {}).get('url', '')
    year = fuegocine_attr(content, 'data-year') or (re.search(r'\((\d{4})\)', entry.get('title', {}).get('$t', '')) or [None, ''])[1]
    rating = fuegocine_attr(content, 'data-imdb')

    # Detección precisa de Serie vs Película (evita bug de clasificar películas de anime como series)
    m_ptype = re.search(r'data-post-type=[\'\"]([^\'\"]+)[\'\"]', content, re.I)
    ptype = m_ptype.group(1).lower() if m_ptype else ''
    title_raw = html.unescape(entry.get('title', {}).get('$t', '')).strip()

    if ptype == 'serie':
        is_serie = True
    elif ptype == 'movie':
        is_serie = False
    elif 'Movie' in labels:
        is_serie = False
    elif 'Serie' in labels or 'temporadas' in title_raw.lower():
        is_serie = True
    else:
        is_serie = False

    return {
        'title': network.limpiar_texto(title_raw),
        'url': url,
        'cover': image,
        'is_serie': is_serie,
        'year': str(year).strip() if year else '',
        'rating': str(rating).strip() if rating else '',
        'plot': network.limpiar_texto(re.sub(r'<[^>]+>', '', summary.group(1))) if summary else '',
        'genres': content_metadata.genres(fuegocine_attr(content, 'data-genres').split(',')),
        'source': 'fuegocine',
    }


def fuegocine_catalogo(label, page=1):
    if label not in ('Movie', 'Serie', 'Anime') or page < 1:
        raise ValueError('Categoría no válida')
    feed = fuegocine_feed(label=label, start=(page - 1) * FUEGOCINE_PAGE_SIZE + 1)
    items = [fuegocine_entry_item(e) for e in feed.get('entry', [])]
    return [i for i in items if i]


def fuegocine_catalogo_genero(label, page=1, is_serie=False):
    if page < 1:
        raise ValueError('Página no válida')
    feed = fuegocine_feed(label=label, start=(page - 1) * FUEGOCINE_PAGE_SIZE + 1)
    items = [fuegocine_entry_item(e) for e in feed.get('entry', [])]
    return [i for i in items if i and bool(i.get('is_serie')) == is_serie]


def fuegocine_buscar(query, limit=30):
    query = query.strip()
    if not query:
        return []
    feed = fuegocine_feed(query=query, limit=limit)
    items = [fuegocine_entry_item(e) for e in feed.get('entry', [])]
    return [i for i in items if i]


def fuegocine_obtener_temporadas_episodios(series_url, limit=450):
    page = fuegocine_get(series_url)
    match = re.search(r'<article\b[^>]*data-post-id=[\'\"](\d+)[\'\"]', page, re.I)
    if not match:
        return {}
    post_id = match.group(1)
    result = {}
    start = 1
    while start <= limit:
        entries = fuegocine_feed(label='id-' + post_id, start=start, limit=min(150, limit - start + 1)).get('entry', [])
        if not entries:
            break
        for entry in entries:
            body = entry.get('content', {}).get('$t', '')
            season = fuegocine_attr(body, 'data-season-number')
            episode = fuegocine_attr(body, 'data-episode-count')
            if not season or not episode:
                title = entry.get('title', {}).get('$t', '')
                numbers = re.search(r'(\d+)\s*x\s*(\d+)', title, re.I)
                if numbers:
                    season, episode = numbers.groups()
            if not season or not episode:
                continue
            url = next((x.get('href', '') for x in entry.get('link', []) if x.get('rel') == 'alternate'), '')
            if not url:
                continue
            synopsis = re.search(r'<p\b[^>]*id=[\'\"]tmdb-synopsis[\'\"][^>]*>(.*?)</p>', body, re.I | re.S)
            title = network.limpiar_texto(entry.get('title', {}).get('$t', ''))
            item = {
                'title': f"T{season}:E{episode} - {title}",
                'name': title,
                'url': url,
                'season': str(season),
                'episode': str(episode),
                'cover': fuegocine_attr(body, 'data-backdrop'),
                'plot': network.limpiar_texto(re.sub(r'<[^>]+>', '', synopsis.group(1))) if synopsis else '',
                'is_serie': True,
                'source': 'fuegocine',
            }
            result.setdefault(str(season), []).append(item)
        start += len(entries)
        if len(entries) < 150:
            break

    for values in result.values():
        values.sort(key=lambda x: int(x['episode']) if x['episode'].isdigit() else 0)
    return result


def _es_reproducible_fuego(s_url):
    u = s_url.lower()
    return any(k in u for k in ['drive.google.com', 'drive.usercontent.google.com', 'ok.ru', 'vids.st', 'repfuegocinefree', 'archive.org', '1a-1791.com', '.m3u8', '.mp4'])


def fuegocine_obtener_servidores(page_url):
    page = fuegocine_get(page_url)
    match = re.search(r'\bconst\s+_SV_LINKS\s*=\s*\[(.*?)\]\s*;?', page, re.I | re.S)
    if not match:
        return []
    result = []
    for block in re.findall(r'\{([^{}]*)\}', match.group(1), re.S):
        values = dict((key, html.unescape(value)) for key, value in
                      re.findall(r'\b(lang|name|quality|url)\s*:\s*[\'\"]([^\'\"]*)[\'\"]', block, re.I))
        url = values.get('url', '').strip()
        if url.startswith(('https://', 'http://')):
            nom_raw = values.get('name', 'Servidor')
            qual = values.get('quality', '')
            lang = values.get('lang', '')

            if 'drive.google.com' in url:
                nombre = f"Google Drive {qual} ({lang})"
            elif 'ok.ru' in url:
                nombre = f"OK.RU Alta Velocidad {qual} ({lang})"
            elif 'vids.st' in url or 'vst' in nom_raw.lower():
                nombre = f"VIDS Dual Audio {qual} ({lang})"
            elif 'repfuegocinefree' in url:
                target = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).get('link', [''])[0]
                host = urllib.parse.urlsplit(target).hostname or 'Directo'
                if host.endswith('.rumble.cloud') or host == '1a-1791.com':
                    host = 'Rumble'
                elif host == 'files.eintim.me':
                    host = 'Eintim'
                nombre = f"FuegoCine {host} {qual} ({lang})"
            else:
                nombre = f"{nom_raw} {qual} ({lang})"

            nom_limpio = network.limpiar_texto(nombre)
            result.append({
                'nombre': nom_limpio or "Servidor FuegoCine",
                'url': url
            })

    result.sort(key=lambda s: not _es_reproducible_fuego(s['url']))
    return result


def es_url_hackstore(url):
    return str(url).startswith('hack://')


def es_url_pelisjuanita(url):
    return str(url).startswith('juanita://')


def es_url_fuegocine(url):
    return 'fuegocine' in str(url) or 'fuego://' in str(url)


def es_url_pelisflix(url):
    return 'pelisflix' in str(url)


def buscar_unificado(query):
    """
    Busca de forma coordinada en SoloLatino, HackStore2, PelisJuanita y FuegoCine,
    unificando resultados y eliminando duplicados.
    """
    query = query.strip()
    if not query:
        return []

    resultados = []
    urls_vistas = set()

    # 1. SoloLatino
    try:
        for it in sololatino_buscar(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    # 2. HackStore2
    try:
        for it in hackstore_search(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    # 3. PelisJuanita
    try:
        for it in pelisjuanita_search(query):
            if it['url'] not in urls_vistas:
                urls_vistas.add(it['url'])
                resultados.append(it)
    except Exception:
        pass

    return resultados


def obtener_episodios(serie_obj):
    """
    Obtiene temporadas y episodios detectando el proveedor (SoloLatino, HackStore2, PelisJuanita o FuegoCine).
    """
    import servidores as tubi
    if tubi.tubi_owns(serie_obj.get('url', '')):
        return tubi.tubi_episodes(serie_obj)
    import doramas
    if doramas.is_dorama(serie_obj):
        return doramas.episodes(serie_obj)
    u = serie_obj.get('url', '')
    if u.startswith('lolplus://tv/') or serie_obj.get('source') == 'lolplus':
        import lolplus
        return lolplus.lolplus_obtener_temporadas_episodios(serie_obj)
    elif es_url_hackstore(u):
        return hackstore_episodes(u)
    elif es_url_pelisjuanita(u):
        return pelisjuanita_episodes(u)
    elif es_url_fuegocine(u):
        return {}
    elif es_url_pelisflix(u):
        return pelisflix_episodes(u)
    else:
        return sololatino_obtener_temporadas_episodios(u, serie_obj)


def ordenar_servidores_por_calidad(lista_servidores):
    # Drive queda descartado por decision del usuario. Filtrar tambien los
    # enlaces encapsulados en el reproductor de FuegoCine.
    lista_servidores = [s for s in lista_servidores if not (
        'google drive' in s.get('nombre', '').lower() or
        any(host in urllib.parse.unquote(s.get('url', '')).lower()
            for host in ('drive.google.com', 'drive.usercontent.google.com')))]

    def _prio(s):
        nom = (s.get('nombre') or '').lower()
        idioma = (s.get('idioma') or nom).lower()
        u = (s.get('url') or '').lower()

        # 1. Prioridad estricta por idioma: Latino primero
        if any(k in idioma for k in ['latino', 'lat']):
            lang_score = 0
        elif any(k in idioma for k in ['castellano', 'esp', 'español', 'espanol', 'spanish']):
            lang_score = 1
        elif any(k in idioma for k in ['sub', 'subtitulado', 'ingles', 'eng']):
            lang_score = 2
        else:
            lang_score = 3

        # 2. Prioridad estricta por calidad: FullHD / 1080p / Multicalidad primero
        if any(k in nom for k in ['1080', 'fullhd', 'fhd', '4k']) or 'streamwish' in nom or 'wish' in u or 'voe' in nom or 'voe' in u or 'pelisserieshoy' in u:
            res_score = 0
        elif any(k in nom for k in ['720', 'hd']) or 'goodstream' in nom or 'vimeos' in u:
            res_score = 1
        elif any(k in nom for k in ['480', 'sd', 'dood']) or 'dood' in u:
            res_score = 2
        else:
            res_score = 3

        # 3. Estabilidad y tipo de reproductor
        if 'premium' in nom or 'pelisserieshoy' in u or 'directo' in nom or 'mediafire' in nom:
            host_score = 0
        elif 'voe' in nom or 'voe' in u:
            host_score = 1
        elif 'streamwish' in nom or 'wish' in u:
            host_score = 2
        elif 'dood' in nom or 'dood' in u:
            host_score = 3
        elif 'archive.org' in u or 'videro' in u:
            host_score = 4
        elif 'ok.ru' in u or 'ok.ru' in nom:
            host_score = 5
        elif 'streamtape' in nom or 'streamtape' in u:
            host_score = 6
        elif 'filemoon' in nom or 'byse' in u:
            host_score = 7
        elif 'netu' in nom or 'waaw' in u:
            host_score = 8
        else:
            host_score = 9

        return (lang_score, res_score, host_score)

    lista_servidores.sort(key=_prio)
    return lista_servidores


def ordenar_servidores_experimental(lista_servidores):
    def _prio(s):
        nom = s.get('nombre', '').lower()

        is_unverified = 1 if 'sin verificar' in nom or 'no verificado' in nom else 0
        has_lang = 0 if ('latino' in nom or 'español' in nom or 'espanol' in nom) else 1

        res_score = 9999
        if '4k' in nom or '2160p' in nom:
            res_score = 0
        elif '1080p' in nom:
            res_score = 1
        elif '720p' in nom:
            res_score = 2
        elif '480p' in nom:
            res_score = 3
        elif '360p' in nom:
            res_score = 4
        elif '240p' in nom:
            res_score = 5

        return (is_unverified, has_lang, res_score)

    lista_servidores.sort(key=_prio)
    return lista_servidores


def titulo_coincide(a, b):
    def normalizar(value):
        import unicodedata
        value = re.sub(r'^T\d+:E\d+\s*-\s*', '', value, flags=re.I)
        value = re.sub(r'\s+\d+x\d+\s*$', '', value, flags=re.I)
        value = re.sub(r'\(\d{4}\)|\s*-?\s*(?:todas?\s+las?\s+)?\btemporadas?\b.*$', '', value, flags=re.I)
        value = ''.join(c for c in unicodedata.normalize('NFKD', value) if not unicodedata.combining(c))
        return re.sub(r'[^a-z0-9]', '', value.lower())
    return bool(normalizar(a)) and normalizar(a) == normalizar(b)


def obtener_servidores_video(url_video, titulo=""):
    """
    Extrae los servidores disponibles según el proveedor:
    - HackStore2: GoodStream, Vimeos (con enriquecimiento prioritario de SoloLatino PREMIUM).
    - PelisJuanita: GoodStream, Vimeos (con enriquecimiento prioritario de SoloLatino PREMIUM).
    - FuegoCine: Google Drive, OK.RU, VIDS, Directos (con enriquecimiento prioritario de SoloLatino PREMIUM).
    - SoloLatino: PREMIUM Mediafire, PelisSeriesHoy.
    """
    servidores = []
    import servidores as cinecalidad
    import servidores as tubi
    if cinecalidad.cinecalidad_owns(url_video):
        servidores = cinecalidad.cinecalidad_servers({'url': url_video})
    elif tubi.tubi_owns(url_video):
        servidores = tubi.tubi_servers({'url': url_video})
    elif es_url_hackstore(url_video):
        servidores = hackstore_servers(url_video)
    elif es_url_pelisjuanita(url_video):
        servidores = pelisjuanita_servers(url_video)
    elif es_url_fuegocine(url_video):
        servidores = []
    elif es_url_pelisflix(url_video):
        servidores = pelisflix_servers(url_video)
    else:
        servidores = sololatino_obtener_servidores(url_video)

    # Enriquecimiento universal con SoloLatino PREMIUM si tenemos título y no está ya incluido
    tiene_premium = any('premium' in s.get('nombre', '').lower() or 'pelisserieshoy' in s.get('url', '').lower() for s in servidores)
    if titulo and not tiene_premium:
        try:
            tit_clean = re.sub(r'T\d+:E\d+\s*-\s*', '', titulo).strip()
            tit_clean = re.sub(r'\(\d{4}\)', '', tit_clean).strip()
            tit_clean = re.sub(r'\s+\d+x\d+\s*$', '', tit_clean).strip()
            m_ep = re.search(r'T(\d+):E(\d+)', titulo)
            if tit_clean:
                sol_cands = sololatino_buscar(tit_clean)
                sol_cands = [c for c in sol_cands if titulo_coincide(c.get('title', ''), tit_clean)]
                if sol_cands:
                    mejor = sol_cands[0]
                    if m_ep:
                        t_num, e_num = m_ep.group(1), m_ep.group(2)
                        eps_sol = sololatino_obtener_temporadas_episodios(mejor['url'])
                        ep_list = eps_sol.get(str(t_num), [])
                        for ep_it in ep_list:
                            if str(ep_it.get('episode')) == str(e_num):
                                srvs_sol = sololatino_obtener_servidores(ep_it['url'])
                                servidores = srvs_sol + servidores
                                break
                    else:
                        srvs_sol = sololatino_obtener_servidores(mejor['url'])
                        servidores = srvs_sol + servidores
        except Exception:
            pass

    return ordenar_servidores_por_calidad(servidores)


PELISFLIX_BASE_URL = 'https://pelisflix200.store'


def _pelisflix_fetch(path, params=None):
    url = urllib.parse.urljoin(PELISFLIX_BASE_URL, path)
    if params:
        url += '?' + urllib.parse.urlencode(params)
    html, _ = network.fetch_html(url)
    return html


def _pelisflix_parse_items(html):
    items = []
    articles = re.findall(r'<article[^>]*>(.*?)</article>', html, re.DOTALL)

    for art in articles:
        url_m = re.search(r'<a\s+href="([^"]+)"', art)
        title_m = re.search(r'<h[23][^>]*>(.*?)</h[23]>', art)
        if not title_m:
            title_m = re.search(r'alt="([^"]+)"', art)

        img_m = re.search(r'<img\s+[^>]*data-src="([^"]+)"', art)
        if not img_m:
            img_m = re.search(r'<img\s+[^>]*src="([^"]+)"', art)

        if url_m and title_m:
            url = url_m.group(1)
            title = network.limpiar_texto(unescape(re.sub(r'<[^>]+>', '', title_m.group(1))))
            cover = img_m.group(1) if img_m else ''

            if not url.startswith('http'):
                url = urllib.parse.urljoin(PELISFLIX_BASE_URL, url)
            if cover and not cover.startswith('http'):
                cover = urllib.parse.urljoin(PELISFLIX_BASE_URL, cover)

            is_serie = '/serie/' in url or '/episodio/' in url or '/temporada/' in url
            items.append({
                'title': title,
                'url': url,
                'cover': cover,
                'is_serie': is_serie,
                'source': 'pelisflix'
            })
    return items


def pelisflix_search(query):
    html = _pelisflix_fetch('/', {'s': query})
    return _pelisflix_parse_items(html)


def pelisflix_catalog(kind, page=1, genre=None):
    if genre:
        path = f'/genero/{genre}/'
        if page > 1:
            path += f'page/{page}/'
    else:
        path = '/series' if kind == 'series' else '/peliculas'
        if page > 1:
            path += f'/page/{page}/'
    html = _pelisflix_fetch(path)
    items = _pelisflix_parse_items(html)
    if genre:
        return [i for i in items if bool(i.get('is_serie')) == (kind == 'series')]
    return items


def pelisflix_episodes(series_url):
    html = _pelisflix_fetch(series_url)
    items = []

    # Encontrar paginas de temporadas
    season_urls = set(re.findall(r'<a\s+href="([^"]+/temporada/[^"]+)"', html))
    if not season_urls:
        season_urls = [series_url] # Fallback

    vistos = set()
    for s_url in season_urls:
        if not s_url.startswith('http'):
            s_url = urllib.parse.urljoin(PELISFLIX_BASE_URL, s_url)
        s_html = _pelisflix_fetch(s_url) if s_url != series_url else html

        # Buscar episodios directamente por url (.../episodio/...-1x1/)
        eps_urls = set(re.findall(r'<a\s+href="([^"]+/episodio/[^"]+-(\d+)x(\d+)/?)"', s_html))
        for url, season, episode in eps_urls:
            if not url.startswith('http'):
                url = urllib.parse.urljoin(PELISFLIX_BASE_URL, url)
            if url in vistos:
                continue
            vistos.add(url)
            items.append({
                'title': f'{season}x{episode}',
                'url': url,
                'is_serie': True,
                'season': int(season),
                'episode': int(episode),
                'source': 'pelisflix'
            })

    grouped = {}
    for item in sorted(items, key=lambda x: (x['season'], x['episode'])):
        s_key = str(item['season'])
        if s_key not in grouped:
            grouped[s_key] = []
        grouped[s_key].append(item)
    return grouped


def pelisflix_servers(url):
    html = _pelisflix_fetch(url)
    import base64
    servidores = []
    urls_vistas = set()

    # Data URLs from nupload/iframes
    data_urls = set(re.findall(r'data-url="([^"]+)"', html))
    for data in data_urls:
        try:
            data += '=' * (-len(data) % 4)
            dec = base64.b64decode(data).decode('utf-8')
            if 'nupload.my' in dec:
                u_parsed = urllib.parse.urlsplit(dec)
                qs = urllib.parse.parse_qs(u_parsed.query)
                if 'url' in qs:
                    target = qs['url'][0]
                    if target not in urls_vistas:
                        urls_vistas.add(target)
                        servidores.append({
                            'nombre': urllib.parse.urlsplit(target).hostname or 'Servidor',
                            'url': target
                        })
        except Exception:
            pass

    iframes = re.findall(r'<iframe[^>]*src="([^"]+)"', html)
    for iframe in iframes:
        if iframe not in urls_vistas and 'pelisflix' not in iframe:
            urls_vistas.add(iframe)
            servidores.append({
                'nombre': urllib.parse.urlsplit(iframe).hostname or 'Servidor',
                'url': iframe
            })

    # Return sorting is not strictly needed as Vaquexflix usually sorts later
    return servidores


# Fuente: cinecalidad
from urllib.parse import urlencode, urljoin, urlsplit
from provider_cache import PageCache

cinecalidad_BASE = 'https://www.cinecalidad.my'


cinecalidad__CACHE = PageCache()


cinecalidad_PLAYERS = {
    'OnlineVoe': ('Voe', 'https://voe.sx/e/'),
    'OnlineFilemoon': ('Filemoon', 'https://bysedikamoum.com/e/'),
    'OnlineDoodstream': ('Doodstream', 'https://doodstream.com/e/'),
    'OnlineMega': ('Mega', 'https://mega.nz/embed/'),
    'OnlineNetu': ('Netu', 'https://www.zarato.top/watch_video.php?v='),
}


def cinecalidad_owns(url):
    return (urlsplit(url).hostname or '') in ('cinecalidad.my', 'www.cinecalidad.my')


def cinecalidad_soup(markup):
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))
        from bs4 import BeautifulSoup
    return BeautifulSoup(markup, 'html.parser')


def cinecalidad_fetch(url):
    if not cinecalidad_owns(url):
        raise ValueError('URL ajena a Cinecalidad')
    return cinecalidad_soup(cinecalidad__CACHE.get(url, lambda: network.fetch_html(url, referer=cinecalidad_BASE + '/', timeout=12)[0]))


def cinecalidad_parse_items(doc):
    items, seen = [], set()
    for card in doc.select('.home_post_cont'):
        anchor, img = card.select_one('a[href]'), card.select_one('img')
        if not anchor or not img:
            continue
        url = urljoin(cinecalidad_BASE, anchor['href'])
        name = img.get('alt') or img.get('title') or ''
        if not cinecalidad_owns(url) or not urlsplit(url).path.startswith('/pelicula/') or not name or url in seen:
            continue
        seen.add(url)
        year = re.search(r'\((\d{4})\)\s*$', name)
        extract = cinecalidad_soup(img.get('extract', '')).select_one('p')
        items.append({'title': re.sub(r'\s*\(\d{4}\)\s*$', '', name), 'url': url,
                      'year': year.group(1) if year else '', 'is_serie': False,
                      'source': 'cinecalidad', 'cover': urljoin(cinecalidad_BASE, img.get('data-src') or img.get('src', '')),
                      'plot': extract.get_text(' ', strip=True) if extract else ''})
    return items


def cinecalidad_next_page(doc):
    for anchor in doc.select('a[href]'):
        if anchor.get_text(' ', strip=True).lower() == 'más películas':
            url = urljoin(cinecalidad_BASE, anchor['href'])
            return url if cinecalidad_owns(url) and re.search(r'/page/\d+/?$', urlsplit(url).path) else None
    return None


def cinecalidad_page(number=1, genre=None):
    if genre:
        url = cinecalidad_BASE + f"/genero-peliculas/{genre}/" + (f"page/{number}/" if number > 1 else "")
    else:
        url = cinecalidad_BASE + ('/page/%d/' % number if number > 1 else '/')
    doc = cinecalidad_fetch(url)
    return cinecalidad_parse_items(doc), bool(cinecalidad_next_page(doc))


def cinecalidad_search(query):
    if not query.strip():
        return []
    url = cinecalidad_BASE + '/?' + urlencode({'s': query.strip()})
    seen_pages, results = set(), {}
    while url and url not in seen_pages:
        seen_pages.add(url)
        doc = cinecalidad_fetch(url)
        items = cinecalidad_parse_items(doc)
        fresh = [item for item in items if item['url'] not in results]
        if not fresh:
            break
        results.update((item['url'], item) for item in fresh)
        url = cinecalidad_next_page(doc)
    return list(results.values())


def cinecalidad_servers(item):
    doc = cinecalidad_fetch(item['url'])
    results, seen = [], set()
    for anchor in doc.select('#panel_online a[service][data]'):
        service, key = anchor['service'], anchor['data'].strip()
        if service not in cinecalidad_PLAYERS or not re.fullmatch(r'[\w#-]+', key):
            continue
        name, prefix = cinecalidad_PLAYERS[service]
        url = prefix + key
        if url not in seen:
            seen.add(url)
            results.append({'nombre': name + ' | Latino', 'url': url, 'source': 'cinecalidad'})
    return results


def cinecalidad_metadata(item):
    doc = cinecalidad_fetch(item['url'])
    plot = doc.select_one('.single_left table td:nth-of-type(2) p')
    return {'plot': plot.get_text(' ', strip=True)} if plot else {}


# Fuente: tubi
import sqlite3
import unicodedata
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from urllib.parse import urlsplit, urljoin, unquote, urlencode, parse_qs
from urllib.request import Request

tubi_BASE = 'https://tubitv.com'


tubi_PAGE_SIZE = 30


tubi__LOCK = threading.Lock()


tubi__AVAILABILITY_CACHE = {'time': 0, 'status': None}


tubi__AVAILABILITY_TTL = 30


tubi_NS = {'s': 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'v': 'http://www.google.com/schemas/sitemap-video/1.1',
      'i': 'http://www.google.com/schemas/sitemap-image/1.1'}


def tubi_is_available(force=False):
    now = time.time()
    if not force and tubi__AVAILABILITY_CACHE['status'] is not None and now - tubi__AVAILABILITY_CACHE['time'] < tubi__AVAILABILITY_TTL:
        return tubi__AVAILABILITY_CACHE['status']
    import servidores as s
    available = False
    try:
        req = Request(tubi_BASE, headers={'User-Agent': network.UA}, method='HEAD')
        with network.nueva_sesion().open(req, timeout=3) as resp:
            final_url = resp.geturl()
            available = tubi_owns(final_url) and 'gdpr' not in final_url
    except Exception:
        available = False
    tubi__AVAILABILITY_CACHE['time'] = now
    tubi__AVAILABILITY_CACHE['status'] = available
    return available


def tubi_database():
    try:
        import xbmcvfs
        root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vaquexflix')
    except ImportError:
        root = ''
    if not root:
        root = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'Kodi', 'userdata', 'addon_data', 'plugin.video.vaquexflix')
    os.makedirs(root, exist_ok=True)
    return os.path.join(root, 'tubi_catalog.sqlite')


def tubi_owns(url):
    return urlsplit(url).hostname in ('tubitv.com', 'www.tubitv.com')


def tubi_normalize(value):
    value = ''.join(c for c in unicodedata.normalize('NFKD', value.lower()) if not unicodedata.combining(c))
    return ' '.join(re.findall(r'[a-z0-9]+', value))


def tubi_request(url, limit=24000000):
    import servidores as s
    if not tubi_owns(url) or urlsplit(url).scheme != 'https':
        raise ValueError('URL de Tubi no valida')
    with network.nueva_sesion().open(Request(url, headers={'User-Agent': network.UA}), timeout=25) as response:
        body = response.read(limit + 1)
        if len(body) > limit:
            raise ValueError('Respuesta de Tubi demasiado grande')
        return body.decode('utf-8', 'replace')


def tubi_parse_sitemap(text):
    result = []
    for node in ET.fromstring(text).findall('s:url', tubi_NS):
        url = node.findtext('s:loc', '', tubi_NS)
        path = urlsplit(url).path
        if not tubi_owns(url) or not re.match(r'^/(movies|series)/[0-9]+/', path):
            continue
        series = path.startswith('/series/')
        title = node.findtext('v:video/v:title', '', tubi_NS) or unquote(path.rstrip('/').rsplit('/', 1)[-1]).replace('-', ' ').title()
        result.append({'title': title, 'url': url, 'is_serie': series,
                       'cover': node.findtext('i:image/i:loc', '', tubi_NS) or node.findtext('v:video/v:thumbnail_loc', '', tubi_NS),
                       'plot': node.findtext('v:video/v:description', '', tubi_NS),
                       'source': 'tubi', 'media_type': 'series' if series else 'movie'})
    return result


def tubi_refresh(force=False):
    if not tubi_is_available():
        return
    with tubi__LOCK:
        with closing(sqlite3.connect(tubi_database(), timeout=60)) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS titles (url TEXT PRIMARY KEY, title TEXT, kind TEXT, drama INTEGER, data TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)')
            # Migrate the existing index in place so an offline user also sees
            # every Tubi title in Series or Peliculas immediately.
            routing = db.execute("SELECT value FROM meta WHERE key='routing'").fetchone()
            if not routing or routing[0] != 'experimental':
                old = db.execute('SELECT url, kind, data FROM titles WHERE drama=1').fetchall()
                for url, kind, raw in old:
                    item = json.loads(raw)
                    item['section'] = kind
                    db.execute('UPDATE titles SET drama=0, data=? WHERE url=?',
                               (json.dumps(item, ensure_ascii=False), url))
                db.execute("INSERT OR REPLACE INTO meta VALUES ('routing', 'experimental')")
                db.commit()
            stamp = db.execute("SELECT value FROM meta WHERE key='updated'").fetchone()
            if not force and stamp and time.time() - float(stamp[0]) < 86400:
                return
            try:
                root = ET.fromstring(tubi_request(tubi_BASE + '/sitemap.xml'))
                maps = [n.text for n in root.findall('s:sitemap/s:loc', tubi_NS)
                        if re.fullmatch(r'https://tubitv.com/sitemaps/(movies|tv-shows)-[0-9]+\.xml', n.text or '')]
                if not maps:
                    raise ValueError('Tubi no publico los mapas de catalogo')
                with ThreadPoolExecutor(max_workers=3) as pool:
                    batches = list(pool.map(lambda u: tubi_parse_sitemap(tubi_request(u)), maps))
                rows = {}
                for batch in batches:
                    for item in batch:
                        kind = 'series' if item['is_serie'] else 'peliculas'
                        item['section'] = kind
                        rows[item['url']] = (item['url'], tubi_normalize(item['title']), kind, 0,
                                             json.dumps(item, ensure_ascii=False))
                if not rows:
                    raise ValueError('Catalogo de Tubi vacio')
                # Publish only a complete refresh; never replace a working index with partial data.
                db.execute('DELETE FROM titles')
                db.executemany('INSERT INTO titles VALUES (?,?,?,?,?)', rows.values())
                db.execute("INSERT OR REPLACE INTO meta VALUES ('updated', ?)", (str(time.time()),))
                db.execute("INSERT OR REPLACE INTO meta VALUES ('sitemaps', ?)", (str(len(maps)),))
            except Exception:
                db.rollback()
                if not stamp:
                    raise
                import servidores
                network.log_resolver('Tubi: usando catalogo anterior; actualizacion no disponible')


tubi_TUBI_GENRE_KEYWORDS = {
    'accion': ['accion', 'action'],
    'animacion': ['animacion', 'animation', 'animated', 'anime'],
    'anime': ['anime', 'animacion'],
    'aventura': ['aventura', 'adventure'],
    'comedia': ['comedia', 'comedy'],
    'crimen': ['crimen', 'crime'],
    'documental': ['documental', 'documentary'],
    'drama': ['drama'],
    'familia': ['familia', 'family'],
    'familiar': ['familia', 'family'],
    'fantasia': ['fantasia', 'fantasy'],
    'historia': ['historia', 'history', 'historical'],
    'misterio': ['misterio', 'mystery'],
    'romance': ['romance', 'romantic'],
    'suspense': ['suspense', 'thriller', 'suspenso'],
    'suspenso': ['suspense', 'thriller', 'suspenso'],
    'terror': ['terror', 'horror'],
    'western': ['western'],
}


def tubi_page(section, number=1, genre=None):
    if not tubi_is_available():
        return [], False
    if number < 1:
        raise ValueError('Pagina no valida')
    tubi_refresh()
    if section not in ('series', 'peliculas'):
        return [], False
    with closing(sqlite3.connect(tubi_database())) as db:
        if genre:
            kws = tubi_TUBI_GENRE_KEYWORDS.get(genre, [])
            if not kws:
                return [], False
            where = 'kind=? AND (' + ' OR '.join('data LIKE ?' for _ in kws) + ')'
            params = [section] + ['%' + kw + '%' for kw in kws] + [tubi_PAGE_SIZE + 1, (number - 1) * tubi_PAGE_SIZE]
            rows = db.execute('SELECT data FROM titles WHERE ' + where + ' ORDER BY title, url LIMIT ? OFFSET ?', params).fetchall()
        else:
            rows = db.execute('SELECT data FROM titles WHERE kind=? ORDER BY title, url LIMIT ? OFFSET ?',
                              (section, tubi_PAGE_SIZE + 1, (number - 1) * tubi_PAGE_SIZE)).fetchall()
    return [json.loads(r[0]) for r in rows[:tubi_PAGE_SIZE]], len(rows) > tubi_PAGE_SIZE


def tubi_search(query):
    if not tubi_is_available():
        return []
    words = tubi_normalize(query).split()
    if not words:
        return []
    # Keep meaningful words mandatory; tolerate changes such as "de" / "en".
    stopwords = {'a', 'al', 'de', 'del', 'el', 'en', 'la', 'las', 'lo', 'los',
                 'un', 'una', 'unos', 'unas', 'y'}
    words = [word for word in words if word not in stopwords] or words
    tubi_refresh()
    clause = ' AND '.join('title LIKE ?' for _ in words)
    with closing(sqlite3.connect(tubi_database())) as db:
        rows = db.execute('SELECT data FROM titles WHERE ' + clause + ' ORDER BY title, url', ['%' + w + '%' for w in words]).fetchall()
    return [json.loads(r[0]) for r in rows]


def tubi_state(text):
    match = re.search(r'window\.__data\s*=\s*(.*?);</script>', text, re.S)
    if not match:
        raise ValueError('Tubi no entrego datos; comprueba disponibilidad regional (US_VPN)')
    # Parse data, never evaluate scripts. Preserve quoted occurrences of undefined.
    raw = re.sub(r'("(?:\\.|[^"\\])*"|\bundefined\b)', lambda m: 'null' if m[0] == 'undefined' else m[0], match[1])
    return json.loads(raw)


def tubi_detail(url):
    if not tubi_owns(url):
        raise ValueError('Fuente Tubi no valida')
    match = re.match(r'^/(movies|series|tv-shows)/([0-9]+)(?:/|$)', urlsplit(url).path)
    if not match:
        raise ValueError('Ficha Tubi no valida')
    data = tubi_state(tubi_request(url))
    # Match the requested ID, never a recommended title or another episode.
    target = next((v for v in data.get('video', {}).get('byId', {}).values()
                   if str(v.get('id', '')).lstrip('0') == match[2].lstrip('0')), None)
    if not target:
        raise ValueError('Tubi no ofrece este titulo en la region actual (US_VPN)')
    return target


def tubi_metadata(item):
    d = tubi_detail(item['url'])
    return {'title': d.get('title', item.get('title', '')), 'plot': d.get('description', ''),
            'year': d.get('year', ''), 'genres': d.get('tags', []),
            'is_serie': d.get('type') == 's' or bool(d.get('series_id')),
            'media_type': 'series' if d.get('type') == 's' else ('episode' if d.get('series_id') else 'movie')}


def tubi_episodes(item):
    d = tubi_detail(item['url'])
    grouped = {}
    for season in d.get('seasons', []):
        sn = str(season.get('number') or 1)
        for ep in season.get('episodes', []):
            number = str(ep.get('num') or ep.get('episode_number') or '')
            if not number.isdigit() or not str(ep.get('id', '')).isdigit():
                continue
            grouped.setdefault(sn, []).append({'title': 'T%s:E%s - %s' % (sn, number, item['title']),
                'url': tubi_BASE + '/tv-shows/' + str(ep['id']), 'cover': item.get('cover', ''),
                'is_serie': True, 'season': sn, 'episode': number, 'source': 'tubi',
                'section': item.get('section', 'series'), 'plot': ep.get('description', '')})
    for entries in grouped.values():
        entries.sort(key=lambda e: int(e['episode']))
    return grouped


def tubi_servers(item):
    if not tubi_is_available():
        return []
    return [{'nombre': 'US_VPN', 'url': 'tubi://play?' + urlencode({'url': item['url']}), 'premium': False}]
