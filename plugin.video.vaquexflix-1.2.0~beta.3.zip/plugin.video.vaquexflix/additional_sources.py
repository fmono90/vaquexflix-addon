"""Fuentes verificadas: Dondever y Ver Películas Online.

Los enlaces de servidor se resuelven al seleccionarlos: sus URLs caducan y
una opción anunciada no equivale a un vídeo comprobado.
"""

import html
import json
import re
from urllib.parse import urlencode, urljoin, urlsplit, parse_qs, quote

import network
import source_switches

DONDEVER = 'https://dondever.net'
VERPEL = 'https://ver-peliculas-online.net'


def _headers(referer, api=False):
    return {
        'User-Agent': network.UA, 'Referer': referer,
        'Accept': 'application/json, text/plain, */*' if api else
                  'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
        'Sec-Fetch-Dest': 'empty' if api else 'document',
        'Sec-Fetch-Mode': 'cors' if api else 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        **({'X-Requested-With': 'XMLHttpRequest'} if api else {}),
    }


def _get(url, referer=None, api=False, data=None):
    page, _ = network.fetch_html(url, referer=referer or url, timeout=10,
                                 data=data, headers_dict=_headers(referer or url, api))
    if not page:
        raise network.ServidorNoDisponible('La fuente no respondió: ' + (urlsplit(url).hostname or 'desconocida'))
    return page


def _text(fragment):
    return html.unescape(re.sub(r'<[^>]+>', '', fragment or '')).strip()


def owns(url):
    return urlsplit(url).hostname in ('dondever.net', 'www.dondever.net',
                                     'ver-peliculas-online.net', 'www.ver-peliculas-online.net')


def _cards(page, source):
    if source == 'Dondever':
        cards = re.findall(r'<article\b[^>]*\bnt-card\b[^>]*>(.*?)</article>', page, re.I | re.S)
        path_pattern = r'/(?:movies|tvshows)/[^"\'<> ]+'
    else:
        cards = re.findall(r'<div\b[^>]*class=["\']result-item["\'][^>]*>\s*<article>(.*?)</article>',
                           page, re.I | re.S)
        cards.extend(re.findall(r'<article\b[^>]*class=["\'][^"\']*\bitem\s+movies\b[^"\']*["\'][^>]*>(.*?)</article>',
                                page, re.I | re.S))
        path_pattern = r'/pelicula/[^"\'<> ]+'
    found = {}
    for card in cards:
        link = re.search(r'href=["\'](https?://[^"\']+' + path_pattern + r')["\']', card, re.I)
        if not link:
            continue
        url = html.unescape(link.group(1))
        if source == 'Dondever':
            title_match = re.search(r'<h3\b[^>]*>\s*<a[^>]*>(.*?)</a>', card, re.I | re.S)
        else:
            title_match = re.search(r'<div\b[^>]*class=["\']title["\'][^>]*>\s*<a[^>]*>(.*?)</a>', card, re.I | re.S)
            if not title_match:
                title_match = re.search(r'<h3\b[^>]*>\s*<a[^>]*>(.*?)</a>', card, re.I | re.S)
        title = _text(title_match.group(1)) if title_match else ''
        if not title:
            continue
        image = re.search(r'<img\b[^>]*(?:data-src|src)=["\'](https?://[^"\']+)', card, re.I)
        year = re.search(r'\b(?:19|20)\d{2}\b', card)
        found[url] = {'title': title, 'url': url, 'cover': html.unescape(image.group(1)) if image else '',
                      'year': year.group(0) if year else '', 'source': source,
                      'is_serie': '/tvshows/' in url, 'section': 'series' if '/tvshows/' in url else 'peliculas'}
    return list(found.values())


def search_dondever(query):
    page = _get(DONDEVER + '/?' + urlencode({'s': query}), DONDEVER + '/')
    return _cards(page, 'Dondever')


def search_verpel(query):
    page = _get(VERPEL + '/?' + urlencode({'s': query}), VERPEL + '/')
    return _cards(page, 'VerPeliculasOnline')


def search(query):
    results = []
    for key, getter in (('dondever', search_dondever), ('verpel', search_verpel)):
        if not source_switches.enabled(key):
            continue
        try:
            results.extend(getter(query))
        except Exception as exc:
            network.log_resolver('Fuente adicional: ' + str(exc))
    return results


def page(source, number, section='peliculas'):
    """Catálogos propios para que las fichas verificadas sean navegables."""
    if number < 1 or source not in ('dondever', 'verpel') or not source_switches.enabled(source):
        return [], False
    if source == 'dondever':
        kind = 'tvshows' if section == 'series' else 'movies'
        base = DONDEVER + '/' + kind + '/'
        url = base if number == 1 else base + f'page/{number}/'
        page_html = _get(url, DONDEVER + '/')
        items = _cards(page_html, 'Dondever')
        return items, f'/{kind}/page/{number + 1}/' in page_html
    if section != 'peliculas':
        return [], False
    base = VERPEL + '/pelicula/'
    url = base if number == 1 else base + f'page/{number}/'
    page_html = _get(url, VERPEL + '/')
    items = _cards(page_html, 'VerPeliculasOnline')
    return items, f'/pelicula/page/{number + 1}/' in page_html


def episodes(series):
    if not source_switches.allowed(series):
        return {}
    url = series.get('url', '')
    if urlsplit(url).hostname not in ('dondever.net', 'www.dondever.net') or '/tvshows/' not in url:
        return {}
    page = _get(url, DONDEVER + '/')
    found = {}
    for episode_url, season, number in re.findall(
            r'href=["\'](https://dondever\.net/episodes/[^"\']+?-(\d+)x(\d+)/)["\']', page, re.I):
        key = (int(season), int(number))
        found[key] = {'title': f'T{season}:E{number} - {series.get("title", "Episodio")}',
                      'url': episode_url, 'season': str(int(season)), 'episode': str(int(number)),
                      'cover': series.get('cover', ''), 'is_serie': True, 'section': 'series',
                      'source': 'Dondever'}
    result = {}
    for (season, _), item in sorted(found.items()):
        result.setdefault(str(season), []).append(item)
    return result


def servers(item):
    if not source_switches.allowed(item):
        return []
    url = item.get('url', '')
    host = urlsplit(url).hostname or ''
    referer = DONDEVER + '/' if 'dondever' in host else VERPEL + '/'
    if 'dondever' in host and '/episodes/' in url:
        match_series = re.search(r'/episodes/(.+?)-\d+x\d+/', url)
        if match_series:
            referer = DONDEVER + '/tvshows/' + match_series.group(1) + '/'
    page = _get(url, referer)
    if 'dondever.net' in host:
        match = re.search(r'<script\b[^>]*data-nt-sources[^>]*>(.*?)</script>', page, re.I | re.S)
        if not match:
            raise network.ServidorNoDisponible('Dondever no publicó opciones para esta ficha.')
        try:
            data = json.loads(html.unescape(match.group(1)))
        except ValueError as exc:
            raise network.ServidorNoDisponible('Dondever publicó opciones inválidas.') from exc
        post = data.get('post')
        if not isinstance(post, int) or post <= 0:
            raise network.ServidorNoDisponible('Dondever no publicó un ID de reproductor válido.')
        result = []
        for group in data.get('groups', []):
            if not isinstance(group, dict):
                continue
            language = group.get('label') or group.get('code') or ''
            for option in group.get('servers', []):
                if not isinstance(option, dict) or not isinstance(option.get('index'), int):
                    continue
                name = option.get('name') or 'Servidor'
                token = urlencode({'post': post, 'index': option['index'], 'referer': url})
                result.append({'nombre': f'{name} [Dondever] | Audio: {language}',
                               'url': 'vaquexsrc://dondever?' + token, 'calidad': 'Sin verificar',
                               'idioma': language})
        return result
    if 'ver-peliculas-online.net' in host:
        result = []
        for tag, body in re.findall(r'(<li\b[^>]*\bdooplay_player_option\b[^>]*>)(.*?)</li>', page, re.I | re.S):
            post = re.search(r'\bdata-post=["\'](\d+)', tag)
            nume = re.search(r'\bdata-nume=["\'](\d+)', tag)
            kind = re.search(r'\bdata-type=["\']([a-z]+)', tag)
            if not (post and nume and kind):
                continue
            label = _text((re.search(r'<span\b[^>]*class=["\']title["\'][^>]*>(.*?)</span>', body, re.I | re.S) or [None, ''])[1])
            host_label = _text((re.search(r'<span\b[^>]*class=["\']server["\'][^>]*>(.*?)</span>', body, re.I | re.S) or [None, ''])[1])
            token = urlencode({'post': post.group(1), 'nume': nume.group(1),
                               'type': kind.group(1), 'referer': url})
            result.append({'nombre': f'{host_label or "Servidor"} [Ver Películas Online] | Audio: {label or "Sin indicar"}',
                           'url': 'vaquexsrc://verpel?' + token, 'calidad': 'Sin verificar',
                           'idioma': label})
        return result
    return []


def resolve(url):
    parsed = urlsplit(url)
    params = parse_qs(parsed.query)
    referer = params.get('referer', [''])[0]
    if parsed.netloc == 'dondever':
        if urlsplit(referer).hostname not in ('dondever.net', 'www.dondever.net'):
            raise network.ServidorNoDisponible('Dondever: ficha de origen inválida.')
        post = params.get('post', [''])[0]
        index = params.get('index', [''])[0]
        if not post.isdigit() or not index.isdigit():
            raise network.ServidorNoDisponible('Dondever: servidor inválido.')
        api = DONDEVER + '/wp-json/nt/v1/marco?' + urlencode({'post': post, 'index': index})
        data = json.loads(_get(api, referer, api=True))
        target = data.get('iframe') if data.get('ok') else None
        error = 'Dondever no entregó el iframe de este servidor.'
    elif parsed.netloc == 'verpel':
        if urlsplit(referer).hostname not in ('ver-peliculas-online.net', 'www.ver-peliculas-online.net'):
            raise network.ServidorNoDisponible('Ver Películas Online: ficha de origen inválida.')
        post, nume, kind = (params.get(key, [''])[0] for key in ('post', 'nume', 'type'))
        if not post.isdigit() or not nume.isdigit() or kind not in ('movie', 'tv'):
            raise network.ServidorNoDisponible('Ver Películas Online: servidor inválido.')
        payload = urlencode({'action': 'doo_player_ajax', 'post': post,
                             'nume': nume, 'type': kind}).encode()
        headers = _headers(referer, api=True)
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        page, _ = network.fetch_html(VERPEL + '/wp-admin/admin-ajax.php', referer=referer,
                                     timeout=10, data=payload, headers_dict=headers)
        if not page:
            raise network.ServidorNoDisponible('Ver Películas Online: la API no respondió.')
        data = json.loads(page)
        target = data.get('embed_url')
        error = 'Ver Películas Online no entregó el iframe de este servidor.'
    else:
        raise network.ServidorNoDisponible('Fuente adicional desconocida.')
    if not isinstance(target, str) or urlsplit(target).scheme not in ('https', 'http') or not urlsplit(target).hostname:
        raise network.ServidorNoDisponible(error)
    return target
