"""Sondeo acotado de metadatos HLS/MP4, sin dependencias nativas ni Kodi."""
import hashlib
import queue
import re
import struct
import threading
import time
from urllib.parse import parse_qsl, urljoin
from urllib.request import Request


def cache_key(url):
    return hashlib.sha256(url.encode('utf-8')).hexdigest()


def language(code='', name=''):
    code, name = code.lower(), name.lower()
    if 'latino' in name or code in ('es-419', 'es-mx', 'es-ar', 'es-co', 'lat'):
        return 'LAT'
    if 'castellano' in name or code == 'es-es':
        return 'ESP'
    aliases = {'es': 'ES', 'spa': 'ES', 'esp': 'ES', 'en': 'ENG', 'eng': 'ENG',
               'pt': 'POR', 'por': 'POR', 'ja': 'JPN', 'jpn': 'JPN', 'fr': 'FRA',
               'fra': 'FRA', 'fre': 'FRA', 'de': 'DEU', 'deu': 'DEU', 'ger': 'DEU'}
    if code in ('', 'und', 'unknown', 'zxx'):
        return 'Idioma no indicado'
    return aliases.get(code, aliases.get(code.split('-')[0], code.upper()))


def parse_hls(text):
    heights, audio, groups = set(), [], set()
    attributes = lambda line: dict((k, v.strip('"')) for k, v in
        re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,\r\n]+)', line))
    for line in text.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            attrs = attributes(line)
            match = re.fullmatch(r'(\d+)x(\d+)', attrs.get('RESOLUTION', ''))
            if match:
                w, h = int(match.group(1)), int(match.group(2))
                if w >= 1920 or h >= 1080 or (w >= 1320 and h >= 720):
                    heights.add(1080)
                else:
                    heights.add(h)
            if attrs.get('AUDIO'):
                groups.add(attrs['AUDIO'])
    for line in text.splitlines():
        if not line.startswith('#EXT-X-MEDIA:'):
            continue
        attrs = attributes(line)
        if attrs.get('TYPE') != 'AUDIO' or (groups and attrs.get('GROUP-ID') not in groups):
            continue
        channel = attrs.get('CHANNELS', '').split('/')[0]
        track = {'language': language(attrs.get('LANGUAGE', ''), attrs.get('NAME', '')),
                 'channels': int(channel) if channel.isdigit() else 0}
        if track not in audio:
            audio.append(track)
    return {'heights': sorted(heights), 'audio': audio}


def boxes(data):
    offset = 0
    while offset + 8 <= len(data):
        size, kind = struct.unpack_from('>I4s', data, offset)
        header = 8
        if size == 1:
            if offset + 16 > len(data):
                return
            size = struct.unpack_from('>Q', data, offset + 8)[0]
            header = 16
        if size == 0:
            size = len(data) - offset
        if size < header or offset + size > len(data):
            return
        yield kind, data[offset + header:offset + size]
        offset += size


def parse_moov(data):
    heights, audio = set(), []
    for kind, track in boxes(data):
        if kind != b'trak':
            continue
        children = dict(boxes(track))
        mdia = dict(boxes(children.get(b'mdia', b'')))
        handler = mdia.get(b'hdlr', b'')[8:12]
        if handler == b'vide':
            header = children.get(b'tkhd', b'')
            if len(header) >= 84:
                height = struct.unpack('>I', header[-4:])[0] >> 16
                if height:
                    heights.add(height)
        elif handler == b'soun':
            mdhd = mdia.get(b'mdhd', b'')
            lang_offset = 32 if mdhd[:1] == b'\x01' else 20
            code = ''
            if len(mdhd) >= lang_offset + 2:
                packed = struct.unpack_from('>H', mdhd, lang_offset)[0]
                if packed:
                    code = ''.join(chr(((packed >> shift) & 31) + 96) for shift in (10, 5, 0))
                    if not re.fullmatch(r'[a-z]{3}', code):
                        code = ''
            minf = dict(boxes(mdia.get(b'minf', b'')))
            stbl = dict(boxes(minf.get(b'stbl', b'')))
            stsd = stbl.get(b'stsd', b'')
            channels = 0
            for _, entry in boxes(stsd[8:]):
                if len(entry) >= 18:
                    channels = struct.unpack_from('>H', entry, 16)[0]
                    break
            audio.append({'language': language(code), 'channels': channels})
    return {'heights': sorted(heights), 'audio': audio}


def inspect_stream(stream, opener, deadline):
    url, _, options = stream.partition('|')
    headers = {k: v for k, v in parse_qsl(options) if k.lower() not in ('ext', 'verifypeer', 'range')}

    def read_range(offset, count):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Tiempo de sondeo agotado')
        request = Request(url, headers=dict(headers, Range='bytes={}-{}'.format(offset, offset + count - 1)))
        with opener.open(request, timeout=min(4, remaining)) as response:
            if offset:
                content_range = response.headers.get('Content-Range', '')
                if response.status != 206 or not content_range.startswith('bytes {}-'.format(offset)):
                    raise ValueError('El servidor no permite leer metadatos por rangos')
            return response.read(count)

    initial = read_range(0, 65536)
    windows = [(0, initial)]

    def read_at(offset, count):
        for start, data in windows:
            if start <= offset and offset + count <= start + len(data):
                return data[offset-start:offset-start+count]
        if len(windows) >= 12:
            raise ValueError('Limite de metadatos alcanzado')
        data = read_range(offset, max(65536, count))
        windows.append((offset, data))
        return data[:count]

    def atoms(start, end):
        for _ in range(64):
            if start + 8 > end:
                break
            raw = read_at(start, 16)
            if len(raw) < 8:
                break
            size, kind = struct.unpack_from('>I4s', raw)
            header = 8
            if size == 1:
                if len(raw) < 16:
                    break
                size, header = struct.unpack_from('>Q', raw, 8)[0], 16
            if size < header or start + size > end:
                break
            yield kind, start + header, start + size
            start += size

    def sparse_moov(start, end):
        # Las tablas de muestras pueden ocupar megabytes: saltarlas y leer
        # solamente dimensiones, lenguaje y la descripcion del primer codec.
        tracks = bytearray()
        make_box = lambda kind, data: struct.pack('>I4s', len(data) + 8, kind) + data
        for kind, track_start, track_end in atoms(start, end):
            if kind != b'trak':
                continue
            track = bytearray()
            for child, a, b in atoms(track_start, track_end):
                if child == b'tkhd':
                    track.extend(make_box(child, read_at(a, min(b-a, 104))))
                elif child == b'mdia':
                    mdia = bytearray()
                    for field, c, d in atoms(a, b):
                        if field in (b'mdhd', b'hdlr'):
                            mdia.extend(make_box(field, read_at(c, min(d-c, 40))))
                        elif field == b'minf':
                            for node, e, f in atoms(c, d):
                                if node != b'stbl':
                                    continue
                                for sample, g, h in atoms(e, f):
                                    if sample == b'stsd' and h-g >= 34:
                                        first = read_at(g, 34)
                                        description = first[:8] + make_box(first[12:16], first[16:34])
                                        mdia.extend(make_box(b'minf', make_box(b'stbl', make_box(b'stsd', description))))
                                        break
                    track.extend(make_box(b'mdia', bytes(mdia)))
            tracks.extend(make_box(b'trak', bytes(track)))
        return parse_moov(bytes(tracks))
    if initial.lstrip(b'\xef\xbb\xbf \r\n').startswith(b'#EXTM3U'):
        # Una lista truncada no permite afirmar cuales son todas las pistas.
        text = initial.decode('utf-8-sig', 'replace')
        if len(initial) == 65536:
            raise ValueError('El manifiesto está truncado; no se pudo verificar el vídeo')
        metadata = parse_hls(text)
        def fetch(resource, count=65536):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Tiempo de sondeo agotado')
            req = Request(resource, headers=dict(headers, Range='bytes=0-1023'))
            with opener.open(req, timeout=min(4, remaining)) as response:
                return response.read(count), response.geturl()

        variants = []
        lines = text.splitlines()
        for index, line in enumerate(lines[:-1]):
            if line.startswith('#EXT-X-STREAM-INF:'):
                match = re.search(r'RESOLUTION=\d+x(\d+)', line)
                variants.append((int(match.group(1)) if match else 0, urljoin(url, lines[index + 1].strip())))
        candidates = sorted(variants, reverse=True)[:3] if variants else [(0, url)]
        for height, candidate in candidates:
            try:
                playlist, playlist_url = fetch(candidate) if variants else (initial, url)
                playlist_text = playlist.decode('utf-8-sig', 'replace')
                if not playlist_text.lstrip().startswith('#EXTM3U'):
                    continue
                maps = re.findall(r'#EXT-X-MAP:[^\n]*URI="([^"]+)"', playlist_text)
                segment = next((line.strip() for line in playlist_text.splitlines()
                                if line.strip() and not line.startswith('#')), '')
                if not segment:
                    continue
                resources = maps + [segment]
                for resource in resources:
                    sample, _ = fetch(urljoin(playlist_url, resource), 32)
                    if not sample or sample.lstrip().lower().startswith((b'<html', b'<!doctype')):
                        raise ValueError('El segmento no contiene video')
                if variants and height:
                    metadata['heights'] = [height]
                return metadata
            except Exception:
                continue
        raise ValueError('El manifiesto no tiene segmentos accesibles')
    if len(initial) < 8 or initial[4:8] not in (b'ftyp', b'moov', b'free', b'wide'):
        raise ValueError('No se recibió un archivo de video')
    offset = 0
    # Saltar mdat por su longitud; nunca descargar el cuerpo del video.
    for _ in range(16):
        header = initial[offset:offset+16] if offset + 16 <= len(initial) else read_range(offset, 16)
        if len(header) < 8:
            break
        size, kind = struct.unpack_from('>I4s', header)
        header_size = 8
        if size == 1:
            if len(header) < 16:
                break
            size, header_size = struct.unpack_from('>Q', header, 8)[0], 16
        if size < header_size:
            break
        if kind == b'moov':
            if size > 2 * 1024 * 1024:
                return sparse_moov(offset + header_size, offset + size)
            if offset + size <= len(initial):
                payload = initial[offset + header_size:offset + size]
            else:
                payload = read_range(offset + header_size, size - header_size)
            return parse_moov(payload)
        offset += size
    return {}


def quality_label(metadata):
    if metadata.get('label', '').startswith('Multirresolucion:'):
        return metadata['label']
    heights = metadata.get('heights', [])
    if not heights:
        return metadata.get('label', '')
    return ('Multirresolucion: ' if len(heights) > 1 else '') + ' / '.join('{}p'.format(h) for h in heights)


def audio_label(metadata, server):
    tracks = metadata.get('audio', [])
    if tracks:
        values = []
        for track in tracks:
            text = track['language']
            channels = track.get('channels', 0)
            if channels == 1:
                text += ' (mono)'
            elif channels == 2:
                text += ' (estéreo)'
            elif channels:
                text += ' ({} canales)'.format(channels)
            if text not in values:
                values.append(text)
        return ('Audio multiple: ' if len(tracks) > 1 else 'Audio: ') + ' / '.join(values)
    if server.get('language') or server.get('idioma'):
        return 'Audio: {} (fuente)'.format(server.get('language') or server['idioma'])
    name = server.get('nombre', '').lower()
    for token, label in (('lat', 'LAT'), ('latino', 'LAT'), ('esp', 'ESP'), ('eng', 'ENG')):
        if re.search(r'\b' + token + r'\b', name):
            return 'Audio: {} (fuente)'.format(label)
    if re.search(r'\bsub\b', name):
        return 'Subtitulado (fuente); audio no indicado'
    return 'Audio no indicado'


class Scanner:
    """Tres workers reutilizables; resultados tardios no modifican la UI ni disco."""
    def __init__(self, resolver, opener_factory, quality_lookup, budget_context):
        self.resolver, self.opener_factory = resolver, opener_factory
        self.quality_lookup, self.budget_context = quality_lookup, budget_context
        self.jobs = queue.Queue(maxsize=64)
        self.lock = threading.Lock()
        self.closed = threading.Event()
        self.cancellations = set()
        self.cache, self.streams, self.inflight = {}, {}, set()
        for _ in range(3):
            threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        while not self.closed.is_set():
            try:
                url, key, deadline, cancel = self.jobs.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                if time.monotonic() >= deadline or cancel.is_set():
                    continue
                with self.budget_context(deadline, cancel):
                    stream = self.resolver(url)
                    if cancel.is_set() or self.closed.is_set():
                        continue
                    if not stream:
                        with self.lock:
                            self.cache[key] = {'scanned': True, 'updated': time.time(),
                                               'error': 'No disponible: el servidor no entregó vídeo'}
                        continue
                    try:
                        # Respetar la opción TLS explícita que recibirá Kodi.
                        # Algunos CDN de OK.ru sirven MP4 con un certificado
                        # incompleto, aunque el vídeo se reproduce en Kodi.
                        insecure = bool(re.search(r'(?:^|[|&])verifypeer=false(?:&|$)', stream, re.I))
                        opener = self.opener_factory(verify_tls=False) if insecure else self.opener_factory()
                        details = inspect_stream(stream, opener, deadline)
                        result = {'updated': time.time(), 'scanned': True, 'playable': True}
                        result.update(details)
                        if not result.get('heights'):
                            result['label'] = self.quality_lookup(stream.split('|')[0])
                    except Exception as exc:
                        result = {'updated': time.time(), 'scanned': True,
                                  'error': 'No disponible: ' + str(exc)}
                    with self.lock:
                        if cancel.is_set() or self.closed.is_set():
                            continue
                        self.cache[key] = result
                        if result.get('playable'):
                            self.streams[key] = (time.monotonic(), stream)
            except Exception as exc:
                # Una caida durante el sondeo no convierte el enlace en invalido.
                if not cancel.is_set():
                    with self.lock:
                        self.cache[key] = {'scanned': True, 'updated': time.time(),
                                           'error': 'No disponible: ' + str(exc)[:160]}
            finally:
                with self.lock:
                    self.inflight.discard(key)
                self.jobs.task_done()

    def scan(self, servers, stored=None, seconds=15, progress=None):
        keys = [cache_key(s['url']) for s in servers]
        deadline = time.monotonic() + seconds
        cancel = threading.Event()
        with self.lock:
            if self.closed.is_set():
                return {}
            self.cancellations.add(cancel)
            self.streams = {k: v for k, v in self.streams.items() if time.monotonic() - v[0] < 90}
            if len(self.cache) > 256:
                keep = sorted(self.cache, key=lambda k: self.cache[k].get('updated', 0), reverse=True)[:256]
                self.cache = {k: self.cache[k] for k in keep}
            for server, key in zip(servers, keys):
                if key not in self.inflight:
                    try:
                        self.cache.pop(key, None)
                        self.streams.pop(key, None)
                        self.jobs.put_nowait((server['url'], key, deadline, cancel))
                        self.inflight.add(key)
                    except queue.Full:
                        break
        try:
            while time.monotonic() < deadline and not self.closed.is_set():
                with self.lock:
                    count = sum(key not in self.inflight for key in keys)
                if progress and progress(count, len(keys)) is False:
                    break
                if count == len(keys):
                    break
                self.closed.wait(min(0.1, max(0, deadline - time.monotonic())))
        finally:
            cancel.set()
            with self.lock:
                self.cancellations.discard(cancel)
        with self.lock:
            return {key: dict(self.cache[key]) for key in keys if key in self.cache}

    def resolved(self, url):
        with self.lock:
            stamp, stream = self.streams.get(cache_key(url), (0, None))
        return stream if time.monotonic() - stamp < 90 else None

    def close(self):
        self.closed.set()
        with self.lock:
            for cancel in self.cancellations:
                cancel.set()
