# -*- coding: utf-8 -*-
"""
tv_en_vivo.py - Módulo de TV en Vivo para Vaquexflix (Kodi 20/21)
Gestiona subcategorías, proveedores de listas M3U (Pluto TV, TDT España, IPTV-Org),
fuentes deportivas dinámicas (agenda de eventos, ESPN, Fox, DSports), webcams mundiales 24/7,
guía electrónica de programación (EPG en tiempo real) y resolución de señales en vivo.
"""

import os
import re
import json
import time
import base64
import urllib.request
import urllib.error
import urllib.parse
import threading

import tv_epg

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

# 1. Definición canónica de las subcategorías (Portadas horizontales 16:9 para vista en lista)
SUBCATEGORIAS = [
    {
        'key': 'deportes',
        'title': 'DEPORTES Y EVENTOS EN VIVO',
        'url': 'tv://deportes',
        'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&h=450&fit=crop&q=80',
        'plot': 'Transmisiones deportivas en directo: partidos de fútbol internacional, ligas del mundo, canales 24/7 (ESPN, Fox Sports, DSports, TyC) y eventos oficiales.'
    },
    {
        'key': 'cine',
        'title': 'CINE Y PELÍCULAS 24/7',
        'url': 'tv://cine',
        'cover': 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales temáticos de cine 24/7: Acción, Terror, Comedia, Drama, Suspenso y Cine Clásico sin interrupciones.'
    },
    {
        'key': 'series',
        'title': 'SERIES Y RETRO 24/7',
        'url': 'tv://series',
        'cover': 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=800&h=450&fit=crop&q=80',
        'plot': 'Maratones continuos de series icónicas, clásicos retro de televisión, novelas y comedias legendarias.'
    },
    {
        'key': 'infantil',
        'title': 'ANIMACIÓN E INFANTIL',
        'url': 'tv://infantil',
        'cover': 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales continuos de anime, clásicos de Nickelodeon, caricaturas infantiles y programación para toda la familia.'
    },
    {
        'key': 'noticias',
        'title': 'NOTICIAS Y ACTUALIDAD',
        'url': 'tv://noticias',
        'cover': 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&h=450&fit=crop&q=80',
        'plot': 'Información y noticias en directo 24 horas: Euronews en español, 24h TVE, Actualidad 360 y cobertura global.'
    },
    {
        'key': 'musica',
        'title': 'MÚSICA Y ENTRETENIMIENTO',
        'url': 'tv://musica',
        'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales musicales en vivo, videoclips mundiales, señales MTV, documentales, realities y entretenimiento continuo.'
    },
    {
        'key': 'espana',
        'title': 'CANALES DE ESPAÑA (TDT)',
        'url': 'tv://espana',
        'cover': 'https://images.unsplash.com/photo-1543783207-ec64e4d95325?w=800&h=450&fit=crop&q=80',
        'plot': 'Emisiones nacionales y autonómicas de la TDT de España en vivo y alta definición con guía EPG en tiempo real.'
    },
    {
        'key': 'latam',
        'title': 'CANALES DE LATINOAMÉRICA',
        'url': 'tv://latam',
        'cover': 'https://images.unsplash.com/photo-1589556264800-08ae9e129a8c?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales de televisión abierta y regional de México, Argentina, Colombia, Chile, Perú y toda Latinoamérica en vivo.'
    },
    {
        'key': 'webcams',
        'title': 'WEBCAMS DEL MUNDO (EN VIVO)',
        'url': 'tv://webcams',
        'cover': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop&q=80',
        'plot': 'Cámaras públicas 24/7 en directo: vistas desde la Estación Espacial Internacional (ISS), playas paradisíacas, ciudades icónicas, volcanes y reservas naturales.'
    }
]

NOVA_COUNTRIES = (
    ('PE', 'PERÚ'), ('MX', 'MÉXICO'), ('AR', 'ARGENTINA'),
    ('CO', 'COLOMBIA'), ('CL', 'CHILE'), ('EC', 'ECUADOR'),
    ('VE', 'VENEZUELA'), ('BO', 'BOLIVIA'), ('BR', 'BRASIL'),
    ('ES', 'ESPAÑA'), ('US', 'ESTADOS UNIDOS'), ('INT', 'INTERNACIONALES'),
)
NOVA_COUNTRY_CATEGORIES = tuple({
    'key': 'nova_' + code.lower(),
    'title': 'CANALES ' + ('INTERNACIONALES' if code == 'INT' else 'DE ' + name),
    'url': 'tv://nova_' + code.lower(),
    'cover': os.path.join(os.path.dirname(os.path.abspath(__file__)), 'img_channel.jpg'),
    'plot': 'Canales en vivo de {}. La señal se comprueba al abrir cada canal.'.format(name.title()),
} for code, name in NOVA_COUNTRIES)
NOVA_GENRES = (
    ('noticias', 'NOTICIAS'), ('deportes', 'DEPORTES'),
    ('peliculas', 'PELÍCULAS'), ('musica', 'MÚSICA'),
    ('infantil', 'INFANTIL'), ('documentales', 'DOCUMENTALES'),
    ('entretenimiento', 'ENTRETENIMIENTO'), ('educacion', 'EDUCACIÓN'),
    ('religioso', 'RELIGIOSOS'),
)
NOVA_GENRE_CATEGORIES = tuple({
    'key': 'nova_genre_' + genre.lower().replace(' ', '_'),
    'title': 'CANALES DE ' + label,
    'url': 'tv://nova_genre_' + genre.lower().replace(' ', '_'),
    'cover': os.path.join(os.path.dirname(os.path.abspath(__file__)), 'img_channel.jpg'),
    'plot': 'Canales en vivo de {}.'.format(label.lower()),
} for genre, label in NOVA_GENRES)
NOVA_ALL_CATEGORY = {
    'key': 'nova_page_0', 'title': 'EXPLORAR TODOS LOS CANALES',
    'url': 'tv://nova_page_0',
    'cover': os.path.join(os.path.dirname(os.path.abspath(__file__)), 'img_channel.jpg'),
    'plot': 'Catálogo completo por páginas, incluidos otros países y categorías.',
}

# Canales destacados inmediatos (Garantía instantánea de arranque sin latencia de red)
CANALES_BASE = {
    'deportes': [
        {
            'title': 'ESPN (Deportes en Vivo)',
            'url': 'tv_sport://espn',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Canal principal de ESPN: fútbol internacional, Champions League, ligas europeas, torneos de tenis y SportsCenter.'
        },
        {
            'title': 'ESPN 2',
            'url': 'tv_sport://espn2',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Transmisiones deportivas de ESPN 2: fútbol de primera división, tenis Grand Slam, baloncesto y rugby.'
        },
        {
            'title': 'ESPN 3',
            'url': 'tv_sport://espn3',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Señal complementaria de ESPN: fútbol sudamericano, torneos de tenis ATP, ciclismo mundial y automovilismo.'
        },
        {
            'title': 'ESPN Premium',
            'url': 'tv_sport://espnpremium',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Canal exclusivo de fútbol profesional: partidos en vivo, coberturas previas y análisis detallado de la fecha.'
        },
        {
            'title': 'Fox Sports 1',
            'url': 'tv_sport://foxsports',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Copa Libertadores, Copa Sudamericana, fútbol internacional, artes marciales mixtas y debates deportivos.'
        },
        {
            'title': 'Fox Sports 2',
            'url': 'tv_sport://foxsports2',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Copa Libertadores en simultáneo, fútbol de México y Sudamérica, lucha libre WWE y deportes de motor.'
        },
        {
            'title': 'DSports (DirecTV)',
            'url': 'tv_sport://dsports',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Canal deportivo de DirecTV con LaLiga española, Copa del Rey, Conmebol y los mejores programas de debate.'
        },
        {
            'title': 'DSports 2',
            'url': 'tv_sport://dsports2',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Segunda señal de DSports con partidos en directo de ligas europeas, baloncesto y transmisiones simultáneas.'
        },
        {
            'title': 'DSports+',
            'url': 'tv_sport://dsportsplus',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Eventos premium de DSports: ciclismo World Tour, pádel, automovilismo y partidos definitorios.'
        },
        {
            'title': 'TyC Sports',
            'url': 'tv_sport://tycsports',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'La señal deportiva líder de Argentina: fútbol de primera, Copa Argentina, Selección Argentina y básquetbol.'
        },
        {
            'title': 'Liga 1 Max',
            'url': 'tv_sport://liga1max',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Canal oficial del fútbol profesional peruano: todos los partidos de la Liga 1 Te Apuesto en directo.'
        },
        {
            'title': 'Teledeporte (TVE)',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/tdp/tdp_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/teledeporteRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal temático deportivo de RTVE en vivo: fútbol, atletismo, ciclismo, tenis y competiciones oficiales.'
        },
        {
            'title': 'FIFA+ TV',
            'url': 'https://jmp2.uk/plu-626a575e9bb2a70007dbfc62.m3u8',
            'cover': 'https://images.pluto.tv/channels/626a575e9bb2a70007dbfc62/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Señal oficial de FIFA con partidos históricos, resúmenes de Mundiales y torneos internacionales.'
        },
        {
            'title': 'Pluto TV Deportes',
            'url': 'https://jmp2.uk/plu-5f33ee64c399b500072b2201.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f33ee64c399b500072b2201/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Transmisión ininterrumpida de eventos deportivos, fútbol playa, combates y deportes de acción.'
        },
        {
            'title': 'Pluto TV Motor',
            'url': 'https://jmp2.uk/plu-61e938361b7f00000799464e.m3u8',
            'cover': 'https://images.pluto.tv/channels/61e938361b7f00000799464e/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Automovilismo, carreras de resistencia, motociclismo, rallies y el mundo de la velocidad 24/7.'
        },
        {
            'title': 'Dominance FC TV (MMA & Combate)',
            'url': 'https://jmp2.uk/plu-6490656a81e33c00084f88e7.m3u8',
            'cover': 'https://images.pluto.tv/channels/6490656a81e33c00084f88e7/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Artes marciales mixtas, veladas de combate, Muay Thai y boxeo profesional sin censura.'
        },
        {
            'title': 'World Poker Tour',
            'url': 'https://jmp2.uk/plu-5f8021d7b3e02000076a084c.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f8021d7b3e02000076a084c/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Los mejores torneos de póker del planeta con las mesas finales y leyendas de Las Vegas.'
        }
    ],
    'cine': [
        {
            'title': 'Pluto TV Cine Acción',
            'url': 'https://jmp2.uk/plu-5f33ee4ab339670007945d94.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f33ee4ab339670007945d94/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Películas de acción, artes marciales, explosiones y thrillers de adrenalina las 24 horas.'
        },
        {
            'title': 'Pluto TV Cine Terror',
            'url': 'https://jmp2.uk/plu-602e3b2e596bb000076d333f.m3u8',
            'cover': 'https://images.pluto.tv/channels/602e3b2e596bb000076d333f/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Cine de terror psicológico, gore, casas encantadas y criaturas de la noche sin pausas.'
        },
        {
            'title': 'Pluto TV Cine Clásico',
            'url': 'https://jmp2.uk/plu-5f33ee58b339670007945d97.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f33ee58b339670007945d97/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Obras maestras de la época dorada del cine, cine negro, westerns y directores consagrados.'
        },
        {
            'title': 'Pluto TV Cine Comedia',
            'url': 'https://jmp2.uk/plu-5f33ee53b339670007945d96.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f33ee53b339670007945d96/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Las comedias más divertidas, humor inteligente, parodias y situaciones disparatadas.'
        },
        {
            'title': 'Paramount Network Pluto TV',
            'url': 'https://jmp2.uk/plu-6490656a81e33c00084f88e7.m3u8',
            'cover': 'https://images.pluto.tv/channels/6490656a81e33c00084f88e7/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Grandes superproducciones cinematográficas y películas premiadas del catálogo Paramount.'
        }
    ],
    'series': [
        {
            'title': 'Doctor Who (Canal 24/7)',
            'url': 'https://jmp2.uk/plu-60bb4a64f43477000779796d.m3u8',
            'cover': 'https://images.pluto.tv/channels/60bb4a64f43477000779796d/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Las aventuras a través del espacio y el tiempo de El Doctor y su TARDIS sin interrupciones.'
        },
        {
            'title': 'BBC Drama & Series',
            'url': 'https://jmp2.uk/plu-61e938361b7f00000799464e.m3u8',
            'cover': 'https://images.pluto.tv/channels/61e938361b7f00000799464e/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Aclamadas producciones de la BBC británica, suspense policíaco y dramas de época.'
        },
        {
            'title': 'Sin Tetas No Hay Paraíso',
            'url': 'https://jmp2.uk/plu-63b7e7ab4376c900085ba46a.m3u8',
            'cover': 'https://images.pluto.tv/channels/63b7e7ab4376c900085ba46a/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'La exitosa serie completa sobre la ambición, el narcotráfico y el amor con El Duque.'
        },
        {
            'title': 'Curro Jiménez',
            'url': 'https://jmp2.uk/plu-5f8021d7b3e02000076a084c.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f8021d7b3e02000076a084c/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'El legendario bandolero andaluz de la Sierra de Ronda en sus aventuras más célebres.'
        },
        {
            'title': 'Hechizada (Bewitched)',
            'url': 'https://jmp2.uk/plu-5f60e90c2941fa0007612f07.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f60e90c2941fa0007612f07/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Samantha y sus simpáticos hechizos que vuelven loco al bueno de Darrin en este clásico eterno.'
        }
    ],
    'infantil': [
        {
            'title': 'Detective Conan 24/7',
            'url': 'https://jmp2.uk/plu-5fa9329188bfca00077c5c00.m3u8',
            'cover': 'https://images.pluto.tv/channels/5fa9329188bfca00077c5c00/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Shinichi Kudo resuelve los crímenes más intrincados en el cuerpo del pequeño detective Conan.'
        },
        {
            'title': 'Anime Clásico',
            'url': 'https://jmp2.uk/plu-5fa9329188bfca00077c5c00.m3u8',
            'cover': 'https://images.pluto.tv/channels/5fa9329188bfca00077c5c00/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Grandes sagas de la animación japonesa: combates Shonen, fantasía y aventuras épicas.'
        },
        {
            'title': 'Avatar: La Leyenda de Aang',
            'url': 'https://jmp2.uk/plu-61e938361b7f00000799464e.m3u8',
            'cover': 'https://images.pluto.tv/channels/61e938361b7f00000799464e/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Aang y sus amigos dominan los cuatro elementos para restablecer la paz en las cuatro naciones.'
        },
        {
            'title': 'Bob Esponja 24/7',
            'url': 'https://jmp2.uk/plu-5f8021d7b3e02000076a084c.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f8021d7b3e02000076a084c/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Fondo de Bikini en su máxima diversión con Patricio, Calamardo y Bob en el Crustáceo Cascarudo.'
        },
        {
            'title': 'South Park en Español',
            'url': 'https://jmp2.uk/plu-5fa9329188bfca00077c5c00.m3u8',
            'cover': 'https://images.pluto.tv/channels/5fa9329188bfca00077c5c00/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Sátira, irreverencia y humor con Stan, Kyle, Cartman y Kenny en audio latino.'
        },
        {
            'title': 'Clan TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/clan/clan_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/clanRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal infantil público de RTVE con las mejores series de animación educativa y entretenimiento.'
        }
    ],
    'noticias': [
        {
            'title': 'Canal 24 Horas (RTVE)',
            'url': 'https://ztnr.rtve.es/ztnr/1694255.m3u8',
            'cover': 'https://graph.facebook.com/24hRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal de información continua de Televisión Española: directo, debates y noticias al minuto.'
        },
        {
            'title': 'Euronews en Español',
            'url': 'https://euronews-live-spa-es.fast.rakuten.tv/v1/master/3722cddfe5cf4da2cedce830cf7061719b6f8496/euronews-live-spa-es/index.m3u8',
            'cover': 'https://graph.facebook.com/es.euronews/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Toda la actualidad europea y mundial analizada con rigor periodístico independiente.'
        },
        {
            'title': 'Actualidad 360',
            'url': 'https://jmp2.uk/plu-67517fae5534bb0008187997.m3u8',
            'cover': 'https://images.pluto.tv/channels/67517fae5534bb0008187997/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Noticias globales, reportajes de investigación y coberturas especiales de última hora.'
        },
        {
            'title': 'CBS News 24/7',
            'url': 'https://jmp2.uk/plu-60bb4a64f43477000779796d.m3u8',
            'cover': 'https://images.pluto.tv/channels/60bb4a64f43477000779796d/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Transmisión continua de noticias mundiales con corresponsales de la cadena internacional CBS.'
        }
    ],
    'musica': [
        {
            'title': 'MTV Clásicos',
            'url': 'https://jmp2.uk/plu-5f60e90c2941fa0007612f07.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f60e90c2941fa0007612f07/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Los himnos musicales de los 80s, 90s y 2000s que marcaron a toda una generación de MTV.'
        },
        {
            'title': 'MTV En Vivo Hits',
            'url': 'https://jmp2.uk/plu-5fa9329188bfca00077c5c00.m3u8',
            'cover': 'https://images.pluto.tv/channels/5fa9329188bfca00077c5c00/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Éxitos pop mundiales, ritmos urbanos, reguetón y las canciones más escuchadas de las listas.'
        },
        {
            'title': 'Qello Concerts',
            'url': 'https://jmp2.uk/plu-61e938361b7f00000799464e.m3u8',
            'cover': 'https://images.pluto.tv/channels/61e938361b7f00000799464e/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Conciertos históricos en directo, giras mundiales y actuaciones en vivo de bandas legendarias.'
        },
        {
            'title': 'Loupe Art & Relax',
            'url': 'https://jmp2.uk/plu-5f8021d7b3e02000076a084c.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f8021d7b3e02000076a084c/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Paisajes visuales relajantes, galerías de arte contemporáneo y música ambiental envolvente.'
        }
    ],
    'espana': [
        {
            'title': 'La 1 de TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/la1/la1_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/la1detve/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Primer canal generalista de RTVE con informativos Telediario, series, películas y entretenimiento.'
        },
        {
            'title': 'La 2 de TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/la2/la2_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/la2detve/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal cultural de RTVE: grandes documentales de naturaleza, cine clásico, arte y Saber y Ganar.'
        },
        {
            'title': 'Canal 24 Horas (RTVE)',
            'url': 'https://ztnr.rtve.es/ztnr/1694255.m3u8',
            'cover': 'https://graph.facebook.com/24hRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Información y noticias ininterrumpidas de España y del mundo 24/7.'
        },
        {
            'title': 'Teledeporte',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/tdp/tdp_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/teledeporteRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'El canal de los grandes eventos del deporte español e internacional en vivo.'
        },
        {
            'title': 'Clan TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/clan/clan_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/clanRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Dibujos animados, contenidos didácticos y las series infantiles más populares.'
        },
        {
            'title': 'TRECE TV',
            'url': 'https://play.cdn.enetres.net/091DB7AFBD77442B9BA2FA6AE666063B021/028/playlist.m3u8',
            'cover': 'https://graph.facebook.com/TRECEtves/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal nacional de televisión con cine clásico, westerns, actualidad informativa y debate.'
        },
        {
            'title': 'Telemadrid',
            'url': 'https://telemadrid-live.hls.adaptive.level3.net/hls/live/2034336/telemadrid/master.m3u8',
            'cover': 'https://graph.facebook.com/telemadrid/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Televisión autonómica pública de la Comunidad de Madrid: Madrid Directo, actualidad y cultura.'
        },
        {
            'title': 'Canal Sur Andalucía',
            'url': 'https://canalsur-live.hls.adaptive.level3.net/hls/live/2034340/canalsur/master.m3u8',
            'cover': 'https://graph.facebook.com/canalsur/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal autonómico de Andalucía: tradiciones, noticias, fiestas populares y entretenimiento.'
        }
    ],
    'latam': [
        {
            'title': 'ADN 40 (México)',
            'url': 'https://jmp2.uk/plu-646ccd3681844c000974d6f4.m3u8',
            'cover': 'https://images.pluto.tv/channels/646ccd3681844c000974d6f4/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Canal informativo de México con análisis político, debate, economía y noticias al momento.'
        },
        {
            'title': 'Telefe Noticias (Argentina)',
            'url': 'https://jmp2.uk/plu-5fa9329188bfca00077c5c00.m3u8',
            'cover': 'https://images.pluto.tv/channels/5fa9329188bfca00077c5c00/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Transmisión en vivo de las principales ediciones de noticias y actualidad de Telefe Argentina.'
        },
        {
            'title': 'Caracol Internacional (Colombia)',
            'url': 'https://jmp2.uk/plu-5f60e90c2941fa0007612f07.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f60e90c2941fa0007612f07/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Señal internacional de Caracol Televisión con las novelas y programas más exitosos de Colombia.'
        },
        {
            'title': 'TV Pública (Argentina)',
            'url': 'https://jmp2.uk/plu-61e938361b7f00000799464e.m3u8',
            'cover': 'https://images.pluto.tv/channels/61e938361b7f00000799464e/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Canal estatal argentino con programación cultural, festivales federales y deportes nacionales.'
        },
        {
            'title': 'Chilevisión Noticias',
            'url': 'https://jmp2.uk/plu-5f8021d7b3e02000076a084c.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f8021d7b3e02000076a084c/colorLogoPNG.png',
            'rating': '1080p',
            'plot': 'Información al instante de Chile y Sudamérica con reportajes y debates en vivo.'
        }
    ],
    'webcams': [
        {
            'title': 'Estación Espacial Internacional ISS (Tierra en Directo HD)',
            'url': 'https://www.youtube.com/watch?v=ROboUHfPUrU',
            'cover': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Cámaras exteriores de alta definición a bordo de la Estación Espacial Internacional transmitiendo la Tierra en directo.'
        },
        {
            'title': 'Nueva York — Times Square en Directo',
            'url': 'https://www.youtube.com/watch?v=KHy_n-EMWY8',
            'cover': 'https://images.unsplash.com/photo-1534430480872-3498386e7856?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Cámara en vivo transmitiendo el movimiento continuo y las luces de Times Square en Nueva York.'
        },
        {
            'title': 'Tokio — Cruce de Shibuya en Vivo 24/7',
            'url': 'https://www.youtube.com/watch?v=5B4LmH4JbnY',
            'cover': 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'El icónico y transitado cruce peatonal de Shibuya en Tokio, Japón en transmisión ininterrumpida.'
        },
        {
            'title': 'Venecia — Gran Canal y Puente de Rialto',
            'url': 'https://www.youtube.com/watch?v=r8N6IsoIkTk',
            'cover': 'https://images.unsplash.com/photo-1514890547357-a9ee288728e0?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Góndolas y vistas panorámicas del Gran Canal de Venecia frente al Puente de Rialto en tiempo real.'
        },
        {
            'title': 'Volcán Popocatépetl — México en Directo',
            'url': 'https://www.youtube.com/watch?v=xytHO8TgCBE',
            'cover': 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Transmisión 24 horas del Volcán Popocatépetl en México monitoreado en tiempo real desde la estación Tlamacas.'
        },
        {
            'title': 'Playas de Cataluña y Costa Brava (Multicámara)',
            'url': 'https://directes-tv-int.3catdirectes.cat/live-content/beauties-hls/master.m3u8',
            'cover': 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Cámaras fijas del litoral mediterráneo de Cataluña y la Costa Brava en alta definición.'
        },
        {
            'title': 'Costa de Almería y Mar Mediterráneo',
            'url': 'https://interalmeria.tv/directo/live.m3u8',
            'cover': 'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Panorámica de la bahía y el puerto de Almería sobre el mar Mediterráneo.'
        },
        {
            'title': 'Vistas de A Coruña y Faro de Fisterra',
            'url': 'https://crtvgdirectohls-lh.akamaihd.net/i/camaras_1@76437/master.m3u8',
            'cover': 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&h=450&fit=crop&q=80',
            'rating': '1080p',
            'plot': 'Costa atlántica de Galicia y el Fin del Mundo desde Fisterra y A Coruña.'
        }
    ]
}

_cache_lock = threading.Lock()
_cache_memoria = {}
_cache_file_path = None
_actualizando_bg = False

_agenda_lock = threading.Lock()
_agenda_cache = []
_agenda_timestamp = 0
_logo_status = {}
_logo_status_lock = threading.Lock()


def logo_cache_estado(url):
    """Última comprobación HTTP de un logo, sin bloquear la interfaz."""
    with _logo_status_lock:
        entry = _logo_status.get(url)
    if entry and time.time() - entry[1] < (86400 if entry[0] else 600):
        return entry[0]
    return None


def logo_disponible(url):
    """Comprueba que el enlace entregue datos de imagen reales."""
    cached = logo_cache_estado(url)
    if cached is not None:
        return cached
    image_url, _, options = (url or '').partition('|')
    parsed = urllib.parse.urlsplit(image_url)
    if parsed.scheme not in ('http', 'https'):
        return bool(url and os.path.isfile(url))
    try:
        headers = {'User-Agent': UA, 'Accept': 'image/*', 'Range': 'bytes=0-127'}
        for key, value in urllib.parse.parse_qsl(options):
            if key.lower() in ('user-agent', 'referer', 'origin'):
                headers[key] = value
        request = urllib.request.Request(image_url, headers=headers)
        with urllib.request.urlopen(request, timeout=5) as response:
            mime = response.headers.get('Content-Type', '').split(';', 1)[0].lower()
            prefix = response.read(128).lstrip()
        image_magic = (prefix.startswith(b'\x89PNG\r\n\x1a\n') or
                       prefix.startswith(b'\xff\xd8\xff') or
                       prefix.startswith((b'GIF87a', b'GIF89a')) or
                       (prefix.startswith(b'RIFF') and prefix[8:12] == b'WEBP'))
        valid = bool(prefix and (image_magic or
                     (mime.startswith('image/') and not prefix.lower().startswith((b'<html', b'<!doctype')))))
    except Exception:
        valid = False
    with _logo_status_lock:
        _logo_status[url] = (valid, time.time())
    return valid


def set_cache_path(base_dir):
    global _cache_file_path
    if not os.path.exists(base_dir):
        try:
            os.makedirs(base_dir, exist_ok=True)
        except Exception:
            pass
    _cache_file_path = os.path.join(base_dir, 'tv_channels_cache.json')


def get_subcategories():
    """Devuelve la lista canónica de subcategorías temáticas de TV en Vivo."""
    import source_switches
    if source_switches.only_enabled('nova'):
        return [dict(NOVA_ALL_CATEGORY)] + [dict(category) for category in
                                            NOVA_COUNTRY_CATEGORIES + NOVA_GENRE_CATEGORIES]
    categories = list(SUBCATEGORIAS)
    if source_switches.enabled('nova'):
        categories.append(dict(NOVA_ALL_CATEGORY))
        categories.extend(dict(category) for category in NOVA_COUNTRY_CATEGORIES + NOVA_GENRE_CATEGORIES)
    return categories


def _clasificar_canal(ch, source_id=""):
    """Clasifica un canal M3U dentro de una de las subcategorías canónicas."""
    name = ch.get('title', '').lower()
    group = ch.get('group', '').lower()

    if any(k in group for k in ['deporte', 'sport', 'competencia', 'motor', 'auto']) or \
       any(k in name for k in ['sport', 'deporte', 'futbol', 'fútbol', 'teledeporte', 'gol play', 'motor', 'fifa']):
        return 'deportes'
    if any(k in group for k in ['cine', 'película', 'pelicula', 'movie']):
        return 'cine'
    if any(k in group for k in ['anime', 'infantil', 'kids', 'animation', 'animación', 'animacion', 'south park', 'cartoon']):
        return 'infantil'
    if any(k in group for k in ['noticia', 'news', 'actualidad', 'business', 'información']):
        return 'noticias'
    if any(k in group for k in ['serie', 'novela', 'retro', 'policiaca', 'crimen', 'misterio', 'paranormal', 'investigación']):
        return 'series'
    if any(k in group for k in ['música', 'musica', 'music', 'mtv', 'reality', 'lifestyle', 'estilo', 'cultura']):
        return 'musica'
    if source_id == 'tdt':
        return 'espana'
    return 'latam'


def _parsear_m3u(content, source_id=""):
    """Parsea el contenido de texto de una lista M3U y extrae metadatos limpios sin omitir canales sin logo."""
    channels = []
    lines = content.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('#EXTINF:'):
            logo_m = re.search(r'tvg-logo="([^"]*)"', line)
            logo = logo_m.group(1) if logo_m else ''

            group_m = re.search(r'group-title="([^"]*)"', line)
            group = group_m.group(1) if group_m else ''

            name_m = re.search(r',([^,]+)$', line)
            name = name_m.group(1).strip() if name_m else 'Canal'

            url = ""
            if i + 1 < len(lines):
                next_l = lines[i + 1].strip()
                if next_l.startswith('http'):
                    url = next_l

            if url and not any(r in name.lower() for r in ['radio', 'rne acces', 'ondacero', 'ser ']):
                res_m = re.search(r'\((\d+p)\)', name)
                res = res_m.group(1) if res_m else ('1080p' if 'pluto' in url or 'rtve' in url else 'DIRECTO')
                clean_name = re.sub(r'\s*\(\d+p\)', '', name)
                clean_name = re.sub(r'\s*\[Geo-blocked\]', '', clean_name)
                clean_name = re.sub(r'\s*\[Not 24/7\]', '', clean_name).strip()

                channels.append({
                    'title': clean_name,
                    'url': url,
                    'cover': logo,
                    'group': group,
                    'source': source_id,
                    'rating': res,
                    'plot': f"Transmisión en directo de {clean_name}. Señal de televisión en vivo."
                })
            i += 2
        else:
            i += 1
    return channels


def _descargar_texto(url, timeout=10, referer=None):
    """Descarga de red segura con headers y timeout explícito."""
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8', errors='ignore')


def _cargar_cache_disco():
    """Lee el catálogo de canales desde el archivo de caché si es reciente."""
    global _cache_memoria
    if not _cache_file_path or not os.path.exists(_cache_file_path):
        return None
    try:
        with open(_cache_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        ts = data.get('_updated', 0)
        if (time.time() - ts) < 86400 and 'canales' in data:
            _cache_memoria = data['canales']
            return _cache_memoria
    except Exception:
        pass
    return None


def _guardar_cache_disco(canales_dict):
    """Escribe de forma atómica el catálogo a disco en userdata."""
    if not _cache_file_path:
        return
    tmp = _cache_file_path + '.tmp'
    try:
        data = {
            '_updated': time.time(),
            'canales': canales_dict
        }
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, _cache_file_path)
    except Exception:
        pass


def _actualizar_canales_en_segundo_plano():
    """Descarga en hilo de fondo las listas oficiales y construye el índice agrupado."""
    global _actualizando_bg, _cache_memoria
    if _actualizando_bg:
        return
    _actualizando_bg = True

    try:
        sources = [
            ('pluto_es', 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plutotv_es.m3u'),
            ('pluto_mx', 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plutotv_mx.m3u'),
            ('tdt', 'https://www.tdtchannels.com/lists/tv.m3u')
        ]

        nuevos_canales = {sub['key']: list(CANALES_BASE.get(sub['key'], [])) for sub in SUBCATEGORIAS}
        titulos_vistos = {sub['key']: {c['title'].lower() for c in CANALES_BASE.get(sub['key'], [])} for sub in SUBCATEGORIAS}

        for src_id, src_url in sources:
            try:
                raw_text = _descargar_texto(src_url, timeout=10)
                parsed = _parsear_m3u(raw_text, src_id)
                for ch in parsed:
                    categoria = _clasificar_canal(ch, src_id)
                    if categoria not in nuevos_canales:
                        categoria = 'latam'

                    norm_title = ch['title'].lower()
                    if norm_title not in titulos_vistos[categoria]:
                        titulos_vistos[categoria].add(norm_title)
                        nuevos_canales[categoria].append(ch)
            except Exception:
                continue

        with _cache_lock:
            _cache_memoria = nuevos_canales
            _guardar_cache_disco(nuevos_canales)

    except Exception:
        pass
    finally:
        _actualizando_bg = False


def init_background_cache(userdata_dir):
    """Inicializa las rutas de caché de canales y de guía EPG."""
    set_cache_path(userdata_dir)
    tv_epg.init_epg_cache(userdata_dir)
    cached = _cargar_cache_disco()
    if not cached:
        threading.Thread(target=_actualizar_canales_en_segundo_plano, daemon=True).start()


def obtener_agenda_deportes():
    """
    Consulta las APIs unificadas de deportes (api.wqxag.com / agenda18.com)
    y retorna la lista de partidos programados y en vivo del día.
    """
    global _agenda_cache, _agenda_timestamp
    now = time.time()
    with _agenda_lock:
        if _agenda_cache and (now - _agenda_timestamp) < 180:
            return list(_agenda_cache)

    urls = [
        'https://api.wqxag.com/diaries.json',
        'https://agenda18.com/agenda.json'
    ]
    data = None
    for u in urls:
        try:
            req = urllib.request.Request(u, headers={'User-Agent': UA, 'Referer': 'https://futbol-libre.cam/'})
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data:
                    break
        except Exception:
            continue

    if not data:
        with _agenda_lock:
            return list(_agenda_cache) if _agenda_cache else []

    eventos = data if isinstance(data, list) else data.get('data', [])
    items_agenda = []

    for ev in eventos:
        attrs = ev if 'diary_description' in ev else ev.get('attributes', {})
        desc = attrs.get('diary_description', '').replace('\r', '').replace('\n', ' ').strip()
        hora_str = attrs.get('diary_hour', '00:00:00')
        fecha_str = attrs.get('date_diary', '')
        embeds_data = attrs.get('embeds', {})
        embed_list = embeds_data if isinstance(embeds_data, list) else embeds_data.get('data', [])

        try:
            h_parts = hora_str.split(':')
            ev_hora = int(h_parts[0])
            ev_min = int(h_parts[1]) if len(h_parts) > 1 else 0
            hora_humana = f"{ev_hora:02d}:{ev_min:02d}"
        except Exception:
            hora_humana = hora_str[:5]

        pais_img = ""
        try:
            p_data = attrs.get('country', {}).get('data', {})
            img_rel = p_data.get('attributes', {}).get('image', {}).get('data', {}).get('attributes', {}).get('url', '')
            if img_rel:
                pais_img = "https://img.wqxag.com" + img_rel
        except Exception:
            pass

        if not embed_list:
            continue

        for emb in embed_list:
            e_attrs = emb if 'embed_name' in emb else emb.get('attributes', {})
            emb_name = e_attrs.get('embed_name', 'Señal 1').strip()
            emb_iframe = e_attrs.get('embed_iframe', '')
            if not emb_iframe:
                continue

            target_url = emb_iframe
            if '?r=' in emb_iframe:
                b64 = emb_iframe.split('?r=')[-1]
                try:
                    target_url = base64.b64decode(b64).decode('utf-8')
                except Exception:
                    pass

            item_title = f"[{hora_humana}] {desc} ({emb_name})"
            items_agenda.append({
                'title': item_title,
                'url': f"tv_sport://{target_url}",
                'cover': pais_img or 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
                'rating': 'VIVO',
                'plot': f"Partido: {desc}\nCanal / Señal: {emb_name}\nHora programada: {hora_humana}\nFecha: {fecha_str}\n(La transmisión se activa al iniciar el evento deportivo)."
            })

    with _agenda_lock:
        _agenda_cache = items_agenda
        _agenda_timestamp = now
        return list(_agenda_cache)


def resolver_canal_stream(stream_url, raise_on_failure=False):
    """
    Resuelve enlaces dinámicos de TV (como tv_sport:// o vídeos de YouTube) a su stream HLS (.m3u8)
    o URL reproducible con los headers HTTP necesarios para Kodi VideoPlayer.
    """
    if not stream_url:
        return None

    if stream_url.startswith('novatv://'):
        import nova_sources
        return nova_sources.channel_stream(stream_url, raise_on_failure=raise_on_failure)

    # Si es una emisión o vídeo de YouTube (ej. webcams mundiales)
    if 'youtube.com' in stream_url or 'youtu.be' in stream_url or stream_url.startswith('tube://'):
        try:
            import tube_engine
            return tube_engine.resolve(stream_url)
        except Exception:
            return None

    if not stream_url.startswith('tv_sport://'):
        return stream_url

    raw_url = stream_url.replace('tv_sport://', '').strip()

    # Si es un slug de canal deportivo simple
    if not raw_url.startswith('http'):
        raw_url = f"https://tvf90.com/5.php?stream={raw_url}"

    # Normalizar tvf90 a endpoint directo 5.php
    if 'tvf90.com' in raw_url:
        stream_m = re.search(r'stream=([^&]+)', raw_url)
        slug = stream_m.group(1) if stream_m else 'espn'
        raw_url = f"https://tvf90.com/5.php?stream={slug}"
        headers = {'User-Agent': UA, 'Referer': 'https://tvf90.com/'}
        try:
            req = urllib.request.Request(raw_url, headers=headers)
            with urllib.request.urlopen(req, timeout=6) as resp:
                html = resp.read().decode('utf-8', errors='ignore')
                m3u8s = re.findall(r'https?://[^\s"\'<>]+(?:\.m3u8|mono\.m3u8)[^\s"\'<>]*', html)
                if m3u8s:
                    kodi_headers = f"|User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote('https://tvf90.com/')}"
                    return m3u8s[0] + kodi_headers
        except Exception:
            pass

    # Si es la18hd o fallback de slug
    if 'la18hd' in raw_url or 'canal.php' in raw_url:
        stream_m = re.search(r'stream=([^&]+)', raw_url)
        slug = stream_m.group(1) if stream_m else ''
        if slug:
            fallback_tvf = f"https://tvf90.com/5.php?stream={slug}"
            try:
                req = urllib.request.Request(fallback_tvf, headers={'User-Agent': UA, 'Referer': 'https://tvf90.com/'})
                with urllib.request.urlopen(req, timeout=6) as resp:
                    html = resp.read().decode('utf-8', errors='ignore')
                    m3u8s = re.findall(r'https?://[^\s"\'<>]+(?:\.m3u8|mono\.m3u8)[^\s"\'<>]*', html)
                    if m3u8s:
                        kodi_headers = f"|User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote('https://tvf90.com/')}"
                        return m3u8s[0] + kodi_headers
            except Exception:
                pass

    return None


DEFAULT_CHANNEL_COVER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'img_channel.jpg')
if not os.path.exists(DEFAULT_CHANNEL_COVER):
    DEFAULT_CHANNEL_COVER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cara_channel.jpg')


def _enriquecer_con_epg(canales):
    """Inyecta en la sinopsis la programación actual y próxima si está disponible en el EPG, y fallback de carátula de canal."""
    for c in canales:
        if not c.get('cover'):
            c['cover'] = DEFAULT_CHANNEL_COVER
        try:
            epg = tv_epg.obtener_info_epg(c.get('title', ''))
            if epg:
                c['plot'] = f"{epg}\n\n{c.get('plot', '')}"
        except Exception:
            pass
    return canales


def get_channels(category_url_or_key):
    """
    Obtiene la lista de canales para una categoría dada:
    - 'tv://todo' o 'todo': Catálogo global agregado de todas las señales.
    - 'tv://buscar?q=...': Búsqueda por texto en nombres y sinopsis.
    - 'tv://deportes' o 'deportes': Canales base fijos + Agenda de partidos del día.
    - 'tv://webcams' o 'webcams': Cámaras públicas mundiales en vivo.
    - Subcategorías temáticas: Catálogo base instantáneo + canales parseados de fondo enriquecidos con EPG.
    """
    raw = category_url_or_key.replace('tv://', '').strip()
    key = raw.lower()
    import source_switches

    if key.startswith('nova_page_'):
        page = key[10:]
        if not source_switches.enabled('nova') or not page.isdecimal():
            return []
        import nova_sources
        return nova_sources.channels_page(int(page))

    if key.startswith('nova_country_') and '_page_' in key:
        country, _, page = key[13:].partition('_page_')
        if not source_switches.enabled('nova') or country.upper() not in dict(NOVA_COUNTRIES) or not page.isdecimal():
            return []
        import nova_sources
        return nova_sources.channels_page(int(page), country.upper())

    if key.startswith('nova_genre_'):
        genre = key[11:]
        genre_map = {name.lower().replace(' ', '_'): name for name, _ in NOVA_GENRES}
        if not source_switches.enabled('nova') or genre not in genre_map:
            return []
        import nova_sources
        return nova_sources.channels_by_category(genre_map[genre])

    if key.startswith('nova_') and key[5:].upper() in dict(NOVA_COUNTRIES):
        if not source_switches.enabled('nova'):
            return []
        import nova_sources
        return nova_sources.channels_page(0, key[5:].upper())

    if key.startswith('buscar?q='):
        query = urllib.parse.unquote_plus(raw.split('=', 1)[1]).lower()
        if source_switches.only_enabled('nova'):
            import nova_sources
            return nova_sources.search_channels(query)
        todos = get_channels('todo')
        found = [c for c in todos if query in c.get('title', '').lower() or
                 query in c.get('plot', '').lower()]
        if source_switches.enabled('nova'):
            import nova_sources
            seen = {c.get('url') for c in found}
            found.extend(c for c in nova_sources.search_channels(query) if c.get('url') not in seen)
        return found

    if key in ('todo', 'todos', 'all'):
        if source_switches.only_enabled('nova'):
            return get_channels('nova_pe')
        canales_totales = []
        vistos = set()
        for c in get_channels('deportes'):
            norm = c['title'].lower()
            if norm not in vistos:
                vistos.add(norm)
                canales_totales.append(c)
        for sub in SUBCATEGORIAS:
            if sub['key'] == 'deportes':
                continue
            for c in get_channels(sub['key']):
                norm = c['title'].lower()
                if norm not in vistos:
                    vistos.add(norm)
                    canales_totales.append(c)
        return canales_totales

    if key == 'deportes':
        base_sports = list(CANALES_BASE.get('deportes', []))
        partidos_hoy = obtener_agenda_deportes()
        return _enriquecer_con_epg(partidos_hoy + base_sports)

    if key == 'webcams':
        return list(CANALES_BASE.get('webcams', []))

    with _cache_lock:
        if _cache_memoria and key in _cache_memoria:
            return _enriquecer_con_epg(list(_cache_memoria[key]))

    disco = _cargar_cache_disco()
    if disco and key in disco:
        return _enriquecer_con_epg(list(disco[key]))

    if not _actualizando_bg:
        threading.Thread(target=_actualizar_canales_en_segundo_plano, daemon=True).start()

    return _enriquecer_con_epg(list(CANALES_BASE.get(key, [])))
