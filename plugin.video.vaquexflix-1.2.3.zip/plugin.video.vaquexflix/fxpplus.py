"""Adaptador de FXP+ para el addon Kodi instalado en este mismo perfil.

Reutiliza su cliente y su sesión; no copia credenciales al perfil de Vaquexflix.
El proveedor instalado puede renovar su propia sesión cuando caduque.
"""
import importlib.util
import json
import os
import re
import sys
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from urllib.parse import parse_qs, quote, unquote, urlencode, urljoin, urlsplit

SOURCE = 'fxpplus'
_lock = threading.RLock()
_provider_class = None
_adult_channel_ids = (0, frozenset())
_section_ids = (0, {}, {})
_catalog_cache = {}
_discovered = {}
_tmdb_cache = None
_tmdb_failed = {}
_adult = re.compile(r'(?i)(?:^|[\s/|·_-])(?:18\+|adultos?|xxx|porn(?:o|ografía)?)(?:$|[\s/|·_-])')

try:
    import Cryptodome
except ImportError:
    for _kodi_site in (
        r'C:\Program Files\Kodi\system\python\Lib\site-packages',
        r'C:\Program Files (x86)\Kodi\system\python\Lib\site-packages',
    ):
        if os.path.isdir(_kodi_site) and _kodi_site not in sys.path:
            sys.path.append(_kodi_site)
            break


def _paths():
    addons = ''
    profile = ''
    try:
        import xbmcvfs
        addons = xbmcvfs.translatePath('special://home/addons')
        profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.xupertvplus')
    except ImportError:
        pass
    if not addons or not profile:
        addons = os.path.dirname(os.path.dirname(__file__))
        profile = os.path.join(os.path.dirname(addons), 'userdata', 'addon_data', 'plugin.video.xupertvplus')
    return os.path.join(addons, 'plugin.video.xupertvplus'), profile


def _package(name, path):
    spec = importlib.util.spec_from_file_location(name, path,
        submodule_search_locations=[os.path.dirname(path)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)


def _provider():
    global _provider_class
    addon_path, profile = _paths()
    if not os.path.isfile(os.path.join(addon_path, 'resources', 'lib', 'providers', 'authorized_provider.py')):
        raise RuntimeError('Instala XUPER TV+ en este perfil de Kodi para usar FXP+')
    with _lock:
        if _provider_class is None:
            _package('_vaquex_fxp', os.path.join(addon_path, 'resources', '__init__.py'))
            _package('_vaquex_fxp.lib', os.path.join(addon_path, 'resources', 'lib', '__init__.py'))
            _package('_vaquex_fxp.lib.providers', os.path.join(addon_path, 'resources', 'lib', 'providers', '__init__.py'))
            from _vaquex_fxp.lib.providers.authorized_provider import AuthorizedProvider
            _provider_class = AuthorizedProvider
    return _provider_class(profile)


def _safe(value):
    return not _adult.search(str(value or ''))


def _visible(entry):
    return all(_safe(entry.get(key)) for key in ('title', 'category', 'group')) and all(
        _safe(tag) for tag in entry.get('genres', []))


def _card(entry, section):
    if not entry.get('id') or not _visible(entry):
        return None
    is_series = section in ('series', 'animes', 'infantil') and entry.get('kind') == 'series'
    # Anime contiene series y películas; la sección no convierte una película en serie.
    raw_title = entry.get('title', '')
    return {'title': _base_title(raw_title) if is_series else raw_title, 'url': 'fxpplus://vod/' + quote(str(entry['id']), safe=''),
            'source': SOURCE, 'fxp_id': str(entry['id']), 'is_serie': is_series,
            'section': section, 'cover': entry.get('poster', ''), 'fanart': entry.get('fanart', ''),
            'plot': entry.get('plot', ''), 'year': entry.get('year', ''),
            'genres': entry.get('genres', []), 'fxp_category': entry.get('category', ''),
            'fxp_alias': entry.get('alias', ''), 'fxp_cast': entry.get('cast', ''),
            'fxp_season_number': _season_number(raw_title) if is_series else None}


def _catalog_entries(provider, root):
    with _lock:
        cached = _catalog_cache.get(root)
        if cached and time.monotonic() - cached[0] < 600:
            return list(cached[1])
    from _vaquex_fxp.lib.metadata import item as normalize
    data = provider.call('getNextColumns', {'columnCode': 'masnew_' + root,
                         'pageNum': 1, 'pageSize': 50, 'version': ''})
    entries = []
    for row in data.get('recommendList') or []:
        for asset in row.get('assetList') or []:
            entry = normalize(asset)
            if entry.get('id'):
                entry['category'] = row.get('name', '')
                entry['alias'] = asset.get('alias') or ''
                entries.append(entry)
    with _lock:
        _catalog_cache[root] = (time.monotonic(), entries)
    return list(entries)


def _tmdb_path():
    _, profile = _paths()
    return os.path.join(os.path.dirname(profile), 'plugin.video.vaquexflix', 'fxp_tmdb_cache.json')


def _read_tmdb_cache():
    global _tmdb_cache
    with _lock:
        if _tmdb_cache is None:
            try:
                with open(_tmdb_path(), encoding='utf-8') as handle:
                    _tmdb_cache = json.load(handle)
            except (OSError, ValueError):
                _tmdb_cache = {}
        return _tmdb_cache


def _save_tmdb_cache():
    path = _tmdb_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with _lock:
        with open(path + '.tmp', 'w', encoding='utf-8') as handle:
            json.dump(_tmdb_cache, handle, ensure_ascii=False)
        os.replace(path + '.tmp', path)


def _tmdb_key(card):
    return 'v3:{}:{}:{}:{}:{}'.format(card['fxp_id'], card.get('title', ''), card.get('fxp_alias', ''), card.get('year', ''),
                                'tv' if card.get('is_serie') else 'movie')


def _tmdb_lookup(card):
    import catalog
    import lolplus
    key = _tmdb_key(card)
    cache = _read_tmdb_cache()
    with _lock:
        if key in cache:
            cached = cache[key]
            if cached.get('tmdb_id'):
                return cached
            retry_season_alias = bool(card.get('is_serie') and re.search(
                r'(?i)\b(?:S|T|Season\s*|Temp(?:orada)?\.?\s*)\d+\s*$',
                str(card.get('fxp_alias') or '')))
            if cached.get('unmatched_until', 0) > time.time() and (not retry_season_alias or cached.get('base_title_retry')):
                return None
        if time.monotonic() - _tmdb_failed.get(key, 0) < 600:
            return None
    kind = 'tv' if card.get('is_serie') else 'movie'
    query = _base_title(catalog.title(card.get('title', '')))
    if not query:
        return None
    alias = _base_title(str(card.get('fxp_alias') or '').split('|', 1)[0].strip())
    queries = [query]
    if alias and catalog.normalize_search_text(alias) != catalog.normalize_search_text(query):
        queries.append(alias)
    year = str(card.get('year') or '')[:4]
    candidates = {}
    had_response = False
    for candidate_query in queries:
        data = lolplus.LolPlusCatalog()._query('/search/' + kind, {'query': candidate_query})
        if 'results' not in data:
            continue
        had_response = True
        norm = catalog.normalize_search_text(candidate_query)
        for row in data.get('results') or []:
            names = [row.get('name') or row.get('title'), row.get('original_name') or row.get('original_title')]
            exact = any(catalog.normalize_search_text(name) == norm for name in names if name)
            score = max((SequenceMatcher(None, norm, catalog.normalize_search_text(name)).ratio()
                         for name in names if name), default=0)
            if not exact and score < .94:
                continue
            row_year = (row.get('first_air_date') or row.get('release_date') or '')[:4]
            if year.isdecimal() and row_year.isdecimal() and abs(int(year) - int(row_year)) > 1:
                continue
            identity = row.get('id')
            if identity is None:
                continue
            count, previous_score, _ = candidates.get(identity, (0, 0, row))
            candidates[identity] = (count + (1 if exact else 0), max(score, previous_score), row)
    if not had_response:
        return None
    ranked = sorted(candidates.values(), key=lambda found: (found[0], found[1]), reverse=True)
    if len(ranked) > 1 and ranked[0][:2] == ranked[1][:2] and card.get('fxp_cast'):
        actors = {catalog.normalize_search_text(name) for name in str(card['fxp_cast']).split(',')[:5] if name.strip()}
        scored = []
        for count, score, candidate in ranked[:5]:
            credits = lolplus.LolPlusCatalog()._query('/{}/{}/credits'.format(kind, candidate['id']))
            names = {catalog.normalize_search_text(person.get('name'))
                     for person in (credits.get('cast') or [])[:20] if person.get('name')}
            scored.append((len(actors & names), count, score, candidate))
        scored.sort(key=lambda found: found[:3], reverse=True)
        if scored and scored[0][0] > 0 and (len(scored) == 1 or scored[0][0] > scored[1][0]):
            ranked = [(scored[0][1], scored[0][2], scored[0][3])]
    if not ranked or (len(ranked) > 1 and ranked[0][:2] == ranked[1][:2]):
        with _lock:
            _tmdb_failed[key] = time.monotonic()
            cache[key] = {'unmatched_until': time.time() + 86400, 'base_title_retry': True}
        return None
    row = ranked[0][2]
    meta = {'tmdb_id': row['id'], 'genre_ids': row.get('genre_ids') or [],
            'original_language': row.get('original_language') or '',
            'origin_country': row.get('origin_country') or [],
            'year': (row.get('first_air_date') or row.get('release_date') or '')[:4],
            'original_title': row.get('original_name') or row.get('original_title') or '',
            'rating': row.get('vote_average') or 0,
            'plot': row.get('overview') or '',
            'poster': row.get('poster_path') or ''}
    with _lock:
        cache[key] = meta
    return meta


def _base_title(value):
    return re.sub(r'(?i)\s+(?:S|T|Season\s*|Temp(?:orada)?\.?\s*)\d+\s*$', '',
                  str(value or '')).strip()


def _season_number(value):
    match = re.search(r'(?i)\s+(?:S|T|Season\s*|Temp(?:orada)?\.?\s*)(\d+)\s*$', str(value or ''))
    return int(match.group(1)) if match else None


def _enrich(cards):
    if not cards:
        return cards
    unique = list({card['fxp_id']: card for card in cards}.values())
    with ThreadPoolExecutor(max_workers=6) as pool:
        matches = dict(zip((card['fxp_id'] for card in unique), pool.map(_tmdb_lookup, unique)))
    _save_tmdb_cache()
    result = []
    for card in cards:
        meta = matches.get(card['fxp_id'])
        if meta:
            card = dict(card, tmdb_id=meta['tmdb_id'], tmdb_genre_ids=meta['genre_ids'],
                        original_language=meta['original_language'], origin_country=meta['origin_country'],
                        original_title=meta['original_title'], rating=meta['rating'])
            if not card.get('year'):
                card['year'] = meta['year']
            if not card.get('plot'):
                card['plot'] = meta['plot']
            if not card.get('cover') and meta['poster']:
                card['cover'] = 'https://image.tmdb.org/t/p/w500' + meta['poster']
        result.append(card)
    return result


def _movie_countries(card):
    import lolplus
    cache = _read_tmdb_cache()
    key = 'countries:movie:{}'.format(card['tmdb_id'])
    with _lock:
        if key in cache:
            return cache[key]
    data = lolplus.LolPlusCatalog()._query('/movie/{}'.format(card['tmdb_id']))
    if not data.get('id'):
        return []
    countries = [row.get('iso_3166_1') for row in data.get('production_countries') or []
                 if row.get('iso_3166_1')]
    with _lock:
        cache[key] = countries
    return countries


def _category_match(card, section, genre):
    import lolplus
    if not genre:
        return True
    if not card.get('tmdb_id'):
        return False
    key = str(genre).lower()
    if key in ('mexicanas', 'mexicana', 'mexico'):
        return 'MX' in (card.get('origin_country') or [] if card.get('is_serie') else _movie_countries(card))
    if key in ('argentinas', 'argentina'):
        return 'AR' in (card.get('origin_country') or [] if card.get('is_serie') else _movie_countries(card))
    if key in ('series-turcas', 'turcas', 'turca'):
        return bool(card.get('is_serie')) and card.get('original_language') == 'tr'
    if key in ('cortos', 'corto', 'cortometrajes'):
        return False  # La respuesta de búsqueda no acredita duración.
    if key in ('infantil', 'kids', 'animacion'):
        return True  # Se consultó exclusivamente la raíz infantil del proveedor.
    genre_ids = set(card.get('tmdb_genre_ids') or [])
    if key == 'suspenso':
        return (9648 if card.get('is_serie') else 53) in genre_ids
    if key.startswith('tmdb-') and key[5:].isdigit():
        return int(key[5:]) in genre_ids
    mapping = lolplus.TMDB_TV_GENRES if card.get('is_serie') else lolplus.TMDB_MOVIE_GENRES
    target = mapping.get(key)
    if isinstance(target, int):
        return target in genre_ids
    if key.startswith('lista-'):
        return True  # Se conserva el catálogo; la lista no anuncia un género.
    return False


def page(section, number, genre=None, preview=False):
    root = {'peliculas': 'movies', 'series': 'series', 'animes': 'anime', 'anime': 'anime',
            'infantil': 'kids'}.get(section)
    if genre in ('infantil', 'kids', 'animacion') and section in ('peliculas', 'series'):
        root = 'kids'
    if not root or int(number) < 1:
        return [], False
    try:
        provider = _provider()
    except Exception:
        return [], False
    entries = _catalog_entries(provider, root)
    with _lock:
        entries += list(_discovered.get(root, {}).values())
    if root == 'kids':
        entries = [item for item in entries if (item.get('kind') == 'series') == (section == 'series')]
    cards = [_card(item, 'animes' if root == 'anime' else section) for item in entries]
    cards = list({card['fxp_id']: card for card in cards if card}.values())
    if not genre and not preview:
        start = (int(number) - 1) * 30
        return _enrich(cards[start:start + 30]), start + 30 < len(cards)
    cards = [card for card in _enrich(cards) if _category_match(card, section, genre)]
    if genre in ('mexicanas', 'mexicana', 'mexico', 'argentinas', 'argentina'):
        _save_tmdb_cache()
    if preview:
        return cards[:3], False
    start = (int(number) - 1) * 30
    return cards[start:start + 30], start + 30 < len(cards)


def search(query, section='all'):
    try:
        provider = _provider()
        data = provider.search(query)
    except Exception:
        return []
    anime_ids, kids_ids = _classified_ids(provider)
    cards = []
    for item in data.get('items', []):
        category = str(item.get('category', '')).lower()
        identifier = str(item.get('id') or '')
        kind = 'animes' if identifier in anime_ids or 'anime' in category else 'infantil' if identifier in kids_ids or 'infantil' in category or 'kids' in category else 'series' if item.get('kind') == 'series' else 'peliculas'
        if section not in ('all', kind, 'anime' if kind == 'animes' else kind):
            continue
        card = _card(item, kind)
        if card:
            cards.append(card)
            root = {'peliculas': 'movies', 'series': 'series', 'animes': 'anime', 'infantil': 'kids'}[kind]
            with _lock:
                _discovered.setdefault(root, {})[str(item['id'])] = item
    return _enrich(cards)


def _classified_ids(provider):
    global _section_ids
    with _lock:
        if time.monotonic() - _section_ids[0] < 600:
            return _section_ids[1], _section_ids[2]
    anime = {str(item['id']) for item in _catalog_entries(provider, 'anime') if item.get('id')}
    kids = {str(item['id']) for item in _catalog_entries(provider, 'kids') if item.get('id')}
    with _lock:
        _section_ids = (time.monotonic(), anime, kids)
    return anime, kids


def episodes(series):
    item = {'id': series['fxp_id'], 'title': series.get('title', ''), 'kind': 'series'}
    try:
        provider = _provider()
        detail = provider.detail(item)
    except Exception:
        return {}
    seasons = detail.get('seasons') or [item]
    result = {}
    for index, season in enumerate(seasons, 1):
        number = str(season.get('number') or series.get('fxp_season_number') or index)
        current = provider.detail(season) if season is not item else detail
        rows = []
        for n, episode in enumerate(current.get('episodes') or [], 1):
            if not episode.get('id') or not _visible(episode):
                continue
            rows.append({'title': episode.get('title') or 'Episodio {}'.format(n),
                'url': 'fxpplus://vod/' + quote(str(episode['id']), safe='') + '?' + urlencode({'season_id': season.get('id', '')}),
                'source': SOURCE, 'fxp_id': str(episode['id']), 'fxp_season_id': season.get('id', ''),
                'is_serie': True, 'section': series.get('section', 'series'),
                'tmdb_id': series.get('tmdb_id'),
                'season': number, 'episode': str(episode.get('number') or n),
                'cover': episode.get('poster') or series.get('cover', ''), 'plot': episode.get('plot', '')})
        if rows:
            existing = result.setdefault(number, [])
            seen = {row['url'] for row in existing}
            existing.extend(row for row in rows if row['url'] not in seen)
    return result


def categories():
    try:
        rows = _provider().categories()
    except Exception:
        return []
    return [{'key': 'fxp_group_' + str(row['id']), 'title': row['title'],
             'url': 'tv://fxp_group_' + str(row['id']), 'cover': '', 'plot': 'Canales en vivo: ' + row['title']}
            for row in rows
            if str(row.get('id')) != '76208' and _safe(row.get('title')) and str(row.get('id', '')).isdigit()]


def _excluded_channels(provider):
    global _adult_channel_ids
    with _lock:
        if time.monotonic() - _adult_channel_ids[0] < 600:
            return _adult_channel_ids[1]
    ids = set()
    try:
        for page_number in range(1, 21):
            data = provider.channels('76208', page_number)
            rows = data.get('items') or []
            ids.update(str(row['id']) for row in rows if row.get('id'))
            if not data.get('more'):
                break
    except Exception:
        pass
    with _lock:
        _adult_channel_ids = (time.monotonic(), frozenset(ids))
    return frozenset(ids)


def channels(category, page_number=1):
    if str(category) == '76208':
        return [], False
    try:
        provider = _provider()
        excluded = _excluded_channels(provider)
        data = provider.channels(str(category), page_number)
    except Exception:
        return [], False
    cards = []
    for item in data.get('items', []):
        if not item.get('id') or str(item['id']) in excluded or not _visible(item):
            continue
        cards.append({'title': item.get('title', ''), 'url': 'fxptv://' + quote(str(item['id']), safe=''),
                      'source': SOURCE, 'cover': item.get('poster', ''), 'plot': item.get('plot', ''),
                      'rating': 'DIRECTO'})
    return cards, bool(data.get('more'))


def resolve(url):
    parsed = urlsplit(url)
    if parsed.scheme not in ('fxptv', 'fxpplus'):
        raise ValueError('Enlace FXP+ inválido')
    identifier = unquote(parsed.netloc if parsed.scheme == 'fxptv' else parsed.path.lstrip('/'))
    if not identifier or len(identifier) > 160 or any(ord(ch) < 32 or ch in '/?#\\' for ch in identifier):
        raise ValueError('Identificador FXP+ inválido')
    if parsed.scheme == 'fxptv' and identifier in _excluded_channels(_provider()):
        raise ValueError('Canal no disponible en FXP+')
    params = parse_qs(parsed.query)
    item = {'id': identifier, 'kind': 'channel' if parsed.scheme == 'fxptv' else 'movie',
            'season_id': params.get('season_id', [''])[0]}
    stream = _provider().resolve(item)
    _probe_stream(stream)
    from _vaquex_fxp.lib.playback import stream_path
    return stream_path(stream)


def _probe_stream(stream, opener=None, depth=0):
    """Comprueba bytes de vídeo; una etiqueta o un 200 HTML no bastan."""
    opener = opener or urllib.request.urlopen
    headers = dict(stream.get('headers') or {})
    url = stream['url']
    hls = urlsplit(url).path.lower().endswith('.m3u8')
    if hls:
        with opener(urllib.request.Request(url, headers=headers), timeout=8) as response:
            manifest = response.read(256 * 1024).decode('utf-8', 'replace')
        if not manifest.startswith('#EXTM3U'):
            raise ValueError('FXP+ no entregó un manifiesto HLS válido')
        resources = []
        for line in manifest.splitlines():
            if line.startswith('#EXT-X-MAP:'):
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    resources.append(match.group(1))
            elif line and not line.startswith('#'):
                resources.append(line.strip())
                break
        if not resources:
            raise ValueError('FXP+ no entregó segmentos de vídeo')
        for resource in resources:
            with opener(urllib.request.Request(urljoin(url, resource), headers=headers), timeout=8) as response:
                first = response.read(16)
            if not first or first.lstrip().lower().startswith((b'<html', b'<!doctype')):
                raise ValueError('FXP+ no entregó bytes de vídeo')
            if first.startswith(b'#EXTM3U'):
                if depth >= 2:
                    raise ValueError('FXP+ no entregó segmentos finales')
                _probe_stream(dict(stream, url=urljoin(url, resource)), opener, depth + 1)
    else:
        with opener(urllib.request.Request(url, headers=dict(headers, Range='bytes=0-1879')), timeout=8) as response:
            first = response.read(16)
        if not first or first.lstrip().lower().startswith((b'<html', b'<!doctype')):
            raise ValueError('FXP+ no entregó bytes de vídeo')
