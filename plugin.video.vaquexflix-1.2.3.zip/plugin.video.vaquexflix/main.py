import network
import resolvers
# -*- coding: utf-8 -*-
import sys, os, time, json, re, hashlib, threading, random, ssl
import urllib.parse, urllib.request, base64
import xbmc, xbmcgui, xbmcaddon, xbmcvfs, xbmcplugin
import servidores
import playback
import watch_history
import stream_metadata
import catalog
import doramas
import anime
import catalog_index
import sessions
import tv_en_vivo
import tv_epg
import tube_engine
import source_switches
import queue
from concurrent.futures import ThreadPoolExecutor, as_completed

def limpiar_texto(value):
    text = network.limpiar_texto(value)
    return re.sub(r'(?i)\b(?:fuegocine|fuegolatino|hackstore2?|pelisjuanita|sololatino)\b(?:\.[a-z]+)?', '', text).strip()


def elegir_caratula_categoria(candidates, used, fallback=''):
    """Elige al azar una portada de la categoría, evitando repeticiones."""
    covers = list(dict.fromkeys(c for c in candidates if c))
    available = [c for c in covers if c not in used]
    chosen = random.choice(available or covers) if covers else fallback
    if chosen:
        used.add(chosen)
    return chosen


TMDB_COLLECTION_POSTERS = {
    'peliculas': {
        'retro': [
            'https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg',
            'https://image.tmdb.org/t/p/w500/iU0qE192Z2qG0q12bC9d3p4lXh0.jpg',
            'https://image.tmdb.org/t/p/w500/6FfCtAuVAW8XJjZ7eWeLibRLWTw.jpg',
            'https://image.tmdb.org/t/p/w500/5K7cOHoay2mZusSLezBOY0Qxh8a.jpg',
            'https://image.tmdb.org/t/p/w500/63N9uy8nd9j7Eog2axPQ8lbr3Wj.jpg',
            'https://image.tmdb.org/t/p/w500/saHP97rTPS5eLmrLQEcANmKrsFl.jpg',
            'https://image.tmdb.org/t/p/w500/vfrQk5IPloGg1v9Rzbh2Eg3VGyM.jpg',
        ],
        'populares': [
            'https://image.tmdb.org/t/p/w500/1E5baAaEse26fej7uHcjOgEE2t2.jpg',
            'https://image.tmdb.org/t/p/w500/qNBAXBIQlnOThrVvA6mA2B5ggV6.jpg',
        ],
        'mejor-valoradas': [
            'https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg',
            'https://image.tmdb.org/t/p/w500/9cqNxx0GxF0bflZmeSMuL5tnGzr.jpg',
        ],
        'tendencias': [
            'https://image.tmdb.org/t/p/w500/8cdWjvZQUExUUTzyp4t6EDMubfO.jpg',
            'https://image.tmdb.org/t/p/w500/b33nnKl1GSFbao8l3urDDgo402F.jpg',
        ],
        'recien-estrenadas': [
            'https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg',
            'https://image.tmdb.org/t/p/w500/aosm8NMQ3UyoBVpSxyimorCQykC.jpg',
        ],
    },
    'series': {
        'retro': [
            'https://image.tmdb.org/t/p/w500/2koX1xLkpTQM4IZebYvKysFW1Nh.jpg',
            'https://image.tmdb.org/t/p/w500/y6wG4b4N3t0d2cZ1iWk0f4u8d1r.jpg',
            'https://image.tmdb.org/t/p/w500/dwyvhvM0M1U6C2pPjZ6g0qF1c2d.jpg',
            'https://image.tmdb.org/t/p/w500/aCw8ON0LoIP946qwOCvRp5M32XH.jpg',
            'https://image.tmdb.org/t/p/w500/lA98COnTbtkhn7ovmDVoauV9zbY.jpg',
            'https://image.tmdb.org/t/p/w500/e9n5Okn5ks7d7B5Uf9kH67f13bE.jpg',
            'https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg',
        ],
        'populares': [
            'https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg',
            'https://image.tmdb.org/t/p/w500/u3bZgnGQ9T01sWNhyveQz0wH0Hl.jpg',
        ],
        'mejor-valoradas': [
            'https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg',
            'https://image.tmdb.org/t/p/w500/lA98COnTbtkhn7ovmDVoauV9zbY.jpg',
        ],
        'tendencias': [
            'https://image.tmdb.org/t/p/w500/7d36wUeQ50v40zWqY1n2U22f2Vf.jpg',
        ],
        'recien-estrenadas': [
            'https://image.tmdb.org/t/p/w500/8cdWjvZQUExUUTzyp4t6EDMubfO.jpg',
        ],
        'en-emision': [
            'https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg',
        ],
    }
}


def caratulas_tmdb_categoria(items, section):
    """Portadas de títulos TMDb de la sección, excluyendo contenido adulto/sexual."""
    blocked = re.compile(r'(?i)\b(?:sex(?:ual|y)?|porn\w*|er[oó]tic\w*|desnud\w*|nude|nudity|'
                         r'prostitut\w*|striptease|playboy|xxx|hentai|onlyfans)\b')
    return list(dict.fromkeys(
        item['cover'] for item in items
        if item.get('source') == 'lolplus'
        and item.get('source') != 'frikiserie'
        and item.get('section') == section
        and item.get('adult') is not True
        and item.get('cover', '').startswith('https://image.tmdb.org/t/p/')
        and not blocked.search(' '.join(str(item.get(k) or '') for k in ('title', 'original_title', 'plot')))))


def ordenar_alternativas_normales(servers, attempted_url, quality_cache=None):
    """Skip a failed Premium and rank the remaining sources once."""
    quality_cache = quality_cache or {}
    unique = {}
    for server in servers:
        url = server.get('url', '')
        if not url or url == attempted_url:
            continue
        name = server.get('nombre', '').lower()
        if server.get('source') == 'sololatino' and 'premium' in name:
            continue
        unique.setdefault(url, server)
    def priority(server):
        meta = quality_cache.get(stream_metadata.cache_key(server['url']), {})
        if time.time() - meta.get('updated', 0) > 21600:
            meta = {}
        return playback.server_priority(server, meta)
    return sorted(unique.values(), key=priority)


def conservar_sinopsis_existente(item, metadata):
    old_plot = item.get('plot', '')
    new_plot = metadata.get('plot', '')
    if not old_plot or not new_plot:
        return False
    if item.get('plot_language') == 'es' and metadata.get('plot_language') == 'en':
        return True
    return metadata.get('plot_language') != 'es' and (
        new_plot.endswith(('...', '…')) or len(old_plot) > len(new_plot))


def _formatear_etiqueta_servidor(server, meta=None):
    meta = meta or {}
    clean_name = re.sub(
        r'\s*[\(\[](?:lat|latino|latam|esp|castellano|eng|sub|subtitulado|cam|hdcam|hdts|ts|scr|pendiente de reparar)[\)\]]',
        '', server.get('nombre', ''), flags=re.I)
    clean_name = re.sub(
        r'\b(?:Multicalidad|FHD|FullHD|HD|SD)\b|\(?\b\d{3,4}p\b\)?',
        '', clean_name, flags=re.I)
    clean_name = re.sub(r'\s+', ' ', clean_name).strip() or server.get('nombre', 'Servidor')
    cam = stream_metadata.cam_tag(server, meta) if hasattr(stream_metadata, 'cam_tag') else ''
    if server.get('resolver_status') == 'pending' and not meta.get('error'):
        badge = server.get('resolver_error') or 'Pendiente de reparar'
    elif meta.get('error'):
        badge = meta['error']
    else:
        cal = stream_metadata.quality_label(meta) if meta.get('playable') else ''
        badge = cal or 'Sin verificar'
    if cam and not re.search(rf'\b{re.escape(cam)}\b', badge, re.I):
        badge = f'{badge} · {cam}'
    return f'[{badge}] {clean_name} | {stream_metadata.audio_label(meta, server)}'


def _prioridad_experimental_servidor(server, meta=None):
    meta = meta or {}
    full_name = _formatear_etiqueta_servidor(server, meta).lower()
    badge = full_name.split(']', 1)[0][1:] if full_name.startswith('[') and ']' in full_name else ''
    is_pending = (
        server.get('resolver_status') == 'pending'
        or 'pendiente de reparar' in badge
        or 'contenido cruzado' in badge
    )
    has_error = bool(meta.get('error')) and not is_pending
    is_unverified = not is_pending and not has_error and (
        'sin verificar' in badge or 'no verificado' in badge
    )
    if is_pending:
        tier = 2
    elif has_error:
        tier = 3
    elif is_unverified:
        tier = 1
    else:
        tier = 0
    is_cam = 1 if (hasattr(stream_metadata, 'cam_tag') and stream_metadata.cam_tag(server, meta)) else 0
    audio = stream_metadata.audio_label(meta, server).lower()
    has_lang = 0 if re.search(r'\b(?:lat|latino|es|esp|español|espanol|spa|spanish)\b', audio) else 1
    max_height = 0
    if tier == 0:
        heights = [int(h) for h in (meta.get('heights') or []) if isinstance(h, (int, float)) and h > 0]
        heights.extend(int(m) for m in re.findall(r'\b(\d{3,4})p\b', badge))
        if '4k' in badge:
            heights.append(2160)
        if '8k' in badge:
            heights.append(4320)
        max_height = max(heights) if heights else 0
    is_argflix = 1 if (server.get('source') == 'argflix' and not source_switches.only_enabled('argflix')) else 0
    return (tier, is_argflix, -max_height, is_cam, has_lang)


def _cargar_calidad_cacheada(servidores, current_item_key='', session_quality=None):
    data_ud = cargar_userdata()
    if data_ud.get('server_quality_version') != 3:
        data_ud['server_quality'] = {}
        data_ud['server_quality_version'] = 3
        guardar_userdata(data_ud)
    persisted = data_ud.get('server_quality', {})
    quality_cache = {}
    for server in servidores:
        url = server.get('url', '')
        if not url:
            continue
        key = stream_metadata.cache_key(url)
        meta = persisted.get(key)
        if stream_metadata.has_verified_cache(meta, current_item_key):
            quality_cache[key] = dict(meta)
    if session_quality:
        for server in servidores:
            url = server.get('url', '')
            if not url:
                continue
            key = stream_metadata.cache_key(url)
            if key in session_quality:
                quality_cache[key] = dict(session_quality[key])
    return quality_cache


def _guardar_calidad_medida(measured, current_item_key=''):
    if not measured:
        return
    stamped = {}
    for key, meta in measured.items():
        entry = dict(meta)
        if current_item_key:
            entry['item_key'] = current_item_key
        stamped[key] = entry
    data = cargar_userdata()
    cache = data.setdefault('server_quality', {})
    cache.update(stamped)
    # Solo persistir metadatos, nunca URLs firmadas ni cookies.
    data['server_quality'] = dict(sorted(
        cache.items(), key=lambda pair: pair[1].get('updated', 0), reverse=True)[:512])
    guardar_userdata(data)


def _invalidar_calidad_servidor(server_url, error, current_item_key='', quality_cache=None):
    if not server_url:
        return
    key = stream_metadata.cache_key(server_url)
    entry = {'scanned': True, 'updated': time.time(), 'error': error or 'No disponible'}
    if current_item_key:
        entry['item_key'] = current_item_key
    if quality_cache is not None:
        quality_cache[key] = dict(entry)
    data = cargar_userdata()
    cache = data.setdefault('server_quality', {})
    cache[key] = entry
    data['server_quality'] = dict(sorted(
        cache.items(), key=lambda pair: pair[1].get('updated', 0), reverse=True)[:512])
    guardar_userdata(data)


def _necesita_sondeo(server, quality_cache, current_item_key=''):
    key = stream_metadata.cache_key(server['url'])
    if server.get('resolver_status') == 'pending':
        quality_cache.setdefault(key, {
            'scanned': True, 'updated': time.time(),
            'error': server.get('resolver_error') or 'Pendiente de reparar',
        })
        return False
    existing = quality_cache.get(key)
    if stream_metadata.has_verified_cache(existing, current_item_key):
        return False
    if isinstance(existing, dict) and existing.get('error'):
        return server.get('source') == 'fxpplus'
    return True


def _sondear_faltantes(ui, candidatos, quality_cache, current_item_key='', label=None):
    missing = [s for s in candidatos if _necesita_sondeo(s, quality_cache, current_item_key)]
    if not missing:
        return {}, False
    if getattr(ui, '_metadata_scanner', None) is None:
        ui._metadata_scanner = stream_metadata.Scanner(
            resolvers.resolver_stream, network.nueva_sesion,
            lambda url: resolvers.CALIDADES_HLS.get(url, ''),
            network.presupuesto_sondeo)
    probe = MetadataProgress('metadata.xml', ADDON_PATH, 'Default', '720p')
    probe.show()
    probe.update(0, len(missing), label=label)
    def probe_progress(done, total):
        probe.update(done, total, label=label)
        return ui.activa and not probe.omitted and not probe.canceled
    try:
        measured = ui._metadata_scanner.scan(missing, {}, seconds=15, progress=probe_progress)
    finally:
        probe.close()
    canceled = probe.canceled or not ui.activa
    if measured:
        _guardar_calidad_medida(measured, current_item_key)
        for key, meta in measured.items():
            entry = dict(meta)
            if current_item_key:
                entry['item_key'] = current_item_key
            quality_cache[key] = entry
    return measured or {}, canceled


def _reordenar_slots_servidor(servidores, nombres, slots, quality_cache):
    ranked = sorted(
        [(servidores[i], _formatear_etiqueta_servidor(
            servidores[i], quality_cache.get(stream_metadata.cache_key(servidores[i]['url']))))
         for i in slots],
        key=lambda pair: _prioridad_experimental_servidor(
            pair[0], quality_cache.get(stream_metadata.cache_key(pair[0]['url']))))
    for slot, (srv, lbl) in zip(slots, ranked):
        servidores[slot] = srv
        nombres[slot] = lbl


def _elegir_con_sondeo_incremental(ui, servidores, titulo, current_item_key, quality_cache,
                                   dialogo, progreso_factory, allow_upfront_cancel=True):
    if len(servidores) <= 6:
        _, canceled = _sondear_faltantes(ui, servidores, quality_cache, current_item_key)
        if allow_upfront_cancel and canceled:
            return None, []
        servidores.sort(key=lambda s: _prioridad_experimental_servidor(
            s, quality_cache.get(stream_metadata.cache_key(s['url']))))
    else:
        servidores.sort(key=lambda s: _prioridad_experimental_servidor(
            s, quality_cache.get(stream_metadata.cache_key(s['url']))))
    nombres = [_formatear_etiqueta_servidor(s, quality_cache.get(stream_metadata.cache_key(s['url'])))
               for s in servidores]

    def probe_group(grupo, indices):
        _, canceled = _sondear_faltantes(
            ui, [servidores[i] for i in indices], quality_cache, current_item_key, label=grupo)
        if not canceled:
            slots = sorted(indices)
            _reordenar_slots_servidor(servidores, nombres, slots, quality_cache)
            indices[:] = slots
        return not canceled

    def on_error(indice, servidor, error):
        _invalidar_calidad_servidor(servidor.get('url', ''), error, current_item_key, quality_cache)
        nombres[indice] = _formatear_etiqueta_servidor(
            servidor, quality_cache.get(stream_metadata.cache_key(servidor['url'])))

    resultado = elegir_servidor_con_reintentos(
        servidores, nombres, titulo, dialogo, progreso_factory, lambda: ui.activa,
        probe_group=probe_group if len(servidores) > 6 else None,
        on_error=on_error)
    return resultado, nombres


def elegir_servidor_con_reintentos(servidores, nombres, titulo, dialogo, progreso_factory,
                                  activo, indice_preferido=None, probe_group=None, on_error=None):
    """Agrupa listas largas y conserva sus opciones tras un fallo."""
    grupos = {}
    if len(servidores) > 6:
        for indice, servidor in enumerate(servidores):
            nombre = str(servidor.get('nombre', ''))
            etiqueta = nombres[indice]
            audio = etiqueta.rsplit(' | ', 1)[-1] if ' | ' in etiqueta else ''
            texto = audio if audio and 'no indicado' not in audio.lower() else nombre
            if 'premium' in nombre.lower():
                grupo = 'Premium'
            elif re.search(r'(?i)\b(?:sub|subtitulado)\b', nombre):
                grupo = 'Subtitulado'
            elif re.search(r'(?i)\b(?:lat|latino|es-419|es-mx)\b', texto):
                grupo = 'Latino'
            elif re.search(r'(?i)\b(?:esp|castellano|es-es)\b', texto):
                grupo = 'Castellano'
            elif re.search(r'(?i)\b(?:sub|subtitulado)\b', texto):
                grupo = 'Subtitulado'
            elif re.search(r'(?i)\b(?:eng|inglés|ingles)\b', texto):
                grupo = 'Inglés'
            else:
                grupo = 'Idioma no indicado'
            grupos.setdefault(grupo, []).append(indice)
    orden = ('Premium', 'Latino', 'Castellano', 'Subtitulado', 'Inglés', 'Idioma no indicado')
    grupos_ordenados = [grupo for grupo in orden if grupo in grupos]
    grupo_actual = next((grupo for grupo, indices in grupos.items()
                         if indice_preferido in indices and len(indices) > 1), None)
    grupos_sondeados = set()
    while activo():
        if grupos:
            if grupo_actual is None:
                opciones = [nombres[grupos[grupo][0]] if grupo == 'Premium' and len(grupos[grupo]) == 1
                            else '{} ({})'.format(grupo, len(grupos[grupo]))
                            for grupo in grupos_ordenados]
                seleccion = dialogo.select(
                    f'Vaquexflix - {limpiar_texto(titulo)} ({len(nombres)} opciones)', opciones)
                if seleccion < 0:
                    return None
                grupo_actual = grupos_ordenados[seleccion]
                if len(grupos[grupo_actual]) == 1:
                    indice = grupos[grupo_actual][0]
                    grupo_actual = None
                else:
                    continue
            else:
                if probe_group is not None and grupo_actual not in grupos_sondeados:
                    if not probe_group(grupo_actual, grupos[grupo_actual]):
                        grupo_actual = None
                        continue
                    grupos_sondeados.add(grupo_actual)
                indices = grupos[grupo_actual]
                seleccion = dialogo.select(
                    f'Vaquexflix - {grupo_actual} ({len(indices)})',
                    [nombres[i] for i in indices])
                if seleccion < 0:
                    grupo_actual = None
                    continue
                indice = indices[seleccion]
        else:
            indice = dialogo.select(
                f'Vaquexflix - {limpiar_texto(titulo)} ({len(nombres)} servidores)', nombres)
            if indice < 0:
                return None
        servidor = servidores[indice]
        if servidor.get('resolver_status') == 'pending':
            dialogo.notification('Vaquexflix', servidor.get('resolver_error') or
                                 'Pendiente de reparar: sin resolutor verificado',
                                 xbmcgui.NOTIFICATION_WARNING, 6000)
            continue
        progreso = progreso_factory()
        msg_srv = f"Conectando a {servidor.get('nombre', 'Servidor')}..."
        progreso.create('Vaquexflix', msg_srv)
        error = 'El servidor no entregó un vídeo reproducible.'
        try:
            waiter = playback.progress_waiter(progreso, activo, msg_srv, 8, 92, 6.0)
            stream = playback.request_with_progress(
                lambda: resolvers.resolver_stream(servidor['url']), network.presupuesto_resolucion,
                waiter)
            if stream:
                progreso.update(100, 'Iniciando reproducción…')
                return indice, stream
        except playback.Cancelled:
            return None
        except TimeoutError:
            error = 'El servidor excedió el tiempo de espera.'
        except network.ServidorNoDisponible as exc:
            error = str(exc)
        except Exception as exc:
            error = f'Error al resolver: {type(exc).__name__}'
            xbmc.log(f'Vaquexflix: {servidor.get("nombre", "Servidor")}: {exc}', xbmc.LOGERROR)
        finally:
            progreso.close()
        dialogo.notification('Vaquexflix', error + ' Elige otro servidor.', xbmcgui.NOTIFICATION_WARNING, 6000)
        if on_error is not None:
            on_error(indice, servidor, error)
    return None
fetch_html = network.fetch_html
resolver_enlace_directo = resolvers.resolver_enlace_directo
_ssl_ctx = network._ssl_ctx
UA = network.UA
SITE_URL = network.SOLOLATINO_BASE

for path_req in ['script.module.six/lib', 'script.module.kodi-six/libs', 'script.module.resolveurl/lib']:
    p = xbmcvfs.translatePath(f'special://home/addons/{path_req}')
    if p and xbmcvfs.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

try:
    import resolveurl
except Exception:
    resolveurl = None

# servidores se importa antes de configurar las rutas de modulos de Kodi.
resolvers.resolveurl = resolveurl

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_FILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/userdata.json')
SEARCH_CACHE_FILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/search_cache.json')
source_switches.configure(xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/source_switches.json'))
SEARCH_CACHE_TTL = 6 * 3600  # Las busquedas guardadas caducan para que aparezca contenido nuevo.
CATEGORIES_FILE = os.path.join(ADDON_PATH, 'resources', 'categories.json')

def _asegurar_advancedsettings():
    try:
        adv_path = xbmcvfs.translatePath('special://masterprofile/advancedsettings.xml')
        cfg = (
            '<advancedsettings version="1.0">\n'
            '  <cache>\n'
            '    <buffermode>1</buffermode>\n'
            '    <memorysize>67108864</memorysize>\n'
            '    <readfactor>20</readfactor>\n'
            '  </cache>\n'
            '  <network>\n'
            '    <buffermode>1</buffermode>\n'
            '    <memorysize>67108864</memorysize>\n'
            '    <readfactor>20</readfactor>\n'
            '    <disablehttp2>true</disablehttp2>\n'
            '  </network>\n'
            '</advancedsettings>\n'
        )
        if not xbmcvfs.exists(adv_path):
            with open(adv_path, 'w', encoding='utf-8') as f:
                f.write(cfg)
            xbmc.log('Vaquexflix: advancedsettings.xml configurado con buffer de 64MB, readfactor 20 y disablehttp2', xbmc.LOGINFO)
        else:
            with open(adv_path, 'r', encoding='utf-8', errors='replace') as f:
                existing = f.read()
            if ('<memorysize>67108864</memorysize>' in existing
                    and '<readfactor>20</readfactor>' in existing
                    and '<disablehttp2>' not in existing):
                with open(adv_path, 'w', encoding='utf-8') as f:
                    f.write(cfg)
                xbmc.log('Vaquexflix: advancedsettings.xml actualizado con disablehttp2', xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(f'Vaquexflix: no se pudo escribir advancedsettings.xml: {exc}', xbmc.LOGDEBUG)

_asegurar_advancedsettings()

def cargar_userdata():
    data = None
    if xbmcvfs.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            pass
    if not data:
        bak = DATA_FILE + '.bak'
        if xbmcvfs.exists(bak):
            try:
                with open(bak, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                pass
    if not data:
        return {'favoritos': [], 'historial': {}, 'youtube_favoritos': [], 'youtube_historial': [], 'youtube_playlists': []}

    # Sanitizar historial para que vídeos de YouTube o TV no contaminen Películas/Series
    hist = data.get('historial', {})
    if isinstance(hist, dict):
        keys_to_remove = [
            k for k, v in hist.items()
            if ('youtube.com' in k or 'googlevideo.com' in k or k.startswith('tube://') or k.startswith('tv://')
                or (isinstance(v, dict) and (v.get('is_youtube') or v.get('is_tv') or v.get('is_live'))))
        ]
        if keys_to_remove:
            for k in keys_to_remove:
                hist.pop(k, None)
            data['historial'] = hist

    # Limpiar emojis de YouTube en userdata para evitar rectángulos vacíos en fuentes de Kodi
    try:
        for cat in ('youtube_historial', 'youtube_favoritos', 'youtube_playlists'):
            lst = data.get(cat, [])
            if isinstance(lst, list):
                for item in lst:
                    if isinstance(item, dict):
                        if 'title' in item:
                            item['title'] = tube_engine.clean_emojis(item['title'])
                        if 'channel' in item:
                            item['channel'] = tube_engine.clean_emojis(item['channel'])
                        if 'plot' in item:
                            item['plot'] = tube_engine.clean_emojis(item['plot'])
    except Exception:
        pass
    return data

def guardar_userdata(data):
    dir_p = os.path.dirname(DATA_FILE)
    if not xbmcvfs.exists(dir_p): xbmcvfs.mkdirs(dir_p)
    tmp = DATA_FILE + '.tmp'
    bak = DATA_FILE + '.bak'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        if xbmcvfs.exists(DATA_FILE):
            try:
                if xbmcvfs.exists(bak): os.remove(bak)
                os.replace(DATA_FILE, bak)
            except Exception: pass
        os.replace(tmp, DATA_FILE)
    except Exception:
        try:
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception: pass

def filtrar_cache_busquedas(cache):
    """Evita que resultados guardados rescaten fichas retiradas."""
    import lolplus
    cache = dict(cache) if isinstance(cache, dict) else {}
    items = cache.get('items')
    queries = cache.get('queries')
    items = items if isinstance(items, dict) else {}
    queries = queries if isinstance(queries, dict) else {}
    cache['items'] = {key: item for key, item in items.items()
                      if not lolplus.catalog_item_excluded(item)}
    cache['queries'] = {
        key: dict(entry, items=[item for item in entry.get('items', [])
                                if not lolplus.catalog_item_excluded(item)])
        if isinstance(entry, dict) else entry
        for key, entry in queries.items()
    }
    return cache


def cargar_search_cache():
    if xbmcvfs.exists(SEARCH_CACHE_FILE):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as f:
                return filtrar_cache_busquedas(json.load(f))
        except Exception: pass
    return {'queries': {}, 'items': {}}

def guardar_search_cache(cache):
    dir_p = os.path.dirname(SEARCH_CACHE_FILE)
    if not xbmcvfs.exists(dir_p): xbmcvfs.mkdirs(dir_p)
    tmp = SEARCH_CACHE_FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False)
        os.replace(tmp, SEARCH_CACHE_FILE)
    except Exception: pass

def cargar_catalogo_categorias():
    if xbmcvfs.exists(CATEGORIES_FILE):
        try:
            with open(CATEGORIES_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except Exception: pass
    return {'peliculas': {}, 'series': {}}

CATALOGO_GENEROS = cargar_catalogo_categorias()
NOMBRES_SECCIONES = {
    'peliculas': 'PELÍCULAS',
    'series': 'SERIES',
    'animes': 'ANIMES',
    'doramas': 'DORAMAS',
    'tv': 'TV EN VIVO',
    'youtube': 'YOUTUBE',
    'busqueda': 'BÚSQUEDA'
}

SIDEBAR_INFO = {
    202: ('Películas', 'Explora el contenido de todas las películas del catálogo.'),
    203: ('Series', 'Explora el contenido de todas las series, temporadas y episodios del catálogo.'),
    207: ('Animes', 'Explora series, películas y últimos episodios de anime (simulcasts) del catálogo.'),
    205: ('Doramas', 'Explora doramas coreanos, chinos, japoneses y otras producciones asiáticas del catálogo.'),
    208: ('TV en Vivo', 'Canales de televisión en directo 24/7, agenda deportiva, cine, series, animación, noticias y señales de distintos países.'),
    209: ('YouTube', 'Busca vídeos, tendencias, música, gaming, podcasts, documentales, directos y listas de reproducción de YouTube.'),
    206: ('Configuración', 'Accede a la guía de ayuda (FAQ), configura los interruptores de fuentes disponibles y actualiza el catálogo.'),
}

YOUTUBE_CHIPS = [
    ('trending', 'Todo'),
    ('tendencias', 'Tendencias'),
    ('shorts', 'Shorts'),
    ('music', 'Música'),
    ('gaming', 'Gaming'),
    ('trailers', 'Tráilers'),
    ('podcasts', 'Podcasts'),
    ('news', 'Noticias'),
    ('docs', 'Documentales'),
    ('concerts', 'Conciertos'),
    ('sports', 'Deportes'),
    ('history', 'Recién vistos'),
    ('live', 'En directo'),
]


def obtener_info_barra_lateral(control_id, experimental=False):
    """Devuelve (título, descripción) para el botón enfocado de la barra lateral."""
    if control_id == 201:
        desc = (
            'Búsqueda general de las secciones Series, Películas, Animes y Doramas.'
            if experimental else
            'Búsqueda general de las secciones Series y Películas.'
        )
        return ('Búsqueda', desc)
    if control_id == 204:
        desc = (
            'Estado actual: Activado. Muestra el catálogo completo, fuentes adicionales, Animes, Doramas y selector manual de servidores. Púlsalo para volver al modo normal.'
            if experimental else
            'Estado actual: Desactivado. Usa el catálogo principal y reproducción automática con Premium. Púlsalo para activar el catálogo completo, Animes, Doramas y todos los servidores.'
        )
        return ('Activa/desactiva modo experimental', desc)
    return SIDEBAR_INFO.get(control_id)

def _default_channel_cover():
    candidates = (
        os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'img_channel.jpg'),
        os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'icons', 'icon_tv.png'),
    )
    return next((path for path in candidates if os.path.exists(path)), candidates[0])


def _resolver_portada_canal(cover, fallback=''):
    legacy_paths = {
        os.path.join(ADDON_PATH, 'img_channel.jpg'),
        os.path.join(ADDON_PATH, 'cara_channel.jpg'),
    }
    if not cover or cover in legacy_paths:
        return fallback or _default_channel_cover()
    return cover


def configurar_item_video(item, titulo, thumb="", plot="", year="", rating="", is_dorama=False, is_episode=False, genres=None, mpaa="", duration=0):
    tit_clean = limpiar_texto(titulo)
    plot_clean = limpiar_texto(plot)
    y_clean = limpiar_texto(year)
    r_clean = limpiar_texto(rating)
    mpaa_clean = limpiar_texto(mpaa)

    if not thumb:
        thumb = os.path.join(ADDON_PATH, 'cara_dora_bk.jpg') if is_dorama else os.path.join(ADDON_PATH, 'cara_bk.jpg')

    dur_val = 0
    if duration:
        try:
            dur_val = int(duration)
        except (ValueError, TypeError):
            dur_val = 0

    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(tit_clean)
        if genres: tag.setGenres(genres)
        if plot_clean: tag.setPlot(plot_clean)
        if str(y_clean).isdigit(): tag.setYear(int(y_clean))
        if r_clean:
            try: tag.setRating(float(str(r_clean).replace('★', '').strip()))
            except: pass
        if mpaa_clean:
            try: tag.setMpaa(mpaa_clean)
            except: pass
        if dur_val > 0:
            try: tag.setDuration(dur_val)
            except: pass
    except Exception:
        info = {'title': tit_clean}
        if genres: info['genre'] = genres
        if plot_clean: info['plot'] = plot_clean
        if str(y_clean).isdigit(): info['year'] = int(y_clean)
        if mpaa_clean: info['mpaa'] = mpaa_clean
        if dur_val > 0: info['duration'] = dur_val
        item.setInfo('video', info)

    if thumb:
        item.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    if genres: item.setProperty('genre', ' / '.join(genres))
    if y_clean: item.setProperty('year', str(y_clean))
    if r_clean: item.setProperty('rating', str(r_clean))
    if mpaa_clean: item.setProperty('mpaa', str(mpaa_clean))
    if dur_val > 0: item.setProperty('duration', str(dur_val))
    if is_episode or (re.match(r'^T\d+:E\d+', tit_clean) and any(x in str(thumb).lower() for x in ['/episodio-', '/backdrop-', '/w300/', 'still'])):
        item.setProperty('is_episode', 'true')

class VaquexflixPlayer(xbmc.Player):
    def __init__(self, ui=None, session=0):
        super().__init__()
        self.ui = ui
        self.session = session

    def _event(self, event):
        if self.ui and self.ui.activa:
            self.ui._eventos_player.put((self.session, event))

    def onAVStarted(self):
        self._event('started')

    def onPlayBackEnded(self):
        self._event('ended')

    def onPlayBackStopped(self):
        self._event('stopped')

    def onPlayBackError(self):
        self._event('error')

class MetadataProgress(xbmcgui.WindowXMLDialog):
    _BAR_WIDTH = 600

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.omitted = False
        self.canceled = False
        self._last_progress = (0, 0, None)

    def onInit(self):
        self.setFocusId(501)
        self._render_progress(*self._last_progress)

    def onClick(self, controlId):
        if controlId == 501:
            self.omitted = True
            self.close()
        elif controlId == 502:
            self.canceled = True
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.canceled = True
            self.close()

    def _render_progress(self, done, total, label=None):
        prefix = f'Consultando {label}' if label else 'Consultando resolución e idiomas'
        pct = min(100, max(0, int(round((done / total) * 100)))) if total else 0
        bar_width = min(self._BAR_WIDTH, max(12 if done > 0 else 0, int((self._BAR_WIDTH * done) / total))) if total else 0
        try:
            self.getControl(503).setLabel('{}: {}/{} ({}%)'.format(prefix, done, total, pct))
        except (RuntimeError, AttributeError):
            pass  # La ventana puede estar terminando de abrirse o cerrarse.
        try:
            self.getControl(504).setWidth(bar_width)
        except (RuntimeError, AttributeError):
            pass

    def update(self, done, total, label=None):
        if not self.omitted and not self.canceled:
            self._last_progress = (done, total, label)
            self._render_progress(done, total, label)


class FAQDialog(xbmcgui.WindowXMLDialog):
    def onClick(self, controlId):
        self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in (9, 10, 92, 7, 100, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_SELECT_ITEM):
            self.close()


class VaquexflixUI(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.seccion_actual = "peliculas"
        self.estado = "categorias"
        self.categoria_actual_url = ""
        self.items_actuales = []
        self.items_originales = []
        self.serie_actual = {}
        self.episodios_actuales = []
        self.canales_actuales = []
        self.youtube_videos_actuales = []
        self._tv_cat_cover = ""
        self.episodio_index_actual = -1
        self.temporadas_disponibles = []
        self.episodios_por_temporada = {}

        self.pagina_actual = 1
        self.hay_mas_paginas = True
        self.cargando_mas = False
        self.vistos_urls = set()
        self.pos_anterior = -1
        self.activa = True
        self.reproduciendo_video = False
        self.en_dialogo_salida = False
        self._en_fullscreen = False
        self.session_reproduccion_activa = 0

        self._inicializado = False
        self._last_x_time = 0.0
        self._x_timer = None
        self._eventos_player = queue.Queue()
        self._playback_context = None
        self._closing_session = None
        self._closing_since = 0
        self._closing_warned = False
        self._pending_stream = None
        self._pending_reinit = False
        self._pending_vista_especial = None
        self._pending_manual_selection = None
        self._pending_auto_results = {}
        self._metadata_scanner = None
        self.experimental = ADDON.getSetting('experimental') == 'true'
        self._catalog_generation = 0
        self._av_started = False
        self._last_play_time = 0
        self._last_history_save = 0
        self._start_deadline = 0
        self.player = VaquexflixPlayer(self)
        self.youtube_video_index_actual = -1
        self.youtube_continuation_token = ""
        self.cargando_mas_youtube = False
        self.youtube_random = False
        self.youtube_repeat = 'off'
        self.youtube_modern_ui = ADDON.getSetting('youtube_modern_ui') != 'false'
        self.tv_modern_ui = ADDON.getSetting('tv_modern_ui') != 'false'
        self.tv_chip_actual = 'todo'
        self.tv_tab_actual = 'todo'
        self.tv_canales_actuales = []
        self._tv_next_page_urls = []
        self.cargando_mas_tv = False
        self.youtube_chip_actual = 'trending'
        self.youtube_tab_actual = 'inicio'
        self.youtube_en_shorts = False
        self.youtube_shorts_items = []
        self.youtube_busqueda_actual = ""
        self.youtube_busqueda_sp = ""
        self.youtube_busqueda_tipo = "Todo"

    def _set_prop(self, key, value):
        try:
            if hasattr(self, 'setProperty'):
                self.setProperty(key, value)
        except Exception:
            pass

    def onInit(self):
        if self._inicializado and (self.reproduciendo_video or self._closing_session is not None):
            # Kodi puede disparar GUI_MSG_WINDOW_INIT al volver de pantalla completa
            # mientras aún cierra VideoPlayer; diferir getControl() evita deadlocks.
            self._pending_reinit = True
            return
        self._ejecutar_on_init()

    def _ejecutar_on_init(self):
        self._set_prop('fanart_image', os.path.join(ADDON_PATH, 'fanart.jpg'))
        self._set_prop('experimental_enabled', 'true' if self.experimental else 'false')
        self._set_prop('seccion_actual', self.seccion_actual)
        self._set_prop('sidebar_title', '')
        try:
            self.getControl(204).setSelected(self.experimental)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()
        try:
            self.getControl(500).setVisible(True)
        except Exception:
            pass
        if not self._inicializado:
            self._inicializado = True
            self._set_prop('vista_episodios', '')
            self._set_prop('serie_cover', '')
            try:
                self.getControl(150).reset()
                self.getControl(150).setVisible(False)
                self.getControl(100).setVisible(True)
            except Exception:
                pass
            xbmc.sleep(100)
            self.actualizar_pie_de_pagina()
            pendiente = getattr(self, 'busqueda_pendiente', None)
            if pendiente:
                self.seccion_actual = "busqueda"
                self._set_prop('seccion_actual', "busqueda")
                self.actualizar_etiqueta(f"BÚSQUEDA: {limpiar_texto(pendiente).upper()}")
                self.cargar_elementos(f"search://{urllib.parse.quote_plus(pendiente)}", reset=True)
            else:
                self.cargar_categorias("peliculas")
            threading.Thread(target=self._monitor_scroll_y_foco, daemon=True).start()
            self.comprobar_actualizacion_en_segundo_plano()
            tv_en_vivo.init_background_cache(xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/cache'))
        else:
            self.actualizar_pie_de_pagina()
            if self.estado in ("episodios", "canales", "youtube_videos", "tv_categorias", "youtube_categorias"):
                self._set_prop('vista_episodios', 'true')
                if self.estado == "episodios":
                    cover_dest = self.serie_actual.get('cover', '')
                    items_source = self.episodios_actuales
                elif self.estado == "canales":
                    cover_dest = getattr(self, '_tv_cat_cover', '')
                    items_source = self.canales_actuales
                elif self.estado == "youtube_videos":
                    cover_dest = getattr(self, '_tube_cat_cover', '') or (self.youtube_videos_actuales[0].get('cover', '') if getattr(self, 'youtube_videos_actuales', []) else '')
                    items_source = getattr(self, 'youtube_videos_actuales', [])
                else:
                    cover_dest = getattr(self, '_tv_cat_cover', '') or getattr(self, '_tube_cat_cover', '')
                    items_source = self.elementos

                self._set_prop('serie_cover', cover_dest)
                try:
                    self.getControl(100).setVisible(False)
                    self.getControl(150).setVisible(True)
                except Exception:
                    pass
                lista_ctrl = self.getControl(150)
                if lista_ctrl:
                    if lista_ctrl.size() == 0 and items_source:
                        ui_items = []
                        for ep in items_source:
                            item = xbmcgui.ListItem(label=catalog.display_title(ep) if isinstance(ep, dict) and ('title' in ep or 'nombre' in ep) else str(ep))
                            if self.estado == "episodios" and ep.get('season') is not None:
                                item.setProperty('episode_season', str(ep['season']))
                            if self.estado == "youtube_videos":
                                configurar_item_video(item, ep.get('title', ''), thumb=ep.get('cover', cover_dest), plot=ep.get('plot', ''), rating=ep.get('rating', 'VÍDEO'), is_dorama=False, is_episode=True, duration=0)
                                item.setProperty('is_live', 'true')
                            elif self.estado == 'canales':
                                logo = ep.get('cover', '')
                                if tv_en_vivo.logo_cache_estado(logo) is False:
                                    logo = tv_en_vivo.DEFAULT_CHANNEL_COVER
                                configurar_item_video(item, ep.get('title', ''), thumb=logo, plot=ep.get('plot', ''), is_episode=True)
                                item.setProperty('is_live', 'true')
                                item.setProperty('is_tv_channel', 'true')
                            else:
                                is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(ep)
                                configurar_item_video(item, ep.get('title', ''), thumb=ep.get('cover', ''), plot=ep.get('plot', ''), rating=ep.get('rating', ''), is_dorama=is_dora, is_episode=True, mpaa=ep.get('mpaa', ''), duration=ep.get('duration', 0))
                            ui_items.append(item)
                        position = lista_ctrl.getSelectedPosition()
                        lista_ctrl.addItems(ui_items)
                        if position >= 0:
                            lista_ctrl.selectItem(position)
                    self.setFocus(lista_ctrl)
                    pos = self.pos_anterior
                    if self.estado == "youtube_videos" and getattr(self, 'youtube_video_index_actual', -1) >= 0:
                        pos = self.youtube_video_index_actual
                    if 0 <= pos < lista_ctrl.size():
                        try: lista_ctrl.selectItem(pos)
                        except Exception: pass
                    if 0 <= pos < len(items_source):
                        self._actualizar_sinopsis_de_elemento(items_source[pos])
            else:
                self._set_prop('vista_episodios', '')
                try:
                    self.getControl(150).setVisible(False)
                    self.getControl(100).setVisible(True)
                except Exception:
                    pass
                lista_ctrl = self.getControl(100)
                if lista_ctrl:
                    self.setFocus(lista_ctrl)
                    if 0 <= self.pos_anterior < lista_ctrl.size():
                        try: lista_ctrl.selectItem(self.pos_anterior)
                        except Exception: pass

    def _actualizar_navegacion_lateral(self):
        try:
            ctrl_faq = self.getControl(206)
        except Exception:
            ctrl_faq = None
        try:
            ctrl_animes = self.getControl(207)
        except Exception:
            ctrl_animes = None
        try:
            ctrl_doramas = self.getControl(205)
        except Exception:
            ctrl_doramas = None
        try:
            ctrl_tv = self.getControl(208)
        except Exception:
            ctrl_tv = None
        try:
            ctrl_yt = self.getControl(209)
        except Exception:
            ctrl_yt = None

        nova_anime_normal = not self.experimental and (source_switches.only_enabled('nova') or source_switches.enabled('fxpplus'))
        if self.experimental or nova_anime_normal:
            if ctrl_animes:
                ctrl_animes.setVisible(True)
                try: ctrl_animes.setPosition(0, 180)
                except Exception: pass
            if ctrl_doramas:
                ctrl_doramas.setVisible(self.experimental)
                if self.experimental:
                    try: ctrl_doramas.setPosition(0, 240)
                    except Exception: pass
                else:
                    ctrl_doramas = None
            if ctrl_tv:
                try: ctrl_tv.setPosition(0, 300 if self.experimental else 240)
                except Exception: pass
            if ctrl_yt:
                try: ctrl_yt.setPosition(0, 360 if self.experimental else 300)
                except Exception: pass

            # Cadena vertical en modo experimental: 201 -> 202 -> 203 -> 207 -> 205 -> 208 -> 209 -> 206 -> 204
            self.getControl(203).controlDown(ctrl_animes or ctrl_doramas or ctrl_tv or ctrl_yt or ctrl_faq)
            if ctrl_animes:
                ctrl_animes.controlUp(self.getControl(203))
                ctrl_animes.controlDown(ctrl_doramas or ctrl_tv or ctrl_yt or ctrl_faq)
            if ctrl_doramas:
                ctrl_doramas.controlUp(ctrl_animes or self.getControl(203))
                ctrl_doramas.controlDown(ctrl_tv or ctrl_yt or ctrl_faq)
            if ctrl_tv:
                ctrl_tv.controlUp(ctrl_doramas or ctrl_animes or self.getControl(203))
                ctrl_tv.controlDown(ctrl_yt or ctrl_faq)
            if ctrl_yt:
                ctrl_yt.controlUp(ctrl_tv or ctrl_doramas or ctrl_animes or self.getControl(203))
                ctrl_yt.controlDown(ctrl_faq or self.getControl(204))
            last_cat_ctrl = ctrl_yt or ctrl_tv or ctrl_doramas or ctrl_animes or self.getControl(203)
        else:
            if ctrl_animes:
                ctrl_animes.setVisible(False)
            if ctrl_doramas:
                ctrl_doramas.setVisible(False)
            if ctrl_tv:
                try: ctrl_tv.setPosition(0, 180)
                except Exception: pass
            if ctrl_yt:
                try: ctrl_yt.setPosition(0, 240)
                except Exception: pass

            # Cadena vertical en modo normal: 201 -> 202 -> 203 -> 208 (TV) -> 209 (YT) -> 206 -> 204
            self.getControl(203).controlDown(ctrl_tv or ctrl_yt or ctrl_faq)
            if ctrl_tv:
                ctrl_tv.controlUp(self.getControl(203))
                ctrl_tv.controlDown(ctrl_yt or ctrl_faq)
            if ctrl_yt:
                ctrl_yt.controlUp(ctrl_tv or self.getControl(203))
                ctrl_yt.controlDown(ctrl_faq or self.getControl(204))
            last_cat_ctrl = ctrl_yt or ctrl_tv or self.getControl(203)

        if ctrl_faq:
            ctrl_faq.controlUp(last_cat_ctrl)
            ctrl_faq.controlDown(self.getControl(204))
            self.getControl(204).controlUp(ctrl_faq)
        else:
            self.getControl(204).controlUp(last_cat_ctrl)

        target_container = self.getControl(150) if self.estado in ("episodios", "canales", "youtube_videos", "tv_categorias", "youtube_categorias") else self.getControl(100)
        for cid in (201, 202, 203, 204, 205, 206, 207, 208, 209):
            try:
                self.getControl(cid).controlRight(target_container)
            except Exception:
                pass
        try:
            active_btn_id = 209 if self.seccion_actual == "youtube" else (208 if self.seccion_actual == "tv" else (205 if (self.experimental and self.seccion_actual == "doramas") else (207 if ((self.experimental or nova_anime_normal) and self.seccion_actual == "animes") else (203 if self.seccion_actual == "series" else 202))))
            self.getControl(150).controlLeft(self.getControl(active_btn_id))
        except Exception:
            pass

    def comprobar_actualizacion_en_segundo_plano(self):
        def _worker():
            try:
                xbmc.sleep(3500)
                url_ver = "https://fmono90.github.io/vaquexflix-addon/version.json"
                req = urllib.request.Request(url_ver, headers={'User-Agent': UA})
                with urllib.request.urlopen(req, timeout=6, context=_ssl_ctx) as r:
                    info = json.loads(r.read().decode('utf-8'))

                ver_remota = info.get('version', '')
                ver_local = ADDON.getAddonInfo('version')

                def _tupla_v(v):
                    base, beta, suffix = str(v).partition('~')
                    return (tuple(map(int, re.findall(r'\d+', base))), not beta,
                            tuple(map(int, re.findall(r'\d+', suffix))))

                if ver_remota and _tupla_v(ver_remota) > _tupla_v(ver_local):
                    diag = xbmcgui.Dialog()
                    resp = diag.yesno(
                        "Vaquexflix",
                        f"Hay una actualizacion disponible: v{ver_remota} (actual: v{ver_local}).\n¿Deseas actualizar ahora?",
                        yeslabel="Actualizar",
                        nolabel="Despues"
                    )
                    if resp:
                        zip_url = info.get('zip_url', '')
                        if zip_url:
                            self._instalar_actualizacion_zip(zip_url, ver_remota)
            except Exception:
                pass

        threading.Thread(target=_worker, daemon=True).start()

    def _instalar_actualizacion_zip(self, zip_url, nueva_version):
        prog = xbmcgui.DialogProgress()
        prog.create("Vaquexflix", "Descargando actualizacion...")
        try:
            dest_zip = xbmcvfs.translatePath('special://temp/vaquexflix_update.zip')
            req = urllib.request.Request(zip_url, headers={'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx) as r, open(dest_zip, 'wb') as f:
                tam_total = int(r.headers.get('Content-Length', 0))
                leido = 0
                while True:
                    chunk = r.read(65536)
                    if not chunk: break
                    f.write(chunk)
                    leido += len(chunk)
                    if tam_total > 0:
                        pct = int((leido / tam_total) * 100)
                        prog.update(pct, f"Descargando v{nueva_version}... ({pct}%)")

            prog.update(100, "Instalando actualizacion...")
            addons_dir = xbmcvfs.translatePath('special://home/addons/')
            import zipfile
            with zipfile.ZipFile(dest_zip, 'r') as z:
                z.extractall(addons_dir)

            try: os.remove(dest_zip)
            except Exception: pass

            prog.close()
            try: xbmc.executebuiltin('UpdateLocalAddons')
            except Exception: pass
            xbmcgui.Dialog().ok("Vaquexflix", f"¡Actualizado con éxito a v{nueva_version}!\nEl complemento se cerrará para cargar la nueva versión.")
            self.activa = False
            self.close()
        except Exception:
            prog.close()
            xbmcgui.Dialog().notification("Vaquexflix", "Error al descargar actualizacion", xbmcgui.NOTIFICATION_ERROR, 2000)

    def _pausar_para_dialogo(self):
        was_paused = xbmc.getCondVisibility('Player.Paused')
        if self.player.isPlayingVideo() and not was_paused:
            xbmc.executebuiltin('PlayerControl(Play)', False)
            return True
        return False

    def _mostrar_dialogo_control_reproductor(self, detenido=False):
        if self.en_dialogo_salida or not self.activa or not self._playback_context:
            return
        self.en_dialogo_salida = True
        session = self.session_reproduccion_activa
        paused_here = False
        action = 'continuar'
        try:
            if not detenido:
                paused_here = self._pausar_para_dialogo()
            diag = xbmcgui.Dialog()
            is_tube = bool(self._playback_context and self._playback_context.get('is_youtube'))
            is_live_or_tv = bool(self._playback_context and (self._playback_context.get('is_tv') or self._playback_context.get('is_live')))
            idx = self.episodio_index_actual
            y_idx = getattr(self, 'youtube_video_index_actual', -1)
            y_vids = getattr(self, 'youtube_videos_actuales', [])

            if is_tube and y_idx >= 0 and len(y_vids) > 1:
                while self.activa:
                    is_rand = bool(getattr(self, 'youtube_random', False))
                    rep_mode = getattr(self, 'youtube_repeat', 'off')
                    rep_str = "Repetir uno (1)" if rep_mode == 'one' else ("Repetir todo (Lista)" if rep_mode == 'all' else "Desactivada")
                    rand_str = "ACTIVADA" if is_rand else "DESACTIVADA"

                    opciones = ['Continuar viendo']
                    acciones = ['continuar']

                    if is_rand:
                        opciones.append('Siguiente vídeo (Aleatorio)')
                        acciones.append('siguiente_yt')
                    elif y_idx + 1 < len(y_vids):
                        opciones.append('Siguiente vídeo: ' + y_vids[y_idx + 1]['title'])
                        acciones.append('siguiente_yt')
                    elif rep_mode == 'all':
                        opciones.append('Siguiente vídeo: ' + y_vids[0]['title'])
                        acciones.append('siguiente_yt')

                    if not is_rand and y_idx > 0:
                        opciones.append('Vídeo anterior: ' + y_vids[y_idx - 1]['title'])
                        acciones.append('anterior_yt')
                    elif not is_rand and rep_mode == 'all':
                        opciones.append('Vídeo anterior: ' + y_vids[-1]['title'])
                        acciones.append('anterior_yt')

                    opciones.append('Ver lista de reproducción (en pantalla)')
                    acciones.append('ver_playlist')

                    opciones.append(f'Reproducción aleatoria: [{rand_str}]')
                    acciones.append('toggle_random')

                    opciones.append(f'Repetición: [{rep_str}]')
                    acciones.append('toggle_repeat')

                    opciones.append('Salir del reproductor')
                    acciones.append('salir')

                    cur_title = y_vids[y_idx]['title'] if 0 <= y_idx < len(y_vids) else 'YouTube'
                    sel = diag.select('Vaquexflix - ' + cur_title, opciones)

                    if sel < 0 or sel >= len(acciones) or acciones[sel] == 'continuar':
                        action = 'continuar'
                        break
                    elif acciones[sel] == 'salir':
                        action = 'salir'
                        break
                    elif acciones[sel] in ('siguiente_yt', 'anterior_yt', 'ver_playlist'):
                        action = acciones[sel]
                        break
                    elif acciones[sel] == 'toggle_random':
                        self.youtube_random = not is_rand
                        xbmcgui.Dialog().notification('Playlist YouTube', 'Modo aleatorio: ' + ('ACTIVADO' if self.youtube_random else 'DESACTIVADO'), xbmcgui.NOTIFICATION_INFO, 1500)
                    elif acciones[sel] == 'toggle_repeat':
                        cycle = {'off': 'all', 'all': 'one', 'one': 'off'}
                        self.youtube_repeat = cycle.get(rep_mode, 'off')
                        n_rep = "Repetir uno (1)" if self.youtube_repeat == 'one' else ("Repetir todo (Lista)" if self.youtube_repeat == 'all' else "Desactivada")
                        xbmcgui.Dialog().notification('Playlist YouTube', f'Repetición: {n_rep}', xbmcgui.NOTIFICATION_INFO, 1500)
            elif not is_tube and not is_live_or_tv and 0 <= idx < len(self.episodios_actuales):
                opciones = ['Continuar viendo']
                acciones = ['continuar']
                if self._playback_context.get('catalog_item'):
                    opciones.append('Cambiar servidor')
                    acciones.append('cambiar_servidor')
                if idx + 1 < len(self.episodios_actuales):
                    opciones.append('Siguiente capítulo: ' + self.episodios_actuales[idx + 1]['title'])
                    acciones.append('siguiente')
                if idx > 0:
                    opciones.append('Capítulo anterior: ' + self.episodios_actuales[idx - 1]['title'])
                    acciones.append('anterior')
                opciones.append('Salir del reproductor')
                acciones.append('salir')
                sel = diag.select('Vaquexflix - ' + self.episodios_actuales[idx]['title'], opciones)
                if 0 <= sel < len(acciones):
                    action = acciones[sel]
            elif not is_tube and not is_live_or_tv:
                opciones = ['Continuar viendo']
                acciones = ['continuar']
                if self._playback_context.get('catalog_item'):
                    opciones.append('Cambiar servidor')
                    acciones.append('cambiar_servidor')
                opciones.append('Salir del reproductor')
                acciones.append('salir')
                sel = diag.select('Vaquexflix - ' + self._playback_context['history']['title'], opciones)
                if 0 <= sel < len(acciones):
                    action = acciones[sel]
            elif diag.yesno('Vaquexflix', '¿Deseas salir del reproductor de video?',
                            yeslabel='Salir', nolabel='Continuar'):
                action = 'salir'
            if not self.activa or session != self.session_reproduccion_activa:
                return
            if action == 'salir':
                self.detener_reproduccion()
            elif action == 'ver_playlist':
                labels = [
                    ('> ' if i == y_idx else '   ') + tube_engine.clean_emojis(v.get('title', 'YouTube'))
                    for i, v in enumerate(y_vids)
                ]
                chosen = diag.select('Lista de reproducción - YouTube', labels)
                if 0 <= chosen < len(y_vids) and chosen != y_idx:
                    self._reproducir_youtube_indice(chosen)
                else:
                    if paused_here and xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)', False)
                    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    self._en_fullscreen = False
            elif action in ('siguiente', 'anterior'):
                target = idx + (1 if action == 'siguiente' else -1)
                self.detener_reproduccion()
                self.reproducir_episodio_por_indice(target)
            elif action == 'cambiar_servidor':
                if not self._cambiar_servidor():
                    if paused_here and xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)', False)
                    if self.player.isPlayingVideo():
                        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                        self._en_fullscreen = False
            elif action == 'siguiente_yt':
                target = self._siguiente_indice_youtube(direction=1)
                if target is not None and self._reproducir_youtube_indice(target):
                    pass
                else:
                    if paused_here and xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)', False)
                    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    self._en_fullscreen = False
            elif action == 'anterior_yt':
                target = self._siguiente_indice_youtube(direction=-1)
                if target is not None and self._reproducir_youtube_indice(target):
                    pass
                else:
                    if paused_here and xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)', False)
                    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    self._en_fullscreen = False
            elif detenido:
                self._iniciar_stream(self._playback_context, self._last_play_time)
            else:
                if paused_here and xbmc.getCondVisibility('Player.Paused'):
                    xbmc.executebuiltin('PlayerControl(Play)', False)
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                self._en_fullscreen = False
        finally:
            self.en_dialogo_salida = False

    def _cambiar_servidor(self):
        """Elige una fuente activa y espera el cierre de Kodi antes de iniciarla."""
        context = self._playback_context
        item = context.get('catalog_item') if context else None
        if not item or not self.activa:
            return False
        cached_servers = list(context.get('all_manual_servers') or context.get('manual_servers') or [])
        if cached_servers:
            base_servers = [server for server in cached_servers if source_switches.allowed(server)]
        else:
            progress = xbmcgui.DialogProgress()
            progress.create('Vaquexflix', 'Buscando servidores activos…')
            try:
                waiter = playback.progress_waiter(
                    progress, lambda: self.activa, 'Buscando servidores activos…', 8, 92, 5.0)
                servers_raw = playback.request_with_progress(
                    lambda: catalog.servers(item, True, context.get('catalog_series')),
                    network.presupuesto_resolucion,
                    waiter)
                progress.update(100, 'Servidores listos')
            except playback.Cancelled:
                return False
            except Exception as exc:
                xbmc.log('Vaquexflix: cambio de servidor: ' + type(exc).__name__, xbmc.LOGWARNING)
                xbmcgui.Dialog().notification('Vaquexflix', 'No se pudo consultar los servidores activos.',
                                              xbmcgui.NOTIFICATION_WARNING, 6000)
                return False
            finally:
                progress.close()
            base_servers = [server for server in (servers_raw or []) if source_switches.allowed(server)]
        if not base_servers:
            xbmcgui.Dialog().notification('Vaquexflix', 'No hay otros servidores de fuentes activas.',
                                          xbmcgui.NOTIFICATION_WARNING, 6000)
            return False
        current = context.get('server_key')
        servers = [server for server in base_servers
                   if stream_metadata.cache_key(server['url']) != current]
        if not servers:
            xbmcgui.Dialog().notification('Vaquexflix', 'No hay otro servidor disponible.',
                                          xbmcgui.NOTIFICATION_INFO, 5000)
            return False

        selector_fn = globals().get('_elegir_con_sondeo_incremental')
        cache_loader = globals().get('_cargar_calidad_cacheada')
        item_key = context.get('item_key') or (
            stream_metadata.item_key(item, context.get('catalog_series'))
            if hasattr(stream_metadata, 'item_key') else '')
        session_quality = dict(context.get('session_quality') or {})
        if selector_fn is not None and cache_loader is not None:
            quality_cache = cache_loader(servers, item_key, session_quality)
            result, labels = selector_fn(
                self, servers, context['history']['title'], item_key,
                quality_cache, xbmcgui.Dialog(), xbmcgui.DialogProgress,
                allow_upfront_cancel=True)
            session_quality.update(quality_cache)
            context['all_manual_servers'] = base_servers
            context['session_quality'] = session_quality
            if item_key:
                context['item_key'] = item_key
        else:
            labels = [resolvers.etiqueta_servidor(server, 'Sin verificar') + ' | ' +
                      stream_metadata.audio_label({}, server) for server in servers]
            result = elegir_servidor_con_reintentos(
                servers, labels, context['history']['title'], xbmcgui.Dialog(),
                xbmcgui.DialogProgress, lambda: self.activa)
        if result is None:
            return False
        index, stream = result
        try:
            offset = self.player.getTime() if self.player.isPlayingVideo() else self._last_play_time
        except Exception:
            offset = self._last_play_time
        self._last_play_time = max(0, offset)
        updated = dict(context, stream=stream, manual_servers=servers, manual_labels=labels,
                       all_manual_servers=base_servers, session_quality=session_quality,
                       item_key=item_key, manual_index=index, fallback_servers=[], lazy_fallback=False,
                       fallback_item=None, fallback_series=None,
                       server_key=stream_metadata.cache_key(servers[index]['url']),
                       quality=resolvers.CALIDADES_HLS.get(stream.split('|')[0], ''),
                       quality_saved=False)
        self.detener_reproduccion()
        self._iniciar_stream(updated, self._last_play_time)
        return True

    def procesar_eventos_player(self):
        """Un solo consumidor para callbacks, dialogos y progreso de reproduccion."""
        while not self._eventos_player.empty():
            session, event = self._eventos_player.get_nowait()
            if event == 'auto_fallback_ready':
                result = getattr(self, '_pending_auto_results', {}).pop(session, None)
                if result and session == self.session_reproduccion_activa and self.activa:
                    _, updated, offset = result
                    if updated:
                        self._iniciar_stream(updated, offset)
                    else:
                        xbmcgui.Dialog().notification('Vaquexflix', 'No se pudo reproducir este contenido', xbmcgui.NOTIFICATION_WARNING, 6000)
                continue
            if session == self._closing_session and event in ('stopped', 'ended', 'error'):
                playback.stop_close_diagnostic()
                xbmc.log('Vaquexflix: cierre confirmado de sesion {}'.format(session), xbmc.LOGINFO)
                self._closing_session = None
                pending, self._pending_stream = self._pending_stream, None
                if pending:
                    self._iniciar_stream(*pending)
                elif self._pending_manual_selection:
                    self._reanudar_selector_servidores()
                continue
            if session != self.session_reproduccion_activa or not self.reproduciendo_video:
                continue
            if event == 'started':
                self._av_started = True
                self._start_deadline = 0
            elif event == 'error' or (event in ('ended', 'stopped') and not self._av_started):
                if self._reintentar_servidor():
                    continue
                manual = dict(self._playback_context) if self._playback_context and self._playback_context.get('manual_servers') else None
                self.reproduciendo_video = False
                self.detener_reproduccion()
                if manual:
                    self._pending_manual_selection = manual
                xbmcgui.Dialog().notification('Vaquexflix', 'El servidor no pudo iniciar el video. Elige otro servidor.', xbmcgui.NOTIFICATION_ERROR)
                if manual and self._closing_session is None:
                    self._reanudar_selector_servidores()
            elif event == 'stopped':
                self.reproduciendo_video = False
                self._en_fullscreen = False
                if self._playback_context and (self._playback_context.get('is_live') or self._playback_context.get('is_youtube') or self._playback_context.get('is_tv')):
                    self.detener_reproduccion()
                    continue
                self._guardar_progreso()
                self._mostrar_dialogo_control_reproductor(detenido=True)
            elif event == 'ended':
                if self._playback_context and self._playback_context.get('is_youtube') and not self._playback_context.get('is_live'):
                    next_idx = self._siguiente_indice_youtube(direction=1, auto=True)
                    if next_idx is not None and self._reproducir_youtube_indice(next_idx):
                        continue
                self.reproduciendo_video = False
                self._en_fullscreen = False
                if self._playback_context and (self._playback_context.get('is_live') or self._playback_context.get('is_youtube') or self._playback_context.get('is_tv')):
                    self.detener_reproduccion()
                    continue
                self._guardar_progreso(finalizado=True)
                self.on_playback_ended()
        self._comprobar_cierre_player()
        self._procesar_foco_pendiente()
        if not self.reproduciendo_video or self.en_dialogo_salida:
            return
        if not self._av_started:
            # El selector de calidad de ISA precede a onAVStarted. El tiempo
            # que el usuario dedica a elegir no es una espera del servidor.
            if self._playback_context.get('ask_quality') and xbmc.getCondVisibility('System.HasModalDialog'):
                self._start_deadline = time.monotonic() + 45
                return
            if self._start_deadline and time.monotonic() > self._start_deadline:
                if self._reintentar_servidor():
                    return
                self.detener_reproduccion()
                xbmcgui.Dialog().notification('Vaquexflix', 'El servidor no entrego el video a tiempo. Prueba otro servidor.', xbmcgui.NOTIFICATION_ERROR, 6000)
            return
        if self.player.isPlayingVideo():
            try:
                self._last_play_time = self.player.getTime()
                self._playback_context['total'] = self.player.getTotalTime()
                if self._playback_context.get('server_key') and not self._playback_context.get('quality_saved'):
                    verified_quality = self._playback_context.get('quality')
                    if verified_quality:
                        data = cargar_userdata()
                        entry = data.setdefault('server_quality', {}).setdefault(self._playback_context['server_key'], {})
                        item_k = self._playback_context.get('item_key', '')
                        if not (entry.get('playable') and (not item_k or entry.get('item_key') == item_k)):
                            entry.update({'label': verified_quality, 'updated': time.time(),
                                          'playable': True})
                            if item_k:
                                entry['item_key'] = item_k
                            guardar_userdata(data)
                    self._playback_context['quality_saved'] = True
                if time.monotonic() - self._last_history_save >= 5:
                    self._guardar_progreso()
            except RuntimeError:
                pass
            is_fs = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            is_osd = xbmc.getCondVisibility('Window.IsActive(videoosd)')
            is_pl = xbmc.getCondVisibility('Window.IsActive(videoplaylist)')
            is_settings = xbmc.getCondVisibility('Window.IsActive(osdvideosettings) | Window.IsActive(osdaudiosettings) | Window.IsActive(osdsubtitlesettings)')
            if is_fs or is_osd or is_pl or is_settings:
                self._en_fullscreen = True
            elif self._en_fullscreen and not xbmc.getCondVisibility('System.HasModalDialog'):
                self._en_fullscreen = False
                self._mostrar_dialogo_control_reproductor()

    def _reintentar_servidor(self):
        """Consume remaining automatic candidates after a player error/timeout."""
        context = self._playback_context
        remaining = list(context.get('fallback_servers', []))
        if not remaining and context.get('lazy_fallback') and self.activa:
            context['lazy_fallback'] = False
            offset = self._last_play_time
            self.detener_reproduccion()
            session = self.session_reproduccion_activa
            threading.Thread(target=self._cargar_alternativa_normal,
                             args=(dict(context), offset, session), daemon=True).start()
            return True
        if not remaining or not self.activa:
            return False
        offset = self._last_play_time
        self.detener_reproduccion()
        while remaining and self.activa:
            server = remaining.pop(0)
            context['fallback_servers'] = list(remaining)
            try:
                stream = playback.request_with_progress(
                    lambda url=server['url']: resolvers.resolver_stream(url),
                    network.presupuesto_resolucion,
                    lambda: self.activa)
            except playback.Cancelled:
                context['fallback_servers'] = []
                return True
            except Exception as exc:
                xbmc.log('Vaquexflix: fallo en alternativa: ' + type(exc).__name__, xbmc.LOGWARNING)
                continue
            if stream:
                updated = dict(context, stream=stream,
                    server_key=stream_metadata.cache_key(server['url']),
                    quality=resolvers.CALIDADES_HLS.get(stream.split('|')[0], ''),
                    quality_saved=False, fallback_servers=list(remaining))
                self._iniciar_stream(updated, offset)
                return True
        if not self.activa:
            context['fallback_servers'] = []
            return True
        return False

    def _cargar_alternativa_normal(self, context, offset, session):
        """Discover fallback sources off the UI thread after Premium fails to start."""
        updated = None
        try:
            deadline = time.monotonic() + 45
            tried = set()
            if context.get('attempted_premium_url'):
                tried.add(context['attempted_premium_url'])
            with network.presupuesto_resolucion(deadline, threading.Event()):
                for exp_flag in (False, True):
                    raw_servers = catalog.servers(
                        context['fallback_item'], exp_flag, context.get('fallback_series'))
                    candidates = [
                        srv for srv in ordenar_alternativas_normales(
                            raw_servers, context.get('attempted_premium_url', ''))
                        if srv.get('url') not in tried
                    ]
                    for index, server in enumerate(candidates):
                        if not self.activa or session != self.session_reproduccion_activa:
                            return
                        tried.add(server['url'])
                        try:
                            stream = resolvers.resolver_stream(server['url'])
                        except Exception as exc:
                            xbmc.log('Vaquexflix: alternativa no disponible: ' + type(exc).__name__, xbmc.LOGWARNING)
                            continue
                        if stream:
                            updated = dict(context, stream=stream,
                                server_key=stream_metadata.cache_key(server['url']),
                                quality=resolvers.CALIDADES_HLS.get(stream.split('|')[0], ''),
                                quality_saved=False, fallback_servers=candidates[index + 1:],
                                fallback_item=None, fallback_series=None)
                            break
                    if updated:
                        break
        except Exception as exc:
            xbmc.log('Vaquexflix: busqueda de alternativas no disponible: ' + type(exc).__name__, xbmc.LOGWARNING)
        self._pending_auto_results[session] = (session, updated, offset)
        self._eventos_player.put((session, 'auto_fallback_ready'))

    def _reanudar_selector_servidores(self):
        context, self._pending_manual_selection = self._pending_manual_selection, None
        if not context or not self.activa:
            return
        servers = context['manual_servers']
        labels = list(context['manual_labels'])
        session_quality = dict(context.get('session_quality') or {})
        item_key = context.get('item_key', '')
        invalidate = globals().get('_invalidar_calidad_servidor')
        format_lbl = globals().get('_formatear_etiqueta_servidor')
        failed_idx = context.get('manual_index')
        if isinstance(failed_idx, int) and 0 <= failed_idx < len(servers) and invalidate and format_lbl:
            failed_srv = servers[failed_idx]
            invalidate(failed_srv.get('url', ''), 'No disponible: no pudo iniciar la reproducción',
                       item_key, session_quality)
            labels[failed_idx] = format_lbl(
                failed_srv, session_quality.get(stream_metadata.cache_key(failed_srv['url'])))

        def on_error(indice, servidor, error):
            if invalidate and format_lbl:
                invalidate(servidor.get('url', ''), error, item_key, session_quality)
                labels[indice] = format_lbl(
                    servidor, session_quality.get(stream_metadata.cache_key(servidor['url'])))

        result = elegir_servidor_con_reintentos(
            servers, labels, context['history']['title'],
            xbmcgui.Dialog(), xbmcgui.DialogProgress, lambda: self.activa,
            indice_preferido=failed_idx,
            on_error=on_error if invalidate and format_lbl else None)
        if result is None:
            return
        index, stream = result
        updated = dict(context, stream=stream, manual_labels=labels, session_quality=session_quality,
                       server_key=stream_metadata.cache_key(servers[index]['url']),
                       quality=resolvers.CALIDADES_HLS.get(stream.split('|')[0], ''),
                       quality_saved=False, manual_index=index)
        self._iniciar_stream(updated, self._last_play_time)

    def _comprobar_cierre_player(self):
        if self._closing_session is None:
            return
        elapsed = time.monotonic() - self._closing_since
        if elapsed < 1.5:
            return
        if not self.player.isPlaying():
            playback.stop_close_diagnostic()
            # Kodi can stop without delivering its terminal callback to Python.
            self._closing_session = None
            pending, self._pending_stream = self._pending_stream, None
            if pending and self.activa:
                self._iniciar_stream(*pending)
            elif getattr(self, '_pending_manual_selection', None) and self.activa:
                self._reanudar_selector_servidores()
        elif elapsed >= 15 and not self._closing_warned:
            self._closing_warned = True
            self._pending_stream = None
            xbmc.log('Vaquexflix: Kodi sigue cerrando el video tras 15 segundos', xbmc.LOGWARNING)
            if self.activa:
                xbmcgui.Dialog().notification('Vaquexflix', 'Kodi sigue cerrando el video anterior. Intenta abrir otro servidor cuando termine.', xbmcgui.NOTIFICATION_WARNING, 6000)

    def _guardar_progreso(self, finalizado=False):
        ctx = self._playback_context
        if not ctx or ctx.get('is_live') or ctx.get('is_youtube') or ctx.get('is_tv'):
            return
        url_check = str(ctx.get('url_norm', '')).lower()
        if 'youtube.com' in url_check or 'googlevideo.com' in url_check or url_check.startswith('tube://') or url_check.startswith('tv://'):
            return
        data = cargar_userdata()
        history = data.setdefault('historial', {})
        for alias in ctx.get('history_aliases', []):
            if alias != ctx['url_norm']:
                history.pop(alias, None)
        if finalizado:
            history[ctx['url_norm']] = dict(ctx['history'], time=0, total=int(ctx.get('total', 0)), completed=True, updated=time.time())
        else:
            history[ctx['url_norm']] = dict(ctx['history'], time=int(self._last_play_time), total=int(ctx.get('total', 0)), updated=time.time())
        guardar_userdata(data)
        self._last_history_save = time.monotonic()

    def _iniciar_stream(self, context, offset=0):
        if not self.activa:
            return
        if self._closing_session is not None:
            self._pending_stream = (context, offset)
            xbmcgui.Dialog().notification('Vaquexflix', 'Esperando el cierre del video anterior...', xbmcgui.NOTIFICATION_INFO)
            return
        if self.reproduciendo_video:
            self.detener_reproduccion()
            if self._closing_session is not None:
                self._pending_stream = (context, offset)
                return
        self.session_reproduccion_activa += 1
        self._playback_context = context
        self._last_play_time = offset
        self._av_started = False
        self._en_fullscreen = False
        self.reproduciendo_video = True
        self._pending_vista_especial = None
        self._start_deadline = time.monotonic() + 45
        self.player = VaquexflixPlayer(self, self.session_reproduccion_activa)
        item = xbmcgui.ListItem(label=catalog.display_title(context['history']))
        is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama({'url': context.get('url_norm', '')})
        configurar_item_video(item, context['history']['title'], thumb=context['history']['cover'], plot=context['history']['plot'], is_dorama=is_dora)
        item.setProperty('IsPlayable', 'true')
        if context.get('playlist'):
            self._guardar_progreso()
            try:
                self.player.play(item=context['playlist'], startpos=offset)
            except Exception as exc:
                xbmc.log('Vaquexflix: no se pudo iniciar playlist: ' + type(exc).__name__, xbmc.LOGERROR)
                self._eventos_player.put((self.session_reproduccion_activa, 'error'))
            return
        if offset > 0:
            item.setProperty('StartOffset', str(offset))
        try:
            major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        except (ValueError, IndexError):
            major = 20
        adaptive = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
        hls_quality_mode = ADDON.getSetting('hls_quality')
        ask_quality = hls_quality_mode == '1'
        context['ask_quality'] = False
        is_tv_stream = bool(context.get('is_tv', False))
        stream = playback.configure_stream(item, context['stream'], UA, adaptive, major, ask_quality=ask_quality, hls_quality=hls_quality_mode, is_tv=is_tv_stream)
        self._guardar_progreso()
        try:
            self.player.play(stream, item)
        except Exception as exc:
            xbmc.log('Vaquexflix: no se pudo iniciar el reproductor: ' + type(exc).__name__, xbmc.LOGERROR)
            self._eventos_player.put((self.session_reproduccion_activa, 'error'))

    def _monitor_scroll_y_foco(self):
        while self.activa and not xbmc.Monitor().abortRequested():
            if self.reproduciendo_video or self._closing_session is not None:
                xbmc.sleep(250)
                continue
            try:
                lista_ctrl = self.getControl(150 if self.estado in ("episodios", "canales", "youtube_videos", "tv_categorias", "youtube_categorias") else 100)
                if lista_ctrl:
                    pos = lista_ctrl.getSelectedPosition()
                    tot = lista_ctrl.size()

                    # 2. Deteccion de cambio de foco para actualizar sinopsis real en ID 303
                    if pos != self.pos_anterior and 0 <= pos < len(self.items_actuales):
                        self.pos_anterior = pos
                        sel = self.items_actuales[pos]
                        self._actualizar_sinopsis_de_elemento(sel)

                    # 3. Scroll infinito continuo
                    if self.estado == "elementos" and self.hay_mas_paginas and not self.cargando_mas:
                        if not self.categoria_actual_url.startswith("local://") and not self.categoria_actual_url.startswith("search://"):
                            if tot > 0 and pos >= (tot - 18):
                                self.cargar_siguiente_pagina()

                    # 4. Scroll infinito en YouTube (categorías y búsquedas)
                    if self.estado == "youtube_videos" and getattr(self, 'youtube_continuation_token', '') and not getattr(self, 'cargando_mas_youtube', False):
                        if tot > 0 and pos >= (tot - 8):
                            self.cargar_siguiente_pagina_youtube()

                    # 5. Scroll infinito en YouTube moderno (cuadrícula 900 y shorts 950)
                    if self.estado == "youtube_moderno" and getattr(self, 'youtube_continuation_token', '') and not getattr(self, 'cargando_mas_youtube', False):
                        ctrl_ym = self.getControl(950 if getattr(self, 'youtube_en_shorts', False) else 900)
                        if ctrl_ym:
                            tot_ym = ctrl_ym.size()
                            pos_ym = ctrl_ym.getSelectedPosition()
                            if tot_ym > 0 and pos_ym >= (tot_ym - 8):
                                self.cargar_siguiente_pagina_youtube_moderno()

                    # 6. Scroll infinito en TV en Vivo moderno (cuadrícula 1400)
                    if self.estado == "tv_moderno" and getattr(self, '_tv_next_page_urls', []) and not getattr(self, 'cargando_mas_tv', False):
                        ctrl_tv = self.getControl(1400)
                        if ctrl_tv:
                            tot_tv = ctrl_tv.size()
                            pos_tv = ctrl_tv.getSelectedPosition()
                            if tot_tv > 0 and pos_tv >= (tot_tv - 8):
                                self.cargar_siguiente_pagina_tv()
            except Exception: pass
            xbmc.sleep(250)

    def _actualizar_sinopsis_de_elemento(self, sel):
        def display():
            parts = []
            if sel.get('rating'): parts.append(f"★ {sel['rating']}")
            if sel.get('year'): parts.append(str(sel['year']))
            if sel.get('mpaa'): parts.append(str(sel['mpaa']))
            if sel.get('duration'):
                mins = int(sel['duration']) // 60
                if mins > 0:
                    parts.append(f"{mins} min")
            if sel.get('genres'):
                genres = sel['genres']
                if isinstance(genres, list):
                    parts.append(' / '.join(genres[:2]))
                else:
                    parts.append(str(genres))
            self.getControl(302).setLabel('  ·  '.join(parts))
            plot = sel.get('plot', '')
            if self.estado == 'episodios':
                progress = watch_history.resume_text(cargar_userdata().get('historial', {}), sel)
                plot += ('[CR][CR]' + progress if progress else '')
            elif self.estado == 'canales':
                epg_info = tv_epg.obtener_info_epg(sel.get('title', ''))
                if epg_info:
                    plot = (plot + '[CR][CR]' + epg_info) if plot else epg_info
            self.actualizar_sinopsis_texto(plot)

        display()
        u = sel.get('url', '')
        if urllib.parse.urlsplit(u).scheme not in ('http', 'https', 'lolplus'):
            return
        if not hasattr(self, '_content_metadata_cache'):
            self._content_metadata_cache = {}
        generation = self._catalog_generation
        def selected_control():
            control = self.getControl(150 if self.estado == 'episodios' else 100)
            position = control.getSelectedPosition() if control else -1
            if (self.activa and generation == self._catalog_generation and
                    0 <= position < len(self.items_actuales) and self.items_actuales[position].get('url') == u):
                return control, position
            return None, -1

        def apply(info):
            if conservar_sinopsis_existente(sel, info):
                info = dict(info)
                info['plot'] = sel['plot']
                info['plot_language'] = sel.get('plot_language', '')
            sel.update({k: v for k, v in info.items() if v or k == 'is_serie'})
            control, position = selected_control()
            if control:
                item = control.getListItem(position)
                configurar_item_video(item, sel['title'], thumb=sel.get('cover', ''), plot=sel.get('plot', ''),
                    year=sel.get('year', ''), rating=sel.get('rating', ''), genres=sel.get('genres', []),
                    is_episode=self.estado == 'episodios', is_dorama=doramas.is_dorama(sel),
                    mpaa=sel.get('mpaa', ''), duration=sel.get('duration', 0))
                display()

        if u in self._content_metadata_cache:
            apply(self._content_metadata_cache[u])
            return
        def fetch_metadata():
            # Avoid requests for cards crossed rapidly while navigating.
            xbmc.sleep(250)
            if not selected_control()[0]:
                return
            try:
                info = catalog.metadata(sel)
                if len(self._content_metadata_cache) >= 128:
                    self._content_metadata_cache.pop(next(iter(self._content_metadata_cache)))
                self._content_metadata_cache[u] = info
                apply(info)
            except Exception as exc:
                xbmc.log('Vaquexflix: metadatos: ' + type(exc).__name__, xbmc.LOGWARNING)
        threading.Thread(target=fetch_metadata, daemon=True).start()

    def actualizar_etiqueta(self, texto):
        self._titulo_actual = texto
        try: self.getControl(400).setLabel(f"[B]{limpiar_texto(texto)}[/B]")
        except Exception: pass

    def actualizar_sinopsis_texto(self, texto):
        try: self.getControl(303).setText(limpiar_texto(texto))
        except Exception: pass

    def _actualizar_caratulas_categorias(self, generation, section, targets):
        """Sustituye portadas por títulos reales sin reconstruir la lista."""
        if section not in ('peliculas', 'series', 'animes', 'doramas') or not targets:
            return
        if getattr(self, '_category_chosen_covers', {}).get(section):
            return
        cache = getattr(self, '_category_cover_cache', None)
        if cache is None:
            cache = self._category_cover_cache = {}

        def load_candidates(url):
            if generation != self._catalog_generation or not self.activa:
                return []
            if not cache.get(url):
                query = url.split('://', 1)[1]
                if section in ('peliculas', 'series') and not source_switches.only_enabled('argflix'):
                    import lolplus
                    parsed = urllib.parse.urlsplit('unified://' + query)
                    genre = urllib.parse.parse_qs(parsed.query).get('genre', [None])[0]
                    items, _ = lolplus.lolplus_catalog_page(section, 1, genre=genre)
                    cache[url] = caratulas_tmdb_categoria(items, section)
                else:
                    items, _ = catalog.page(query, 1, experimental=self.experimental,
                                            preview=True)
                    cache[url] = list(dict.fromkeys(item.get('cover') for item in items
                                                    if item.get('cover')))
            return cache[url]

        def refresh():
            used = set()
            def apply(index, url, covers):
                if generation != self._catalog_generation or self.estado != 'categorias':
                    return
                if not covers or self.items_actuales[index].get('url') != url:
                    return
                cover = elegir_caratula_categoria(covers, used)
                self.items_actuales[index]['cover'] = cover
                item = self.getControl(100).getListItem(index)
                item.setArt({'thumb': cover, 'icon': cover, 'poster': cover})

            if source_switches.only_enabled('sololatino'):
                # Un hilo daemon secuencial permite cerrar Kodi sin esperar
                # docenas de consultas TMDb lanzadas por un pool de portada.
                for index, url in targets:
                    if generation != self._catalog_generation or not self.activa:
                        break
                    try:
                        apply(index, url, load_candidates(url))
                    except Exception as exc:
                        xbmc.log('Vaquexflix: caratula categoria: ' + type(exc).__name__, xbmc.LOGWARNING)
                return
            with ThreadPoolExecutor(max_workers=4) as pool:
                futures = {pool.submit(load_candidates, url): (index, url)
                           for index, url in targets}
                for future in as_completed(futures):
                    index, url = futures[future]
                    if generation != self._catalog_generation or self.estado != 'categorias':
                        break
                    try:
                        covers = future.result()
                        apply(index, url, covers)
                    except Exception as exc:
                        xbmc.log('Vaquexflix: caratula categoria: ' + type(exc).__name__, xbmc.LOGWARNING)
        threading.Thread(target=refresh, daemon=True).start()

    def cargar_categorias(self, seccion=None):
        self._catalog_generation += 1
        if seccion: self.seccion_actual = seccion
        if not self.experimental and (self.seccion_actual == 'doramas' or
                                      (self.seccion_actual == 'animes' and not (source_switches.only_enabled('nova') or source_switches.enabled('fxpplus')))):
            self.seccion_actual = 'peliculas'
        self._set_prop('seccion_actual', self.seccion_actual)
        self.actualizar_etiqueta(NOMBRES_SECCIONES.get(self.seccion_actual, self.seccion_actual.upper()))

        # Las secciones de TV y YouTube se presentan en formato Lista (Control 150)
        if self.seccion_actual in ('tv', 'youtube'):
            self.estado = f"{self.seccion_actual}_categorias"
            self._set_prop('vista_episodios', 'true')
            self._set_prop('serie_cover', '')
            try:
                self.getControl(100).setVisible(False)
                self.getControl(150).setVisible(True)
            except Exception:
                pass
            lista_ctrl = self.getControl(150)
            if not lista_ctrl: return
            lista_ctrl.reset()

            self.items_actuales = []
            if self.seccion_actual == 'tv':
                data_u = cargar_userdata()
                tv_favs = data_u.get('tv_favoritos', [])
                tv_hist = data_u.get('tv_historial', [])
                default_channel_img = _default_channel_cover()

                cover_fav = _resolver_portada_canal(tv_favs[0].get('cover', ''), default_channel_img) if tv_favs else default_channel_img
                cover_hist = _resolver_portada_canal(tv_hist[0].get('cover', ''), default_channel_img) if tv_hist else default_channel_img
                cover_todo = 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=800&h=450&fit=crop&q=80'

                self.items_actuales.append({
                    'title': 'FAVORITOS (CANALES)',
                    'url': 'tv://favoritos',
                    'cover': cover_fav,
                    'is_serie': False,
                    'plot': 'Tus canales de televisión favoritos guardados para acceso rápido.'
                })
                self.items_actuales.append({
                    'title': 'RECIÉN VISTOS (CANALES)',
                    'url': 'tv://historial',
                    'cover': cover_hist,
                    'is_serie': False,
                    'plot': 'Canales de televisión sintonizados recientemente. Continúa viendo tus señales.'
                })
                if not source_switches.only_enabled('nova'):
                    self.items_actuales.append({
                        'title': 'TODO (TV EN VIVO)',
                        'url': 'tv://todo',
                        'cover': cover_todo,
                        'is_serie': False,
                        'plot': 'Catálogo completo y unificado de todos los canales de televisión disponibles.'
                    })

                subcats = tv_en_vivo.get_subcategories()
                for sc in subcats:
                    self.items_actuales.append({
                        'title': sc['title'],
                        'url': sc['url'],
                        'cover': sc.get('cover', default_channel_img),
                        'is_serie': False,
                        'plot': sc.get('plot', '')
                    })
            else:  # youtube
                data_u = cargar_userdata()
                tube_favs = data_u.get('youtube_favoritos', [])
                tube_hist = data_u.get('youtube_historial', [])
                cover_fav = tube_favs[0].get('cover', '') if tube_favs else ''
                cover_hist = tube_hist[0].get('cover', '') if tube_hist else ''
                for tc in tube_engine.TUBE_CATEGORIAS:
                    c_cover = tc.get('cover', '')
                    if tc.get('key') == 'favorites' and cover_fav:
                        c_cover = cover_fav
                    elif tc.get('key') == 'history' and cover_hist:
                        c_cover = cover_hist
                    self.items_actuales.append({
                        'title': tc['title'],
                        'url': tc['url'],
                        'cover': c_cover,
                        'is_serie': False,
                        'plot': tc.get('plot', '')
                    })

            self.items_originales = list(self.items_actuales)
            ui_items = []
            for obj in self.items_actuales:
                item = xbmcgui.ListItem(label=obj['title'])
                configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), is_episode=True)
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self._limpiar_foco_barra_lateral()
            self._pending_focus = None
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
            self._actualizar_navegacion_lateral()
            return

        self.estado = "categorias"
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()

        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        self.items_actuales = []
        ui_items = []

        menu_loader = None
        catalogo_sec = CATALOGO_GENEROS.get(self.seccion_actual, {})
        if self.seccion_actual in ('peliculas', 'series'):
            try:
                import lolplus
                catalogo_sec = lolplus.tmdb_menu_categories(self.seccion_actual, catalogo_sec)
            except Exception as exc:
                xbmc.log('Vaquexflix: categorias TMDb: ' + str(exc), xbmc.LOGWARNING)
            if self.seccion_actual == 'series' and source_switches.only_enabled('sololatino'):
                # No ofrecer categorias sin contenido util en el indice SoloLatino.
                catalogo_sec = {key: value for key, value in catalogo_sec.items()
                                if key not in catalog.SOLOLATINO_EMPTY_MENU_GENRES}
        if self.seccion_actual == 'doramas':
            menu = getattr(self, '_doramas_menu', None)
            catalogo_sec = menu['genres'] if menu else doramas.DEFAULT_DORAMAS_GENRES
            if menu is None and not getattr(self, '_doramas_menu_loading', False):
                self._doramas_menu_loading = True
                generation = self._catalog_generation
                def load_menu():
                    try:
                        self._doramas_menu = doramas.menu()
                        if self.activa and generation == self._catalog_generation and self.estado == 'categorias':
                            targets = [(index, entry['url']) for index, entry in enumerate(self.items_actuales)
                                       if entry.get('url', '').startswith('unified://doramas')]
                            self._actualizar_caratulas_categorias(generation, 'doramas', targets)
                    except Exception as exc:
                        xbmc.log('Vaquexflix: categorias Doramas: ' + str(exc), xbmc.LOGWARNING)
                    finally:
                        self._doramas_menu_loading = False
                menu_loader = load_menu
        is_tmdb_sec = self.seccion_actual in ('peliculas', 'series')
        todos_posters = []
        for g_data in catalogo_sec.values():
            todos_posters.extend(
                p for p in g_data.get('posters', [])
                if isinstance(p, str) and (not is_tmdb_sec or p.startswith('https://image.tmdb.org/t/p/'))
            )

        used_covers = set()

        # Manejo de portadas de categorías fijas por sesión y sección:
        # Cargan al instante exclusivamente de TMDb, una sola vez, y se quedan
        # fijas hasta cerrar el addon o cambiar de sección (sin re-actualizaciones dinámicas).
        if not hasattr(self, '_category_chosen_covers'):
            self._category_chosen_covers = {}

        last_sec = getattr(self, '_last_category_section', None)
        if last_sec is not None and last_sec != self.seccion_actual:
            self._category_chosen_covers.pop(last_sec, None)
        self._last_category_section = self.seccion_actual

        sec_covers = self._category_chosen_covers.setdefault(self.seccion_actual, {})

        # Portadas predeterminadas directas de TMDb para garantizar que las colecciones y todo no queden vacías
        default_hist = 'https://image.tmdb.org/t/p/w500/iU0qE192Z2qG0q12bC9d3p4lXh0.jpg' if self.seccion_actual == 'peliculas' else 'https://image.tmdb.org/t/p/w500/2koX1xLkpTQM4IZebYvKysFW1Nh.jpg'
        default_todo = 'https://image.tmdb.org/t/p/w500/8cdWjvZQUExUUTzyp4t6EDMubfO.jpg' if self.seccion_actual == 'peliculas' else 'https://image.tmdb.org/t/p/w500/u3bZgnGQ9T01sWNhyveQz0wH0Hl.jpg'

        todo_url = f'unified://{self.seccion_actual}'
        if todo_url in sec_covers and sec_covers[todo_url]:
            cover_todo = sec_covers[todo_url]
        else:
            candidates_todo = [p for p in todos_posters if isinstance(p, str) and p.startswith('https://image.tmdb.org/t/p/')] if is_tmdb_sec else todos_posters
            cover_todo = elegir_caratula_categoria(candidates_todo, used_covers, default_todo)
            if self.seccion_actual == 'doramas':
                menu_covers = (getattr(self, '_doramas_menu', None) or {}).get('covers', [])
                cover_todo = random.choice(menu_covers) if menu_covers else os.path.join(ADDON_PATH, 'cara_dora_bk.jpg')
            if not cover_todo:
                cover_todo = default_todo
            sec_covers[todo_url] = cover_todo
        if cover_todo:
            used_covers.add(cover_todo)

        # Favoritos e historial con portadas reales o respaldo TMDb
        data_u = cargar_userdata()
        is_sec_serie = (self.seccion_actual in ("series", "doramas", "animes"))

        recent_hist = watch_history.recent(data_u.get('historial', {}), is_sec_serie)
        if self.seccion_actual in ('doramas', 'animes'):
            recent_hist += watch_history.recent(data_u.get('historial', {}), False)
        recent_hist = catalog.in_section(catalog.visible(recent_hist, self.experimental), self.seccion_actual)
        cover_hist = ""
        if recent_hist:
            first_h = recent_hist[0]
            cover_hist = first_h.get('series', {}).get('cover') or first_h.get('cover', '')
        if not cover_hist and is_tmdb_sec:
            cover_hist = default_hist

        favs_items = [
            f for f in data_u.get('favoritos', [])
            if f.get('is_serie', any(x in f.get('url', '') for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-'])) == is_sec_serie or self.seccion_actual in ('doramas', 'animes')
        ]
        favs_items = catalog.in_section(catalog.visible(favs_items, self.experimental), self.seccion_actual)
        cover_fav = favs_items[-1].get('cover', '') if favs_items else ""
        if not cover_fav:
            cover_fav = os.path.join(ADDON_PATH, 'cara_dora_bk.jpg') if self.seccion_actual == 'doramas' else os.path.join(ADDON_PATH, 'cara_bk.jpg')
        used_covers.update(c for c in (cover_hist, cover_fav) if c)

        dorama_covers = {}
        if self.seccion_actual == 'doramas' and getattr(self, '_doramas_menu', None):
            dorama_covers = doramas.category_covers(self._doramas_menu, (cover_hist, cover_fav))
            cover_todo = dorama_covers.get('todo', cover_todo)
            if cover_todo:
                used_covers.add(cover_todo)
        tipo_str = "películas" if self.seccion_actual == "peliculas" else self.seccion_actual
        tipo_titulo = NOMBRES_SECCIONES.get(self.seccion_actual, self.seccion_actual.upper())
        self.items_actuales.append({'title': "FAVORITOS", 'url': "local://favoritos", 'cover': cover_fav, 'is_serie': False, 'plot': f"Tus {tipo_str} favoritas guardadas."})
        self.items_actuales.append({'title': "RECIÉN VISTOS", 'url': "local://historial", 'cover': cover_hist, 'is_serie': False, 'plot': f"Reanuda tus {tipo_str} donde las dejaste."})
        self.items_actuales.append({'title': f"TODO ({tipo_titulo})", 'url': f"unified://{self.seccion_actual}", 'cover': cover_todo, 'is_serie': False, 'plot': f"Catálogo completo de {tipo_str}."})
        category_targets = [(len(self.items_actuales) - 1, f'unified://{self.seccion_actual}')]
        if self.seccion_actual == 'animes' and not source_switches.only_enabled('nova'):
            cover_simulcast = 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&h=450&fit=crop&q=80'
            self.items_actuales.append({'title': "ÚLTIMOS EPISODIOS (SIMULCASTS)", 'url': "anime://ultimos", 'cover': cover_simulcast, 'is_serie': False, 'plot': "Episodios recién emitidos en Japón con subtítulos en español."})

        if is_tmdb_sec:
            col_posters_map = TMDB_COLLECTION_POSTERS.get(self.seccion_actual, {})
            colecciones_tmdb = [
                ('populares', 'Populares'),
                ('mejor-valoradas', 'Mejor valoradas'),
                ('tendencias', 'Tendencias de la semana'),
                ('recien-estrenadas', 'Recién estrenadas'),
                ('retro', 'Retro / Clásicos')
            ]
            if self.seccion_actual == 'series':
                colecciones_tmdb.append(('en-emision', 'En emisión'))

            for key, label in colecciones_tmdb:
                url = f'unified://{self.seccion_actual}?genre=lista-{key}'
                if url in sec_covers and sec_covers[url]:
                    collection_cover = sec_covers[url]
                else:
                    col_candidates = col_posters_map.get(key, [])
                    candidates = [p for p in (col_candidates + todos_posters)
                                  if isinstance(p, str) and p.startswith('https://image.tmdb.org/t/p/')]
                    collection_cover = elegir_caratula_categoria(candidates, used_covers, cover_todo)
                    if not collection_cover:
                        collection_cover = col_candidates[0] if col_candidates else cover_todo
                    sec_covers[url] = collection_cover
                self.items_actuales.append({
                    'title': label,
                    'url': url,
                    'cover': collection_cover,
                    'is_serie': False,
                    'plot': f'Explora {tipo_str}: {label.lower()}.'
                })
                category_targets.append((len(self.items_actuales) - 1, url))

        # Cargar categorias con contenido de generos directamente con caratulas TMDb
        for g_key, g_info in catalogo_sec.items():
            url_cat = f"unified://{self.seccion_actual}?genre={urllib.parse.quote(g_key)}"
            if url_cat in sec_covers and sec_covers[url_cat]:
                portada_azar = sec_covers[url_cat]
            else:
                posters_gen = [p for p in g_info.get('posters', [])
                               if isinstance(p, str) and (not is_tmdb_sec or p.startswith('https://image.tmdb.org/t/p/'))]
                if not posters_gen and self.seccion_actual not in ('doramas', 'animes'):
                    posters_gen = [p for p in todos_posters if isinstance(p, str) and p.startswith('https://image.tmdb.org/t/p/')]
                if not posters_gen and self.seccion_actual not in ('doramas', 'animes'):
                    continue

                candidates = ([dorama_covers.get(g_key, cover_todo)] if self.seccion_actual == 'doramas'
                              else posters_gen)
                portada_azar = elegir_caratula_categoria(candidates, used_covers, cover_todo)
                if not portada_azar:
                    portada_azar = posters_gen[0] if posters_gen else cover_todo
                sec_covers[url_cat] = portada_azar

            nom_cat = limpiar_texto(g_info.get('nom', g_key.capitalize()))
            self.items_actuales.append({
                'title': nom_cat,
                'url': url_cat,
                'cover': portada_azar,
                'is_serie': False,
                'plot': f"Explora {tipo_str} del género {nom_cat}."
            })
            category_targets.append((len(self.items_actuales) - 1, url_cat))

        self.items_originales = list(self.items_actuales)
        for obj in self.items_actuales:
            item = xbmcgui.ListItem(label=catalog.display_title(obj))
            is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
            configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), is_dorama=is_dora)
            ui_items.append(item)

        lista_ctrl.addItems(ui_items)
        xbmc.sleep(40)
        self._limpiar_foco_barra_lateral(clear_subtitle=True)
        self._pending_focus = None
        self.setFocus(lista_ctrl)
        lista_ctrl.selectItem(0)
        self.pos_anterior = 0
        if self.items_actuales:
            self.actualizar_sinopsis_texto(self.items_actuales[0].get('plot', ''))
        # Las portadas de categorías cargan exclusivamente de TMDb una sola vez y quedan fijas
        # hasta cerrar el addon o cambiar de sección. No re-actualizar dinámicamente en pantalla.
        if menu_loader:
            threading.Thread(target=menu_loader, daemon=True).start()

    def _parsear_tarjetas(self, html_code):
        return servidores.sololatino_parsear_tarjetas(html_code, self.seccion_actual, self.vistos_urls)

    def _buscar_contenido(self, query, experimental=None, section='all'):
        experimental = self.experimental if experimental is None else experimental
        q_raw = query.strip()
        if not q_raw: return []
        q_norm = limpiar_texto(q_raw).lower()

        cache = cargar_search_cache()
        queries_cache = cache.setdefault('queries', {})
        items_cache = cache.setdefault('items', {})

        # Each completed local catalog refresh invalidates older search results.
        solo_revision = 'none'
        if section != 'doramas':
            try:
                catalog_index.ensure_background()
                solo_revision = catalog_index.revision()
            except Exception as exc:
                solo_revision = 'pending'
                xbmc.log('Vaquexflix: indice SoloLatino: ' + type(exc).__name__, xbmc.LOGWARNING)
        cache_key = 'v23:' + source_switches.revision() + ':' + solo_revision + ':' + section + ':' + ('experimental:' if experimental else 'normal:') + q_norm
        cached = queries_cache.get(cache_key)
        # Formato antiguo (lista sin fecha) se considera caducado.
        if isinstance(cached, dict) and time.time() - cached.get('t', 0) < SEARCH_CACHE_TTL:
            return catalog.sort_by_relevance(catalog.merge(catalog.in_section(catalog.visible(cached.get('items', []), experimental), section)), q_raw)

        # Búsqueda unificada en SoloLatino + HackStore2 + PelisJuanita + FuegoCine
        items_encontrados = catalog.search(q_raw, experimental=experimental, section=section)
        search_errors = getattr(items_encontrados, 'errors', [])

        # Fallback a caché local si la red falla
        if not items_encontrados and items_cache:
            palabras = [p for p in re.findall(r'\w+', q_norm) if len(p) > 2]
            locales = []
            for u_item, it in items_cache.items():
                if solo_revision not in ('none', 'pending') and catalog.is_primary(it):
                    # The completed index already checked this title; old cached
                    # entries must not resurrect removed SoloLatino content.
                    continue
                tit = (it.get('title') or '').lower()
                if q_norm in tit or any(p in tit for p in palabras):
                    locales.append(it)
            if locales:
                items_encontrados = catalog.sort_by_relevance(catalog.in_section(catalog.visible(locales, experimental), section), q_raw)

        # Almacenar en caché para acceso ultra-rápido posterior
        for it in items_encontrados:
            items_cache[it['url']] = it

        if items_encontrados:
            now = time.time()
            for k in [k for k, v in queries_cache.items() if not isinstance(v, dict) or now - v.get('t', 0) >= SEARCH_CACHE_TTL]:
                del queries_cache[k]
            if not search_errors:
                queries_cache[cache_key] = {'t': now, 'items': items_encontrados}
            guardar_search_cache(cache)

        from provider_cache import SearchResults
        return SearchResults(items_encontrados, search_errors)

    def _cargar_pagina_unificada(self, number):
        generation = self._catalog_generation
        experimental = self.experimental
        section = self.categoria_actual_url.split('://', 1)[1]
        self.cargando_mas = True
        def load():
            try:
                found, more = catalog.page(section, number, experimental=experimental,
                                           primary_source=getattr(self, '_primary_catalog_source', None))
                if not self.activa or generation != self._catalog_generation or self.estado != 'elementos':
                    return
                control = self.getControl(100)
                before = len(self.items_actuales)
                self.items_actuales = catalog.merge(self.items_actuales + found)
                if number == 1:
                    self._primary_catalog_source = 'cache' if any(i.get('catalog_cached') for i in found) else 'live'
                self.items_originales = list(self.items_actuales)
                self.pagina_actual = number
                self.hay_mas_paginas = more
                # Si una fuente repite la ultima pagina, no consultarla sin fin.
                if len(self.items_actuales) == before:
                    self._empty_catalog_pages = getattr(self, '_empty_catalog_pages', 0) + 1
                    if self._empty_catalog_pages >= 3:
                        self.hay_mas_paginas = False
                else:
                    self._empty_catalog_pages = 0
                # Keep the existing entries; Kodi addItems still rebinds its native list.
                ui_items = []
                for obj in self.items_actuales[before:]:
                    item = xbmcgui.ListItem(label=catalog.display_title(obj))
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora, mpaa=obj.get('mpaa', ''), duration=obj.get('duration', 0))
                    ui_items.append(item)
                pos_guardada = control.getSelectedPosition() if before else -1
                if pos_guardada < 0 and before:
                    pos_guardada = self.pos_anterior

                if ui_items:
                    control.addItems(ui_items)
                    if pos_guardada >= 0 and number > 1:
                        try:
                            control.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass

                if number == 1 and self.items_actuales:
                    control.selectItem(0)
                    self.pos_anterior = 0
                    self._limpiar_foco_barra_lateral()
                    self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
                    self.setFocus(control)
                    if not experimental and any(i.get('catalog_cached') for i in found):
                        xbmcgui.Dialog().notification('SoloLatino', 'Mostrando catalogo guardado', xbmcgui.NOTIFICATION_INFO)
                elif number == 1:
                    xbmcgui.Dialog().notification('Vaquexflix', 'No hay contenido disponible', xbmcgui.NOTIFICATION_WARNING)
            except Exception as exc:
                xbmc.log('Vaquexflix: catalogo unificado ({})'.format(type(exc).__name__), xbmc.LOGWARNING)
                if generation == self._catalog_generation and self.activa and isinstance(exc, network.ServidorNoDisponible):
                    xbmcgui.Dialog().notification('Vaquexflix', str(exc), xbmcgui.NOTIFICATION_WARNING)
            finally:
                if generation == self._catalog_generation:
                    self.cargando_mas = False
        threading.Thread(target=load, daemon=True).start()

    def cargar_siguiente_pagina_youtube(self):
        if getattr(self, 'cargando_mas_youtube', False) or not getattr(self, 'youtube_continuation_token', ''):
            return
        self.cargando_mas_youtube = True

        def load():
            try:
                token = self.youtube_continuation_token
                nuevos_videos, next_token = tube_engine.search(continuation=token, with_token=True)
                if not self.activa or self.estado != "youtube_videos":
                    return

                existentes_ids = set(v.get('id') for v in getattr(self, 'youtube_videos_actuales', []) if v.get('id'))
                filtrados = [v for v in nuevos_videos if v.get('id') not in existentes_ids]

                if filtrados:
                    self.youtube_continuation_token = next_token
                    self.youtube_videos_actuales.extend(filtrados)
                    self.items_actuales.extend(filtrados)

                    lista_ctrl = self.getControl(150)
                    if lista_ctrl:
                        ui_items = []
                        for vid in filtrados:
                            item = xbmcgui.ListItem(label=vid['title'])
                            configurar_item_video(
                                item,
                                vid['title'],
                                thumb=vid.get('cover', getattr(self, '_tube_cat_cover', '')),
                                plot=vid.get('plot', ''),
                                rating=vid.get('rating', 'VÍDEO'),
                                is_dorama=False,
                                is_episode=True,
                                duration=0
                            )
                            item.setProperty('is_live', 'true')
                            ui_items.append(item)
                        position = lista_ctrl.getSelectedPosition()
                        lista_ctrl.addItems(ui_items)
                        if position >= 0:
                            lista_ctrl.selectItem(position)
                else:
                    self.youtube_continuation_token = ""
            except Exception as exc:
                xbmc.log('Vaquexflix: error paginacion youtube: ' + str(exc), xbmc.LOGWARNING)
                self.youtube_continuation_token = ""
            finally:
                self.cargando_mas_youtube = False

        threading.Thread(target=load, daemon=True).start()

    def cargar_siguiente_pagina_youtube_moderno(self):
        if getattr(self, 'cargando_mas_youtube', False) or not getattr(self, 'youtube_continuation_token', ''):
            return
        self.cargando_mas_youtube = True

        def load():
            try:
                token = self.youtube_continuation_token
                tipo_info = getattr(self, 'youtube_continuation_tipo', ('search',))
                tipo = tipo_info[0]

                if tipo == 'playlist':
                    _, nuevos_videos, next_token = tube_engine.get_playlist_videos("", limit=100, continuation=token, with_token=True)
                elif tipo == 'shorts':
                    nuevos_videos, next_token = tube_engine.get_category_videos('shorts', continuation=token, with_token=True)
                elif tipo == 'category':
                    cat_k = tipo_info[1] if len(tipo_info) > 1 else 'trending'
                    nuevos_videos, next_token = tube_engine.get_category_videos(cat_k, continuation=token, with_token=True)
                else:
                    nuevos_videos, next_token = tube_engine.search(continuation=token, with_token=True)

                if not self.activa or self.estado != "youtube_moderno":
                    return

                existentes_ids = set(v.get('id') for v in getattr(self, 'youtube_videos_actuales', []) if v.get('id'))
                filtrados = [v for v in nuevos_videos if v.get('id') not in existentes_ids]

                if filtrados:
                    self.youtube_continuation_token = next_token
                    self.youtube_videos_actuales.extend(filtrados)
                    self.items_actuales = self.youtube_videos_actuales

                    is_shorts = getattr(self, 'youtube_en_shorts', False)
                    ctrl_id = 950 if is_shorts else 900
                    ctrl = self.getControl(ctrl_id)
                    if ctrl:
                        pos = ctrl.getSelectedPosition()
                        ui_items = []
                        if is_shorts:
                            for s in filtrados:
                                clean_t = tube_engine.clean_emojis(s.get('title', 'Short'))
                                clean_p = tube_engine.clean_emojis(s.get('plot', ''))
                                li = xbmcgui.ListItem(label=clean_t)
                                thumb = s.get('cover', '')
                                li.setArt({'thumb': thumb, 'icon': thumb})
                                li.setProperty('views', str(s.get('views', s.get('rating', ''))))
                                li.setProperty('is_short', 'true')
                                li.setProperty('plot', clean_p)
                                ui_items.append(li)
                        else:
                            for v in filtrados:
                                clean_t = tube_engine.clean_emojis(v.get('title', 'Vídeo'))
                                clean_ch = tube_engine.clean_emojis(v.get('channel', ''))
                                clean_p = tube_engine.clean_emojis(v.get('plot', ''))
                                clean_d = tube_engine.clean_emojis(v.get('rating', ''))
                                li = xbmcgui.ListItem(label=clean_t)
                                thumb = v.get('cover', '')
                                li.setArt({'thumb': thumb, 'icon': thumb})
                                li.setProperty('duration', str(clean_d))
                                li.setProperty('channel', str(clean_ch))
                                li.setProperty('views', str(v.get('views', '')))
                                li.setProperty('is_live', 'true' if v.get('is_live') else '')
                                li.setProperty('is_playlist', 'true' if v.get('is_playlist') else '')
                                li.setProperty('plot', clean_p)
                                ui_items.append(li)
                        ctrl.addItems(ui_items)
                        if pos >= 0:
                            ctrl.selectItem(pos)
                else:
                    self.youtube_continuation_token = ""
            except Exception as exc:
                xbmc.log('Vaquexflix: error paginacion youtube moderno: ' + str(exc), xbmc.LOGWARNING)
                self.youtube_continuation_token = ""
            finally:
                self.cargando_mas_youtube = False

        threading.Thread(target=load, daemon=True).start()

    def cargar_elementos(self, url_target, reset=True):
        self.estado = "elementos"
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return

        if reset:
            self._catalog_generation += 1
            lista_ctrl.reset()
            self.items_actuales = []
            self.items_originales = []
            self.vistos_urls.clear()
            self.pagina_actual = 1
            self._empty_catalog_pages = 0
            self._primary_catalog_source = None
            self.hay_mas_paginas = True
            self.cargando_mas = False
            self.pos_anterior = -1
            self.categoria_actual_url = url_target

        if (SITE_URL in url_target or 'sololatino' in url_target) and ('genero=' in url_target or 'genre=' in url_target):
            parsed_u = urllib.parse.urlsplit(url_target)
            sec = 'series' if '/series' in parsed_u.path else 'peliculas'
            qs = urllib.parse.parse_qs(parsed_u.query)
            gen = qs.get('genero', qs.get('genre', ['']))[0]
            if gen:
                url_target = f"unified://{sec}?genre={urllib.parse.quote(gen)}"
                self.categoria_actual_url = url_target

        if url_target == "anime://ultimos":
            import anime
            self.estado = "episodios"
            self._set_prop('vista_episodios', 'true')
            try:
                self.getControl(100).setVisible(False)
                self.getControl(150).setVisible(True)
            except Exception:
                pass
            self._actualizar_navegacion_lateral()
            self.actualizar_etiqueta("ÚLTIMOS EPISODIOS (SIMULCASTS)")
            lista_ctrl = self.getControl(150)
            if not lista_ctrl:
                return
            lista_ctrl.reset()
            elementos = anime.ultimos_episodios()
            self.hay_mas_paginas = False
            self.items_actuales = elementos
            self.items_originales = list(elementos)
            self.episodios_actuales = elementos
            ui_items = []
            for f in elementos:
                item = xbmcgui.ListItem(label=catalog.display_title(f))
                f_thumb = f.get('thumb') or f.get('cover', '')
                configurar_item_video(item, f['title'], thumb=f_thumb, plot=f.get('plot', ''), is_episode=True)
                item.setProperty('is_live', 'false')
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            if reset and ui_items:
                xbmc.sleep(40)
                self._limpiar_foco_barra_lateral()
                self._pending_focus = None
                try: self.setFocus(lista_ctrl)
                except Exception: pass
                lista_ctrl.selectItem(0)
                self.pos_anterior = 0
                if self.items_actuales:
                    self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
            return

        if url_target == "anime://directorio":
            url_target = "unified://animes"
            self.categoria_actual_url = url_target

        if url_target.startswith('unified://'):
            self._cargar_pagina_unificada(1)
            return

        if url_target.startswith("local://"):
            data = cargar_userdata()
            is_sec_serie = (self.seccion_actual in ("series", "doramas", "animes"))
            tipo_str = self.seccion_actual
            elementos = []
            if "favoritos" in url_target:
                for f in data.get('favoritos', []):
                    u_f = f.get('url', '')
                    f_is_serie = f.get('is_serie', any(x in u_f for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))
                    if f_is_serie == is_sec_serie or self.seccion_actual in ('doramas', 'animes'):
                        elementos.append(f)
            elif "historial" in url_target:
                elementos = watch_history.recent(data.get('historial', {}), is_sec_serie)
                if self.seccion_actual in ('doramas', 'animes'):
                    elementos += watch_history.recent(data.get('historial', {}), False)

            elementos = catalog.in_section(catalog.visible(elementos, self.experimental), self.seccion_actual)
            if not elementos:
                elementos = [{
                    'title': "Ninguno",
                    'url': "",
                    'cover': "",
                    'is_serie': is_sec_serie,
                    'plot': f"No tienes {tipo_str} en esta seccion todavia."
                }]

            self.items_actuales = elementos
            self.items_originales = list(elementos)
            self.hay_mas_paginas = False
            ui_items = []
            for f in elementos:
                label_txt = f['title']
                if "historial" in url_target and not f.get('is_serie') and f['title'] != "Ninguno":
                    h_entry = data.get('historial', {}).get(f.get('url', ''), {})
                    t_sec = h_entry.get('time', 0)
                    if t_sec > 0:
                        m, s = divmod(t_sec, 60)
                        label_txt = f"{f['title']} ({m:02d}:{s:02d})"
                item = xbmcgui.ListItem(label=catalog.display_title(f, label_txt))
                is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(f)
                f_cover = f.get('series', {}).get('cover') or f.get('cover', '')
                configurar_item_video(item, label_txt, thumb=f_cover, plot=f.get('plot', ''), is_dorama=is_dora)
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            if reset and ui_items:
                xbmc.sleep(40)
                self._limpiar_foco_barra_lateral(clear_subtitle=True)
                self._pending_focus = None
                try: self.setFocus(lista_ctrl)
                except Exception: pass
                lista_ctrl.selectItem(0)
                self.pos_anterior = 0
                self.actualizar_sinopsis_texto(elementos[0].get('plot', ''))
            return

        if url_target.startswith("search://") or "/buscar" in url_target or "/api/search/suggest" in url_target:
            query = ''
            section = 'all'
            if url_target.startswith("search://"):
                query = urllib.parse.unquote_plus(url_target.replace('search://', '').split('?', 1)[0])
                section = urllib.parse.parse_qs(urllib.parse.urlsplit(url_target).query).get('section', ['all'])[0]
            elif "q=" in url_target:
                query = urllib.parse.parse_qs(urllib.parse.urlparse(url_target).query).get('q', [''])[0]

            self.seccion_actual = section if section != 'all' else "busqueda"
            self.actualizar_etiqueta(f"BÚSQUEDA: {limpiar_texto(query).upper()}")
            self.hay_mas_paginas = False

            generation = self._catalog_generation
            experimental = self.experimental
            def _hilo_busqueda():
                self.cargando_mas = True
                xbmcgui.Dialog().notification("Vaquexflix", "Buscando contenido...", xbmcgui.NOTIFICATION_INFO, 1200)
                nuevos = self._buscar_contenido(query, experimental, section)
                if not self.activa or generation != self._catalog_generation:
                    return
                search_errors = [e for e in getattr(nuevos, 'errors', []) if e != 'DoramaExpress' and 'doramaexpress' not in e.lower()]
                if search_errors:
                    xbmcgui.Dialog().notification('Busqueda incompleta',
                        'No respondieron: ' + ', '.join(search_errors), xbmcgui.NOTIFICATION_WARNING, 6000)
                self.items_actuales = nuevos
                self.items_originales = list(nuevos)

                ui_items = []
                for obj in nuevos:
                    label = obj['title'] + (' [Dorama]' if section == 'all' and doramas.is_dorama(obj) else '')
                    item = xbmcgui.ListItem(label=catalog.display_title(obj, label))
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora, mpaa=obj.get('mpaa', ''), duration=obj.get('duration', 0))
                    ui_items.append(item)

                lista_ctrl.addItems(ui_items)
                if reset and ui_items:
                    xbmc.sleep(40)
                    self._limpiar_foco_barra_lateral()
                    try: self.setFocus(lista_ctrl)
                    except Exception: pass
                    cur_p = lista_ctrl.getSelectedPosition()
                    if cur_p <= 0:
                        lista_ctrl.selectItem(0)
                        self.pos_anterior = 0
                        if self.items_actuales:
                            self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

                self.cargando_mas = False
                if not nuevos and reset and not search_errors:
                    xbmcgui.Dialog().notification("Vaquexflix", "No se encontraron elementos.", xbmcgui.NOTIFICATION_WARNING)

            threading.Thread(target=_hilo_busqueda, daemon=True).start()
            return

        generation = self._catalog_generation
        def _hilo_fetch_inicial():
            self.cargando_mas = True
            pag = 1
            acumulados = 0
            xbmcgui.Dialog().notification("Vaquexflix", "Cargando contenido...", xbmcgui.NOTIFICATION_INFO, 1200)

            while pag <= 3 and self.hay_mas_paginas:
                sep = '&' if '?' in url_target else '?'
                url_pag = url_target if pag == 1 else f"{url_target}{sep}page={pag}"
                html_res, _ = fetch_html(url_pag)
                if not self.activa or generation != self._catalog_generation:
                    return
                if not html_res:
                    self.hay_mas_paginas = False
                    break

                nuevos = self._parsear_tarjetas(html_res)
                if not nuevos:
                    self.hay_mas_paginas = False
                    break

                self.items_actuales.extend(nuevos)
                self.items_originales = list(self.items_actuales)
                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=catalog.display_title(obj))
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora, mpaa=obj.get('mpaa', ''), duration=obj.get('duration', 0))
                    ui_items.append(item)

                pos_guardada = lista_ctrl.getSelectedPosition()
                if pos_guardada < 0:
                    pos_guardada = self.pos_anterior

                lista_ctrl.addItems(ui_items)
                acumulados += len(nuevos)

                if pag == 1 and reset and ui_items:
                    cur_p = lista_ctrl.getSelectedPosition()
                    if cur_p <= 0 and pos_guardada <= 0:
                        self._limpiar_foco_barra_lateral()
                        self.setFocus(lista_ctrl)
                        lista_ctrl.selectItem(0)
                        self.pos_anterior = 0
                        if self.items_actuales:
                            self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
                    elif pos_guardada > 0:
                        try:
                            lista_ctrl.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass
                else:
                    if pos_guardada > 0:
                        try:
                            lista_ctrl.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass

                self.pagina_actual = pag
                pag += 1

            self.cargando_mas = False
            if acumulados == 0 and reset:
                xbmcgui.Dialog().notification("Vaquexflix", "No se encontraron elementos.", xbmcgui.NOTIFICATION_WARNING)

        threading.Thread(target=_hilo_fetch_inicial, daemon=True).start()

    def cargar_siguiente_pagina(self):
        if not self.hay_mas_paginas or self.cargando_mas or self.categoria_actual_url.startswith("local://") or self.categoria_actual_url.startswith("search://"):
            return

        self.cargando_mas = True
        prox_pag = self.pagina_actual + 1



        if self.categoria_actual_url.startswith('unified://'):
            self._cargar_pagina_unificada(prox_pag)
            return

        generation = self._catalog_generation
        def _hilo_mas():
            try:
                sep = '&' if '?' in self.categoria_actual_url else '?'
                url_pag = f"{self.categoria_actual_url}{sep}page={prox_pag}"
                html_res, _ = fetch_html(url_pag)
                if not self.activa or generation != self._catalog_generation:
                    return
                if not html_res:
                    self.hay_mas_paginas = False
                    self.cargando_mas = False
                    return

                nuevos = self._parsear_tarjetas(html_res)
                if not nuevos:
                    self.hay_mas_paginas = False
                    self.cargando_mas = False
                    return

                lista_ctrl = self.getControl(100)
                if not lista_ctrl:
                    self.cargando_mas = False
                    return

                self.items_actuales.extend(nuevos)
                self.items_originales = list(self.items_actuales)
                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=catalog.display_title(obj))
                    is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora, mpaa=obj.get('mpaa', ''), duration=obj.get('duration', 0))
                    ui_items.append(item)

                pos_guardada = lista_ctrl.getSelectedPosition()
                if pos_guardada < 0:
                    pos_guardada = self.pos_anterior

                lista_ctrl.addItems(ui_items)

                if pos_guardada > 0:
                    try:
                        lista_ctrl.selectItem(pos_guardada)
                        self.pos_anterior = pos_guardada
                    except Exception: pass

                self.pagina_actual = prox_pag
            except Exception: pass
            finally:
                if generation == self._catalog_generation:
                    self.cargando_mas = False

        threading.Thread(target=_hilo_mas, daemon=True).start()

    def cargar_temporadas(self, serie_obj):
        self._catalog_generation += 1
        if serie_obj.get('legacy_episode'):
            candidates = catalog.search(serie_obj['title'], experimental=self.experimental)
            matches = [c for c in candidates if c.get('is_serie') and
                       servidores.titulo_coincide(c['title'], serie_obj['title'])]
            if len(matches) != 1:
                xbmcgui.Dialog().notification('Vaquexflix', 'No se pudo identificar la serie del historial antiguo. Búscala en el catálogo.', xbmcgui.NOTIFICATION_WARNING)
                return
            parent = matches[0]
            data = cargar_userdata()
            for entry_key in serie_obj.get('history_keys', []):
                if entry_key in data.get('historial', {}):
                    data['historial'][entry_key]['series'] = parent
            guardar_userdata(data)
            serie_obj = parent
        if self.estado == 'elementos':
            self._titulo_catalogo = getattr(self, '_titulo_actual', 'SERIES')
        self.estado = "temporadas"
        self._set_prop('vista_episodios', '')
        self._set_prop('serie_cover', serie_obj.get('cover', '') if serie_obj else '')
        try:
            self.getControl(150).reset()
            self.getControl(150).setVisible(False)
            self.getControl(100).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()
        self.serie_actual = serie_obj
        self.actualizar_etiqueta(limpiar_texto(serie_obj['title']).upper())
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        episode_error = ''
        self._fast_season_counts = None
        try:
            counts = catalog.fast_season_summaries(serie_obj)
            if counts is None and self.experimental and not serie_obj.get('_expanded'):
                serie_obj = catalog.expand(serie_obj)
                serie_obj['_expanded'] = True
                self.serie_actual = serie_obj
                counts = catalog.fast_season_summaries(serie_obj)
            self._fast_season_counts = counts
            self.episodios_por_temporada = ({season: [] for season in counts}
                                               if counts is not None else
                                               catalog.episodes(serie_obj, experimental=self.experimental))
        except Exception as exc:
            xbmc.log(f'Vaquexflix error al cargar episodios: {exc}', xbmc.LOGERROR)
            episode_error = str(exc) if isinstance(exc, network.ServidorNoDisponible) else 'No se pudieron cargar los episodios. Intenta nuevamente.'
            self.episodios_por_temporada = {}

        self.temporadas_disponibles = sorted(self.episodios_por_temporada.keys(), key=lambda x: int(x) if str(x).isdigit() else 0)
        self.items_actuales = []
        ui_items = []
        for t_key in self.temporadas_disponibles:
            label = f"Temporada {t_key}"
            num_eps = (self._fast_season_counts.get(t_key, 0) if self._fast_season_counts is not None
                       else len(self.episodios_por_temporada[t_key]))
            t_plot = f"{serie_obj['title']} - Temporada {t_key} ({num_eps} episodios)"
            self.items_actuales.append({
                'title': label,
                'season': t_key,
                'cover': serie_obj.get('cover', ''),
                'plot': t_plot,
                'is_serie': True
            })
            item = xbmcgui.ListItem(label=catalog.display_title(serie_obj, label))
            is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(serie_obj)
            configurar_item_video(item, label, thumb=serie_obj.get('cover', ''), plot=t_plot, is_dorama=is_dora)
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self._limpiar_foco_barra_lateral(clear_subtitle=True)
            self._pending_focus = None
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self.actualizar_sinopsis_texto(self.items_actuales[0]['plot'])
        else:
            is_lol = serie_obj.get('source') == 'lolplus' or str(serie_obj.get('url', '')).startswith('lolplus://')
            reason = sessions.access_error() if (catalog.is_primary(serie_obj) and not is_lol) else ''
            xbmcgui.Dialog().notification("Vaquexflix", episode_error or reason or "La fuente no publica episodios disponibles.", xbmcgui.NOTIFICATION_WARNING, 8000)

    def cargar_episodios(self, num_temp):
        season_key = str(num_temp)
        if getattr(self, '_fast_season_counts', None) is not None and not self.episodios_por_temporada.get(season_key):
            try:
                episodes = catalog.season_episodes(self.serie_actual, season_key)
                if not episodes:
                    raise network.ServidorNoDisponible('TMDb no entregó los episodios de esta temporada.')
                self.episodios_por_temporada[season_key] = episodes
            except Exception as exc:
                xbmc.log('Vaquexflix: temporada {}: {}'.format(season_key, exc), xbmc.LOGWARNING)
                xbmcgui.Dialog().notification('Vaquexflix', str(exc), xbmcgui.NOTIFICATION_WARNING, 6000)
                return
        self.estado = "episodios"
        self._set_prop('vista_episodios', 'true')
        self._set_prop('serie_cover', self.serie_actual.get('cover', '') if self.serie_actual else '')
        try:
            self.getControl(100).setVisible(False)
            self.getControl(150).setVisible(True)
        except Exception:
            pass
        self._actualizar_navegacion_lateral()

        lista_ctrl = self.getControl(150)
        if not lista_ctrl: return
        lista_ctrl.reset()

        self.episodios_actuales = self.episodios_por_temporada.get(str(num_temp), [])
        self.items_actuales = self.episodios_actuales
        self.actualizar_etiqueta(f"{limpiar_texto(self.serie_actual['title']).upper()} - T{num_temp}")
        ui_items = []
        for ep in self.episodios_actuales:
            item = xbmcgui.ListItem(label=catalog.display_title(ep))
            item.setProperty('episode_season', str(num_temp))
            is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(ep)
            configurar_item_video(item, ep['title'], thumb=ep.get('cover', ''), plot=ep.get('plot', ''), rating=ep.get('rating', ''), is_dorama=is_dora, is_episode=True, mpaa=ep.get('mpaa', ''), duration=ep.get('duration', 0))
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self._limpiar_foco_barra_lateral()
            self._pending_focus = None
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.episodios_actuales:
                self._actualizar_sinopsis_de_elemento(self.episodios_actuales[0])

    def _verificar_logos_tv(self, generation, cat_url, channels, fallback):
        """Reemplaza sólo logos fallidos, sin reconstruir la lista ni el foco."""
        def check(index, url):
            if generation != getattr(self, '_tv_logo_generation', None):
                return index, True
            return index, tv_en_vivo.logo_disponible(url)

        def refresh():
            targets = [(index, ch.get('cover', '')) for index, ch in enumerate(channels)
                       if (ch.get('cover') or '').startswith(('http://', 'https://'))]
            with ThreadPoolExecutor(max_workers=6) as pool:
                futures = {pool.submit(check, index, url): index for index, url in targets}
                for future in as_completed(futures):
                    if (generation != getattr(self, '_tv_logo_generation', None) or
                            self.estado != 'canales' or self.categoria_actual_url != cat_url):
                        break
                    try:
                        index, valid = future.result()
                        if not valid:
                            item = self.getControl(150).getListItem(index)
                            item.setArt({'thumb': fallback, 'icon': fallback, 'poster': fallback})
                    except Exception as exc:
                        xbmc.log('Vaquexflix: logo TV: ' + type(exc).__name__, xbmc.LOGWARNING)
        threading.Thread(target=refresh, daemon=True).start()

    def cargar_canales_tv(self, cat_url, cat_title, cat_cover=""):
        self._tv_logo_generation = getattr(self, '_tv_logo_generation', 0) + 1
        logo_generation = self._tv_logo_generation
        self.estado = "canales"
        self._tv_cat_cover = cat_cover
        self.categoria_actual_url = cat_url
        self._set_prop('vista_episodios', 'true')
        self._set_prop('serie_cover', cat_cover)
        try:
            self.getControl(100).setVisible(False)
            self.getControl(150).setVisible(True)
        except Exception:
            pass

        self._actualizar_navegacion_lateral()
        self.actualizar_etiqueta(f"TV - {limpiar_texto(cat_title).upper()}")

        lista_ctrl = self.getControl(150)
        if not lista_ctrl:
            return
        lista_ctrl.reset()

        if cat_url == "tv://favoritos":
            data = cargar_userdata()
            channels = data.get('tv_favoritos', [])
            if not channels:
                channels = [{
                    'title': 'Sin canales favoritos aún',
                    'url': '',
                    'cover': cat_cover,
                    'rating': 'INFO',
                    'plot': 'No tienes canales agregados a favoritos. Presiona C o el botón X sobre cualquier canal para guardarlo aquí.'
                }]
        elif cat_url == "tv://historial":
            data = cargar_userdata()
            channels = data.get('tv_historial', [])
            if not channels:
                channels = [{
                    'title': 'Sin historial de canales',
                    'url': '',
                    'cover': cat_cover,
                    'rating': 'INFO',
                    'plot': 'Aún no has sintonizado ningún canal de televisión en Vaquexflix.'
                }]
        else:
            channels = tv_en_vivo.get_channels(cat_url)
            if not channels:
                channels = [{
                    'title': 'No hay canales disponibles',
                    'url': '',
                    'cover': cat_cover,
                    'rating': 'INFO',
                    'plot': 'No se encontraron canales activos para esta sección en este momento.'
                }]

        self.canales_actuales = channels
        self.items_actuales = channels

        default_cover = _default_channel_cover() or cat_cover

        ui_items = []
        for ch in channels:
            item = xbmcgui.ListItem(label=ch['title'])
            ch_thumb = _resolver_portada_canal(ch.get('cover'), default_cover)
            if tv_en_vivo.logo_cache_estado(ch_thumb) is False:
                ch_thumb = default_cover
            configurar_item_video(
                item,
                ch['title'],
                thumb=ch_thumb,
                plot=ch.get('plot', ''),
                rating=ch.get('rating', '1080p'),
                is_dorama=False,
                is_episode=True,
                duration=0
            )
            item.setProperty('is_live', 'true')
            item.setProperty('is_tv_channel', 'true')
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self._limpiar_foco_barra_lateral()
            self._pending_focus = None
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
            self._verificar_logos_tv(logo_generation, cat_url, channels, default_cover)

    def reproducir_canal_tv(self, ch):
        self.episodio_index_actual = -1
        titulo = ch.get('title', 'Canal TV')
        stream_url = ch.get('url', '')
        if not stream_url:
            return
        if stream_url.startswith(('tv://nova_page_', 'tv://nova_country_', 'tv://fxp_page_')):
            self.cargar_canales_tv(stream_url, titulo, ch.get('cover', ''))
            return

        if stream_url.startswith(('novatv://', 'fxptv://')):
            progress = xbmcgui.DialogProgress()
            progress.create('TV en Vivo', 'Comprobando señal…')
            signal_error = None
            try:
                waiter = playback.progress_waiter(
                    progress, lambda: self.activa, 'Comprobando señal…', 8, 92, 6.0)
                final_stream = playback.request_with_progress(
                    lambda: tv_en_vivo.resolver_canal_stream(stream_url, raise_on_failure=True),
                    network.presupuesto_resolucion,
                    waiter, seconds=24)
                if final_stream:
                    progress.update(100, 'Señal verificada')
            except playback.Cancelled:
                return
            except Exception as exc:
                xbmc.log('Vaquexflix: TV: ' + type(exc).__name__, xbmc.LOGWARNING)
                signal_error = ('Tiempo de espera agotado al comprobar la señal'
                                if isinstance(exc, TimeoutError) else str(exc)[:140])
                final_stream = None
            finally:
                progress.close()
        else:
            final_stream = tv_en_vivo.resolver_canal_stream(stream_url)
        if not final_stream:
            if stream_url.startswith(('novatv://', 'fxptv://')) and signal_error:
                xbmc.sleep(300)
                xbmcgui.Dialog().ok('TV en Vivo', '{}: {}'.format(titulo, signal_error))
                return
            plot = ch.get('plot', '')
            if 'programada para' in plot or 'comenzará' in plot or ch.get('rating') == 'PROGRAMADO':
                xbmcgui.Dialog().notification("TV en Vivo", "Este evento comenzará a la hora programada", xbmcgui.NOTIFICATION_INFO, 3500)
            else:
                xbmcgui.Dialog().notification("TV en Vivo", "Señal fuera de transmisión o temporalmente inactiva", xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        default_cover = _default_channel_cover()
        ch_thumb = _resolver_portada_canal(ch.get('cover'), default_cover)

        try:
            data = cargar_userdata()
            tv_h = data.get('tv_historial', [])
            tv_h = [x for x in tv_h if x.get('url') != stream_url and x.get('title') != titulo]
            tv_h.insert(0, {
                'title': titulo,
                'url': stream_url,
                'cover': ch_thumb,
                'rating': ch.get('rating', '1080p'),
                'plot': ch.get('plot', '')
            })
            data['tv_historial'] = tv_h[:40]
            guardar_userdata(data)
        except Exception:
            pass

        prog_actual = tv_epg.obtener_programa_actual(titulo)
        display_title = f"{titulo} — {prog_actual}" if prog_actual else titulo
        if prog_actual:
            xbmcgui.Dialog().notification(titulo, f"En emisión: {prog_actual}", ch_thumb, 4000)

        self.seccion_actual = "tv"
        self._set_prop('seccion_actual', "tv")
        context = {
            'url_norm': final_stream,
            'stream': final_stream,
            'is_serie': False,
            'is_live': True,
            'is_tv': True,
            'history': {
                'title': display_title,
                'url': stream_url,
                'cover': ch_thumb,
                'plot': ch.get('plot', ''),
                'is_serie': False,
                'is_live': True,
                'is_tv': True
            }
        }
        self._iniciar_stream(context, offset=0)

    def cargar_videos_youtube(self, cat_url, cat_title, cat_cover=""):
        self.seccion_actual = "youtube"
        self._set_prop('seccion_actual', "youtube")
        self.categoria_actual_url = cat_url
        self._tube_cat_cover = cat_cover
        raw_key = cat_url.replace('tube://', '').strip()
        key = raw_key.lower()

        if key == 'search':
            menu_search_opts = [
                "Búsqueda normal",
                "Sugerencias de búsqueda (Autocompletar)",
                "Buscar con filtros",
                "Buscar canal de YouTube",
                "Buscar playlists de YouTube",
                "Buscar directos en vivo"
            ]
            sel_m = xbmcgui.Dialog().select("Búsqueda en YouTube", menu_search_opts)
            if sel_m < 0:
                return

            query = ""
            sp_param = ""
            if sel_m == 0:
                kb = xbmc.Keyboard('', 'Buscar en YouTube (Vídeos y Playlists)')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText().strip():
                    return
                query = kb.getText().strip()
                cat_title = f"BÚSQUEDA: {query.upper()}"
            elif sel_m == 1:
                kb = xbmc.Keyboard('', 'Escribe el inicio de tu búsqueda (Autocompletar)')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText().strip():
                    return
                prefix = kb.getText().strip()
                sugs = tube_engine.suggest_queries(prefix)
                if sugs:
                    s_opts = [f"[B]{prefix}[/B] (buscar tal cual)"] + sugs
                    s_sel = xbmcgui.Dialog().select("Sugerencias de YouTube", s_opts)
                    if s_sel < 0:
                        return
                    query = prefix if s_sel == 0 else sugs[s_sel - 1]
                else:
                    query = prefix
                cat_title = f"BÚSQUEDA: {query.upper()}"
            elif sel_m == 2:
                filter_types = ["Por duración", "Por fecha de subida", "Por ordenación", "Solo directos en vivo"]
                ft_sel = xbmcgui.Dialog().select("Seleccionar tipo de filtro", filter_types)
                if ft_sel < 0:
                    return
                if ft_sel == 0:
                    d_opts = ["Cualquier duración", "Cortos (< 4 min)", "Medios (4-20 min)", "Largos (> 20 min)"]
                    d_params = ["", "EgIYAQ==", "EgIYAw==", "EgIYAg=="]
                    d_sel = xbmcgui.Dialog().select("Filtrar por duración", d_opts)
                    if d_sel < 0: return
                    sp_param = d_params[d_sel]
                elif ft_sel == 1:
                    dt_opts = ["Cualquier fecha", "Última hora", "Hoy", "Esta semana", "Este mes", "Este año"]
                    dt_params = ["", "EgIIAQ==", "EgIIAg==", "EgIIAw==", "EgIIBA==", "EgIIBQ=="]
                    dt_sel = xbmcgui.Dialog().select("Filtrar por fecha", dt_opts)
                    if dt_sel < 0: return
                    sp_param = dt_params[dt_sel]
                elif ft_sel == 2:
                    s_opts = ["Relevancia", "Fecha de subida", "Número de visitas", "Valoración"]
                    s_params = ["", "CAISAhAB", "CAMSAhAB", "CAESAhAB"]
                    s_sel = xbmcgui.Dialog().select("Ordenar por", s_opts)
                    if s_sel < 0: return
                    sp_param = s_params[s_sel]
                elif ft_sel == 3:
                    sp_param = "EgJAAQ=="

                kb = xbmc.Keyboard('', 'Buscar con filtros en YouTube')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText().strip():
                    return
                query = kb.getText().strip()
                cat_title = f"FILTRADO: {query.upper()}"
            elif sel_m == 3:
                kb = xbmc.Keyboard('', 'Nombre del canal de YouTube')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText().strip():
                    return
                query = kb.getText().strip()
                sp_param = "EgIQAg=="
                cat_title = f"CANALES: {query.upper()}"
            elif sel_m == 4:
                kb = xbmc.Keyboard('', 'Buscar playlists de YouTube')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText().strip():
                    return
                query = kb.getText().strip()
                sp_param = "EgIQAw=="
                cat_title = f"PLAYLISTS: {query.upper()}"
            elif sel_m == 5:
                kb = xbmc.Keyboard('', 'Buscar directos en vivo en YouTube')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText().strip():
                    return
                query = kb.getText().strip()
                sp_param = "EgJAAQ=="
                cat_title = f"EN VIVO: {query.upper()}"

            prog = xbmcgui.DialogProgress()
            prog.create("Vaquexflix", "Buscando en YouTube...")
            videos, self.youtube_continuation_token = tube_engine.search(query, sp=sp_param, with_token=True)
            prog.close()
        elif key == 'favorites':
            data = cargar_userdata()
            videos = data.get('youtube_favoritos', [])
            if not videos:
                videos = [{
                    'id': '',
                    'title': 'Sin favoritos guardados',
                    'url': '',
                    'cover': cat_cover,
                    'rating': 'INFO',
                    'plot': 'Pulsa la tecla C sobre cualquier vídeo de YouTube para guardarlo en tus favoritos.'
                }]
        elif key == 'history':
            data = cargar_userdata()
            videos = data.get('youtube_historial', [])
        elif key == 'playlists':
            data = cargar_userdata()
            saved_pls = data.get('youtube_playlists', [])
            playlists_items = [
                {
                    'id': 'action_add',
                    'title': '[COLOR cyan][B]+ AÑADIR PLAYLIST (ENLACE O ID)[/B][/COLOR]',
                    'url': 'tube://add_playlist',
                    'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
                    'rating': 'NUEVO',
                    'plot': 'Pega la URL o ID de una playlist de YouTube (ejemplo: https://www.youtube.com/playlist?list=PL...)'
                }
            ]
            for pl in saved_pls:
                playlists_items.append({
                    'id': pl.get('id', ''),
                    'title': f"[PLAYLIST] {pl.get('title', 'Lista guardada')}",
                    'url': f"tube://playlist/{pl.get('id', '')}",
                    'cover': pl.get('cover', 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80'),
                    'rating': 'PLAYLIST',
                    'plot': pl.get('plot', f"Playlist de YouTube guardada (ID: {pl.get('id')}). Pulsa para abrir sus vídeos.")
                })
            for pop in tube_engine.POPULAR_PLAYLISTS:
                if not any(x.get('id') == pop.get('id') for x in saved_pls):
                    playlists_items.append({
                        'id': pop.get('id', ''),
                        'title': f"[PLAYLIST] {pop.get('title', '')}",
                        'url': f"tube://playlist/{pop.get('id', '')}",
                        'cover': pop.get('cover', ''),
                        'rating': 'PLAYLIST',
                        'plot': pop.get('plot', '')
                    })
            videos = playlists_items
        elif key == 'add_playlist':
            kb = xbmc.Keyboard('', 'Pega la URL o ID de la playlist de YouTube')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                return
            raw_input = kb.getText().strip()
            pl_id = tube_engine.extract_playlist_id(raw_input)
            if not pl_id:
                xbmcgui.Dialog().notification("YouTube", "ID o URL de playlist no válida", xbmcgui.NOTIFICATION_WARNING, 3000)
                return
            prog = xbmcgui.DialogProgress()
            prog.create("Vaquexflix", "Consultando información de la playlist...")
            pl_name, pl_videos = tube_engine.get_playlist_videos(pl_id)
            prog.close()
            if not pl_videos:
                xbmcgui.Dialog().notification("YouTube", "No se encontraron vídeos en la playlist", xbmcgui.NOTIFICATION_WARNING, 3000)
                return
            data = cargar_userdata()
            pls = data.get('youtube_playlists', [])
            pls = [p for p in pls if p.get('id') != pl_id]
            thumb = pl_videos[0].get('cover', '') if pl_videos else ''
            pls.insert(0, {
                'id': pl_id,
                'title': pl_name or f"Playlist {pl_id[:10]}",
                'cover': thumb,
                'plot': f"Playlist con {len(pl_videos)} vídeos disponibles."
            })
            data['youtube_playlists'] = pls
            guardar_userdata(data)
            xbmcgui.Dialog().notification("YouTube", f"Playlist guardada: {pl_name or pl_id}", xbmcgui.NOTIFICATION_INFO, 3000)
            self.cargar_videos_youtube(f"tube://playlist/{pl_id}", pl_name or "PLAYLIST", thumb)
            return
        elif raw_key.startswith('playlist/'):
            pl_id = raw_key.split('playlist/')[-1].strip()
            prog = xbmcgui.DialogProgress()
            prog.create("Vaquexflix", "Cargando vídeos de la playlist...")
            pl_name, videos = tube_engine.get_playlist_videos(pl_id)
            prog.close()
            if pl_name:
                cat_title = f"PLAYLIST - {pl_name.upper()}"
        elif raw_key.startswith('channel/'):
            cid = raw_key.split('channel/')[-1].strip()
            prog = xbmcgui.DialogProgress()
            prog.create("Vaquexflix", "Cargando vídeos del canal...")
            ch_name, videos = tube_engine.get_channel_videos(cid)
            prog.close()
            if ch_name:
                cat_title = f"CANAL - {ch_name.upper()}"
        else:
            prog = xbmcgui.DialogProgress()
            prog.create("Vaquexflix", "Cargando vídeos de YouTube...")
            videos, self.youtube_continuation_token = tube_engine.get_category_videos(key, with_token=True)
            prog.close()

        if not videos:
            videos = [{
                'id': '',
                'title': 'Sin resultados disponibles',
                'url': '',
                'cover': cat_cover,
                'rating': 'INFO',
                'plot': 'No se encontraron vídeos disponibles en este momento.'
            }]

        self.estado = "youtube_videos"
        self._set_prop('vista_episodios', 'true')
        self._set_prop('serie_cover', cat_cover or (videos[0].get('cover', '') if videos else ''))
        try:
            self.getControl(100).setVisible(False)
            self.getControl(150).setVisible(True)
        except Exception:
            pass

        self._actualizar_navegacion_lateral()
        self.actualizar_etiqueta(f"YOUTUBE - {limpiar_texto(cat_title).upper()}")

        lista_ctrl = self.getControl(150)
        if not lista_ctrl:
            return
        lista_ctrl.reset()

        self.youtube_videos_actuales = videos
        self.items_actuales = videos

        ui_items = []
        for vid in videos:
            item = xbmcgui.ListItem(label=vid['title'])
            configurar_item_video(
                item,
                vid['title'],
                thumb=vid.get('cover', cat_cover),
                plot=vid.get('plot', ''),
                rating=vid.get('rating', 'VÍDEO'),
                is_dorama=False,
                is_episode=True,
                duration=0
            )
            item.setProperty('is_live', 'true')
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self._limpiar_foco_barra_lateral()
            self._pending_focus = None
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

    def _siguiente_indice_youtube(self, direction=1, auto=False):
        y_vids = getattr(self, 'youtube_videos_actuales', [])
        y_idx = getattr(self, 'youtube_video_index_actual', -1)
        if not y_vids or y_idx < 0:
            return None
        total = len(y_vids)
        rep_mode = getattr(self, 'youtube_repeat', 'off')
        if auto and rep_mode == 'one':
            return y_idx
        if getattr(self, 'youtube_random', False):
            if total <= 1:
                return y_idx if (not auto or rep_mode != 'off') else None
            candidates = [i for i in range(total) if i != y_idx]
            return random.choice(candidates)
        target = y_idx + (1 if direction >= 0 else -1)
        if 0 <= target < total:
            return target
        if rep_mode == 'all':
            return 0 if direction >= 0 else total - 1
        return None

    def _reproducir_youtube_indice(self, target):
        y_vids = getattr(self, 'youtube_videos_actuales', [])
        if 0 <= target < len(y_vids):
            self.detener_reproduccion()
            self.reproducir_video_youtube(y_vids[target], index=target)
            return True
        return False

    def reproducir_video_youtube(self, vid, index=-1):
        self.episodio_index_actual = -1
        self.youtube_video_index_actual = index
        self.seccion_actual = "youtube"
        self._set_prop('seccion_actual', "youtube")
        vid_id = vid.get('id') or tube_engine.extract_video_id(vid.get('url', ''))
        if not vid_id:
            return

        is_live_content = bool(vid.get('is_live', False))
        prog = xbmcgui.DialogProgress()
        prog.create("Vaquexflix", "Conectando con YouTube...")
        info = tube_engine.resolve_playback(vid_id, is_live=is_live_content)
        prog.close()

        stream_url = None
        if info:
            is_live_content = bool(is_live_content or info.get('is_live'))
            if info.get('kind') == 'mpd' and info.get('mpd'):
                import hls_proxy
                hdrs = dict(info.get('headers') or {})
                mpd_url = hls_proxy.start_manifest(info['mpd'], headers=hdrs, kind='mpd')
                ua_val = hdrs.get('User-Agent') or UA
                stream_url = f"{mpd_url}|User-Agent={urllib.parse.quote(ua_val, safe='')}"
            else:
                stream_url = info.get('url')

        if not stream_url:
            xbmcgui.Dialog().notification("Vaquexflix", "Vídeo no disponible en este momento", xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        try:
            data = cargar_userdata()
            yt_h = data.get('youtube_historial', [])
            yt_h = [x for x in yt_h if x.get('id') != vid_id]
            yt_h.insert(0, {
                'id': vid_id,
                'title': tube_engine.clean_emojis(vid.get('title', 'Vídeo YouTube')),
                'url': f"https://www.youtube.com/watch?v={vid_id}",
                'cover': vid.get('cover', ''),
                'rating': vid.get('rating', 'VÍDEO'),
                'plot': tube_engine.clean_emojis(vid.get('plot', ''))
            })
            data['youtube_historial'] = yt_h[:40]
            guardar_userdata(data)
        except Exception:
            pass

        context = {
            'url_norm': stream_url,
            'stream': stream_url,
            'is_serie': False,
            'is_live': is_live_content,
            'is_youtube': True,
            'history': {
                'title': vid.get('title', 'Vídeo YouTube'),
                'url': f"https://www.youtube.com/watch?v={vid_id}",
                'cover': vid.get('cover', ''),
                'plot': vid.get('plot', ''),
                'is_serie': False,
                'is_live': is_live_content,
                'is_youtube': True
            }
        }
        self._iniciar_stream(context, offset=0)

    # -------------------------------------------------------------
    # MÉTODOS DE LA INTERFAZ MODERNA DE YOUTUBE (YOUTUBE MODERN UI)
    # -------------------------------------------------------------
    def abrir_youtube_moderno(self, categoria='trending'):
        self.seccion_actual = 'youtube'
        self.estado = 'youtube_moderno'
        self.youtube_tab_actual = 'inicio' if categoria in ('trending', 'tendencias') else categoria
        self.youtube_en_shorts = (categoria == 'shorts')
        self._set_prop('vista_youtube_modern', 'true')
        self._set_prop('vista_episodios', '')
        self._set_prop('seccion_actual', 'youtube')
        self._set_prop('youtube_tab_activo', self.youtube_tab_actual)
        self._set_prop('youtube_vista_shorts', 'true' if self.youtube_en_shorts else '')
        self._set_prop('youtube_seccion_titulo', 'TODO')

        try:
            self.getControl(100).setVisible(False)
            self.getControl(150).setVisible(False)
        except Exception:
            pass

        self._poblar_chips_youtube()
        self.cargar_contenido_youtube_moderno(categoria)

    def _poblar_chips_youtube(self):
        try:
            ctrl = self.getControl(800)
            if not ctrl:
                return
            ctrl.reset()
            items = []
            for key, label in YOUTUBE_CHIPS:
                li = xbmcgui.ListItem(label=label)
                li.setProperty('chip_key', key)
                items.append(li)
            ctrl.addItems(items)
        except Exception:
            pass

    def cargar_contenido_youtube_moderno(self, cat_key, query=None, sp="", filter_label=""):
        self._catalog_generation += 1
        gen = self._catalog_generation
        self.youtube_chip_actual = cat_key
        self.youtube_en_shorts = (cat_key == 'shorts')
        self._set_prop('youtube_vista_shorts', 'true' if self.youtube_en_shorts else '')
        self._set_prop('youtube_footer_hint', '[OK] Reproducir   •   [Atrás] Volver   •   [C] Favorito')

        label_map = dict(YOUTUBE_CHIPS)
        titulo = label_map.get(cat_key, cat_key.upper())

        if cat_key == 'channels':
            self._set_prop('youtube_seccion_titulo', 'CANALES EN TENDENCIA')
            self._set_prop('youtube_footer_hint', '[OK] Ver vídeos del canal   •   [Atrás] Volver')
            prog = xbmcgui.DialogProgress()
            prog.create('Vaquexflix', 'Cargando Canales en Tendencia...')
            try:
                vids = tube_engine.get_trending_channels(limit=30)
            except Exception:
                vids = []
            finally:
                prog.close()
            self._render_videos_youtube_moderno(vids, gen)
            return

        if str(cat_key).startswith('channel/'):
            cid = str(cat_key).split('channel/')[-1].strip()
            prog = xbmcgui.DialogProgress()
            prog.create('Vaquexflix', 'Cargando vídeos del canal...')
            try:
                ch_name, vids = tube_engine.get_channel_videos(cid, limit=40)
            except Exception:
                ch_name, vids = "", []
            finally:
                prog.close()
            self._set_prop('youtube_seccion_titulo', f"CANAL: {ch_name.upper() if ch_name else cid}")
            self._render_videos_youtube_moderno(vids, gen)
            return

        if str(cat_key).startswith('playlist/'):
            pid = str(cat_key).split('playlist/')[-1].strip()
            prog = xbmcgui.DialogProgress()
            prog.create('Vaquexflix', 'Cargando lista de reproducción...')
            try:
                res = tube_engine.get_playlist_videos(pid, limit=150, with_token=True)
                if isinstance(res, tuple) and len(res) == 3:
                    pl_name, vids, next_token = res
                elif isinstance(res, tuple) and len(res) == 2:
                    pl_name, vids = res
                    next_token = ""
                else:
                    pl_name, vids, next_token = "", [], ""
                self.youtube_continuation_token = next_token
                self.youtube_continuation_tipo = ('playlist', pid)
            except Exception:
                pl_name, vids = "", []
                self.youtube_continuation_token = ""
            finally:
                prog.close()
            self._set_prop('youtube_seccion_titulo', f"PLAYLIST: {pl_name.upper() if pl_name else pid}")
            self._render_videos_youtube_moderno(vids, gen)
            return

        if cat_key == 'history':
            data = cargar_userdata()
            hist_items = data.get('youtube_historial', [])
            vids = []
            if hist_items:
                vids.append({
                    'id': 'action_clear_history',
                    'title': '[BORRAR TODO EL HISTORIAL]',
                    'url': 'tube://clear_history',
                    'cover': 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&h=450&fit=crop&q=80',
                    'rating': 'ACCIÓN',
                    'channel': 'Historial',
                    'plot': 'Pulsa para eliminar todo tu historial de reproducciones de YouTube.'
                })
                vids.extend(hist_items)
            else:
                vids.append({
                    'id': '',
                    'title': 'Sin historial de reproducción',
                    'url': '',
                    'cover': '',
                    'rating': 'INFO',
                    'channel': 'Historial',
                    'plot': 'Aún no has reproducido vídeos en YouTube.'
                })
            self._set_prop('youtube_seccion_titulo', 'RECIÉN VISTOS')
            self._set_prop('youtube_footer_hint', '[OK] Reproducir   •   [Supr / C] Eliminar del historial   •   [Atrás] Volver')
            self._render_videos_youtube_moderno(vids, gen)
            return

        if cat_key == 'favorites':
            data = cargar_userdata()
            vids = data.get('youtube_favoritos', [])
            self._set_prop('youtube_seccion_titulo', 'FAVORITOS')
            self._render_videos_youtube_moderno(vids, gen)
            return

        if cat_key == 'playlists':
            data = cargar_userdata()
            user_lists = data.get('youtube_playlists', [])
            action_item = [{
                'id': 'action_add',
                'title': '+ AÑADIR PLAYLIST',
                'url': 'tube://add_playlist',
                'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
                'rating': 'NUEVO',
                'channel': 'Vaquexflix',
                'plot': 'Pulsa para ingresar la URL o ID de cualquier lista de reproducción de YouTube y guardarla en tu colección.',
                'is_playlist': True
            }]
            all_lists = action_item + user_lists + [p for p in tube_engine.POPULAR_PLAYLISTS if not any(x.get('id') == p.get('id') for x in user_lists)]
            self._set_prop('youtube_seccion_titulo', 'LISTAS DE REPRODUCCIÓN')
            self._set_prop('youtube_footer_hint', '[OK] Abrir lista   •   [C] Eliminar de mis listas   •   [Atrás] Volver')
            self._render_videos_youtube_moderno(all_lists, gen)
            return

        if self.youtube_en_shorts:
            prog = xbmcgui.DialogProgress()
            prog.create('Vaquexflix', 'Cargando YouTube Shorts...')
            try:
                res = tube_engine.get_category_videos('shorts', limit=25, with_token=True)
                vids, next_token = res if isinstance(res, tuple) else (res, "")
                self.youtube_continuation_token = next_token
                self.youtube_continuation_tipo = ('shorts', 'shorts')
            except Exception:
                vids = []
                self.youtube_continuation_token = ""
            finally:
                prog.close()
            self._set_prop('youtube_seccion_titulo', 'SHORTS')
            self._render_shorts_youtube_moderno(vids, gen)
            return

        if cat_key == 'search' or query:
            self.youtube_busqueda_actual = query or ""
            self.youtube_busqueda_sp = sp or ""
            self.youtube_busqueda_tipo = filter_label or "Todo"
            if filter_label and filter_label not in ('Todo', 'Todo (General)'):
                titulo = f"BÚSQUEDA: {query.upper()} ({filter_label.upper()})"
            else:
                titulo = f"BÚSQUEDA: {query.upper()}"
            self._set_prop('youtube_seccion_titulo', titulo)
            self._set_prop('youtube_footer_hint', '[OK] Reproducir / Abrir   •   [Atrás] Volver   •   [C] Favorito')
            prog = xbmcgui.DialogProgress()
            prog.create('Vaquexflix', f'Buscando en YouTube: {query}...')
            try:
                res = tube_engine.search(query, sp=sp, limit=36, with_token=True)
                vids, next_token = res if isinstance(res, tuple) else (res, "")
                self.youtube_continuation_token = next_token
                self.youtube_continuation_tipo = ('search', query, sp)
            except Exception:
                vids = []
                self.youtube_continuation_token = ""
            finally:
                prog.close()
            self._render_videos_youtube_moderno(vids, gen)
            return

        self._set_prop('youtube_seccion_titulo', titulo.upper())
        prog = xbmcgui.DialogProgress()
        prog.create('Vaquexflix', f'Cargando {titulo}...')
        try:
            target_key = 'trending' if cat_key in ('trending', 'tendencias', 'all', 'todo') else cat_key
            res = tube_engine.get_category_videos(target_key, limit=36, with_token=True)
            vids, next_token = res if isinstance(res, tuple) else (res, "")
            self.youtube_continuation_token = next_token
            self.youtube_continuation_tipo = ('category', target_key)
        except Exception:
            vids = []
            self.youtube_continuation_token = ""
        finally:
            prog.close()

        self._render_videos_youtube_moderno(vids, gen)

    def _render_videos_youtube_moderno(self, videos, generation):
        if generation != self._catalog_generation:
            return
        self.youtube_videos_actuales = list(videos or [])
        self.items_actuales = self.youtube_videos_actuales
        try:
            ctrl = self.getControl(900)
            if not ctrl:
                return
            ctrl.reset()
            ui_items = []
            for v in self.youtube_videos_actuales:
                clean_title = tube_engine.clean_emojis(v.get('title', 'Vídeo'))
                clean_channel = tube_engine.clean_emojis(v.get('channel', ''))
                clean_plot = tube_engine.clean_emojis(v.get('plot', ''))
                clean_dur = tube_engine.clean_emojis(v.get('rating', ''))
                li = xbmcgui.ListItem(label=clean_title)
                thumb = v.get('cover', '')
                li.setArt({'thumb': thumb, 'icon': thumb})
                li.setProperty('duration', str(clean_dur))
                li.setProperty('channel', str(clean_channel))
                li.setProperty('views', str(v.get('views', '')))
                li.setProperty('is_live', 'true' if v.get('is_live') else '')
                li.setProperty('is_playlist', 'true' if v.get('is_playlist') else '')
                li.setProperty('plot', clean_plot)
                ui_items.append(li)
            ctrl.addItems(ui_items)
            if ui_items:
                self.setFocus(ctrl)
                ctrl.selectItem(0)
        except Exception as exc:
            xbmc.log(f'Vaquexflix: error renderizando videos: {exc}', xbmc.LOGWARNING)

    def _render_shorts_youtube_moderno(self, shorts, generation):
        if generation != self._catalog_generation:
            return
        self.youtube_shorts_items = list(shorts or [])
        self.youtube_videos_actuales = self.youtube_shorts_items
        self.items_actuales = self.youtube_shorts_items
        try:
            ctrl = self.getControl(950)
            if not ctrl:
                return
            ctrl.reset()
            ui_items = []
            for s in self.youtube_shorts_items:
                clean_title = tube_engine.clean_emojis(s.get('title', 'Short'))
                clean_plot = tube_engine.clean_emojis(s.get('plot', ''))
                li = xbmcgui.ListItem(label=clean_title)
                thumb = s.get('cover', '')
                li.setArt({'thumb': thumb, 'icon': thumb})
                li.setProperty('views', str(s.get('views', s.get('rating', ''))))
                li.setProperty('is_short', 'true')
                li.setProperty('plot', clean_plot)
                ui_items.append(li)
            ctrl.addItems(ui_items)
            if ui_items:
                self.setFocus(ctrl)
                ctrl.selectItem(0)
        except Exception as exc:
            xbmc.log(f'Vaquexflix: error renderizando shorts: {exc}', xbmc.LOGWARNING)

    def _alternar_favorito_youtube(self, vid):
        if not vid or not vid.get('id'):
            return
        data = cargar_userdata()
        favs = data.get('youtube_favoritos', [])
        vid_id = vid['id']
        existe = any(x.get('id') == vid_id for x in favs)
        if existe:
            favs = [x for x in favs if x.get('id') != vid_id]
            msg = 'Eliminado de Favoritos de YouTube'
        else:
            favs.insert(0, {
                'id': vid_id,
                'title': tube_engine.clean_emojis(vid.get('title', 'Vídeo YouTube')),
                'url': vid.get('url', f"https://www.youtube.com/watch?v={vid_id}"),
                'cover': vid.get('cover', ''),
                'rating': vid.get('rating', 'VÍDEO'),
                'channel': tube_engine.clean_emojis(vid.get('channel', '')),
                'plot': tube_engine.clean_emojis(vid.get('plot', ''))
            })
            msg = 'Añadido a Favoritos de YouTube'
        data['youtube_favoritos'] = favs
        guardar_userdata(data)
        xbmcgui.Dialog().notification('YouTube', msg, xbmcgui.NOTIFICATION_INFO, 2000)

    def _dialogo_agregar_playlist_youtube(self):
        kb = xbmc.Keyboard('', 'Pega la URL o ID de la playlist de YouTube')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            return
        raw_input = kb.getText().strip()
        pl_id = tube_engine.extract_playlist_id(raw_input)
        if not pl_id:
            xbmcgui.Dialog().notification("YouTube", "ID o URL de playlist no válida", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        prog = xbmcgui.DialogProgress()
        prog.create("Vaquexflix", "Consultando información de la playlist...")
        pl_name, pl_videos = tube_engine.get_playlist_videos(pl_id)
        prog.close()
        if not pl_videos:
            xbmcgui.Dialog().notification("YouTube", "No se encontraron vídeos en la playlist", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        data = cargar_userdata()
        pls = data.get('youtube_playlists', [])
        pls = [p for p in pls if p.get('id') != pl_id]
        thumb = pl_videos[0].get('cover', '') if pl_videos else ''
        pls.insert(0, {
            'id': pl_id,
            'title': pl_name or f"Playlist {pl_id[:10]}",
            'url': f"tube://playlist/{pl_id}",
            'cover': thumb,
            'rating': f"{len(pl_videos)} VÍDEOS",
            'channel': 'Mi colección',
            'plot': f"Playlist con {len(pl_videos)} vídeos disponibles.",
            'is_playlist': True
        })
        data['youtube_playlists'] = pls
        guardar_userdata(data)
        xbmcgui.Dialog().notification("YouTube", f"Playlist guardada: {pl_name or pl_id}", xbmcgui.NOTIFICATION_INFO, 3000)
        self.cargar_contenido_youtube_moderno('playlists')

    def _dialogo_busqueda_avanzada_youtube(self):
        filtros = tube_engine.SEARCH_FILTERS
        nombres = [f[1] for f in filtros]
        sel_idx = xbmcgui.Dialog().select("Búsqueda avanzada en YouTube", nombres)
        if sel_idx < 0:
            return
        sp_code, label_filtro = filtros[sel_idx]
        default_txt = getattr(self, 'youtube_busqueda_actual', '') or ''
        kb = xbmc.Keyboard(default_txt, f"Buscar en YouTube ({label_filtro})")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            q = kb.getText().strip()
            self.youtube_tab_actual = 'buscar'
            self._set_prop('youtube_tab_activo', 'buscar')
            self.cargar_contenido_youtube_moderno('search', query=q, sp=sp_code, filter_label=label_filtro)

    def _confirmar_borrar_historial_youtube(self):
        if xbmcgui.Dialog().yesno("YouTube", "¿Deseas borrar TODO el historial de vídeos de YouTube?"):
            data = cargar_userdata()
            data['youtube_historial'] = []
            guardar_userdata(data)
            xbmcgui.Dialog().notification("YouTube", "Historial vaciado", xbmcgui.NOTIFICATION_INFO, 2000)
            self.cargar_contenido_youtube_moderno('history')

    def _eliminar_video_actual_historial(self):
        if getattr(self, 'youtube_chip_actual', '') != 'history':
            return
        fid = self.getFocusId()
        if fid not in (900, 950):
            return
        pos = self.getControl(fid).getSelectedPosition()
        videos = getattr(self, 'youtube_videos_actuales', [])
        if not (0 <= pos < len(videos)):
            return
        sel = videos[pos]
        if sel.get('id') == 'action_clear_history':
            self._confirmar_borrar_historial_youtube()
            return
        vid_id = sel.get('id')
        data = cargar_userdata()
        hist = [x for x in data.get('youtube_historial', []) if x.get('id') != vid_id]
        data['youtube_historial'] = hist
        guardar_userdata(data)
        xbmcgui.Dialog().notification("YouTube", "Eliminado del historial", xbmcgui.NOTIFICATION_INFO, 1500)
        self.cargar_contenido_youtube_moderno('history')

    def _accion_contexto_youtube(self, item):
        if not item:
            return
        if getattr(self, 'youtube_chip_actual', '') == 'history':
            if item.get('id') == 'action_clear_history':
                self._confirmar_borrar_historial_youtube()
                return
            opts = [
                "Eliminar este vídeo del historial",
                "Borrar TODO el historial de YouTube",
                "Añadir a Favoritos"
            ]
            sel = xbmcgui.Dialog().select("Opciones de Historial", opts)
            if sel == 0:
                self._eliminar_video_actual_historial()
            elif sel == 1:
                self._confirmar_borrar_historial_youtube()
            elif sel == 2:
                self._alternar_favorito_youtube(item)
            return

        if getattr(self, 'youtube_chip_actual', '') == 'playlists':
            pl_id = item.get('id')
            if pl_id == 'action_add':
                self._dialogo_agregar_playlist_youtube()
                return
            data = cargar_userdata()
            pls = data.get('youtube_playlists', [])
            matched = [p for p in pls if p.get('id') == pl_id]
            if matched:
                if xbmcgui.Dialog().yesno("YouTube", f"¿Deseas eliminar '{item.get('title')}' de tus listas?"):
                    pls = [p for p in pls if p.get('id') != pl_id]
                    data['youtube_playlists'] = pls
                    guardar_userdata(data)
                    xbmcgui.Dialog().notification("YouTube", "Playlist eliminada", xbmcgui.NOTIFICATION_INFO, 2000)
                    self.cargar_contenido_youtube_moderno('playlists')
            else:
                xbmcgui.Dialog().notification("YouTube", "Esta playlist es predeterminada", xbmcgui.NOTIFICATION_INFO, 2000)
            return
        self._alternar_favorito_youtube(item)

    def salir_youtube_moderno(self):
        self._set_prop('vista_youtube_modern', '')
        self._set_prop('youtube_vista_shorts', '')
        self._set_prop('youtube_seccion_titulo', '')
        self.cargar_categorias("peliculas")
        try:
            self.setFocus(self.getControl(209))
        except Exception:
            pass

    # -------------------------------------------------------------
    # MÉTODOS DE LA INTERFAZ MODERNA DE TV EN VIVO (TV MODERN UI)
    # -------------------------------------------------------------
    def abrir_tv_moderno(self, categoria='todo'):
        self.seccion_actual = 'tv'
        self.estado = 'tv_moderno'
        self.tv_tab_actual = categoria
        self.tv_chip_actual = categoria
        self._tv_next_page_urls = []
        self.cargando_mas_tv = False
        self._set_prop('vista_tv_modern', 'true')
        self._set_prop('vista_youtube_modern', '')
        self._set_prop('vista_episodios', '')
        self._set_prop('seccion_actual', 'tv')
        self._set_prop('tv_tab_activo', self.tv_tab_actual)
        self._set_prop('tv_seccion_titulo', 'TODO')
        self._set_prop('tv_footer_hint', '[OK] Reproducir   •   [Atrás] Volver   •   [C] Favorito')

        try:
            self.getControl(100).setVisible(False)
            self.getControl(150).setVisible(False)
        except Exception:
            pass

        self._poblar_chips_tv()
        self.cargar_contenido_tv_moderno(categoria)

    def _poblar_chips_tv(self):
        try:
            ctrl = self.getControl(1300)
            if not ctrl:
                return
            ctrl.reset()
            items = []
            chips = tv_en_vivo.get_unified_chips()
            for key, label in chips:
                li = xbmcgui.ListItem(label=label)
                li.setProperty('chip_key', key)
                items.append(li)
            ctrl.addItems(items)
        except Exception:
            pass

    def cargar_contenido_tv_moderno(self, cat_key, query=None):
        self._catalog_generation += 1
        gen = self._catalog_generation
        self.tv_chip_actual = cat_key
        self._tv_next_page_urls = []
        self.cargando_mas_tv = False
        self._set_prop('tv_footer_hint', '[OK] Reproducir   •   [Atrás] Volver   •   [C] Favorito')

        # Buscar
        if cat_key == 'search' and query:
            clean_q = limpiar_texto(query).upper()
            self._set_prop('tv_seccion_titulo', f"BÚSQUEDA: {clean_q}")
            prog = xbmcgui.DialogProgress()
            prog.create('TV en Vivo', f"Buscando canales: {clean_q}...")
            try:
                channels = tv_en_vivo.get_channels(f"tv://buscar?q={urllib.parse.quote_plus(query)}")
            except Exception:
                channels = []
            finally:
                prog.close()
            self._render_canales_tv_moderno(channels, gen)
            return

        # Historial
        if cat_key == 'history':
            data = cargar_userdata()
            hist_items = data.get('tv_historial', [])
            self._set_prop('tv_seccion_titulo', 'RECIÉN VISTOS')
            self._set_prop('tv_footer_hint', '[OK] Reproducir   •   [C] Eliminar del historial   •   [Atrás] Volver')
            self._render_canales_tv_moderno(hist_items, gen)
            return

        # Favoritos
        if cat_key == 'favorites':
            data = cargar_userdata()
            favs = data.get('tv_favoritos', [])
            self._set_prop('tv_seccion_titulo', 'FAVORITOS')
            self._set_prop('tv_footer_hint', '[OK] Reproducir   •   [C] Eliminar de Favoritos   •   [Atrás] Volver')
            self._render_canales_tv_moderno(favs, gen)
            return

        # Agenda deportiva / Eventos deportivos en vivo
        if cat_key in ('eventos_deportivos', 'agenda', 'deportes_agenda'):
            self._set_prop('tv_seccion_titulo', 'EVENTOS DEPORTIVOS EN VIVO')
            prog = xbmcgui.DialogProgress()
            prog.create('TV en Vivo', 'Cargando eventos deportivos en vivo...')
            try:
                channels = tv_en_vivo.get_channels_unified('eventos_deportivos')
            except Exception:
                channels = []
            finally:
                prog.close()
            self._render_canales_tv_moderno(channels, gen)
            return

        # Título de la categoría
        chips_dict = dict(tv_en_vivo.UNIFIED_CATEGORIES)
        cat_title = chips_dict.get(cat_key, cat_key.replace('_', ' ').upper())
        self._set_prop('tv_seccion_titulo', cat_title.upper())

        prog = xbmcgui.DialogProgress()
        prog.create('TV en Vivo', f"Cargando canales de {cat_title}...")
        try:
            channels = tv_en_vivo.get_channels_unified(cat_key)
        except Exception:
            channels = []
        finally:
            prog.close()

        self._render_canales_tv_moderno(channels, gen)

    def _render_canales_tv_moderno(self, channels, generation):
        if generation != self._catalog_generation:
            return
        canales_filtrados = []
        next_pages = []
        for ch in (channels or []):
            if not ch or not isinstance(ch, dict):
                continue
            u = str(ch.get('url', ''))
            t = str(ch.get('title', '')).lower()
            if u.startswith(('tv://nova_page_', 'tv://nova_country_', 'tv://fxp_page_')) or ('siguiente' in t and ('página' in t or 'pagina' in t)):
                if u and u not in next_pages:
                    next_pages.append(u)
                continue
            canales_filtrados.append(ch)

        self._tv_next_page_urls = next_pages
        self.tv_canales_actuales = canales_filtrados
        self.items_actuales = self.tv_canales_actuales
        try:
            ctrl = self.getControl(1400)
            if not ctrl:
                return
            ctrl.reset()
            ui_items = []
            default_cover = _default_channel_cover()
            for ch in self.tv_canales_actuales:
                title = ch.get('title', 'Canal')
                li = xbmcgui.ListItem(label=title)
                thumb = ch.get('cover') or default_cover
                li.setArt({'thumb': thumb, 'icon': thumb})
                prog_act = ch.get('current_program', '')
                if not prog_act:
                    try:
                        prog_act = tv_epg.obtener_programa_actual(title)
                    except Exception:
                        prog_act = ''
                li.setProperty('current_program', prog_act)
                li.setProperty('channel_desc', ch.get('plot', ''))
                li.setProperty('is_tv_channel', 'true')
                li.setProperty('is_live', 'true')
                ui_items.append(li)
            ctrl.addItems(ui_items)
            if ui_items:
                self.setFocus(ctrl)
                ctrl.selectItem(0)
        except Exception as exc:
            xbmc.log(f'Vaquexflix: error renderizando canales tv: {exc}', xbmc.LOGWARNING)

    def cargar_siguiente_pagina_tv(self):
        if getattr(self, 'cargando_mas_tv', False) or not getattr(self, '_tv_next_page_urls', []):
            return
        self.cargando_mas_tv = True
        generation = self._catalog_generation
        cat_key = getattr(self, 'tv_chip_actual', 'todo')

        def load():
            try:
                next_url = self._tv_next_page_urls.pop(0)
                nuevos = tv_en_vivo.get_channels(next_url)
                if not nuevos or not self.activa or generation != self._catalog_generation or self.estado != 'tv_moderno':
                    return

                canales_nuevos = []
                for ch in nuevos:
                    if not ch or not isinstance(ch, dict):
                        continue
                    u = str(ch.get('url', ''))
                    t = str(ch.get('title', '')).lower()
                    if u.startswith(('tv://nova_page_', 'tv://nova_country_', 'tv://fxp_page_')) or ('siguiente' in t and ('página' in t or 'pagina' in t)):
                        if u and u not in self._tv_next_page_urls:
                            self._tv_next_page_urls.append(u)
                        continue
                    canales_nuevos.append(ch)

                if cat_key == 'todo':
                    canales_nuevos = [c for c in canales_nuevos if not c.get('is_match') and not c.get('is_event') and not str(c.get('url', '')).startswith('tv_sport://')]
                elif cat_key == 'deportes':
                    canales_nuevos = tv_en_vivo._filtrar_canales_deportivos(canales_nuevos)

                if not canales_nuevos:
                    return

                vistos_existentes = {tv_en_vivo._normalize_title_key(c.get('title', '')) for c in self.tv_canales_actuales}
                canales_a_anadir = []
                for c in canales_nuevos:
                    k = tv_en_vivo._normalize_title_key(c.get('title', ''))
                    if k and k not in vistos_existentes:
                        vistos_existentes.add(k)
                        canales_a_anadir.append(c)

                if not canales_a_anadir:
                    return

                canales_a_anadir = tv_en_vivo._enriquecer_con_epg(canales_a_anadir)
                self.tv_canales_actuales.extend(canales_a_anadir)
                self.items_actuales = self.tv_canales_actuales

                ctrl = self.getControl(1400)
                if not ctrl:
                    return

                ui_items = []
                default_cover = _default_channel_cover()
                for ch in canales_a_anadir:
                    title = ch.get('title', 'Canal')
                    li = xbmcgui.ListItem(label=title)
                    thumb = ch.get('cover') or default_cover
                    li.setArt({'thumb': thumb, 'icon': thumb})
                    prog_act = ch.get('current_program', '')
                    if not prog_act:
                        try:
                            prog_act = tv_epg.obtener_programa_actual(title)
                        except Exception:
                            prog_act = ''
                    li.setProperty('current_program', prog_act)
                    li.setProperty('channel_desc', ch.get('plot', ''))
                    li.setProperty('is_tv_channel', 'true')
                    li.setProperty('is_live', 'true')
                    ui_items.append(li)

                position = ctrl.getSelectedPosition()
                ctrl.addItems(ui_items)
                if position >= 0:
                    ctrl.selectItem(position)
            except Exception as exc:
                xbmc.log(f'Vaquexflix: error cargando siguiente pagina tv: {exc}', xbmc.LOGWARNING)
            finally:
                if generation == self._catalog_generation:
                    self.cargando_mas_tv = False

        threading.Thread(target=load, daemon=True).start()

    def _alternar_favorito_tv_moderno(self, ch):
        if not ch or not ch.get('title'):
            return
        data = cargar_userdata()
        favs = data.get('tv_favoritos', [])
        ch_title = ch.get('title')
        ch_url = ch.get('url', '')
        existe = any(x.get('title') == ch_title or (ch_url and x.get('url') == ch_url) for x in favs)
        if existe:
            favs = [x for x in favs if x.get('title') != ch_title and (not ch_url or x.get('url') != ch_url)]
            msg = 'Eliminado de Favoritos de TV'
        else:
            favs.insert(0, dict(ch))
            msg = 'Añadido a Favoritos de TV'
        data['tv_favoritos'] = favs
        guardar_userdata(data)
        xbmcgui.Dialog().notification('TV en Vivo', msg, xbmcgui.NOTIFICATION_INFO, 2000)
        if getattr(self, 'tv_chip_actual', '') == 'favorites':
            self.cargar_contenido_tv_moderno('favorites')

    def _eliminar_canal_historial_tv_moderno(self, ch):
        if not ch or not ch.get('title'):
            return
        data = cargar_userdata()
        hist = data.get('tv_historial', [])
        ch_title = ch.get('title')
        ch_url = ch.get('url', '')
        data['tv_historial'] = [x for x in hist if x.get('title') != ch_title and (not ch_url or x.get('url') != ch_url)]
        guardar_userdata(data)
        xbmcgui.Dialog().notification('TV en Vivo', 'Eliminado de Recién Vistos', xbmcgui.NOTIFICATION_INFO, 1500)
        if getattr(self, 'tv_chip_actual', '') == 'history':
            self.cargar_contenido_tv_moderno('history')

    def reproducir_canal_tv_moderno(self, ch, index=-1):
        if not ch or not ch.get('url'):
            return
        stream_url = ch.get('url', '')

        if stream_url.startswith(('tv://nova_page_', 'tv://nova_country_', 'tv://fxp_page_')):
            self.cargar_contenido_tv_moderno(stream_url)
            return

        self.reproducir_canal_tv(ch)

    def salir_tv_moderno(self):
        self._set_prop('vista_tv_modern', '')
        self._set_prop('tv_seccion_titulo', '')
        self.cargar_categorias("peliculas")
        try:
            self.setFocus(self.getControl(208))
        except Exception:
            pass

    def reproducir_con_historial(self, titulo, url_video, cover_url="", is_serie=False, plot="", ep_index=-1):
        if getattr(self, '_preparando_video', False):
            return
        self._preparando_video = True
        try:
            self._preparar_reproduccion(titulo, url_video, cover_url, is_serie, plot, ep_index)
        finally:
            self._preparando_video = False

    def _preparar_reproduccion(self, titulo, url_video, cover_url="", is_serie=False, plot="", ep_index=-1):
        self.episodio_index_actual = ep_index
        url_norm = url_video.split('?')[0].rstrip('/')
        diag = xbmcgui.Dialog()
        choose_server = self.experimental
        prog = xbmcgui.DialogProgress()
        def active():
            return self.activa and (prog is None or not prog.iscanceled())

        if prog is not None:
            prog.create("Vaquexflix", "Preparando reproducción…")
            xbmc.sleep(50)
        fast_premium = False
        def all_servers(start_pct=26, end_pct=55, msg='Consultando servidores disponibles…', exp_override=None):
            exp_flag = self.experimental if exp_override is None else exp_override
            waiter = playback.progress_waiter(
                prog, lambda: self.activa, msg, start_pct, end_pct, 5.0)
            return playback.request_with_progress(
                lambda: catalog.servers(selected, exp_flag, self.serie_actual if is_serie else None),
                network.presupuesto_resolucion, waiter)
        try:
            candidates = self.episodios_actuales if ep_index >= 0 else self.items_actuales
            selected = next((x for x in candidates if x.get('url') == url_video),
                            {'title': titulo, 'url': url_video, 'cover': cover_url, 'is_serie': is_serie})
            servidores_disp = []
            extended_tried = False
            if not choose_server:
                try:
                    waiter_fast = playback.progress_waiter(
                        prog, lambda: self.activa, 'Buscando servidor principal…', 5, 25, 3.0)
                    servidores_disp = playback.request_with_progress(
                        lambda: catalog.normal_premium(selected, self.serie_actual if is_serie else None),
                        network.presupuesto_resolucion, waiter_fast)
                    fast_premium = bool(servidores_disp)
                except playback.Cancelled:
                    raise
                except Exception as exc:
                    xbmc.log('Vaquexflix: Premium rapido no disponible: ' + type(exc).__name__, xbmc.LOGWARNING)
            if not servidores_disp:
                if choose_server:
                    servidores_disp = all_servers(8, 92, 'Consultando servidores disponibles…')
                else:
                    servidores_disp = all_servers(26, 55, 'Consultando servidores disponibles…')
                    if not servidores_disp and active():
                        extended_tried = True
                        servidores_disp = all_servers(
                            56, 75, 'Buscando en otras fuentes activas…', exp_override=True)
        except playback.Cancelled:
            if prog is not None:
                prog.close()
            return
        except Exception as exc:
            xbmc.log(f'Vaquexflix error al obtener servidores: {exc}', xbmc.LOGERROR)
            servidores_disp = []
        if choose_server:
            if servidores_disp and prog is not None:
                prog.update(100, 'Servidores listos')
            prog.close()

        if not servidores_disp:
            prog.close()
            message = 'No hay servidores disponibles' if choose_server else 'No hay servidores disponibles para este contenido'
            is_lol = selected.get('source') == 'lolplus' or str(selected.get('url', '')).startswith('lolplus://')
            if catalog.is_primary(selected) and not is_lol:
                message = sessions.access_error() or message
            diag.notification('Vaquexflix', message, xbmcgui.NOTIFICATION_WARNING, 6000)
            return

        # Sondear cabeceras en paralelo antes de mostrar las opciones.
        current_item_key = stream_metadata.item_key(selected, self.serie_actual if is_serie else None)
        def server_key(server):
            return stream_metadata.cache_key(server['url'])

        if choose_server:
            quality_cache = _cargar_calidad_cacheada(servidores_disp, current_item_key)
        else:
            data_ud = cargar_userdata()
            if data_ud.get('server_quality_version') != 3:
                data_ud['server_quality'] = {}
                data_ud['server_quality_version'] = 3
                guardar_userdata(data_ud)
            quality_cache = data_ud.get('server_quality', {})
            def auto_priority(server):
                meta = quality_cache.get(server_key(server), {})
                if time.time() - meta.get('updated', 0) > 21600:
                    meta = {}
                return playback.server_priority(server, meta)
            servidores_disp.sort(key=auto_priority)

        idx = 0
        nombres = []
        if choose_server:
            resultado, nombres = _elegir_con_sondeo_incremental(
                self, servidores_disp, titulo, current_item_key, quality_cache,
                diag, xbmcgui.DialogProgress, allow_upfront_cancel=True)
            if resultado is None:
                return
            idx, stream_final = resultado
        else:
            stream_final = None
            attempted_premium_url = servidores_disp[0]['url'] if fast_premium else ''
            tried_urls = set()
            cursor = 30 if fast_premium else 58
            while True:
                total_srv = len(servidores_disp)
                for idx, srv_actual in enumerate(servidores_disp):
                    if not active():
                        break
                    srv_url = srv_actual.get('url', '')
                    if srv_url:
                        tried_urls.add(srv_url)
                    if srv_actual.get('resolver_status') == 'pending':
                        xbmc.log('Vaquexflix: servidor pendiente de resolver: ' +
                                 srv_actual.get('nombre', 'Servidor'), xbmc.LOGINFO)
                        continue
                    slice_end = min(96, cursor + max(8, (96 - cursor) // 2))
                    msg_srv = f"Conectando a {srv_actual.get('nombre', 'Servidor')} ({idx + 1}/{total_srv})…"
                    xbmc.log('Vaquexflix: intento {}/{} seleccion {} / {} / {}'.format(
                        idx + 1, total_srv, limpiar_texto(titulo),
                        srv_actual.get('nombre', 'Servidor'),
                        urllib.parse.urlsplit(srv_actual['url']).hostname), xbmc.LOGINFO)
                    try:
                        waiter = playback.progress_waiter(
                            prog, lambda: self.activa, msg_srv, cursor, slice_end, 5.0)
                        cursor = slice_end
                        stream_final = playback.request_with_progress(
                            lambda url=srv_actual['url']: resolvers.resolver_stream(url),
                            network.presupuesto_resolucion, waiter)
                        if stream_final:
                            break
                    except playback.Cancelled:
                        prog.close()
                        return
                    except network.ServidorNoDisponible as exc:
                        xbmc.log(f'Vaquexflix: {srv_actual.get("nombre", "Servidor")}: {exc}', xbmc.LOGWARNING)
                    except Exception as exc:
                        xbmc.log(f'Vaquexflix error al resolver {srv_actual.get("nombre", "Servidor")}: {exc}', xbmc.LOGERROR)
                if stream_final or not active():
                    break
                if fast_premium:
                    fast_premium = False
                    exp_flag = False
                    msg_alt = 'Buscando servidores alternativos…'
                elif not extended_tried:
                    extended_tried = True
                    exp_flag = True
                    msg_alt = 'Buscando en otras fuentes activas…'
                else:
                    break
                try:
                    found_alt = all_servers(min(cursor, 75), 82, msg_alt, exp_override=exp_flag)
                    servidores_disp = [
                        srv for srv in ordenar_alternativas_normales(
                            found_alt, attempted_premium_url, quality_cache)
                        if srv.get('url') not in tried_urls
                    ]
                    cursor = 82
                except playback.Cancelled:
                    prog.close()
                    return
                except Exception as exc:
                    xbmc.log('Vaquexflix: alternativas no disponibles: ' + type(exc).__name__, xbmc.LOGWARNING)
                    servidores_disp = []
            if stream_final and prog is not None:
                prog.update(100, 'Iniciando reproducción…')
            prog.close()
            if not self.activa or not stream_final:
                if self.activa:
                    diag.notification('Vaquexflix', 'No se pudo reproducir este contenido', xbmcgui.NOTIFICATION_WARNING, 6000)
                return

        if choose_server:
            servidor_elegido = servidores_disp[idx]
            diag.notification("Vaquexflix", f"Reproduciendo: {servidor_elegido.get('nombre', 'Servidor')}", xbmcgui.NOTIFICATION_INFO, 3500)

        data_user = cargar_userdata()
        segundo_reanudar = 0
        historial = data_user.get('historial', {})
        saved_progress = watch_history.entry_for(historial, selected)
        if saved_progress:
            seg = saved_progress.get('time', 0)
            m, s = divmod(int(seg), 60)
            if seg > 20:
                if diag.yesno("Vaquexflix", f"Deseas reanudar desde {m:02d}:{s:02d}?", nolabel="Inicio", yeslabel="Reanudar"):
                    segundo_reanudar = seg

        tit_hist = re.sub(r'\s*\(\d+:\d+\)', '', limpiar_texto(titulo)).strip()
        quality = resolvers.CALIDADES_HLS.get(stream_final.split('|')[0], '')
        if quality and choose_server:
            diag.notification('Vaquexflix - Calidad disponible', quality, xbmcgui.NOTIFICATION_INFO, 4000)
        series_info = dict(self.serie_actual) if is_serie and ep_index >= 0 and self.serie_actual else {}
        poster_serie = series_info.get('cover', '') if series_info else ''
        hist_cover = poster_serie if (is_serie and poster_serie) else cover_url
        self._iniciar_stream({
            'stream': stream_final, 'url_norm': url_norm,
            'manual_servers': servidores_disp if choose_server else [],
            'manual_labels': nombres if choose_server else [],
            'all_manual_servers': list(servidores_disp) if choose_server else [],
            'session_quality': dict(quality_cache) if choose_server else {},
            'item_key': current_item_key,
            'manual_index': idx if choose_server else None,
            'fallback_servers': servidores_disp[idx + 1:] if not choose_server else [],
            'lazy_fallback': bool(not choose_server and fast_premium),
            'fallback_item': selected if not choose_server and fast_premium else None,
            'fallback_series': self.serie_actual if not choose_server and fast_premium and is_serie else None,
            'attempted_premium_url': attempted_premium_url if not choose_server else '',
            'history_aliases': [watch_history.key(v['url']) for v in catalog.variants(selected)],
            'catalog_item': dict(selected),
            'catalog_series': dict(self.serie_actual) if is_serie and self.serie_actual else None,
            'server_key': server_key(servidores_disp[idx]), 'quality': quality,
            'history': dict({'title': tit_hist, 'cover': hist_cover, 'episode_cover': cover_url, 'is_serie': is_serie, 'plot': plot,
                             'year': selected.get('year', ''), 'variants': catalog.variants(selected)},
                            **({'series': series_info} if series_info else {})),
        }, segundo_reanudar)

    def detener_reproduccion(self):
        if self._av_started and self.reproduciendo_video:
            self._guardar_progreso()
        was_active = self.reproduciendo_video
        self.reproduciendo_video = False
        self._en_fullscreen = False
        session = self.session_reproduccion_activa
        self.session_reproduccion_activa += 1
        try:
            if self._closing_session is None and (was_active or self.player.isPlaying()):
                self._closing_session = session
                self._closing_since = time.monotonic()
                self._closing_warned = False
                xbmc.log('Vaquexflix: cierre solicitado de sesion {}'.format(session), xbmc.LOGINFO)
                if urllib.parse.urlsplit(self._playback_context.get('stream', '').split('|')[0]).hostname == '127.0.0.1':
                    try:
                        captured = playback.start_close_diagnostic(os.path.join(os.path.dirname(DATA_FILE), 'mega_close_threads.log'))
                        xbmc.log('Vaquexflix: diagnostico de cierre local ' + ('activado' if captured else 'no disponible'), xbmc.LOGINFO)
                    except Exception:
                        pass
                # No bloquear Python esperando al hilo de video durante el cierre.
                xbmc.executebuiltin('PlayerControl(Stop)', False)
        except Exception:
            pass
        finally:
            # Regla global: cualquier pelicula, episodio o directo puede haber
            # iniciado un proxy HLS local. Liberar sus clientes en todo cierre.
            import hls_proxy
            hls_proxy.cancel_active()

        # Diferir las consultas/visibilidad de controles GUI hasta confirmar el cierre de Kodi
        # para evitar interbloqueos entre el GIL de Python y CCurlFile::Stat/GUI en Windows.
        if getattr(self, 'seccion_actual', '') in ("youtube", "tv"):
            self._pending_vista_especial = self.seccion_actual

    def _aplicar_vista_retorno_especial(self, seccion):
        if seccion == 'tv' and getattr(self, 'estado', '') == 'tv_moderno':
            self._set_prop('vista_tv_modern', 'true')
            self._set_prop('vista_episodios', '')
            try:
                self.getControl(100).setVisible(False)
                self.getControl(150).setVisible(False)
                ctrl = self.getControl(1400)
                if ctrl:
                    self.setFocus(ctrl)
            except Exception:
                pass
            return

        if seccion == 'youtube' and getattr(self, 'estado', '') == 'youtube_moderno':
            self._set_prop('vista_youtube_modern', 'true')
            self._set_prop('vista_episodios', '')
            try:
                self.getControl(100).setVisible(False)
                self.getControl(150).setVisible(False)
                target = 950 if getattr(self, 'youtube_en_shorts', False) else 900
                ctrl = self.getControl(target)
                if ctrl:
                    self.setFocus(ctrl)
            except Exception:
                pass
            return

        cfg = {
            'youtube': ('youtube_videos_actuales', 'youtube_videos'),
            'tv': ('canales_actuales', 'canales'),
        }.get(seccion)
        if not cfg:
            return
        attr, estado = cfg
        if getattr(self, attr, []):
            self.estado = estado
            self._set_prop('vista_episodios', 'true')
            try:
                self.getControl(100).setVisible(False)
                self.getControl(150).setVisible(True)
                self.setFocus(self.getControl(150))
            except Exception:
                pass
        else:
            self.cargar_categorias(seccion)

    # (se ha removido el duplicado _mostrar_dialogo_control_reproductor)

    def _confirmar_cambio_episodio(self, idx):
        if self.en_dialogo_salida:
            return
        self.en_dialogo_salida = True
        paused_here = self._pausar_para_dialogo()
        try:
            if xbmcgui.Dialog().yesno('Vaquexflix', '¿Deseas reproducir este episodio?\n' + self.episodios_actuales[idx]['title'], yeslabel='Reproducir', nolabel='Cancelar'):
                self.detener_reproduccion()
                self.reproducir_episodio_por_indice(idx)
            elif paused_here and xbmc.getCondVisibility('Player.Paused'):
                xbmc.executebuiltin('PlayerControl(Play)', False)
        finally:
            self.en_dialogo_salida = False

    def reproducir_episodio_por_indice(self, idx):
        if 0 <= idx < len(self.episodios_actuales):
            ep = self.episodios_actuales[idx]
            self.pos_anterior = idx
            lista_ctrl = self.getControl(150 if self.estado == "episodios" else 100)
            if lista_ctrl and self.estado == "episodios":
                try: lista_ctrl.selectItem(idx)
                except Exception: pass
            self.reproducir_con_historial(
                ep['title'], ep['url'], cover_url=ep.get('cover', ''), is_serie=True, plot=ep.get('plot', ''), ep_index=idx
            )

    def on_playback_ended(self):
        self.reproduciendo_video = False
        self._en_fullscreen = False
        if self.seccion_actual == "youtube" and getattr(self, 'youtube_video_index_actual', -1) >= 0:
            sig_y = self.youtube_video_index_actual + 1
            y_vids = getattr(self, 'youtube_videos_actuales', [])
            if sig_y < len(y_vids):
                sig_vid = y_vids[sig_y]
                if not self.activa: return
                self.reproducir_video_youtube(sig_vid, index=sig_y)
                return
        if self.episodio_index_actual >= 0 and self.episodios_actuales:
            sig_idx = self.episodio_index_actual + 1
            if sig_idx < len(self.episodios_actuales):
                sig_ep = self.episodios_actuales[sig_idx]
                if not self.activa: return
                resp = xbmcgui.Dialog().yesno(
                    "Vaquexflix",
                    f"¿Deseas reproducir el siguiente episodio?\n{sig_ep['title']}",
                    yeslabel="Reproducir",
                    nolabel="Cancelar"
                )
                if resp:
                    self.reproducir_episodio_por_indice(sig_idx)

    def alternar_favorito(self, item_obj):
        data = cargar_userdata()
        favs = data.setdefault('favoritos', [])
        u = item_obj.get('url', '')
        url_norm = u.split('?')[0].rstrip('/')
        idx = next((i for i, f in enumerate(favs) if f.get('url', '').split('?')[0].rstrip('/') == url_norm), -1)
        is_serie = item_obj.get('is_serie', any(x in u for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))

        if idx >= 0:
            favs.pop(idx)
            xbmcgui.Dialog().notification("Vaquexflix", "Eliminado de Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
        else:
            raw_tit = item_obj.get('title', 'Video')
            tit_clean = re.sub(r'\s*\(\d+:\d+\)', '', limpiar_texto(raw_tit)).strip()
            favs.append({
                'title': tit_clean,
                'url': u,
                'cover': item_obj.get('cover', ''),
                'is_serie': is_serie,
                'plot': item_obj.get('plot', ''),
                'year': item_obj.get('year', ''), 'variants': catalog.variants(item_obj)
            })
            xbmcgui.Dialog().notification("Vaquexflix", "Anadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
        guardar_userdata(data)
        if self.categoria_actual_url == "local://favoritos":
            self.cargar_elementos("local://favoritos", reset=True)

    def eliminar_del_historial(self, item_obj):
        url_norm = item_obj.get('url', '').split('?')[0].rstrip('/')
        data = cargar_userdata()
        historial = data.get('historial', {})
        encontrado = False
        for k in list(historial.keys()):
            if k in item_obj.get('history_keys', []) or k.split('?')[0].rstrip('/') == url_norm or k == item_obj.get('url', ''):
                del historial[k]
                encontrado = True
        if encontrado:
            guardar_userdata(data)
            xbmcgui.Dialog().notification("Vaquexflix", "Eliminado de Recien Vistos", xbmcgui.NOTIFICATION_INFO, 1500)
            if self.categoria_actual_url == "local://historial":
                self.cargar_elementos("local://historial", reset=True)
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "No se encontro en el historial", xbmcgui.NOTIFICATION_INFO, 1200)

    def mostrar_menu_ordenar(self):
        if self.estado not in ["elementos"] or not self.items_actuales:
            return
        opciones = [
            "Por defecto (Metadata original)",
            "Ano (Mas recientes primero)",
            "Ano (Mas antiguos primero)",
            "Alfabetico (A - Z)",
            "Alfabetico (Z - A)",
            "Calificacion (Mayor a menor)"
        ]
        diag = xbmcgui.Dialog()
        sel = diag.select("Vaquexflix - Ordenar contenido", opciones)
        if sel == -1: return

        if sel == 0:
            if self.items_originales:
                self.items_actuales = list(self.items_originales)
        elif sel == 1:
            self.items_actuales.sort(
                key=lambda x: int(re.sub(r'\D', '', str(x.get('year', 0))) or 0),
                reverse=True
            )
        elif sel == 2:
            self.items_actuales.sort(
                key=lambda x: int(re.sub(r'\D', '', str(x.get('year', 9999))) or 9999)
            )
        elif sel == 3:
            self.items_actuales.sort(
                key=lambda x: limpiar_texto(x.get('title', '')).lower()
            )
        elif sel == 4:
            self.items_actuales.sort(
                key=lambda x: limpiar_texto(x.get('title', '')).lower(),
                reverse=True
            )
        elif sel == 5:
            def _get_rating(x):
                r = str(x.get('rating', '0')).replace('★', '').replace(',', '.').strip()
                try: return float(r)
                except: return 0.0
            self.items_actuales.sort(key=_get_rating, reverse=True)

        lista_ctrl = self.getControl(100)
        if lista_ctrl:
            lista_ctrl.reset()
            ui_items = []
            for obj in self.items_actuales:
                item = xbmcgui.ListItem(label=catalog.display_title(obj))
                is_dora = self.seccion_actual == 'doramas' or doramas.is_dorama(obj)
                configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''), genres=obj.get('genres', []), is_dorama=is_dora, mpaa=obj.get('mpaa', ''), duration=obj.get('duration', 0))
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

    def actualizar_pie_de_pagina(self):
        txt = "[B][X][/B] Buscar   [B][Y][/B] Ordenar   [B][XX / C][/B] Favorito/Quitar   [B][A / Enter][/B] Seleccionar   [B][B / Esc][/B] Volver"
        try:
            self.getControl(500).setVisible(True)
        except Exception:
            pass
        try:
            ctrl = self.getControl(501)
            if ctrl:
                ctrl.setLabel(txt)
        except Exception:
            pass

    def _on_x_pressed(self):
        now = time.time()
        if (now - self._last_x_time) < 0.42:
            self._last_x_time = 0.0
            if self._x_timer:
                self._x_timer.cancel()
                self._x_timer = None
            self._ejecutar_accion_secundaria()
        else:
            self._last_x_time = now
            if self._x_timer:
                self._x_timer.cancel()
            self._x_timer = threading.Timer(0.38, self._ejecutar_single_x)
            self._x_timer.start()

    def _ejecutar_single_x(self):
        self._x_timer = None
        if self.activa and not self.reproduciendo_video and not self.player.isPlaying():
            self.abrir_busqueda()

    def _ejecutar_accion_secundaria(self):
        if self.estado in ["elementos"]:
            lista_ctrl = self.getControl(100)
            if lista_ctrl:
                idx = lista_ctrl.getSelectedPosition()
                if 0 <= idx < len(self.items_actuales):
                    sel = self.items_actuales[idx]
                    if not sel.get('url'):
                        return
                    if self.categoria_actual_url == "local://historial":
                        self.eliminar_del_historial(sel)
                    else:
                        self.alternar_favorito(sel)
        elif self.estado == "canales":
            lista_ctrl = self.getControl(150)
            if lista_ctrl:
                idx = lista_ctrl.getSelectedPosition()
                if 0 <= idx < len(self.canales_actuales):
                    ch = self.canales_actuales[idx]
                    if not ch.get('url'):
                        return
                    data = cargar_userdata()
                    if self.categoria_actual_url == "tv://historial":
                        hist = [x for x in data.get('tv_historial', []) if x.get('url') != ch.get('url') and x.get('title') != ch.get('title')]
                        data['tv_historial'] = hist
                        guardar_userdata(data)
                        xbmcgui.Dialog().notification("TV en Vivo", "Eliminado de Recién Vistos", xbmcgui.NOTIFICATION_INFO, 1500)
                        self.cargar_canales_tv("tv://historial", "RECIÉN VISTOS", self._tv_cat_cover)
                    else:
                        favs = data.get('tv_favoritos', [])
                        exists = any(x.get('url') == ch.get('url') or x.get('title') == ch.get('title') for x in favs)
                        if exists:
                            favs = [x for x in favs if x.get('url') != ch.get('url') and x.get('title') != ch.get('title')]
                            data['tv_favoritos'] = favs
                            guardar_userdata(data)
                            xbmcgui.Dialog().notification("TV en Vivo", "Eliminado de Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
                        else:
                            favs.insert(0, {
                                'title': ch.get('title', 'Canal'),
                                'url': ch.get('url', ''),
                                'cover': ch.get('cover', ''),
                                'rating': ch.get('rating', '1080p'),
                                'plot': ch.get('plot', '')
                            })
                            data['tv_favoritos'] = favs
                            guardar_userdata(data)
                            xbmcgui.Dialog().notification("TV en Vivo", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
                        if self.categoria_actual_url == "tv://favoritos":
                            self.cargar_canales_tv("tv://favoritos", "FAVORITOS", self._tv_cat_cover)
        elif self.estado == "youtube_videos":
            lista_ctrl = self.getControl(150)
            if lista_ctrl:
                idx = lista_ctrl.getSelectedPosition()
                if 0 <= idx < len(getattr(self, 'youtube_videos_actuales', [])):
                    vid = self.youtube_videos_actuales[idx]
                    data = cargar_userdata()
                    cat_key = getattr(self, 'categoria_actual_url', '').replace('tube://', '').strip().lower()

                    if cat_key == "playlists":
                        pls = data.get('youtube_playlists', [])
                        matched = [p for p in pls if p.get('id') == vid.get('id')]
                        if matched:
                            pls = [p for p in pls if p.get('id') != vid.get('id')]
                            data['youtube_playlists'] = pls
                            guardar_userdata(data)
                            xbmcgui.Dialog().notification("YouTube", "Playlist eliminada", xbmcgui.NOTIFICATION_INFO, 1500)
                            self.cargar_videos_youtube("tube://playlists", "LISTAS DE REPRODUCCIÓN", getattr(self, '_tube_cat_cover', ''))
                        else:
                            xbmcgui.Dialog().notification("YouTube", "Esta playlist es predeterminada", xbmcgui.NOTIFICATION_INFO, 1500)
                        return

                    vid_id = vid.get('id') or tube_engine.extract_video_id(vid.get('url', ''))
                    if not vid_id:
                        return

                    if cat_key == "history":
                        hist = [x for x in data.get('youtube_historial', []) if (x.get('id') != vid_id and x.get('title') != vid.get('title'))]
                        data['youtube_historial'] = hist
                        guardar_userdata(data)
                        xbmcgui.Dialog().notification("YouTube", "Eliminado de Recién Vistos", xbmcgui.NOTIFICATION_INFO, 1500)
                        self.cargar_videos_youtube("tube://history", "RECIÉN VISTOS (YOUTUBE)", getattr(self, '_tube_cat_cover', ''))
                    else:
                        favs = data.get('youtube_favoritos', [])
                        exists = any((x.get('id') == vid_id or x.get('title') == vid.get('title')) for x in favs)
                        if exists:
                            favs = [x for x in favs if (x.get('id') != vid_id and x.get('title') != vid.get('title'))]
                            data['youtube_favoritos'] = favs
                            guardar_userdata(data)
                            xbmcgui.Dialog().notification("YouTube", "Eliminado de Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
                            if cat_key == "favorites":
                                self.cargar_videos_youtube("tube://favorites", "FAVORITOS (YOUTUBE)", getattr(self, '_tube_cat_cover', ''))
                        else:
                            favs.insert(0, {
                                'id': vid_id,
                                'title': vid.get('title', 'Vídeo YouTube'),
                                'url': f"https://www.youtube.com/watch?v={vid_id}",
                                'cover': vid.get('cover', ''),
                                'rating': vid.get('rating', 'VÍDEO'),
                                'plot': vid.get('plot', '')
                            })
                            data['youtube_favoritos'] = favs
                            guardar_userdata(data)
                            xbmcgui.Dialog().notification("YouTube", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)

    def abrir_busqueda(self, global_search=False):
        if self.seccion_actual == 'tv' and not global_search:
            if getattr(self, 'tv_modern_ui', True) and self.estado == 'tv_moderno':
                kb = xbmc.Keyboard('', 'Buscar Canal de TV')
                kb.doModal()
                if kb.isConfirmed() and kb.getText().strip():
                    self.cargar_contenido_tv_moderno('search', query=kb.getText().strip())
                return
            kb = xbmc.Keyboard('', 'Buscar Canal de TV')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                txt = kb.getText().strip()
                if txt:
                    self.cargar_canales_tv(f"tv://buscar?q={urllib.parse.quote_plus(txt)}", f"BÚSQUEDA TV: {limpiar_texto(txt).upper()}", "")
            return

        if self.seccion_actual == 'youtube' and not global_search:
            self.cargar_videos_youtube('tube://search', 'BUSCADOR DE YOUTUBE', '')
            return

        section = 'all' if global_search or self.seccion_actual in ('busqueda', 'tv', 'youtube') else self.seccion_actual
        kb = xbmc.Keyboard('', 'Buscar en todo' if section == 'all' else 'Buscar en ' + section.title())
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            txt = kb.getText().strip()
            if txt:
                self.seccion_actual = section if section != 'all' else "busqueda"
                self._set_prop('seccion_actual', self.seccion_actual)
                self.actualizar_etiqueta(f"BÚSQUEDA: {limpiar_texto(txt).upper()}")
                url_busqueda = f"search://{urllib.parse.quote_plus(txt)}?section={section}"
                self.cargar_elementos(url_busqueda, reset=True)

    def onClick(self, controlId):
        if getattr(self, "_preparando_video", False):
            return
        if controlId in (100, 150):
            lista_ctrl = self.getControl(controlId)
            idx = lista_ctrl.getSelectedPosition()

            if controlId == 100:
                if self.estado == "categorias":
                    if 0 <= idx < len(self.items_actuales):
                        cat_sel = self.items_actuales[idx]
                        if cat_sel.get('url', '').startswith('tv://'):
                            self.cargar_canales_tv(cat_sel['url'], cat_sel['title'], cat_sel.get('cover', ''))
                        elif cat_sel.get('url', '').startswith('tube://'):
                            self.cargar_videos_youtube(cat_sel['url'], cat_sel['title'], cat_sel.get('cover', ''))
                        else:
                            self.actualizar_etiqueta(cat_sel['title'].upper())
                            self.cargar_elementos(cat_sel['url'], reset=True)
                elif self.estado == "elementos":
                    if 0 <= idx < len(self.items_actuales):
                        sel = self.items_actuales[idx]
                        u = sel.get('url', '')
                        if not u:
                            return
                        if doramas.owns(u) and not sel.get('media_type') and not sel.get('episode'):
                            try:
                                sel.update(doramas.metadata(sel))
                            except Exception as exc:
                                xbmc.log('Vaquexflix: tipo de dorama: ' + str(exc), xbmc.LOGWARNING)
                        if sel.get('history_keys') and sel.get('is_serie'):
                            self.cargar_temporadas(sel)
                        elif '/episodio-' in u or '/temporada-' in u or ('season' in sel and 'episode' in sel) or sel.get('is_episode') or '/ver/' in u:
                            self.reproducir_con_historial(sel['title'], u, cover_url=sel.get('cover', ''), is_serie=True, plot=sel.get('plot', ''), ep_index=-1)
                        elif sel.get('is_serie', False):
                            self.cargar_temporadas(sel)
                        else:
                            self.reproducir_con_historial(sel['title'], u, cover_url=sel.get('cover', ''), is_serie=False, plot=sel.get('plot', ''), ep_index=-1)
                elif self.estado in ("temporadas", "episodios"):
                    if 0 <= idx < len(self.temporadas_disponibles):
                        self.cargar_episodios(self.temporadas_disponibles[idx])
            elif controlId == 150:
                if self.estado == "tv_categorias":
                    if 0 <= idx < len(self.items_actuales):
                        cat_sel = self.items_actuales[idx]
                        self.cargar_canales_tv(cat_sel['url'], cat_sel['title'], cat_sel.get('cover', ''))
                elif self.estado == "youtube_categorias":
                    if 0 <= idx < len(self.items_actuales):
                        cat_sel = self.items_actuales[idx]
                        self.cargar_videos_youtube(cat_sel['url'], cat_sel['title'], cat_sel.get('cover', ''))
                elif self.estado == "episodios":
                    if 0 <= idx < len(self.episodios_actuales):
                        ep = self.episodios_actuales[idx]
                        self.reproducir_con_historial(ep['title'], ep['url'], cover_url=ep.get('cover', ''), is_serie=True, plot=ep.get('plot', ''), ep_index=idx)
                elif self.estado == "canales":
                    if 0 <= idx < len(self.canales_actuales):
                        ch = self.canales_actuales[idx]
                        self.reproducir_canal_tv(ch)
                elif self.estado == "youtube_videos":
                    if 0 <= idx < len(getattr(self, 'youtube_videos_actuales', [])):
                        vid = self.youtube_videos_actuales[idx]
                        u = vid.get('url', '')
                        if u == 'tube://add_playlist':
                            self.cargar_videos_youtube('tube://add_playlist', 'AÑADIR PLAYLIST', '')
                        elif u.startswith('tube://playlist/'):
                            self.cargar_videos_youtube(u, vid.get('title', 'PLAYLIST'), vid.get('cover', ''))
                        elif u.startswith('tube://channel/'):
                            self.cargar_videos_youtube(u, vid.get('title', 'CANAL'), vid.get('cover', ''))
                        else:
                            self.reproducir_video_youtube(vid, index=idx)

        elif controlId == 201:
            if self.seccion_actual == 'youtube':
                self.cargar_videos_youtube('tube://search', 'BUSCADOR DE YOUTUBE', '')
            elif self.seccion_actual == 'tv':
                self.abrir_busqueda(global_search=False)
            else:
                self.abrir_busqueda(global_search=True)
        elif controlId == 202: self.cargar_categorias("peliculas")
        elif controlId == 203: self.cargar_categorias("series")
        elif controlId == 207: self.cargar_categorias("animes")
        elif controlId == 205: self.cargar_categorias("doramas")
        elif controlId == 208:
            if getattr(self, 'tv_modern_ui', True):
                self.abrir_tv_moderno()
            else:
                self.cargar_categorias("tv")
        elif controlId == 209:
            if getattr(self, 'youtube_modern_ui', True):
                self.abrir_youtube_moderno()
            else:
                self.cargar_categorias("youtube")
        elif controlId == 206: self.mostrar_faq()
        elif controlId == 601:
            self.abrir_youtube_moderno('trending')
        elif controlId == 602:
            self.abrir_youtube_moderno('shorts')
        elif controlId == 608:
            self.youtube_tab_actual = 'canales'
            self._set_prop('youtube_tab_activo', 'canales')
            self.cargar_contenido_youtube_moderno('channels')
        elif controlId in (603, 701):
            self._dialogo_busqueda_avanzada_youtube()
        elif controlId == 604:
            self.youtube_tab_actual = 'favoritos'
            self._set_prop('youtube_tab_activo', 'favoritos')
            self.cargar_contenido_youtube_moderno('favorites')
        elif controlId == 605:
            self.youtube_tab_actual = 'historial'
            self._set_prop('youtube_tab_activo', 'historial')
            self.cargar_contenido_youtube_moderno('history')
        elif controlId == 606:
            self.youtube_tab_actual = 'listas'
            self._set_prop('youtube_tab_activo', 'listas')
            self.cargar_contenido_youtube_moderno('playlists')
        elif controlId == 607:
            self.salir_youtube_moderno()
        elif controlId == 800:
            try:
                pos = self.getControl(800).getSelectedPosition()
                if 0 <= pos < len(YOUTUBE_CHIPS):
                    key, label = YOUTUBE_CHIPS[pos]
                    self.cargar_contenido_youtube_moderno(key)
            except Exception:
                pass
        elif controlId == 801:
            try:
                ctrl = self.getControl(800)
                pos = ctrl.getSelectedPosition()
                ctrl.selectItem(max(0, pos - 2))
                self.setFocus(ctrl)
            except Exception:
                pass
        elif controlId == 802:
            try:
                ctrl = self.getControl(800)
                pos = ctrl.getSelectedPosition()
                ctrl.selectItem(min(len(YOUTUBE_CHIPS) - 1, pos + 2))
                self.setFocus(ctrl)
            except Exception:
                pass
        elif controlId == 900:
            try:
                pos = self.getControl(900).getSelectedPosition()
                if 0 <= pos < len(getattr(self, 'youtube_videos_actuales', [])):
                    sel = self.youtube_videos_actuales[pos]
                    u = sel.get('url', '')
                    if u == 'tube://clear_history' or sel.get('id') == 'action_clear_history':
                        self._confirmar_borrar_historial_youtube()
                    elif u == 'tube://add_playlist' or sel.get('id') == 'action_add':
                        self._dialogo_agregar_playlist_youtube()
                    elif u.startswith('tube://playlist/'):
                        pid = u.split('tube://playlist/')[-1].strip()
                        self.cargar_contenido_youtube_moderno(f"playlist/{pid}")
                    elif u.startswith('tube://channel/'):
                        cid = u.split('tube://channel/')[-1].strip()
                        self.cargar_contenido_youtube_moderno(f"channel/{cid}")
                    else:
                        self.reproducir_video_youtube(sel, index=pos)
            except Exception:
                pass
        elif controlId == 950:
            try:
                pos = self.getControl(950).getSelectedPosition()
                if 0 <= pos < len(getattr(self, 'youtube_shorts_items', [])):
                    sel = self.youtube_shorts_items[pos]
                    self.reproducir_video_youtube(sel, index=pos)
            except Exception:
                pass
        elif controlId == 1201:
            kb = xbmc.Keyboard('', 'Buscar Canal de TV')
            kb.doModal()
            if kb.isConfirmed() and kb.getText().strip():
                self.cargar_contenido_tv_moderno('search', query=kb.getText().strip())
        elif controlId == 1202:
            self.tv_tab_actual = 'todo'
            self._set_prop('tv_tab_activo', 'todo')
            self.abrir_tv_moderno('todo')
        elif controlId == 1203:
            self.tv_tab_actual = 'eventos_deportivos'
            self._set_prop('tv_tab_activo', 'eventos_deportivos')
            self.cargar_contenido_tv_moderno('eventos_deportivos')
        elif controlId == 1204:
            try:
                chips = tv_en_vivo.get_unified_chips()
                for idx, (k, l) in enumerate(chips):
                    if k == 'argentina':
                        ctrl_chips = self.getControl(1300)
                        ctrl_chips.selectItem(idx)
                        self.setFocus(ctrl_chips)
                        self.cargar_contenido_tv_moderno(k)
                        break
            except Exception:
                self.cargar_contenido_tv_moderno('latam')
        elif controlId == 1205:
            self.cargar_contenido_tv_moderno('series')
        elif controlId == 1206:
            self.tv_tab_actual = 'favoritos'
            self._set_prop('tv_tab_activo', 'favoritos')
            self.cargar_contenido_tv_moderno('favorites')
        elif controlId == 1207:
            self.tv_tab_actual = 'historial'
            self._set_prop('tv_tab_activo', 'historial')
            self.cargar_contenido_tv_moderno('history')
        elif controlId == 1208:
            self.salir_tv_moderno()
        elif controlId == 1300:
            try:
                pos = self.getControl(1300).getSelectedPosition()
                chips = tv_en_vivo.get_unified_chips()
                if 0 <= pos < len(chips):
                    key, label = chips[pos]
                    self.cargar_contenido_tv_moderno(key)
            except Exception:
                pass
        elif controlId == 1301:
            try:
                ctrl = self.getControl(1300)
                pos = ctrl.getSelectedPosition()
                ctrl.selectItem(max(0, pos - 2))
                self.setFocus(ctrl)
            except Exception:
                pass
        elif controlId == 1302:
            try:
                ctrl = self.getControl(1300)
                pos = ctrl.getSelectedPosition()
                chips = tv_en_vivo.get_unified_chips()
                ctrl.selectItem(min(len(chips) - 1, pos + 2))
                self.setFocus(ctrl)
            except Exception:
                pass
        elif controlId == 1400:
            try:
                pos = self.getControl(1400).getSelectedPosition()
                if 0 <= pos < len(getattr(self, 'tv_canales_actuales', [])):
                    ch = self.tv_canales_actuales[pos]
                    self.reproducir_canal_tv_moderno(ch, index=pos)
            except Exception as exc:
                xbmc.log(f'Vaquexflix: error clic canal tv: {exc}', xbmc.LOGWARNING)
        elif controlId == 204:
            self.experimental = not self.experimental
            ADDON.setSetting('experimental', 'true' if self.experimental else 'false')
            self._set_prop('experimental_enabled', 'true' if self.experimental else 'false')
            self.getControl(204).setSelected(self.experimental)
            self._actualizar_navegacion_lateral()
            target = getattr(self, 'categoria_actual_url', '')
            self._catalog_generation += 1
            self.cargando_mas = False
            if not self.experimental and (self.seccion_actual == 'doramas' or
                                          (self.seccion_actual == 'animes' and not (source_switches.only_enabled('nova') or source_switches.enabled('fxpplus')))):
                self.cargar_categorias('peliculas')
            elif self.estado == 'elementos' and target:
                self.cargar_elementos(target)
                if not target.startswith('local://'):
                    self._aplicar_foco_barra_lateral(204)
            else:
                self.cargar_categorias(self.seccion_actual if self.seccion_actual in
                                      ('series', 'tv', 'youtube') or
                                      (self.seccion_actual == 'animes' and (source_switches.only_enabled('nova') or source_switches.enabled('fxpplus')))
                                      else 'peliculas')
            xbmcgui.Dialog().notification('Vaquexflix', 'Experimental: catálogo completo' if self.experimental else 'Modo normal: solo Premium', xbmcgui.NOTIFICATION_INFO, 3000)

    def mostrar_faq(self):
        dialogo = xbmcgui.Dialog()
        while True:
            yt_status = "ON" if getattr(self, 'youtube_modern_ui', True) else "OFF"
            tv_status = "ON" if getattr(self, 'tv_modern_ui', True) else "OFF"
            opciones = [
                'FAQ',
                'Configurar fuentes',
                f'Diseño moderno YouTube [{yt_status}]',
                f'Diseño moderno TV [{tv_status}]'
            ]
            selected = dialogo.select('Settings', opciones)
            if selected < 0:
                return
            if selected == 0:
                break
            elif selected == 1:
                self._configurar_fuentes(dialogo)
            elif selected == 2:
                self.youtube_modern_ui = not getattr(self, 'youtube_modern_ui', True)
                ADDON.setSetting('youtube_modern_ui', 'true' if self.youtube_modern_ui else 'false')
                xbmcgui.Dialog().notification(
                    'Vaquexflix',
                    f'Diseño moderno YouTube: {"Activado" if self.youtube_modern_ui else "Desactivado"}',
                    xbmcgui.NOTIFICATION_INFO, 2500)
            elif selected == 3:
                self.tv_modern_ui = not getattr(self, 'tv_modern_ui', True)
                ADDON.setSetting('tv_modern_ui', 'true' if self.tv_modern_ui else 'false')
                xbmcgui.Dialog().notification(
                    'Vaquexflix',
                    f'Diseño moderno TV: {"Activado" if self.tv_modern_ui else "Desactivado"}',
                    xbmcgui.NOTIFICATION_INFO, 2500)
        faq_img = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'faq.jpg')
        if os.path.exists(faq_img):
            diag = FAQDialog('faq_dialog.xml', ADDON_PATH, 'Default', '720p')
            diag.doModal()
            del diag
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "Guía visual en preparación (faq.jpg)", xbmcgui.NOTIFICATION_INFO, 3500)

    def _configurar_fuentes(self, dialogo):
        while True:
            entries = ['Actualizar catálogo', 'Activar todas', 'Desactivar todas'] + [f'{label}  [{"ON" if source_switches.enabled(key) else "OFF"}]'
                                           for key, label in source_switches.SOURCES]
            selected = dialogo.select('Configurar fuentes', entries)
            if selected < 0:
                return
            if selected == 0:
                target = getattr(self, 'categoria_actual_url', '')
                self._catalog_generation += 1
                self.cargando_mas = False
                if self.estado == 'elementos' and target:
                    self.cargar_elementos(target)
                elif self.seccion_actual in ('peliculas', 'series', 'animes', 'doramas'):
                    self.cargar_categorias(self.seccion_actual)
                dialogo.notification('Vaquexflix', 'Catálogo actualizado con las fuentes activas.', xbmcgui.NOTIFICATION_INFO, 2500)
                return
            if selected in (1, 2):
                try:
                    source_switches.set_all_enabled(selected == 1)
                except OSError as exc:
                    xbmc.log('Vaquexflix: fuentes: ' + str(exc), xbmc.LOGERROR)
                    dialogo.notification('Vaquexflix', 'No se pudieron guardar los interruptores.', xbmcgui.NOTIFICATION_ERROR)
                    continue
                self._catalog_generation += 1
                self._primary_catalog_source = None
                dialogo.notification('Vaquexflix', 'Todas las fuentes activadas.' if selected == 1 else 'Todas las fuentes desactivadas.', xbmcgui.NOTIFICATION_INFO, 2000)
                continue
            if selected > 2:
                key, label = source_switches.SOURCES[selected - 3]
                try:
                    source_switches.set_enabled(key, not source_switches.enabled(key))
                except OSError as exc:
                    xbmc.log('Vaquexflix: fuente: ' + str(exc), xbmc.LOGERROR)
                    dialogo.notification('Vaquexflix', 'No se pudo guardar el interruptor.', xbmcgui.NOTIFICATION_ERROR)
                    continue
                self._catalog_generation += 1
                self._primary_catalog_source = None
                dialogo.notification('Vaquexflix', f'{label}: {"ON" if source_switches.enabled(key) else "OFF"}', xbmcgui.NOTIFICATION_INFO, 2000)
                continue

    def _aplicar_foco_barra_lateral(self, controlId):
        info = obtener_info_barra_lateral(controlId, getattr(self, 'experimental', False))
        if not info:
            return False
        titulo, descripcion = info
        self._set_prop('sidebar_title', titulo)
        try:
            self.getControl(302).setLabel('')
        except Exception:
            pass
        self.actualizar_sinopsis_texto(descripcion)
        return True

    def _limpiar_foco_barra_lateral(self, clear_subtitle=False):
        self._set_prop('sidebar_title', '')
        if clear_subtitle:
            try:
                self.getControl(302).setLabel('')
            except Exception:
                pass

    def onFocus(self, controlId):
        # Kodi may deliver focus while holding GUI/player locks during Stop.
        # Never query controls from this callback; coalesce work for the loop.
        self._pending_focus = controlId

    def _procesar_foco_pendiente(self):
        if self.reproduciendo_video or self._closing_session is not None:
            return
        if getattr(self, '_pending_reinit', False):
            self._pending_reinit = False
            ejecutar = getattr(self, '_ejecutar_on_init', None)
            if ejecutar:
                ejecutar()
        vista_esp = getattr(self, '_pending_vista_especial', None)
        if vista_esp:
            self._pending_vista_especial = None
            aplicar_vista = getattr(self, '_aplicar_vista_retorno_especial', None)
            if aplicar_vista:
                aplicar_vista(vista_esp)
        controlId = getattr(self, '_pending_focus', None)
        self._pending_focus = None
        if controlId is None:
            return
        aplicar_barra = getattr(self, '_aplicar_foco_barra_lateral', None)
        if aplicar_barra and aplicar_barra(controlId):
            return
        limpiar_barra = getattr(self, '_limpiar_foco_barra_lateral', None)
        if limpiar_barra:
            limpiar_barra()
        if controlId in (100, 150):
            pos = self.pos_anterior
            try:
                ctrl = self.getControl(controlId)
                if ctrl is not None:
                    sel_pos = ctrl.getSelectedPosition()
                    if isinstance(sel_pos, int) and not isinstance(sel_pos, bool) and 0 <= sel_pos < len(self.items_actuales):
                        pos = sel_pos
                        self.pos_anterior = pos
            except Exception:
                pass
            if 0 <= pos < len(self.items_actuales):
                self._actualizar_sinopsis_de_elemento(self.items_actuales[pos])
            else:
                set_sinopsis = getattr(self, 'actualizar_sinopsis_texto', None)
                if set_sinopsis:
                    set_sinopsis('')

    def onAction(self, action):
        aid = action.getId()
        btn_code = action.getButtonCode()

        # 1. Controles durante la reproduccion activa de video
        if self.reproduciendo_video or self.player.isPlaying():
            # Siguiente capitulo / video directo
            if aid in [xbmcgui.ACTION_NEXT_ITEM, 14, 86, 88]:
                if self.seccion_actual == "youtube":
                    target = self._siguiente_indice_youtube(direction=1)
                    if target is not None and self._reproducir_youtube_indice(target):
                        return
                elif self.episodio_index_actual >= 0 and (self.episodio_index_actual + 1) < len(self.episodios_actuales):
                    self._confirmar_cambio_episodio(self.episodio_index_actual + 1)
                    return
            # Capitulo / video anterior directo
            elif aid in [xbmcgui.ACTION_PREV_ITEM, 15, 87, 89]:
                if self.seccion_actual == "youtube":
                    target = self._siguiente_indice_youtube(direction=-1)
                    if target is not None and self._reproducir_youtube_indice(target):
                        return
                elif self.episodio_index_actual > 0:
                    self._confirmar_cambio_episodio(self.episodio_index_actual - 1)
                    return
            # Confirmacion / menu al salir del reproductor de video
            elif aid in [10, 92, 9, 13, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP]:
                self._mostrar_dialogo_control_reproductor()
                return

        # Long press maps to mouse right-click/context menu in Kodi.
        if aid == 101 and not self.reproduciendo_video and not self.player.isPlaying():
            if self.estado == 'youtube_moderno':
                fid = self.getFocusId()
                target_list = getattr(self, 'youtube_videos_actuales', []) if fid == 900 else (getattr(self, 'youtube_shorts_items', []) if fid == 950 else [])
                pos = self.getControl(fid).getSelectedPosition() if fid in (900, 950) else -1
                if 0 <= pos < len(target_list):
                    self._accion_contexto_youtube(target_list[pos])
                    return
            elif self.estado == 'tv_moderno':
                fid = self.getFocusId()
                if fid == 1400:
                    pos = self.getControl(1400).getSelectedPosition()
                    if 0 <= pos < len(getattr(self, 'tv_canales_actuales', [])):
                        ch = self.tv_canales_actuales[pos]
                        if getattr(self, 'tv_chip_actual', '') == 'history':
                            self._eliminar_canal_historial_tv_moderno(ch)
                        else:
                            self._alternar_favorito_tv_moderno(ch)
                        return
            elif self.getFocusId() == 100 and self.estado == 'elementos':
                control = self.getControl(100)
                position = control.getSelectedPosition()
                if 0 <= position < len(self.items_actuales):
                    selected = self.items_actuales[position]
                    if selected.get('url'):
                        self.alternar_favorito(selected)
                return
            elif self.getFocusId() == 150 and self.estado == 'canales':
                self._ejecutar_accion_secundaria()
                return

        # 2. Tecla 'C' en teclado: Favorito / Quitar directo
        if btn_code in [99, 67, 61507] and not self.player.isPlaying():
            if self.estado == 'youtube_moderno':
                fid = self.getFocusId()
                target_list = getattr(self, 'youtube_videos_actuales', []) if fid == 900 else (getattr(self, 'youtube_shorts_items', []) if fid == 950 else [])
                pos = self.getControl(fid).getSelectedPosition() if fid in (900, 950) else -1
                if 0 <= pos < len(target_list):
                    self._accion_contexto_youtube(target_list[pos])
                    return
            elif self.estado == 'tv_moderno':
                fid = self.getFocusId()
                if fid == 1400:
                    pos = self.getControl(1400).getSelectedPosition()
                    if 0 <= pos < len(getattr(self, 'tv_canales_actuales', [])):
                        ch = self.tv_canales_actuales[pos]
                        if getattr(self, 'tv_chip_actual', '') == 'history':
                            self._eliminar_canal_historial_tv_moderno(ch)
                        else:
                            self._alternar_favorito_tv_moderno(ch)
                        return
            self._ejecutar_accion_secundaria()
            return

        # 2b. Tecla Supr / Delete / D: Eliminar del historial de YouTube y TV
        if (btn_code in [127, 61472, 100, 68, 61508] or aid in [xbmcgui.ACTION_DELETE_ITEM, 26]) and not self.player.isPlaying():
            if self.estado == 'youtube_moderno' and getattr(self, 'youtube_chip_actual', '') == 'history':
                self._eliminar_video_actual_historial()
                return
            if self.estado == 'tv_moderno' and getattr(self, 'tv_chip_actual', '') == 'history':
                fid = self.getFocusId()
                if fid == 1400:
                    pos = self.getControl(1400).getSelectedPosition()
                    if 0 <= pos < len(getattr(self, 'tv_canales_actuales', [])):
                        self._eliminar_canal_historial_tv_moderno(self.tv_canales_actuales[pos])
                        return

        # 3. Boton X en gamepad O teclas X / F en teclado (Buscar / Doble X: Favorito o Quitar)
        es_boton_x = (
            aid in [117, 11] or
            btn_code in [120, 88, 61528, 102, 70, 61510]
        )
        if es_boton_x and not self.player.isPlaying():
            self._on_x_pressed()
            return

        # 4. Boton Y en gamepad O teclas Y / O en teclado (Ordenar contenido)
        es_boton_y = (
            aid in [18, 19, 27, 34, 175] or
            btn_code in [121, 89, 61529, 111, 79, 61519]
        )
        if es_boton_y and not self.player.isPlaying():
            self.mostrar_menu_ordenar()
            return

        # 5. Navegacion atras / Volver (B en gamepad, Esc en teclado)
        if aid in [10, 92, 9, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            if self.reproduciendo_video or self.player.isPlaying():
                self._mostrar_dialogo_control_reproductor()
                return

            if self.estado == "episodios":
                if self.categoria_actual_url == "anime://ultimos":
                    self.cargar_categorias("animes")
                else:
                    self.cargar_temporadas(self.serie_actual)
            elif self.estado == "canales":
                self.cargar_categorias("tv")
            elif self.estado == "youtube_videos":
                if getattr(self, 'categoria_actual_url', '').startswith('tube://playlist/'):
                    self.cargar_videos_youtube("tube://playlists", "LISTAS DE REPRODUCCIÓN", getattr(self, '_tube_cat_cover', ''))
                elif getattr(self, 'categoria_actual_url', '').startswith('tube://channel/'):
                    self.cargar_categorias("youtube")
                else:
                    self.cargar_categorias("youtube")
            elif self.estado == "youtube_moderno":
                if str(getattr(self, 'youtube_chip_actual', '')).startswith('channel/'):
                    self.cargar_contenido_youtube_moderno('channels')
                    return
                if str(getattr(self, 'youtube_chip_actual', '')).startswith('playlist/'):
                    self.cargar_contenido_youtube_moderno('playlists')
                    return
                focused = self.getFocusId()
                if focused in (900, 950):
                    try:
                        self.setFocus(self.getControl(800))
                    except Exception:
                        self.setFocus(self.getControl(601))
                elif focused in (800, 801, 802):
                    try:
                        self.setFocus(self.getControl(601))
                    except Exception:
                        pass
                else:
                    self.salir_youtube_moderno()
            elif self.estado == "tv_moderno":
                focused = self.getFocusId()
                if focused == 1400:
                    try:
                        self.setFocus(self.getControl(1300))
                    except Exception:
                        self.setFocus(self.getControl(1201))
                elif focused in (1300, 1301, 1302):
                    try:
                        self.setFocus(self.getControl(1201))
                    except Exception:
                        pass
                else:
                    self.salir_tv_moderno()
            elif self.estado in ("tv_categorias", "youtube_categorias"):
                active_btn = 208 if self.estado == "tv_categorias" else 209
                focused = self.getFocusId()
                # Si el foco ya está en la barra lateral (controles 200-209), mostrar diálogo de salida.
                # Si no, mover el foco a la barra lateral primero (navegación natural).
                if focused in range(200, 210):
                    if xbmcgui.Dialog().yesno("Vaquexflix", "Deseas salir del complemento?", yeslabel="Salir", nolabel="Cancelar"):
                        self.activa = False
                        self.detener_reproduccion()
                        self.close()
                else:
                    try:
                        self.setFocus(self.getControl(active_btn))
                    except Exception:
                        pass
            elif self.estado == "temporadas":
                self.actualizar_etiqueta(getattr(self, '_titulo_catalogo', 'SERIES'))
                self.cargar_elementos(self.categoria_actual_url, reset=True)
            elif self.estado == "elementos":
                self.cargar_categorias(self.seccion_actual if self.seccion_actual != "busqueda" else "peliculas")
            else:
                if xbmcgui.Dialog().yesno("Vaquexflix", "Deseas salir del complemento?", yeslabel="Salir", nolabel="Cancelar"):
                    self.activa = False
                    self.detener_reproduccion()
                    self.close()
            return

        super().onAction(action)

def _parse_argv_params_tmdbhelper():
    params = {}
    try:
        if len(sys.argv) >= 3 and sys.argv[2].startswith('?'):
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        elif len(sys.argv) > 1:
            raw = sys.argv[1][1:] if sys.argv[1].startswith('?') else sys.argv[1]
            params = dict(urllib.parse.parse_qsl(raw))
    except Exception:
        params = {}
    return params

if __name__ == '__main__':
    _tmdbh_params = _parse_argv_params_tmdbhelper()
    _action = _tmdbh_params.get('action')

    if _action == 'play_youtube':
        vid_id = _tmdbh_params.get('id') or ''
        vid_title = _tmdbh_params.get('title') or 'YouTube'
        try:
            handle = int(sys.argv[1])
        except (IndexError, ValueError):
            handle = -1
        stream_url = tube_engine.resolve(vid_id)
        if stream_url:
            it = xbmcgui.ListItem(label=vid_title, path=stream_url)
            it.setProperty('IsPlayable', 'true')
            it.setInfo('video', {'title': vid_title})
            try:
                major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
            except Exception:
                major = 20
            adaptive = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
            hls_quality_mode = ADDON.getSetting('hls_quality')
            stream_final = playback.configure_stream(it, stream_url, UA, adaptive, major, hls_quality=hls_quality_mode, is_tv=False)
            it.setPath(stream_final)
            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, True, it)
            else:
                xbmc.Player().play(stream_final, it)
        elif handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        sys.exit(0)

    if len(sys.argv) >= 2 and sys.argv[1].isdigit():
        try:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False,
                                       updateListing=False, cacheToDisc=False)
        except Exception:
            pass
    ui = VaquexflixUI('main.xml', ADDON_PATH, 'Default', '720p')
    _tmdbh_query = _tmdbh_params.get('query') or _tmdbh_params.get('title')
    if _tmdbh_params.get('action') == 'search' and _tmdbh_query:
        ui.busqueda_pendiente = urllib.parse.unquote_plus(_tmdbh_query)
    ui.show()
    monitor = xbmc.Monitor()
    try:
        while ui.activa and not monitor.waitForAbort(0.1):
            ui.procesar_eventos_player()
    finally:
        ui.activa = False
        if ui._metadata_scanner:
            ui._metadata_scanner.close()
        ui.detener_reproduccion()
        resolvers.cerrar_streams_locales()
        playback.stop_close_diagnostic()
        if ui._x_timer:
            ui._x_timer.cancel()
        ui.close()
        del ui
