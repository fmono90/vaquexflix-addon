"""Resolutores de video compartidos por todas las fuentes."""
import base64
import binascii
import codecs
import hashlib
from html.parser import HTMLParser
import html
import ipaddress
import json
import os
import re
import shutil
import uuid
import urllib.error
import time
import urllib.parse
import urllib.request
import network
import hmac
import secrets
import ctypes
import sys
import threading
from urllib.parse import urlsplit, urljoin


try:
    import resolveurl
except Exception:
    resolveurl = None


CALIDADES_HLS = {}


def calidad_hls(manifest):
    heights = set()
    for line in manifest.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            match = re.search(r'RESOLUTION=(\d+)x(\d+)', line)
            if match:
                w, h = int(match.group(1)), int(match.group(2))
                if w >= 1920 or h >= 1080 or (w >= 1600 and h >= 720):
                    heights.add(1080)
                else:
                    heights.add(h)
    if not heights:
        return ''
    values = ' / '.join('{}p'.format(h) for h in sorted(heights))
    return ('Multirresolucion: ' if len(heights) > 1 else '') + values


def etiqueta_servidor(server, verified=''):
    name = re.sub(r'\b(?:Multicalidad|FHD|FullHD|HD|SD)\b|\(?\b\d{3,4}p\b\)?', '', server.get('nombre', ''), flags=re.I)
    name = re.sub(r'\s+', ' ', name).strip()
    cal = verified or 'Calidad sin verificar'
    return '{} - {}'.format(name, cal)


STREAM_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'


def procesar_hls_local(master_url, referer, opener=None, timeout=15):
    """Validar y conservar el master con todos sus audios y variantes.

    No convertir el master en una lista de audio o de I-frames ni escribir
    cabeceras Kodi dentro de las URI de los segmentos.
    """
    opener = opener or network.nueva_sesion()
    host = (urllib.parse.urlsplit(master_url).hostname or '').lower()
    cdn_hosts = ('acek-cdn.com', 'premilkyway.com', 'dramiyos-cdn.com', 'tiktokcdn.com', 'embedwish.com', 'streamwish')
    ua = STREAM_UA if any(c in host for c in cdn_hosts) else network.UA
    headers = {'User-Agent': ua, 'Referer': referer,
               'Origin': '{0.scheme}://{0.netloc}'.format(urllib.parse.urlsplit(referer))}
    try:
        req = urllib.request.Request(master_url, headers=headers)
        with opener.open(req, timeout=timeout) as response:
            manifest = response.read(2 * 1024 * 1024).decode('utf-8-sig', 'replace')
            final_url = response.geturl()
        if not manifest.lstrip().startswith('#EXTM3U'):
            network.log_resolver('HLS: el servidor devolvio una pagina en lugar del manifiesto')
            return None
        CALIDADES_HLS[final_url] = calidad_hls(manifest)
        if not urllib.parse.urlsplit(final_url).path.lower().endswith('.m3u8'):
            headers['ext'] = '.m3u8'
        return network.url_con_cabeceras(final_url, headers, opener)
    except Exception as exc:
        reason = getattr(exc, 'reason', type(exc).__name__)
        network.log_resolver('HLS: fallo de acceso ({})'.format(reason))
        return None


def resolver_andromedans(embed_url):
    """Lee el HLS anunciado por el iframe Nuxt de Andromedans."""
    parsed = urllib.parse.urlsplit(embed_url)
    if (parsed.scheme != 'https' or parsed.hostname != 'iframe.andromedans.live'
            or parsed.username or parsed.password or parsed.port not in (None, 443)
            or not re.fullmatch(r'/e/[A-Za-z0-9_-]{6,128}', parsed.path)):
        raise network.ServidorNoDisponible('Andromedans: enlace del reproductor no válido.')
    opener = network.nueva_sesion()
    try:
        request = urllib.request.Request(embed_url, headers={'User-Agent': network.UA})
        with opener.open(request, timeout=12) as response:
            page = response.read(512 * 1024 + 1)
        if len(page) > 512 * 1024:
            raise ValueError('Página demasiado grande')
        match = re.search(r'<script\b[^>]*id="__NUXT_DATA__"[^>]*>(.*?)</script>',
                          page.decode('utf-8', 'replace'), re.S | re.I)
        payload = json.loads(match.group(1)) if match else None
        if not isinstance(payload, list):
            raise ValueError('Sin datos del reproductor')
        candidates = [value for value in payload if isinstance(value, str)
                      and urllib.parse.urlsplit(value).scheme == 'https'
                      and urllib.parse.urlsplit(value).hostname == 'stream.andromedans.live'
                      and urllib.parse.urlsplit(value).path.lower().endswith('.m3u8')]
        candidates.sort(key=lambda value: ('vp9' in value.lower(), 'master.m3u8' not in value.lower()))
        if not candidates:
            raise ValueError('Sin manifiesto HLS')
        stream = procesar_hls_local(candidates[0], embed_url, opener=opener, timeout=12)
        if not stream:
            raise ValueError('El manifiesto no entregó vídeo HLS')
        return stream
    except urllib.error.HTTPError as exc:
        raise network.ServidorNoDisponible('Andromedans: acceso rechazado (HTTP {}).'.format(exc.code)) from exc
    except (TimeoutError, urllib.error.URLError) as exc:
        raise network.ServidorNoDisponible('Andromedans: tiempo de espera agotado.') from exc
    except ValueError as exc:
        raise network.ServidorNoDisponible('Andromedans: el iframe no entregó vídeo válido.') from exc


def unpack_js(p, a, c, k, e=None, d=None):
    def _baseN(num, b):
        chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        res = ""
        while num > 0:
            res = chars[num % b] + res
            num //= b
        return res or "0"
    if not 2 <= a <= 62 or not 0 <= c <= 100000:
        raise ValueError('Parametros del packer invalidos')
    lookup = {}
    for i in range(c):
        key = _baseN(i, a)
        lookup[key] = k[i] if i < len(k) and k[i] else key
    def _replace(match):
        w = match.group(0)
        return lookup.get(w, w)
    return re.sub(r'\b\w+\b', _replace, p)


class MiniAES:
    SBOX = [
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
    ]
    INV_SBOX = [0] * 256
    RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]

    @classmethod
    def _init_tables(cls):
        if cls.INV_SBOX[0] != 0 or cls.INV_SBOX[1] != 0:
            return
        for i in range(256):
            cls.INV_SBOX[cls.SBOX[i]] = i

    @staticmethod
    def _xt(a):
        return ((a << 1) ^ 0x1b) & 0xff if (a & 0x80) else (a << 1)

    @classmethod
    def _mul(cls, a, b):
        res = 0
        while b:
            if b & 1:
                res ^= a
            a = cls._xt(a)
            b >>= 1
        return res

    def __init__(self, key):
        self._init_tables()
        self.key = key
        self.Nk = len(key) // 4
        self.Nr = self.Nk + 6
        self.w = self._key_expansion()

    def _key_expansion(self):
        w = [0] * (4 * (self.Nr + 1))
        for i in range(self.Nk):
            w[i] = (self.key[4*i] << 24) | (self.key[4*i+1] << 16) | (self.key[4*i+2] << 8) | self.key[4*i+3]
        for i in range(self.Nk, 4 * (self.Nr + 1)):
            temp = w[i - 1]
            if i % self.Nk == 0:
                rw = ((temp << 8) & 0xffffffff) | (temp >> 24)
                sub = (self.SBOX[(rw >> 24) & 0xff] << 24) | (self.SBOX[(rw >> 16) & 0xff] << 16) | (self.SBOX[(rw >> 8) & 0xff] << 8) | self.SBOX[rw & 0xff]
                temp = sub ^ (self.RCON[i // self.Nk] << 24)
            elif self.Nk > 6 and (i % self.Nk == 4):
                temp = (self.SBOX[(temp >> 24) & 0xff] << 24) | (self.SBOX[(temp >> 16) & 0xff] << 16) | (self.SBOX[(temp >> 8) & 0xff] << 8) | self.SBOX[temp & 0xff]
            w[i] = w[i - self.Nk] ^ temp
        return w

    def encrypt_block(self, block):
        state = list(block)
        for rnd in range(self.Nr + 1):
            if rnd:
                state = [self.SBOX[x] for x in state]
                state = [state[r + 4 * ((c + r) % 4)] for c in range(4) for r in range(4)]
                if rnd != self.Nr:
                    for c in range(4):
                        a = state[4*c:4*c+4]
                        total = a[0] ^ a[1] ^ a[2] ^ a[3]
                        state[4*c:4*c+4] = [a[r] ^ total ^ self._xt(a[r] ^ a[(r+1) % 4]) for r in range(4)]
            state = [value ^ ((self.w[4*rnd + i//4] >> (24 - 8*(i % 4))) & 255)
                     for i, value in enumerate(state)]
        return bytes(state)

    def transform_ctr(self, data, counter):
        result = bytearray()
        for start in range(0, len(data), 16):
            block = self.encrypt_block(counter.to_bytes(16, 'big'))
            result.extend(a ^ b for a, b in zip(data[start:start+16], block))
            counter = (counter + 1) % (1 << 128)
        return bytes(result)

    def decrypt_block(self, block):
        state = [[block[r + 4 * c] for c in range(4)] for r in range(4)]
        for c in range(4):
            w = self.w[self.Nr * 4 + c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        for rnd in range(self.Nr - 1, 0, -1):
            state[1] = state[1][3:] + state[1][:3]
            state[2] = state[2][2:] + state[2][:2]
            state[3] = state[3][1:] + state[3][:1]
            for r in range(4):
                for c in range(4):
                    state[r][c] = self.INV_SBOX[state[r][c]]
            for c in range(4):
                w = self.w[rnd * 4 + c]
                state[0][c] ^= (w >> 24) & 0xff
                state[1][c] ^= (w >> 16) & 0xff
                state[2][c] ^= (w >> 8) & 0xff
                state[3][c] ^= w & 0xff
            for c in range(4):
                u = [state[r][c] for r in range(4)]
                state[0][c] = self._mul(u[0], 0x0e) ^ self._mul(u[1], 0x0b) ^ self._mul(u[2], 0x0d) ^ self._mul(u[3], 0x09)
                state[1][c] = self._mul(u[0], 0x09) ^ self._mul(u[1], 0x0e) ^ self._mul(u[2], 0x0b) ^ self._mul(u[3], 0x0d)
                state[2][c] = self._mul(u[0], 0x0d) ^ self._mul(u[1], 0x09) ^ self._mul(u[2], 0x0e) ^ self._mul(u[3], 0x0b)
                state[3][c] = self._mul(u[0], 0x0b) ^ self._mul(u[1], 0x0d) ^ self._mul(u[2], 0x09) ^ self._mul(u[3], 0x0e)
        state[1] = state[1][3:] + state[1][:3]
        state[2] = state[2][2:] + state[2][:2]
        state[3] = state[3][1:] + state[3][:1]
        for r in range(4):
            for c in range(4):
                state[r][c] = self.INV_SBOX[state[r][c]]
        for c in range(4):
            w = self.w[c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        return bytes(state[r][c] for c in range(4) for r in range(4))

    def decrypt_cbc(self, ciphertext, iv):
        plaintext = bytearray()
        prev = iv
        for i in range(0, len(ciphertext), 16):
            blk = ciphertext[i:i+16]
            dec = self.decrypt_block(blk)
            plaintext.extend(dec[j] ^ prev[j] for j in range(16))
            prev = blk
        pad = plaintext[-1]
        if 1 <= pad <= 16:
            return bytes(plaintext[:-pad])
        return bytes(plaintext)


def fnv1a_32(val_str):
    h = 2166136261
    for ch in val_str:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return f'{h:x}'


def _pelisserieshoy_hls_verificado(url, referer, opener):
    """Return an HLS stream only after its manifest and first segment respond."""
    stream = procesar_hls_local(url, referer, opener=opener, timeout=7)
    if not stream:
        return None
    manifest_url, _, options = stream.partition('|')
    headers = dict(urllib.parse.parse_qsl(options, keep_blank_values=True))
    headers.pop('ext', None)
    try:
        for _ in range(2):
            req = urllib.request.Request(manifest_url, headers=headers)
            with opener.open(req, timeout=7) as response:
                manifest = response.read(2 * 1024 * 1024).decode('utf-8-sig', 'replace')
                manifest_url = response.geturl()
            if not manifest.lstrip().startswith('#EXTM3U'):
                return None
            segment = next((line.strip() for line in manifest.splitlines()
                            if line.strip() and not line.startswith('#')), None)
            if not segment:
                return None
            next_url = urllib.parse.urljoin(manifest_url, segment)
            if '#EXT-X-STREAM-INF' not in manifest:
                req = urllib.request.Request(next_url, headers=dict(headers, Range='bytes=0-1023'))
                with opener.open(req, timeout=7) as response:
                    prefix = response.read(1024)
                    media_type = (response.headers.get('Content-Type') or '').lower()
                if prefix and 'text/html' not in media_type and not prefix.lstrip().startswith(b'<'):
                    return stream
                return None
            manifest_url = next_url
    except Exception:
        return None
    return None


def resolver_pelisserieshoy(url_player):
    try:
        parsed_player = urllib.parse.urlsplit(url_player)
        option_query = urllib.parse.parse_qs(parsed_player.query)
        requested_option = option_query.get('vxopt', [None])[0]
        requested_name = option_query.get('vxname', [None])[0]
        if requested_option is not None and not requested_option.isdigit():
            return None
        url_player = urllib.parse.urlunsplit(parsed_player._replace(query='', fragment=''))
        # El player envia el origen de su iframe en cada solicitud a s.php.
        # Sin este campo, el HTML carga pero el API no entrega servidores.
        solo_origin = network.SOLOLATINO_BASE.rstrip('/')
        opener = network.nueva_sesion()
        headers_get = {'User-Agent': network.UA, 'Referer': solo_origin + '/'}
        req_p = urllib.request.Request(url_player, headers=headers_get)
        with opener.open(req_p, timeout=12) as r_p:
            html_p = r_p.read(2 * 1024 * 1024).decode('utf-8', errors='ignore')

        m_tok = re.search(r"const\s+_t\s*=\s*'([^']+)'", html_p)
        m_qk = re.search(r'var\s+_qk\s*=\s*(\[[^\]]+\]);', html_p)
        m_qc = re.search(r'var\s+_qc\s*=\s*[\"\']([^\"\']+)[\"\'];', html_p)
        m_src = re.search(r'var\s+_qsrc\s*=\s*[\"\']([^\"\']+)[\"\'];', html_p)
        if not (m_tok and m_qk and m_qc):
            return None

        tok = m_tok.group(1)
        qk = json.loads(m_qk.group(1))
        rt = qk[1] + qk[3] + qk[0] + qk[2]
        qc = m_qc.group(1)
        tk = fnv1a_32(f'{rt}|clk|{qc}')
        qsrc = m_src.group(1) if m_src else ""

        url_s = 'https://player.pelisserieshoy.com/s.php'
        headers_post = {
            'User-Agent': network.UA,
            'Referer': url_player,
            'Origin': 'https://player.pelisserieshoy.com',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        body_scan = {'a': '1', 'tok': tok, 'rt': rt, 'tk': tk, 'ao': solo_origin}
        if qsrc:
            body_scan['src'] = qsrc
        req_scan = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_scan).encode('utf-8'), headers=headers_post)
        with opener.open(req_scan, timeout=15) as r_scan:
            scan_json = json.loads(r_scan.read(2 * 1024 * 1024).decode('utf-8'))
            servers = scan_json.get('s', [])
            known = {pair[1] for pair in servers if isinstance(pair, (list, tuple)) and len(pair) >= 2}
            for language, options in (scan_json.get('langs_s') or {}).items():
                for pair in options or []:
                    if isinstance(pair, (list, tuple)) and len(pair) >= 2 and pair[1] not in known:
                        known.add(pair[1])
                        suffix = ' (' + str(language) + ')' if language else ' (alternativa)'
                        servers.append([str(pair[0]) + suffix, pair[1]])
        if not servers:
            network.log_resolver('PelisSeriesHoy: sondeo sin servidores ({})'.format(
                scan_json.get('error') or scan_json.get('msg') or 'respuesta vacia'))

        body_click = {'a': 'click', 'tok': tok, 'rt': rt, 'tk': tk, 'ao': solo_origin}
        if qsrc:
            body_click['src'] = qsrc
        try:
            req_click = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_click).encode('utf-8'), headers=headers_post)
            with opener.open(req_click, timeout=7) as r_click:
                pass
        except Exception:
            pass

        def _srv_priority(item):
            nom = item[0].lower()
            if 'player+' in nom or 'player' in nom:
                return 0
            if 'premium' in nom:
                return 1
            if 'vip' in nom:
                return 2
            return 3

        servers_sorted = sorted(servers, key=_srv_priority)
        if requested_option is not None:
            index = int(requested_option)
            if index >= len(servers) or (requested_name is not None
                    and servers[index][0] != requested_name):
                return None
            servers_sorted = [servers[index]]

        for srv_nombre, v_target in servers_sorted:
            try:
                body_play = {'a': '2', 'v': v_target, 'tok': tok, 'rt': rt, 'tk': tk, 'ao': solo_origin}
                if qsrc:
                    body_play['src'] = qsrc
                req_play = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_play).encode('utf-8'), headers=headers_post)
                with opener.open(req_play, timeout=7) as r_play:
                    data = json.loads(r_play.read(2 * 1024 * 1024).decode('utf-8'))
                    raw_u = data.get('u') or data.get('stream')
                    if not raw_u:
                        continue
                    u_full = raw_u if raw_u.startswith('http') else 'https://player.pelisserieshoy.com' + raw_u

                    if 'p.php' in u_full:
                        try:
                            req_cdn = urllib.request.Request(u_full, headers={
                                'User-Agent': network.UA, 'Referer': url_player,
                                'Range': 'bytes=0-1023'})
                            with opener.open(req_cdn, timeout=7) as r_cdn:
                                media_type = (r_cdn.headers.get('Content-Type') or '').lower()
                                cdn_url = r_cdn.geturl()
                                prefix = r_cdn.read(1024)
                                if (cdn_url and cdn_url.startswith('http')
                                        and 'p.php' not in cdn_url
                                        and prefix and 'text/html' not in media_type
                                        and not prefix.lstrip().startswith(b'<')
                                        and ('video/' in media_type or prefix[4:8] == b'ftyp')):
                                    return cdn_url
                        except Exception as exc:
                            network.log_resolver('PelisSeriesHoy: redireccion de video fallida ({})'.format(
                                type(exc).__name__))
                        continue
                    elif '.m3u8' in u_full:
                        stream = _pelisserieshoy_hls_verificado(u_full, url_player, opener)
                        if stream:
                            return stream
                        network.log_resolver('PelisSeriesHoy: HLS sin segmento verificable')
                    elif u_full.startswith('http'):
                        req_media = urllib.request.Request(
                            u_full, headers={'User-Agent': network.UA,
                                             'Referer': url_player, 'Range': 'bytes=0-1023'})
                        with opener.open(req_media, timeout=7) as media:
                            prefix = media.read(1024)
                            media_type = (media.headers.get('Content-Type') or '').lower()
                        if prefix and ('video/' in media_type or prefix[4:8] == b'ftyp'):
                            return u_full
            except Exception as exc:
                network.log_resolver('PelisSeriesHoy: opcion no disponible ({})'.format(
                    type(exc).__name__))
                continue
        return None
    except Exception as exc:
        network.log_resolver('PelisSeriesHoy: acceso al player fallido ({})'.format(
            type(exc).__name__))
        return None


def pelisserieshoy_opciones(url_player):
    """List player alternatives without claiming they contain playable video."""
    try:
        base_url = urllib.parse.urlunsplit(urllib.parse.urlsplit(url_player)._replace(query='', fragment=''))
        opener = network.nueva_sesion()
        origin = network.SOLOLATINO_BASE.rstrip('/')
        req = urllib.request.Request(base_url, headers={'User-Agent': network.UA, 'Referer': origin + '/'})
        with opener.open(req, timeout=12) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        token = re.search(r"const\s+_t\s*=\s*'([^']+)'", page)
        qk_match = re.search(r'var\s+_qk\s*=\s*(\[[^\]]+\]);', page)
        qc_match = re.search(r'var\s+_qc\s*=\s*["\']([^"\']+)["\'];', page)
        src_match = re.search(r'var\s+_qsrc\s*=\s*["\']([^"\']+)["\'];', page)
        if not (token and qk_match and qc_match):
            return []
        qk = json.loads(qk_match.group(1))
        rt = qk[1] + qk[3] + qk[0] + qk[2]
        body = {'a': '1', 'tok': token.group(1), 'rt': rt,
                'tk': fnv1a_32(f'{rt}|clk|{qc_match.group(1)}'), 'ao': origin}
        if src_match:
            body['src'] = src_match.group(1)
        request = urllib.request.Request('https://player.pelisserieshoy.com/s.php',
            data=urllib.parse.urlencode(body).encode('utf-8'), headers={
                'User-Agent': network.UA, 'Referer': base_url,
                'Origin': 'https://player.pelisserieshoy.com',
                'Content-Type': 'application/x-www-form-urlencoded'})
        with opener.open(request, timeout=15) as response:
            data = json.loads(response.read(2 * 1024 * 1024).decode('utf-8'))
        servers = data.get('s') or []
        known = {pair[1] for pair in servers if isinstance(pair, (list, tuple)) and len(pair) >= 2}
        for language, options in (data.get('langs_s') or {}).items():
            for pair in options or []:
                if isinstance(pair, (list, tuple)) and len(pair) >= 2 and pair[1] not in known:
                    known.add(pair[1])
                    suffix = ' (' + str(language) + ')' if language else ' (alternativa)'
                    servers.append([str(pair[0]) + suffix, pair[1]])
        result = []
        for index, pair in enumerate(servers):
            if not isinstance(pair, (list, tuple)) or len(pair) < 2:
                continue
            name = str(pair[0])
            if 'player+' in name.lower() or 'premium' in name.lower():
                continue
            option_url = base_url + '?' + urllib.parse.urlencode({'vxopt': index, 'vxname': name})
            result.append({'nombre': 'SoloLatino Player ' + name, 'url': option_url,
                           'calidad': 'Sin verificar', 'source': 'sololatino'})
        return result
    except Exception as exc:
        network.log_resolver('PelisSeriesHoy: alternativas no disponibles ({})'.format(type(exc).__name__))
        return []


def _embed69_hosts_html(page):
    """Read the current plain HTML server list without claiming playback works."""
    languages = {}
    for attrs, body in re.findall(r'<li\b([^>]*)>(.*?)</li>', page, re.I | re.S):
        if 'SLD_A' not in attrs:
            continue
        lang_id = re.search(r'\bdata-lang=["\']([^"\']+)', attrs, re.I)
        label = re.search(r'<img\b[^>]*\balt=["\']([^"\']+)', body, re.I)
        if lang_id and label:
            languages[lang_id.group(1)] = html.unescape(label.group(1))
    hosts = []
    seen = set()
    for attrs, body in re.findall(r'<li\b([^>]*)>(.*?)</li>', page, re.I | re.S):
        url_match = re.search(r'\bdata-url=["\']([^"\']+)', attrs, re.I)
        if not url_match:
            continue
        url = html.unescape(url_match.group(1)).strip()
        if urllib.parse.urlsplit(url).scheme not in ('http', 'https') or url in seen:
            continue
        seen.add(url)
        name_match = re.search(r'<span\b[^>]*>(.*?)</span>', body, re.I | re.S)
        name = re.sub(r'<[^>]+>', '', name_match.group(1)).strip() if name_match else ''
        lang_match = re.search(r'\bdata-lang=["\']([^"\']+)', attrs, re.I)
        language = languages.get(lang_match.group(1), lang_match.group(1)) if lang_match else ''
        hosts.append({'nombre': '{} ({})'.format(html.unescape(name) or
                      (urllib.parse.urlsplit(url).hostname or 'Servidor'), language or 'Idioma sin verificar'),
                      'url': url})
    return hosts


def _descifrar_datalink_pow(html_e, max_difficulty=5):
    """Resuelve PoW SHA-256 + AES-CBC sobre dataLink en Embed69/PelisPedia."""
    m_c = re.search(r"(?:const|let|var)\s+POW_CHALLENGE\s*=\s*['\"]([^'\"]+)", html_e)
    m_d = re.search(r"(?:const|let|var)\s+POW_DIFFICULTY\s*=\s*(\d+)", html_e)
    m_s = re.search(r"(?:const|let|var)\s+POW_SALT\s*=\s*['\"]([^'\"]+)", html_e)
    m_links = re.search(r'(?:let|const|var)?\s*\bdataLink\s*=\s*(\[\{.*?\}\]);', html_e, re.DOTALL)
    if not (m_c and m_d and m_s and m_links):
        return []
    c, d, salt = m_c.group(1), int(m_d.group(1)), m_s.group(1)
    if d < 0 or d > max_difficulty:
        return []
    prefix = '0' * d
    nonce = 0
    aes_key_bytes = None
    started = time.monotonic()
    while nonce < 500000:
        if nonce % 1000 == 0:
            network.tiempo_peticion(1)
            if time.monotonic() - started > 5:
                break
        if hashlib.sha256(f'{c}{nonce}'.encode('utf-8')).hexdigest().startswith(prefix):
            aes_key_bytes = hashlib.sha256(f'{c}{nonce}{salt}'.encode('utf-8')).digest()
            break
        nonce += 1
    if not aes_key_bytes:
        return []

    decoded = []
    cipher = MiniAES(aes_key_bytes)
    for grp in json.loads(m_links.group(1)):
        lang = str(grp.get('video_language', 'LAT') or 'LAT').strip()
        for srv in grp.get('sortedEmbeds', []):
            try:
                raw = base64.b64decode(srv['link'])
                iv, ct = raw[:16], raw[16:]
                dec = cipher.decrypt_cbc(ct, iv)
                url_host = dec.decode('utf-8', errors='ignore').replace('`', '').strip()
                s_name = str(srv.get('servername', 'Servidor') or 'Servidor').strip()
                parsed = urllib.parse.urlsplit(url_host)
                if parsed.scheme in ('http', 'https') and parsed.hostname:
                    decoded.append({'lang': lang, 'server': s_name, 'url': url_host})
            except Exception:
                pass
    return decoded


def resolver_embed69_hosts(url_embed):
    hosts = []
    try:
        p_url = urllib.parse.urlsplit(url_embed)
        ref = f"{p_url.scheme}://{p_url.netloc}/" if p_url.netloc else f"{network.SOLOLATINO_BASE}/"
        req = urllib.request.Request(url_embed, headers={'User-Agent': network.UA, 'Referer': ref})
        with network.abrir_url(req, timeout=8, context=network._ssl_ctx) as r:
            html_e = r.read(2 * 1024 * 1024).decode('utf-8', errors='ignore')

        hosts = _embed69_hosts_html(html_e)
        for entry in _descifrar_datalink_pow(html_e):
            if not any(item['url'] == entry['url'] for item in hosts):
                hosts.append({'nombre': f"{entry['server']} ({entry['lang']})", 'url': entry['url']})
    except Exception:
        pass
    return hosts


def resolver_ok_ru(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': network.UA})
        with network.abrir_url(req, timeout=7, context=network._ssl_ctx) as r:
            h = r.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        if 'Video has not been found' in h:
            raise network.ServidorNoDisponible('OK.ru indica que este video ya no existe.')
        m = re.search(r'data-options=[\'"]([^\'"]+)[\'"]', h)
        if not m:
            return None
        d = json.loads(html.unescape(m.group(1)))
        meta = d.get('flashvars', {}).get('metadata')
        if isinstance(meta, str):
            meta = json.loads(meta)
        if not isinstance(meta, dict):
            return None
        videos = meta.get('videos', [])
        prio = {'full': 5, 'hd': 4, 'sd': 3, 'low': 2, 'lowest': 1, 'mobile': 0}
        videos.sort(key=lambda v: prio.get(v.get('name'), 0), reverse=True)
        if videos and videos[0].get('url'):
            v_url = videos[0].get('url')
            return f"{v_url}|User-Agent={urllib.parse.quote(network.UA)}&verifypeer=false"
        hls = meta.get('hlsManifestUrl')
        if hls:
            return f"{hls}|User-Agent={urllib.parse.quote(network.UA)}&verifypeer=false"
    except network.ServidorNoDisponible:
        raise
    except Exception:
        pass
    return None


def resolver_vids_st(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': 'https://www.fuegocine.com/'})
        with network.abrir_url(req, timeout=7, context=network._ssl_ctx) as r:
            h = r.read(2 * 1024 * 1024).decode('utf-8', 'ignore')
        m = re.search(r'const\s+url\s*=\s*[\'"]([^\'"]+m3u8[^\'"]*)[\'"]', h)
        if m:
            clean_url = m.group(1).replace(r'\/', '/')
            return f"{clean_url}|User-Agent={urllib.parse.quote(network.UA)}&Referer=https://vids.st/&verifypeer=false"
    except Exception:
        pass
    return None


class DriveConfirmationParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.action = None
        self.inputs = {}
        self.link = None
        self.in_form = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'form' and attrs.get('id') == 'download-form':
            self.action = attrs.get('action')
            self.in_form = True
        elif tag == 'input' and self.in_form and attrs.get('name'):
            self.inputs[attrs['name']] = attrs.get('value', '')
        elif tag == 'a' and attrs.get('id') == 'uc-download-link':
            self.link = attrs.get('href')

    def handle_endtag(self, tag):
        if tag == 'form':
            self.in_form = False


def resolver_google_drive(url):
    m_id = re.search(r'/d/([a-zA-Z0-9_-]+)', url) or re.search(r'[?&]id=([a-zA-Z0-9_-]+)', url)
    if not m_id:
        return None
    opener = network.nueva_sesion()
    target = 'https://drive.usercontent.google.com/download?' + urllib.parse.urlencode({
        'id': m_id.group(1), 'export': 'download', 'authuser': '0'})
    headers = {'User-Agent': network.UA}
    try:
        for _ in range(3):
            # Probar la misma descarga abierta que pedira el reproductor.
            # Un rango pequeno puede venir de cache aun con la cuota agotada.
            # Solo leemos el prefijo y cerramos; no descargamos el archivo.
            req = urllib.request.Request(target, headers=dict(headers, Range='bytes=0-'))
            with opener.open(req, timeout=12) as response:
                ct = response.headers.get('Content-Type', '').lower().split(';')[0]
                prefix = response.read(2048)
                final_url = response.geturl()
                probe = prefix.lstrip().lower()
                is_html = ct in ('text/html', 'application/xhtml+xml') or probe.startswith((b'<!doctype html', b'<html'))
                if not is_html and prefix and (ct.startswith(('video/', 'audio/')) or ct in ('application/octet-stream', 'application/x-matroska')):
                    # Drive usa /download sin extension: evitar que Kodi haga
                    # otra deteccion HEAD o interprete la URL como una pagina.
                    if ct == 'video/mp4' or prefix[4:8] == b'ftyp':
                        headers['ext'] = '.mp4'
                    elif (ct in ('video/x-matroska', 'application/x-matroska')
                          or (prefix.startswith(b'\x1aE\xdf\xa3') and b'matroska' in prefix)):
                        headers['ext'] = '.mkv'
                    return network.url_con_cabeceras(final_url, headers, opener)
                if not is_html:
                    return None
                body = (prefix + response.read(256 * 1024)).decode('utf-8', 'replace')
            if any(x in body.lower() for x in ('quota exceeded', 'downloadquotaexceeded', 'cuota', 'too many users')):
                network.log_resolver('Google Drive: cuota de descarga agotada')
                raise network.ServidorNoDisponible('Google Drive: cuota de descarga agotada. Elige otro servidor o prueba mas tarde.')
            parser = DriveConfirmationParser()
            parser.feed(body)
            next_url = parser.link
            if parser.action:
                action = urllib.parse.urljoin(final_url, parser.action)
                parts = urllib.parse.urlsplit(action)
                params = dict(urllib.parse.parse_qsl(parts.query))
                params.update(parser.inputs)
                next_url = urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(params)))
            if not next_url:
                return None
            target = urllib.parse.urljoin(final_url, next_url)
            if urllib.parse.urlsplit(target).hostname not in ('drive.google.com', 'drive.usercontent.google.com'):
                return None
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('Google Drive: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_archive_org(url):
    """
    Internet Archive entrega archivos de video que redirigen (302) a nodos de
    almacenamiento (*.archive.org). Resolver la redirección directamente reduce
    latencia y evita renegociaciones al adelantar/retroceder.
    """
    clean_url = url.split('|')[0]
    final_url = clean_url
    host = urllib.parse.urlsplit(clean_url).hostname or ''
    if host == 'archive.org' and '/download/' in clean_url:
        try:
            req = urllib.request.Request(clean_url, method='HEAD', headers={'User-Agent': network.UA})
            with urllib.request.urlopen(req, timeout=4) as resp:
                final_url = resp.geturl()
        except Exception:
            pass
    ref = 'https://archive.org/'
    return f"{final_url}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(ref)}"


def extraer_url_hls(page):
    # Desescapar solo separadores conocidos; no alterar los tokens firmados.
    page = html.unescape(page.replace(r'\/', '/').replace(r'\u0026', '&'))
    match = re.search(r'https?://[^\s\'"<>\\]+\.m3u8(?:\?[^\s\'"<>\\]*)?', page, re.I)
    if match:
        return match.group(0)
    return None


def extraer_fuentes_hls(page, referer):
    """Respetar la prioridad de links del reproductor y validar cada variante."""
    cleaned = html.unescape(page.replace(r'\/', '/').replace(r'\u0026', '&'))
    found = re.search(r'\b(?:var|let|const)\s+links\s*=\s*(\{[^{}]+\})', cleaned)
    if found:
        try:
            links = json.loads(found.group(1))
            return [urllib.parse.urljoin(referer, links[key]) for key in ('hls4', 'hls3', 'hls2')
                    if isinstance(links.get(key), str) and links[key]]
        except ValueError:
            pass

    # 1. Patron sources: [...] (JWPlayer / Plyr / VidHide / StreamWish / etc.)
    m_sources = re.search(r'sources?\s*:\s*\[([^\]]+)\]', cleaned, re.I)
    if m_sources:
        inner = m_sources.group(1)
        matches = re.findall(r'(?:src|file)\s*:\s*["\']?(https?://[^"\'\s,]+(?:\.m3u8|\.mp4)[^"\'\s,]*)', inner, re.I)
        if not matches:
            matches = re.findall(r'https?://[^"\'\s,]+(?:\.m3u8|\.mp4)[^"\'\s,]*', inner, re.I)
        if matches:
            return [urllib.parse.urljoin(referer, m) for m in matches]

    # 2. Patron "hls": "url" (VOE / APIs de reproductores)
    m_hls = re.search(r'["\']hls["\']\s*:\s*["\'](https?://[^"\']+)["\']', cleaned, re.I)
    if m_hls:
        return [urllib.parse.urljoin(referer, m_hls.group(1))]

    # 3. Extraccion directa de URL .m3u8
    media = extraer_url_hls(cleaned)
    if media:
        return [media]

    # 4. Extraccion directa de URL .mp4
    match_mp4 = re.search(r'https?://[^\s\'"<>\\]+\.mp4(?:\?[^\s\'"<>\\]*)?', cleaned, re.I)
    if match_mp4:
        return [match_mp4.group(0)]

    return []


def resolver_host_hls(embed_url, timeout=15, referer=None, opener=None, raise_on_error=False):
    session = opener or network.nueva_sesion()
    host = urllib.parse.urlsplit(embed_url)
    referer = referer or '{}://{}/'.format(host.scheme, host.netloc)
    try:
        if host.path.lower().endswith('.m3u8'):
            return procesar_hls_local(embed_url, referer, session, timeout=timeout)
        req = urllib.request.Request(embed_url, headers={'User-Agent': network.UA, 'Referer': referer})
        with session.open(req, timeout=timeout) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = response.geturl()
        # Redireccion explicita de VOE; no ejecutar JavaScript de la pagina.
        redirect = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
        if redirect:
            req = urllib.request.Request(html.unescape(redirect.group(1)), headers={'User-Agent': network.UA, 'Referer': referer})
            with session.open(req, timeout=timeout) as response:
                page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                referer = response.geturl()
        if 'countries are not allowed' in page.lower():
            raise network.ServidorNoDisponible('Este servidor restringe el acceso desde tu ubicacion. Elige otro servidor.')
        if 'confirm you' in page.lower() and 'human to start the video' in page.lower():
            raise network.ServidorNoDisponible('Este servidor exige verificacion humana en su web. Elige otro servidor en Kodi.')
        if 'file is no longer available as it expired or has been deleted' in page.lower():
            raise network.ServidorNoDisponible('El servidor indica que el archivo expiro o fue eliminado. Elige otro servidor.')
        if '<title>Loading...</title>' in page and not re.search(r'\.m3u8|\.mp4', page, re.I):
            raise network.ServidorNoDisponible('El servidor sólo entregó una página de carga, sin vídeo.')
        sources = extraer_fuentes_hls(page, referer)
        if not sources:
            # El packer puede usar cualquier letra para sus argumentos finales.
            pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
            for match in re.finditer(pattern, page, re.S):
                p, a, c, k = match.groups()
                sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), referer)
                if sources:
                    break
        for media in sources[:3]:
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': referer}, session)
            stream = procesar_hls_local(media, referer, session, timeout=timeout)
            if stream:
                return stream
        network.log_resolver('HLS: no se encontro un manifiesto en ' + host.netloc)
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('HLS: {} en {}'.format(getattr(exc, 'reason', type(exc).__name__), host.netloc))
        if raise_on_error:
            raise _error_red_a_no_disponible(host.netloc or 'El servidor', exc)
    return None


def _vimeos_referer(embed_url, referer=None):
    if referer:
        return referer
    parsed = urllib.parse.urlsplit(embed_url or '')
    token = urllib.parse.parse_qs(parsed.query).get('cf', [''])[0]
    parts = token.split('.') if token else []
    if len(parts) >= 2 and parts[1]:
        try:
            padded = parts[1] + '=' * (-len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(padded).decode('utf-8', 'replace'))
            allowed = payload.get('ao')
            if isinstance(allowed, list):
                for origin in allowed:
                    if isinstance(origin, str) and _validar_url_https_publica(origin):
                        return origin.rstrip('/') + '/'
        except (ValueError, UnicodeError, TypeError):
            pass
    if parsed.scheme and parsed.netloc:
        return f'{parsed.scheme}://{parsed.netloc}/'
    return None


def resolver_goodstream(embed_url, opener=None):
    return resolver_host_hls(embed_url, timeout=8, opener=opener, raise_on_error=True)


def resolver_vimeos(embed_url, referer=None, opener=None):
    return resolver_host_hls(embed_url, referer=_vimeos_referer(embed_url, referer), opener=opener)


def resolver_altcha(challenge, max_seconds=8):
    """Implementar el calculo publico ALTCHA v2 con coste y tiempo acotados."""
    params = challenge['parameters']
    cost = params.get('cost')
    length = params.get('keyLength', 32)
    prefix = params.get('keyPrefix', '')
    if (params.get('algorithm') != 'PBKDF2/SHA-256'
            or not isinstance(cost, int) or not 1 <= cost <= 100000
            or not isinstance(length, int) or not 16 <= length <= 64
            or not isinstance(prefix, str) or not re.fullmatch(r'[0-9a-f]{1,4}', prefix)):
        raise network.ServidorNoDisponible('VOE solicita una verificacion no compatible.')
    nonce = bytes.fromhex(params['nonce'])
    salt = bytes.fromhex(params['salt'])
    if not 1 <= len(nonce) <= 128 or not 1 <= len(salt) <= 128:
        raise ValueError('ALTCHA: parametros invalidos')
    started = time.monotonic()
    deadline = getattr(network._sondeo, 'deadline', None)
    if deadline is not None:
        max_seconds = min(max_seconds, max(0, deadline - started))
    for counter in range(10000):
        cancel = getattr(network._sondeo, 'cancel', None)
        if cancel is not None and cancel.is_set():
            break
        if time.monotonic() - started >= max_seconds:
            break
        derived = hashlib.pbkdf2_hmac('sha256', nonce + counter.to_bytes(4, 'big'),
                                      salt, cost, length).hex()
        if derived.startswith(prefix):
            solution = {'counter': counter, 'derivedKey': derived,
                        'time': round((time.monotonic() - started) * 1000, 1)}
            return base64.b64encode(json.dumps({'challenge': challenge, 'solution': solution}).encode()).decode('ascii')
    raise network.ServidorNoDisponible('VOE: la verificacion excedio el tiempo de espera. Prueba otro servidor.')


class VoeGateParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.challenge = None
        self.fields = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'altcha-widget':
            self.challenge = attrs.get('challenge')
        elif tag == 'input' and attrs.get('name') in ('_token', 'access'):
            self.fields[attrs['name']] = attrs.get('value', '')


def extraer_fuente_voe(page):
    # La variable source visible en el HTML apunta a un video de demostracion.
    # Usar exclusivamente la configuracion JSON del reproductor real.
    for raw in re.findall(r'<script\b[^>]*type=[\'"]application/json[\'"][^>]*>(.*?)</script>', page, re.S | re.I):
        try:
            data = json.loads(raw)
            if not isinstance(data, list) or not data or not isinstance(data[0], str):
                continue
            encoded = codecs.decode(data[0], 'rot_13')
            for marker in ('@$', '^^', '~@', '%?', '*~', '!!', '#&'):
                encoded = encoded.replace(marker, '')
            shifted = base64.b64decode(encoded, validate=True).decode('utf-8')
            decoded = ''.join(chr(ord(c) - 3) for c in shifted)[::-1]
            config = json.loads(base64.b64decode(decoded, validate=True))
            if not isinstance(config, dict):
                continue
            source = config.get('source')
            if isinstance(source, str) and source.startswith(('https://', 'http://')):
                return source
        except (ValueError, TypeError, UnicodeError):
            continue
    return None


def resolver_voe(embed_url):
    opener = network.nueva_sesion()
    domain = urllib.parse.urlsplit(embed_url).netloc or 'voe.sx'
    headers = {'User-Agent': network.UA, 'Referer': f'https://{domain}/'}
    try:
        with opener.open(urllib.request.Request(embed_url, headers=headers), timeout=12) as r:
            page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            url = r.geturl()
        redirect = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
        if redirect:
            with opener.open(urllib.request.Request(html.unescape(redirect.group(1)), headers=headers), timeout=12) as r:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                url = r.geturl()
        if 'permanentToken' in page:
            redirect2 = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"\s]+)[\'"]', page)
            if redirect2:
                with opener.open(urllib.request.Request(html.unescape(redirect2.group(1)), headers={'User-Agent': network.UA, 'Referer': url}), timeout=12) as r:
                    page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                    url = r.geturl()
        gate = VoeGateParser()
        gate.feed(page)
        if gate.challenge:
            challenge_url = urllib.parse.urljoin(url, gate.challenge)
            if urllib.parse.urlsplit(challenge_url).netloc != urllib.parse.urlsplit(url).netloc or '_token' not in gate.fields:
                raise ValueError('VOE: formulario inesperado')
            headers['Referer'] = url
            with opener.open(urllib.request.Request(challenge_url, headers=headers), timeout=12) as r:
                challenge = json.loads(r.read(64 * 1024))
            gate.fields['altcha'] = resolver_altcha(challenge)
            request = urllib.request.Request(url, headers=headers,
                data=urllib.parse.urlencode(gate.fields).encode('utf-8'))
            with opener.open(request, timeout=12) as r:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                url = r.geturl()
            if '<altcha-widget' in page:
                raise network.ServidorNoDisponible('VOE no acepto la verificacion. Prueba otro servidor.')
        source = extraer_fuente_voe(page)
        if source:
            return procesar_hls_local(source, url, opener)
        # Fallback a extraccion directa/desempaquetado
        sources = extraer_fuentes_hls(page, url)
        if not sources:
            pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
            for match in re.finditer(pattern, page, re.S):
                p, a, c, k = match.groups()
                sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), url)
                if sources:
                    break
        for media in sources[:3]:
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': url}, opener)
            stream = procesar_hls_local(media, url, opener)
            if stream:
                return stream
        network.log_resolver('VOE: no se encontro la configuracion de video')
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('VOE: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def _verificar_nupload_hls(m3u8_url, headers):
    """Comprueba manifiesto HLS y el primer segmento real para rechazar respuestas DMCA/HTML."""
    try:
        req = urllib.request.Request(m3u8_url, headers=headers)
        with network.abrir_url(req, timeout=network.tiempo_peticion(8)) as resp:
            playlist_text = resp.read(1024 * 1024).decode('utf-8-sig', 'replace')
            playlist_url = resp.geturl() or m3u8_url
    except Exception as exc:
        raise _error_red_a_no_disponible('Nupload', exc)

    if not playlist_text.lstrip().startswith('#EXTM3U'):
        raise network.ServidorNoDisponible('Nupload no entregó un manifiesto HLS válido.')

    lines = playlist_text.splitlines()
    variants = []
    for idx, line in enumerate(lines[:-1]):
        if line.startswith('#EXT-X-STREAM-INF:'):
            bw_match = re.search(r'BANDWIDTH=(\d+)', line)
            bw = int(bw_match.group(1)) if bw_match else 0
            uri = next((lines[j].strip() for j in range(idx + 1, min(idx + 4, len(lines)))
                        if lines[j].strip() and not lines[j].strip().startswith('#')), '')
            if uri:
                variants.append((bw, urllib.parse.urljoin(playlist_url, uri)))

    if variants:
        target_variant = max(variants, key=lambda pair: pair[0])[1]
        try:
            v_req = urllib.request.Request(target_variant, headers=headers)
            with network.abrir_url(v_req, timeout=network.tiempo_peticion(6)) as v_resp:
                playlist_text = v_resp.read(1024 * 1024).decode('utf-8-sig', 'replace')
                playlist_url = v_resp.geturl() or target_variant
        except Exception as exc:
            raise _error_red_a_no_disponible('Nupload', exc)
        if not playlist_text.lstrip().startswith('#EXTM3U'):
            raise network.ServidorNoDisponible('Nupload entregó una variante HLS inválida.')

    resources = []
    for raw_map in re.findall(r'^#EXT-X-MAP:[^\n]*URI=["\']([^"\']+)["\']', playlist_text, re.M):
        resources.append(urllib.parse.urljoin(playlist_url, raw_map.strip()))
    first_seg = next((ln.strip() for ln in playlist_text.splitlines() if ln.strip() and not ln.strip().startswith('#')), '')
    if not first_seg:
        raise network.ServidorNoDisponible('Nupload entregó un manifiesto HLS sin segmentos.')
    resources.append(urllib.parse.urljoin(playlist_url, first_seg))

    for resource in resources:
        try:
            s_req = urllib.request.Request(resource, headers=dict(headers, Range='bytes=0-1023'))
            with network.abrir_url(s_req, timeout=network.tiempo_peticion(6)) as s_resp:
                sample = s_resp.read(1024)
        except Exception as exc:
            raise _error_red_a_no_disponible('Nupload', exc)
        if not sample:
            raise network.ServidorNoDisponible('Nupload entregó un segmento de vídeo vacío.')
        lower = sample.lstrip().lower()
        if lower.startswith((b'<html', b'<!doctype', b'<head', b'<body', b'<?xml')) or b'file deleted' in lower or b'dmca' in lower:
            raise network.ServidorNoDisponible('Nupload: archivo eliminado por DMCA o bloqueado en el servidor.')


def resolver_nupload(embed_url, referer=None):
    """
    Resuelve enlaces de nupload (nupload.my, nupload.me, nuupload, etc.)
    decodificando el array ofuscado, verificando el HLS y marcando ext=.m3u8.
    """
    if not referer:
        referer = 'https://seriesflixhd.lol/'
    headers = {'User-Agent': network.UA, 'Referer': referer}
    try:
        req = urllib.request.Request(embed_url, headers=headers)
        with network.abrir_url(req, timeout=network.tiempo_peticion(12)) as resp:
            page = resp.read().decode('utf-8', 'replace')
            final_url = resp.geturl() or embed_url
    except Exception as exc:
        raise _error_red_a_no_disponible('Nupload', exc)

    m_arr = re.search(r'var\s+([A-Za-z0-9]+)\s*=\s*(\[[^\]]+\]);', page)
    if not m_arr:
        raise network.ServidorNoDisponible('Nupload no entregó datos de reproducción.')
    arr_var = m_arr.group(1)
    arr_items = json.loads(m_arr.group(2))
    m_loop = re.search(re.escape(arr_var) + r'\.forEach.*?-\s*(\d+)\s*\)', page)
    if not m_loop:
        raise network.ServidorNoDisponible('Nupload no entregó clave de descifrado.')
    offset = int(m_loop.group(1))

    chars = []
    for val in arr_items:
        b64_clean = base64.b64decode(val).decode('utf-8', errors='ignore')
        digits = re.sub(r'\D', '', b64_clean)
        if digits:
            chars.append(chr(int(digits) - offset))
    base_stream = ''.join(chars)

    m_sesz = re.search(r'var\s+sesz\s*=\s*[\'"]([^\'"]+)', page)
    if not base_stream.startswith(('https://', 'http://')) or not m_sesz:
        raise network.ServidorNoDisponible('Nupload no entregó sesión de vídeo válida.')
    sesz = m_sesz.group(1)

    m3u8_url = f"{base_stream}?s={sesz}"
    media_headers = {'User-Agent': network.UA, 'Referer': final_url}
    _verificar_nupload_hls(m3u8_url, media_headers)
    return network.url_con_cabeceras(m3u8_url, dict(media_headers, ext='.m3u8'))


def resolver_playmate(embed_url):
    """API usada por el reproductor publico de Playmate; sx es el master."""
    opener = network.nueva_sesion()
    parts = urllib.parse.urlsplit(embed_url)
    code = parts.path.rstrip('/').split('/')[-1]
    root = '{}://{}'.format(parts.scheme, parts.netloc)
    headers = {'User-Agent': network.UA, 'Referer': embed_url}
    try:
        with opener.open(urllib.request.Request(embed_url, headers=headers), timeout=12) as r:
            r.read(1024 * 1024)
        request = urllib.request.Request(root + '/api/s',
            data=json.dumps({'c': code, 'd': 'desktop'}).encode('utf-8'),
            headers=dict(headers, **{'Content-Type': 'application/json'}))
        with opener.open(request, timeout=12) as r:
            data = json.loads(r.read(256 * 1024))
        media = data.get('sx', '')
        if isinstance(media, str) and media.startswith(('https://', 'http://')):
            return procesar_hls_local(media, embed_url, opener)
        network.log_resolver('PM: la API no devolvio un video disponible')
    except Exception as exc:
        network.log_resolver('PM: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def resolver_unlimplay(embed_url):
    """UA agrupa hosts por idioma y publica un extractor HLS propio."""
    opener = network.nueva_sesion()
    try:
        parts = urllib.parse.urlsplit(embed_url)
        episode = re.search(r'/embed/tv/\d+/(\d+)/(\d+)/?$', parts.path)
        if episode:
            # El frontend redirigido puede perder temporada/episodio de la
            # ruta y devolver solo searched_names. Su API acepta estos campos.
            params = dict(urllib.parse.parse_qsl(parts.query))
            params.setdefault('season', episode.group(1))
            params.setdefault('episode', episode.group(2))
            # /play/ redirige a /f/ descartando el query; usar el destino
            # publicado para conservar esos parametros desde la primera GET.
            path = parts.path.replace('/play/embed/', '/f/embed/', 1)
            embed_url = urllib.parse.urlunsplit(parts._replace(path=path, query=urllib.parse.urlencode(params)))
        req = urllib.request.Request(embed_url, headers={'User-Agent': network.UA})
        with opener.open(req, timeout=12) as r:
            page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = r.geturl()
        endpoint = re.search(r'const\s+ULP_EXTRACT_URL\s*=\s*("[^"\n]+")', page)
        token = re.search(r'const\s+ULP_SESSION_TOKEN\s*=\s*("[^"\n]+")', page)
        found = re.search(r'finalizePlayer\(\s*(\{"searched_names".*?\})\s*\);', page, re.S)
        if not (endpoint and token and found):
            network.log_resolver('UA: no se encontro la lista de servidores')
            return None
        endpoint = json.loads(endpoint.group(1))
        if urllib.parse.urlsplit(endpoint).hostname != urllib.parse.urlsplit(referer).hostname:
            return None
        data = json.loads(found.group(1))
        # FuegoCine anuncia UA latino: no cambiar silenciosamente el idioma.
        # Algunos titulos solo tienen video en el ultimo host (Fastream).
        # Recorrer las alternativas con el mismo limite global de tiempo.
        candidates = [url for name, url in data.get('latino', {}).items()
                      if 'vidhide' not in name.lower() and urllib.parse.urlsplit(url).hostname != 'morencius.com'][:8]
        deadline = time.monotonic() + 35
        for host_url in candidates:
            if time.monotonic() >= deadline:
                break
            try:
                # Fastream firma enlaces para la conexion que extrae el video.
                # El extractor remoto de UA puede entregar una firma rechazada
                # desde Kodi; resolver localmente con su propia sesion.
                if urllib.parse.urlsplit(host_url).hostname == 'fastream.to':
                    stream = resolver_host_hls(host_url, timeout=min(6, max(1, (deadline - time.monotonic()) / 2)))
                    if stream:
                        return stream
                request = urllib.request.Request(endpoint,
                    data=json.dumps({'url': host_url}).encode('utf-8'),
                    headers={'User-Agent': network.UA, 'Referer': referer,
                             'Content-Type': 'application/json',
                             'X-ULP-Token': json.loads(token.group(1))})
                with opener.open(request, timeout=min(8, max(1, deadline - time.monotonic()))) as r:
                    extracted = json.loads(r.read(256 * 1024))
                streams = extracted.get('streams', [])
                if not isinstance(streams, list):
                    continue
                for media in streams[:3]:
                    if time.monotonic() >= deadline:
                        break
                    if not isinstance(media, str) or not media.startswith(('https://', 'http://')):
                        continue
                    stream = procesar_hls_local(media, extracted.get('referer') or host_url,
                        opener, timeout=min(6, max(1, deadline - time.monotonic())))
                    if stream:
                        return stream
            except Exception as exc:
                network.log_resolver('UA: fallo en un host ({})'.format(type(exc).__name__))
        network.log_resolver('UA: ningun manifiesto latino accesible')
    except Exception as exc:
        network.log_resolver('UA: fallo de acceso ({})'.format(type(exc).__name__))
    return None


def hydrax_transform(data, seed):
    # Protocolo publico del player, contrastado con ResolveURL:
    # github.com/Gujal00/ResolveURL/blob/master/script.module.resolveurl/lib/resolveurl/plugins/abyss.py
    seed = str(seed)
    numeric = seed.replace('.', '', 1).replace(':', '').replace('-', '').isdigit()
    material = bytes(int(c) if c.isdigit() else ord(c) for c in seed) if numeric else seed.encode('utf-8')
    key = hashlib.md5(material).hexdigest().encode('ascii')
    return MiniAES(key).transform_ctr(data, int.from_bytes(key[:16], 'big'))


def resolver_hydrax(url):
    opener = network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': url}
    with opener.open(urllib.request.Request(url, headers=headers), timeout=10) as response:
        page = response.read(1024 * 1024).decode('utf-8', 'replace')
    match = re.search(r'(?:const|var)\s+datas\s*=\s*"([^"]+)"', page)
    if not match:
        raise network.ServidorNoDisponible('VIP/Hydrax no entrego la configuracion del video.')
    # El player usa atob: cada byte representa un caracter, no texto UTF-8.
    data = json.loads(base64.b64decode(match.group(1)).decode('latin-1'))
    media = data.get('media')
    if isinstance(media, str):
        seed = '{user_id}:{slug}:{md5_id}'.format(**data)
        media = json.loads(hydrax_transform(bytes(ord(c) & 255 for c in media), seed))
    mp4 = media.get('mp4', {})
    sources = sorted((x for x in mp4.get('sources', []) if x.get('status') and x.get('size')),
                     key=lambda x: int(x['size']), reverse=True)
    if not sources:
        raise network.ServidorNoDisponible('VIP/Hydrax: no hay archivos de video disponibles.')
    source = sources[0]
    domain = next((d for d in mp4.get('domains', []) if d.startswith(source.get('sub', '') + '.')), None)
    if not domain:
        raise network.ServidorNoDisponible('VIP/Hydrax: falta el servidor del archivo.')
    path = '/mp4/{}/{}/{}?v={}'.format(data['md5_id'], source['res_id'], source['size'], data['slug'])
    token = base64.b64encode(base64.b64encode(hydrax_transform(path.encode('utf-8'), source['size']))).decode('ascii')
    target = 'https://{}/sora/{}/{}'.format(domain, source['size'], token)
    with opener.open(urllib.request.Request(target, headers=dict(headers, Range='bytes=0-1023')), timeout=10) as response:
        prefix = response.read(32)
        if response.status != 206 or prefix[4:8] != b'ftyp':
            raise network.ServidorNoDisponible('VIP/Hydrax no entrego un MP4 con soporte para adelantar.')
    # La URL carece de extension. No enviar Range fijo al reproductor.
    labels = sorted({x.get('label', '') for x in sources if re.fullmatch(r'\d+p', x.get('label', ''))},
                    key=lambda value: int(value[:-1]))
    CALIDADES_HLS[target] = ('Multirresolucion: {} (auto: {})'.format(' / '.join(labels), source.get('label', ''))
                            if len(labels) > 1 else source.get('label', ''))
    return network.url_con_cabeceras(target, dict(headers, ext='.mp4'), opener)


def resolver_menu_antiguo(url):
    opener = network.nueva_sesion()
    with opener.open(urllib.request.Request(url, headers={'User-Agent': network.UA}), timeout=8) as response:
        page = response.read(1024 * 1024).decode('utf-8', 'replace')
    targets = re.findall(r"go_to_player\(['\"](https?://[^'\"]+)['\"]", page)
    supported = ('goodstream.one', 'vimeos.net', 'voe.sx', 'hglink.to', 'playmate.to', 'fastream.to', 'player.pelisserieshoy.com', 'abyssplayer.com', 'playhydrax.com')
    for target in list(dict.fromkeys(targets))[:8]:
        if urllib.parse.urlsplit(target).hostname not in supported:
            continue
        try:
            stream = resolver_enlace_directo(html.unescape(target))
            if stream:
                return stream
        except network.ServidorNoDisponible:
            pass
    raise network.ServidorNoDisponible('Este menu antiguo no ofrece un enlace compatible disponible. Elige Premium, StreamWish o VOE.')


def resolver_upns(url):
    parts = urllib.parse.urlsplit(url)
    if not parts.fragment:
        return None
    endpoint = '{}://{}/api/v1/video?{}'.format(parts.scheme, parts.netloc,
        urllib.parse.urlencode({'id': parts.fragment, 'w': 1920, 'h': 1080, 'r': 'fuegocine.com'}))
    try:
        with network.nueva_sesion().open(urllib.request.Request(endpoint, headers={'User-Agent': network.UA, 'Referer': url}), timeout=8) as response:
            data = json.loads(response.read(1024 * 1024))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise network.ServidorNoDisponible('US: el servidor informa que el video no existe o fue eliminado.')
        raise
    source = data.get('hls') or data.get('file') or data.get('url')
    if isinstance(source, str) and '.m3u8' in source:
        return procesar_hls_local(source, url)
    raise network.ServidorNoDisponible('US no ofrece un enlace de video compatible con el addon.')






def _filemoon_crypto(operation, **payload):

    network.tiempo_peticion(8)
    try:
        if operation == 'sign':
            return _fm_py_sign(payload['nonce'])
        if operation == 'decrypt':
            return _fm_py_decrypt(payload['playback'], MiniAES)
        raise ValueError('Unsupported operation')
    except ValueError as exc:
        raise network.ServidorNoDisponible('Filemoon: respuesta criptografica no valida.') from exc


def _filemoon_attest(api, user_agent):
    import sys
    challenge = api('/api/videos/access/challenge', {})
    signature = _filemoon_crypto('sign', nonce=challenge['nonce'])
    identity = {'viewer_id': str(uuid.uuid4()), 'device_id': str(uuid.uuid4())}
    result = api('/api/videos/access/attest', dict(identity, **signature,
                 challenge_id=challenge['challenge_id'], nonce=challenge['nonce'],
                 client={'user_agent': user_agent, 'platform': 'Windows' if sys.platform == 'win32' else sys.platform, 'languages': ['es-ES']},
                 storage={}, attributes={}))
    if not result.get('token'):
        raise network.ServidorNoDisponible('Filemoon: el reproductor no acepto la sesion.')
    return {key: result.get(key, identity.get(key))
            for key in ('token', 'viewer_id', 'device_id', 'confidence')}


def _py_pow_hash(text, first_only=False):
    def rol(a, n):
        return ((a << n) | (a >> (32 - n))) & 0xFFFFFFFF

    def mix(a):
        a[0] = (a[0] + a[1]) & 0xFFFFFFFF
        a[3] = rol(a[3] ^ a[0], 16)
        a[2] = (a[2] + a[3]) & 0xFFFFFFFF
        a[1] = rol(a[1] ^ a[2], 12)
        a[0] = (a[0] + a[1]) & 0xFFFFFFFF
        a[3] = rol(a[3] ^ a[0], 8)
        a[2] = (a[2] + a[3]) & 0xFFFFFFFF
        a[1] = rol(a[1] ^ a[2], 7)

    def imul(a, b):
        return (a * b) & 0xFFFFFFFF

    a = [1779033703, 3144134277, 1013904242, 2773480762]
    for c in text.encode('utf-8'):
        a[0] = rol((a[0] + c) & 0xFFFFFFFF, 7)
        mix(a)
    for _ in range(8):
        mix(a)
    mem = [0] * 512
    for i in range(512):
        mix(a)
        mem[i] = (a[0] ^ a[2]) & 0xFFFFFFFF
    for _ in range(2):
        for i in range(512):
            c = rol((mem[i] + mem[mem[i] & 511]) & 0xFFFFFFFF, 13)
            c = (c ^ imul(mem[(i + 1) & 511], 2654435761)) & 0xFFFFFFFF
            mem[i] = c
            a[0] = (a[0] ^ c) & 0xFFFFFFFF
            mix(a)
    out = []
    for i in range(1 if first_only else 8):
        mix(a)
        n = a[0]
        for j in range(64):
            v = mem[i * 64 + j]
            n = (rol((n + v) & 0xFFFFFFFF, 5) ^ imul(v, 2246822519)) & 0xFFFFFFFF
        out.append((n ^ a[2]) & 0xFFFFFFFF)
    return out


def _filemoon_proof(challenge, timeout=180):
    nonce = challenge.get('pow_nonce', '')
    difficulty = challenge.get('pow_difficulty', 0)
    network.tiempo_peticion(timeout)
    deadline = getattr(network._sondeo, 'deadline', None)
    if deadline is not None:
        timeout = min(timeout, max(0, deadline - time.monotonic()))
    timeout_ms = int(timeout * 1000)

    # Load bundled native code inside Kodi; never launch Node or another Python.

    if not isinstance(nonce, str) or len(nonce) > 256 or type(difficulty) is not int or not 0 <= difficulty <= 24:
        raise network.ServidorNoDisponible('Filemoon: parametros de comprobacion no validos.')
    try:
        accelerator = _fm_native_load()
    except (OSError, ImportError) as exc:
        accelerator = None
        network.log_resolver('Filemoon: acelerador no disponible (%s); usando Python.' % type(exc).__name__)
    if accelerator is not None:
        started = time.monotonic()
        nonce_bytes = nonce.encode('utf-8')
        n = 0
        while time.monotonic() - started < timeout:
            network.tiempo_peticion(timeout)
            solution = _fm_native_batch(accelerator, nonce_bytes, difficulty, n)
            if solution is not None:
                return solution
            n += 128
            if n >= 2**32:
                break
        raise network.ServidorNoDisponible('Filemoon: la comprobacion excedio el tiempo disponible.')

    # 1. Resolver en Python puro
    if isinstance(nonce, str) and len(nonce) <= 256 and type(difficulty) is int and 0 <= difficulty <= 24:
        started = time.monotonic()
        n = 0
        def clz32(val):
            return 32 if val == 0 else 32 - val.bit_length()

        while (time.monotonic() - started) * 1000 < timeout_ms:
            network.tiempo_peticion(timeout)
            zeros = 0
            for v in (_fm_py_proof_word(f'{nonce}:{n}'),):
                zeros += clz32(v)
                if v:
                    break
            if zeros >= difficulty:
                return str(n)
            n += 1

    raise network.ServidorNoDisponible('Filemoon: la comprobacion excedio el tiempo disponible; intenta reproducir de nuevo.')


def _filemoon_resolve(url):
    network.tiempo_peticion(8)  # Honor scanner cancellation before any request or helper.
    parsed = urllib.parse.urlsplit(url)
    code = parsed.path.rstrip('/').rsplit('/', 1)[-1]
    if not re.fullmatch(r'[A-Za-z0-9]+', code):
        raise network.ServidorNoDisponible('Filemoon: enlace de video no valido.')
    host = 'bysefujedu.com' if parsed.hostname == 'filemoon.sx' else parsed.hostname
    origin = 'https://' + host
    referer = url
    opener = network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': referer, 'Accept': 'application/json'}

    def api(path, body=None):
        endpoint = path if path.startswith('/api/videos/access/') else '/api/videos/' + code + '/embed/' + path
        request = urllib.request.Request(origin + endpoint,
                          data=json.dumps(body).encode() if body is not None else None,
                          headers=dict(headers, **({'Content-Type': 'application/json'} if body is not None else {})))
        with opener.open(request, timeout=8) as response:
            raw = response.read(512 * 1024 + 1)
        if len(raw) > 512 * 1024:
            raise ValueError('Filemoon API response too large')
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError('Filemoon API response is not an object')
        return data

    details = api('details')
    frame = details.get('embed_frame_url', '')
    if frame:
        target = urllib.parse.urlsplit(frame)
        # Follow only the HTTPS player for this exact file, never a local host.
        if (target.scheme != 'https' or not target.hostname or '.' not in target.hostname
                or target.username or target.port not in (None, 443)
                or not re.fullmatch(r'/[A-Za-z0-9]{1,16}/' + re.escape(code), target.path)):
            raise network.ServidorNoDisponible('Filemoon: direccion del reproductor no reconocida.')
        import ipaddress
        try:
            ipaddress.ip_address(target.hostname)
        except ValueError:
            pass
        else:
            raise network.ServidorNoDisponible('Filemoon: direccion del reproductor no reconocida.')
        origin, referer = 'https://' + target.hostname, frame
        headers.update({'Referer': frame, 'Origin': origin,
                        'X-Embed-Origin': parsed.hostname, 'X-Embed-Referer': url,
                        'X-Embed-Parent': url})
    settings = api('settings')
    fingerprint = None
    if frame:
        fingerprint = _filemoon_attest(api, network.UA)
    if settings.get('captcha_required'):
        challenge = api('captcha', {})
        solution = _filemoon_proof(challenge)
        verified = api('captcha/verify', {'pow_token': challenge['pow_token'], 'solution': solution})
        if verified.get('status') != 'ok' or not verified.get('token'):
            raise network.ServidorNoDisponible('Filemoon no acepto la comprobacion automatica; puede requerir verificacion visual en su web.')
        headers['X-Captcha-Token'] = verified['token']
    try:
        try:
            playback = api('playback', {'fingerprint': fingerprint}) if fingerprint else api('playback')
        except urllib.error.HTTPError as exc:
            if exc.code != 405:
                raise
            playback = api('playback', {})
    except urllib.error.HTTPError as exc:
        raise network.ServidorNoDisponible('Filemoon: su API de reproduccion respondio HTTP %s; aun no se obtuvo el video.' % exc.code) from exc
    if isinstance(playback.get('playback'), dict):
        playback = _filemoon_crypto('decrypt', playback=playback['playback'])
    # Accept only explicit sources. Never return the player HTML as a video.
    for source in playback.get('sources', []):
        media = source.get('url', '') if isinstance(source, dict) else ''
        if urllib.parse.urlsplit(media).scheme not in ('http', 'https'):
            continue
        stream = procesar_hls_local(media, referer, opener, timeout=8)
        if stream:
            return stream
    raise network.ServidorNoDisponible('Filemoon: la API no entrego un manifiesto compatible; la comprobacion no garantiza la reproduccion.')


def resolver_filemoon(url):
    try:
        return _filemoon_resolve(url)
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('Filemoon API: ' + type(exc).__name__)
    # Legacy mirrors may still publish a packed JWPlayer page.
    stream = resolver_host_hls(url)
    if stream:
        return stream
    raise network.ServidorNoDisponible('Filemoon no entrego una fuente de video compatible con Kodi.')


def resolver_vidhide(embed_url):
    """Resuelve enlaces embebidos de VidHide y sus variantes (minochinos, vidhidepro, vidhidepre, vidhideplus, streamhide, filelions, etc.)."""
    id_match = re.search(r'/(?:v|e|embed)/([a-zA-Z0-9_-]+)', embed_url)
    raw_id = id_match.group(1) if id_match else None

    mirrors = [embed_url]
    if raw_id:
        extra_mirrors = [
            f'https://vidhidepre.com/v/{raw_id}',
            f'https://vidhideplus.com/v/{raw_id}',
            f'https://vidhide.com/v/{raw_id}',
            f'https://streamhide.to/v/{raw_id}',
            f'https://filelions.to/v/{raw_id}',
        ]
        for m in extra_mirrors:
            if m not in mirrors:
                mirrors.append(m)

    for target in mirrors:
        domain = urllib.parse.urlsplit(target).netloc
        referer = f'https://{domain}/' if domain else target
        opener = network.nueva_sesion()
        try:
            req = urllib.request.Request(target, headers={'User-Agent': network.UA, 'Referer': referer})
            with opener.open(req, timeout=8) as response:
                page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                final_referer = response.geturl()

            sources = extraer_fuentes_hls(page, final_referer)
            if not sources:
                pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
                for match in re.finditer(pattern, page, re.S):
                    p, a, c, k = match.groups()
                    sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), final_referer)
                    if sources:
                        break

            for media in sources[:3]:
                if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                    return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': final_referer}, opener)
                stream = procesar_hls_local(media, final_referer, opener, timeout=8)
                if stream:
                    return stream
        except Exception:
            continue

    network.log_resolver('VidHide: no se pudo resolver en ningun espejo disponible')
    return None


def resolver_streamwish(embed_url):
    """
    Resuelve StreamWish y sus multiples espejos (strwish, wishfast, sfastwish, hglink, hanerix, embedwish).
    Prueba el enlace original y los espejos activos conocidos con descarte rapido en caso de fallo.
    """
    id_match = (
        re.search(r'/(?:e|v|embed|d)[/-]([a-zA-Z0-9_-]+?)(?:\.html|\?|$)', embed_url)
        or re.search(r'/(?:e|v|embed)/([a-zA-Z0-9_-]+)', embed_url)
    )
    raw_id = id_match.group(1) if id_match else None

    mirrors = [embed_url]
    if raw_id:
        for m in (f'https://embedwish.com/e/{raw_id}',
                  f'https://swhoi.com/e/{raw_id}',
                  f'https://flaswish.com/e/{raw_id}',
                  f'https://hanerix.com/e/{raw_id}',
                  f'https://wishfast.top/e/{raw_id}'):
            if m not in mirrors:
                mirrors.append(m)
    deadline = time.monotonic() + 10
    failures = []
    for mirror in mirrors:
        if time.monotonic() >= deadline:
            break
        try:
            stream = resolver_host_hls(mirror, timeout=min(3.5, max(1.0, deadline - time.monotonic())))
            if stream:
                return stream
        except network.ServidorNoDisponible as exc:
            failures.append(str(exc))
            continue
        except Exception as exc:
            failures.append(type(exc).__name__)
            continue
    network.log_resolver('StreamWish: no se pudo resolver en ningun espejo disponible')
    raise network.ServidorNoDisponible(
        'StreamWish no entregó un vídeo reproducible. ' + (failures[0] if failures else 'Sus espejos no respondieron.'))


def desenvolver_embed_shortener(url):
    """
    Desenvolver JWT de embedshortener.co / fkplayer.xyz.
    Decodifica la carga util base64 (payload.embed o link) para obtener el servidor real.
    """
    if not url or not any(x in url.lower() for x in ('embedshortener.', 'fkplayer.', 'shortener')):
        return None
    try:
        path = urllib.parse.urlsplit(url).path
        token = path.rstrip('/').split('/')[-1].split('?')[0].split('#')[0]
        parts = token.split('.')
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        payload_b64 += '=' * ((4 - len(payload_b64) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64).decode('utf-8', 'ignore'))
        if not isinstance(payload, dict):
            return None
        if payload.get('embed') and payload['embed'].startswith('http'):
            return payload['embed']
        if payload.get('link'):
            raw_link = payload['link']
            raw_link += '=' * ((4 - len(raw_link) % 4) % 4)
            decoded = base64.b64decode(raw_link).decode('utf-8', 'ignore')
            if decoded.startswith('http'):
                return decoded
    except Exception:
        pass
    return None


def resolver_pixeldrain(url):
    """Pixeldrain: https://pixeldrain.com/u/{id} -> https://pixeldrain.com/api/file/{id}"""
    m = re.search(r'pixeldrain\.com/(?:u|api/file)/([a-zA-Z0-9]+)', url)
    if m:
        file_id = m.group(1)
        direct = f"https://pixeldrain.com/api/file/{file_id}"
        return f"{direct}|User-Agent={urllib.parse.quote(network.UA)}"
    return None


def resolver_vidara(embed_url):
    """Vidara: API POST del reproductor actual, con host y referente originales."""
    m = re.search(r'/(?:e|player)/([^/?#]+)', embed_url)
    if not m:
        return None
    filecode = m.group(1)
    parsed = urllib.parse.urlsplit(embed_url)
    if parsed.hostname not in ('vidara.to', 'vidara.so'):
        return None
    api = f"{parsed.scheme}://{parsed.netloc}/api/stream"
    opener = network.nueva_sesion()
    try:
        payload = json.dumps({'filecode': filecode, 'device': 'web', 'codecs': []}).encode('utf-8')
        req = urllib.request.Request(api, data=payload, headers={
            'User-Agent': network.UA, 'Referer': embed_url, 'Accept': 'application/json',
            'Content-Type': 'application/json'})
        with opener.open(req, timeout=10) as r:
            data = json.loads(r.read(256 * 1024).decode('utf-8', 'replace'))
        if not isinstance(data, dict):
            raise network.ServidorNoDisponible('Vidara no entregó datos de reproducción válidos.')
        media = data.get('streaming_url') or data.get('file') or data.get('url') or (data.get('data') and (data['data'].get('streaming_url') or data['data'].get('url')))
        if media and isinstance(media, str) and media.startswith('http'):
            if '.mp4' in media.lower() and '.m3u8' not in media.lower():
                return network.url_con_cabeceras(media, {'User-Agent': network.UA, 'Referer': embed_url}, opener)
            stream = procesar_hls_local(media, embed_url, opener)
            if stream:
                return stream
            raise network.ServidorNoDisponible('Vidara entregó un HLS cuyo video no se pudo verificar.')
        raise network.ServidorNoDisponible('Vidara no entregó un enlace de video.')
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        network.log_resolver('Vidara: fallo ({})'.format(type(exc).__name__))
        raise network.ServidorNoDisponible('Vidara no respondió con video reproducible: ' + type(exc).__name__) from exc


def resolver_primeload(embed_url):
    """Primeload: busca espejos StreamWish asociados o blobs base64 con .m3u8."""
    opener = network.nueva_sesion()
    headers = {'User-Agent': network.UA, 'Referer': 'https://embedshortener.co/'}
    try:
        req = urllib.request.Request(embed_url, headers=headers)
        with opener.open(req, timeout=10) as r:
            html_text = r.read(1024 * 1024).decode('utf-8', 'replace')
        mirrors = list(dict.fromkeys(re.findall(r'["\'](//[a-z0-9.-]+\.[a-z]{2,}/[A-Za-z0-9_-]{6,}/\d+)["\']', html_text, re.I)))
        for mirror in ['https:' + m for m in mirrors[:4]]:
            try:
                stream = resolver_host_hls(mirror, timeout=6)
                if stream:
                    return stream
            except Exception:
                continue
        for b64 in re.findall(r'atob\(\s*["\']([A-Za-z0-9+/=]{40,})["\']\s*\)', html_text):
            try:
                dec = base64.b64decode(b64).decode('utf-8', 'ignore')
                m3 = extraer_url_hls(dec)
                if m3:
                    return procesar_hls_local(m3, embed_url, opener)
            except Exception:
                pass
    except Exception as exc:
        network.log_resolver('Primeload: fallo ({})'.format(type(exc).__name__))
    return None


def resolver_dood(url):
    import secrets
    opener = network.nueva_sesion(standard_tls=True)
    try:
        user_agent = _dood_configure(opener) or network.UA
    except (OSError, ValueError) as exc:
        raise network.ServidorNoDisponible('Doodstream: no se pudo leer el archivo de cookies configurado.') from exc

    parsed = urllib.parse.urlsplit(url)
    code = parsed.path.rstrip('/').rsplit('/', 1)[-1]
    candidate_urls = [url]
    if parsed.hostname in _DOOD_HOSTS + ('dood.li', 'doodstream.co'):
        for m in ('playmogo.com', 'do7go.com', 'dsvplay.com', 'ds2play.com', 'dood.li', 'doodstream.co'):
            if m == parsed.hostname:
                continue
            candidate_urls.append(urllib.parse.urlunsplit((parsed.scheme, m, '/e/' + code, '', '')))

    last_error = None
    for target_url in candidate_urls:
        request = urllib.request.Request(target_url, headers={'User-Agent': user_agent, 'Referer': target_url})
        try:
            with opener.open(request, timeout=8) as response:
                page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                referer = response.geturl()
            endpoint = re.search(r'''['"](/pass_md5/[^'"]+)''', page)
            token = re.search(r'[?&]token=([a-zA-Z0-9]+)&expiry=', page)
            if not endpoint or not token:
                continue
            pass_req = urllib.request.Request(urllib.parse.urljoin(referer, endpoint.group(1)),
                                             headers={'User-Agent': user_agent, 'Referer': referer})
            with opener.open(pass_req, timeout=8) as response:
                prefix = response.read(8192).decode('utf-8', 'replace').strip()
            if not prefix.startswith(('https://', 'http://')) or '<' in prefix:
                continue
            media = prefix + secrets.token_hex(5) + '?token=' + token.group(1) + '&expiry=' + str(int(time.time() * 1000))
            return network.url_con_cabeceras(media, {'User-Agent': user_agent, 'Referer': referer}, opener)
        except urllib.error.HTTPError as exc:
            if exc.code == 403:
                last_error = network.ServidorNoDisponible('Doodstream: acceso HTTP 403 en %s. Requiere cookies en Ajustes > Doodstream.' % urllib.parse.urlsplit(exc.url).hostname)
            continue
        except Exception as exc:
            last_error = exc
            continue

    if isinstance(last_error, network.ServidorNoDisponible):
        raise last_error
    raise network.ServidorNoDisponible('Dood no entrega el enlace de este video o requiere verificacion en su web.')


def extraer_streamtape(page, referer):
    assignment = re.search(r"getElementById\(['\"]robotlink['\"]\)\.innerHTML\s*=\s*(.*?);", page, re.S)
    if not assignment:
        return None
    expression = assignment.group(1)
    # Only read string literals and numeric substring operations; never execute JS.
    tokens = list(re.finditer(r"(['\"])((?:\\.|(?!\1).)*)\1", expression))
    values = []
    for index, token in enumerate(tokens):
        value = token.group(2).replace(r'\/', '/')
        tail = expression[token.end():tokens[index + 1].start() if index + 1 < len(tokens) else len(expression)]
        for offset in re.findall(r'\.substring\(\s*(\d+)\s*\)', tail):
            value = value[int(offset):]
        values.append(value)
    media = urllib.parse.urljoin(referer, html.unescape(''.join(values)))
    parsed = urllib.parse.urlsplit(media)
    if parsed.hostname != urllib.parse.urlsplit(referer).hostname or parsed.path != '/get_video':
        return None
    return media + '&stream=1'


def resolver_vk(url):
    """
    Resuelve videos incrustados de VKontakte (vk.com / vkvideo.ru).
    Extrae transmisiones HLS o MP4 con multirresolucion.
    """
    try:
        html_src, final_url = network.fetch_html(url, referer="https://vk.com/")
        if not html_src:
            return None
        m_hls = re.search(r'["\']hls["\']\s*:\s*["\'](https?:[^"\']+)["\']', html_src)
        if m_hls:
            hls_url = m_hls.group(1).replace(r'\/', '/')
            return f"{hls_url}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(final_url)}"
        for q in ('url1080', 'url720', 'url480', 'url360', 'url240'):
            m_mp4 = re.search(r'["\']' + q + r'["\']\s*:\s*["\'](https?:[^"\']+)["\']', html_src)
            if m_mp4:
                mp4_url = m_mp4.group(1).replace(r'\/', '/')
                return f"{mp4_url}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(final_url)}"
    except Exception:
        pass
    return None


def resolver_streamtape(url):
    opener = network.nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': url})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    media = extraer_streamtape(page, referer)
    if not media:
        raise network.ServidorNoDisponible('Streamtape no entrega un enlace reproducible para este video.')
    return media + '|User-Agent=' + urllib.parse.quote(network.UA) + '&Referer=' + urllib.parse.quote(referer)


def resolver_mixdrop(url):
    parsed = _validar_url_https_publica(url)
    if not parsed:
        raise network.ServidorNoDisponible('Enlace de Mixdrop inválido.')
    opener = network.nueva_sesion()
    request = urllib.request.Request(url, headers={'User-Agent': network.UA, 'Referer': url})
    try:
        with opener.open(request, timeout=network.tiempo_peticion(12)) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            referer = response.geturl()
    except Exception as exc:
        raise _error_red_a_no_disponible('Mixdrop', exc)
    pattern = r"eval\(function\(p,a,c,k,e,[dr]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
    scripts = [page]
    for match in re.finditer(pattern, page, re.S):
        packed, radix, count, words = match.groups()
        scripts.append(unpack_js(packed, int(radix), int(count), words.split('|')))
    for script in scripts:
        match = re.search(r'MDCore\.wurl\s*=\s*[\'"]([^\'"]+)', script)
        if match:
            media = urllib.parse.urljoin(referer, match.group(1).replace(r'\/', '/'))
            return _verificar_y_formatear_video(media, referer=referer, opener=opener)
    raise network.ServidorNoDisponible('Mixdrop no entrega un video en este enlace; puede haber sido retirado.')


def resolver_yourupload(url):
    opener = network.nueva_sesion()
    embed_url = re.sub(r'/watch/([a-zA-Z0-9]+)', r'/embed/\1', url)
    request = urllib.request.Request(embed_url, headers={'User-Agent': network.UA, 'Referer': 'https://www.yourupload.com/'})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    match = re.search(r"file\s*:\s*['\"](https?://[^'\"]+\.mp4[^'\"]*)['\"]", page)
    if not match:
        match = re.search(r'property=[\'"]og:video[\'"]\s+content=[\'"](https?://[^\'"]+)[\'"]', page)
    if match:
        media = match.group(1)
        return media + '|User-Agent=' + urllib.parse.quote(network.UA) + '&Referer=' + urllib.parse.quote(referer)
    raise network.ServidorNoDisponible('YourUpload no entrego un enlace reproducible para este video.')


def resolver_mp4upload(url):
    opener = network.nueva_sesion()
    m_id = re.search(r'mp4upload\.com/(?:embed-)?([a-zA-Z0-9]+)(?:\.html)?', url)
    embed_url = f"https://www.mp4upload.com/embed-{m_id.group(1)}.html" if m_id else url
    request = urllib.request.Request(embed_url, headers={'User-Agent': network.UA, 'Referer': 'https://www.mp4upload.com/'})
    with opener.open(request, timeout=12) as response:
        page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
        referer = response.geturl()
    match = re.search(r"src\s*:\s*['\"](https?://[^'\"]+\.mp4[^'\"]*)['\"]", page)
    if match:
        media = match.group(1)
        return media + '|User-Agent=' + urllib.parse.quote(network.UA) + '&Referer=' + urllib.parse.quote(referer)
    raise network.ServidorNoDisponible('MP4Upload no entrego un enlace reproducible para este video.')


def resolver_zilla(url):
    m3u8_url = url.replace('/play/', '/m3u8/')
    parsed = urllib.parse.urlsplit(url)
    origin = f"{parsed.scheme}://{parsed.netloc}/"
    headers = {'User-Agent': network.UA, 'Referer': origin}
    try:
        with network.abrir_url(urllib.request.Request(m3u8_url, headers=headers), timeout=6) as response:
            manifest = response.read(1024 * 1024).decode('utf-8-sig', 'replace')
        if not manifest.lstrip().startswith('#EXTM3U'):
            return None
        urls = re.findall(r'#EXT-X-MAP:[^\n]*URI="([^"]+)"', manifest)
        urls += [line.strip() for line in manifest.splitlines() if line.strip() and not line.startswith('#')][:1]
        if not urls:
            return None
        for resource in urls:
            probe = urllib.request.Request(urllib.parse.urljoin(m3u8_url, resource),
                                           headers=dict(headers, Range='bytes=0-1023'))
            with network.abrir_url(probe, timeout=6) as response:
                if not response.read(16):
                    return None
    except Exception as exc:
        network.log_resolver('Zilla: manifiesto o primer segmento inaccesible (' + type(exc).__name__ + ')')
        return None
    return m3u8_url + '|' + urllib.parse.urlencode(headers)


def resolver_mediafire(url):
    """Obtiene el MP4 real desde la pagina de descarga de MediaFire."""
    headers = {'User-Agent': network.UA}
    try:
        with network.abrir_url(urllib.request.Request(url, headers=headers), timeout=8) as response:
            page = response.read(1024 * 1024).decode('utf-8', 'replace')
        match = re.search(r'href=["\'](https://[^"\']+)["\'][^>]*id=["\']downloadButton["\']', page, re.I)
        if not match:
            return None
        direct = html.unescape(match.group(1))
        host = (urllib.parse.urlsplit(direct).hostname or '').lower()
        if not host.endswith('.mediafire.com') or not urllib.parse.urlsplit(direct).path.lower().endswith('.mp4'):
            return None
        probe = urllib.request.Request(direct, headers=dict(headers, Range='bytes=0-1023'))
        with network.abrir_url(probe, timeout=8) as response:
            if response.read(12)[4:8] != b'ftyp':
                return None
        return direct + '|' + urllib.parse.urlencode(headers)
    except Exception as exc:
        network.log_resolver('MediaFire: descarga inaccesible (' + type(exc).__name__ + ')')
        return None


def _resolver_opcional(url):
    if resolveurl is None or getattr(network._sondeo, 'deadline', None) is not None:
        return None
    try:
        candidates = [url]
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname or ''
        if host in ('bysefujedu.com', 'bysevepoin.com', 'bysedikamoum.com', 'bysekoze.com'):
            candidates.append(urllib.parse.urlunsplit((parsed.scheme, 'filemoon.sx', parsed.path, parsed.query, parsed.fragment)))
        elif host in ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com', 'dsvplay.com', 'ds2play.com'):
            candidates.append(urllib.parse.urlunsplit((parsed.scheme, 'playmogo.com', parsed.path, parsed.query, parsed.fragment)))

        for target in candidates:
            if resolveurl.relevant_resolvers(target):
                res = resolveurl.resolve(target)
                if res:
                    return res
    except Exception as exc:
        network.log_resolver('ResolveURL: ' + type(exc).__name__)
    return None


def resolver_esprinahy(embed_url):
    """
    Resuelve enlaces de Esprinahy / Tokvoy a stream MP4 directo.
    """
    import ssl
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    headers = {"User-Agent": network.UA, "Referer": "https://kaj.seriesturcastv.to/"}

    # Normalizar /f/ (reproductor) a /d/ (descarga / tokvoy gate)
    if "esprinahy.com/f/" in embed_url:
        embed_url = embed_url.replace("/f/", "/d/")

    try:
        if "tokvoy.com" in embed_url:
            tok_url = embed_url
        else:
            req = urllib.request.Request(embed_url, headers=headers)
            with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
                html = r.read().decode("utf-8", "ignore")
            m_tok = re.search(r'href="([^"]*tokvoy\.com/d/[^"]+)"', html)
            if not m_tok:
                m_tok = re.search(r"href='([^']*tokvoy\.com/d/[^']+)'", html)
            if not m_tok:
                return None
            tok_url = m_tok.group(1)

        req_tok = urllib.request.Request(tok_url, headers=headers)
        with urllib.request.urlopen(req_tok, context=ctx, timeout=10) as r:
            tok_html = r.read().decode("utf-8", "ignore")

        inputs = dict(re.findall(r'<input[^>]+type="hidden"[^>]*name="([^"]+)"[^>]*value="([^"]*)"', tok_html))
        if not inputs:
            inputs = dict(re.findall(r'<input[^>]+name="([^"]+)"[^>]*value="([^"]*)"[^>]*type="hidden"', tok_html))

        if not inputs.get("hash"):
            return None

        # Anti-bot bypass: Tokvoy rechaza posts menores a 1.2s arrojando 'Security error1'
        time.sleep(1.2)

        post_data = urllib.parse.urlencode(inputs).encode("utf-8")
        post_headers = {
            "User-Agent": network.UA,
            "Referer": tok_url,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        req_post = urllib.request.Request(tok_url, data=post_data, headers=post_headers)
        with urllib.request.urlopen(req_post, context=ctx, timeout=10) as r:
            post_html = r.read().decode("utf-8", "ignore")

        m_mp4 = re.search(r"https?://[^\s<>'\"]+\.mp4[^\s<>'\"]*", post_html)
        if m_mp4:
            stream = m_mp4.group(0)
            return f"{stream}|User-Agent={urllib.parse.quote(network.UA)}"
    except Exception as exc:
        network.log_resolver("Esprinahy error: " + type(exc).__name__)
    return None


_MOVIEBOX_REFERER = 'https://moviebox.ph/'
_NET79_API_BASE = 'https://net79.cc/api/embed-tmdb/'
_NETMIRROR_PATH_RE = re.compile(
    r'^/api/netmirror/(movie|tv)/(\d+)/(\d+)/(\d+)/(\d+)p/(\d+)/?$'
)


def _es_host_hakunaymatata(host):
    host = (host or '').lower().rstrip('.')
    return host == 'hakunaymatata.com' or host.endswith('.hakunaymatata.com')


def _validar_url_https_publica(url):
    if not isinstance(url, str) or not url or len(url) > 2048:
        return None
    base = url.split('|', 1)[0].strip()
    try:
        parsed = urllib.parse.urlsplit(base)
    except ValueError:
        return None
    host = (parsed.hostname or '').lower().rstrip('.')
    if (parsed.scheme != 'https' or not host or parsed.username or parsed.password
            or parsed.port not in (None, 443)):
        return None
    if host == 'localhost' or host.endswith('.local'):
        return None
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return parsed
    if not ip.is_global:
        return None
    return parsed


def _formatear_stream_con_referer(url_media, referer):
    base = url_media.split('|', 1)[0]
    return (
        f"{base}|User-Agent={urllib.parse.quote(network.UA, safe='')}"
        f"&Referer={urllib.parse.quote(referer, safe='')}"
    )


def _parse_res_int(value):
    match = re.search(r'(\d+)', str(value or ''))
    return int(match.group(1)) if match else 0


def _error_red_a_no_disponible(prefijo, exc):
    if isinstance(exc, urllib.error.HTTPError):
        return network.ServidorNoDisponible(f"{prefijo} rechazó la petición (HTTP {exc.code}).")
    if isinstance(exc, TimeoutError):
        return network.ServidorNoDisponible(f"Tiempo de espera agotado en {prefijo}.")
    if isinstance(exc, urllib.error.URLError):
        reason = getattr(exc, 'reason', exc)
        if isinstance(reason, TimeoutError) or 'timed out' in str(reason).lower():
            return network.ServidorNoDisponible(f"Tiempo de espera agotado en {prefijo}.")
        return network.ServidorNoDisponible(f"{prefijo} no accesible por error de red.")
    return network.ServidorNoDisponible(f"{prefijo} no pudo entregar el vídeo.")


def _verificar_y_formatear_video(url_media, referer=None, opener=None):
    """Comprueba bytes reales de MP4/HLS con su Referer antes de entregar el stream a Kodi."""
    base = (url_media or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    if not parsed:
        raise network.ServidorNoDisponible('Enlace de vídeo inválido o no seguro.')
    host = (parsed.hostname or '').lower()
    if referer is None:
        referer = _MOVIEBOX_REFERER if _es_host_hakunaymatata(host) else f"{parsed.scheme}://{parsed.netloc}/"
    session = opener or network.nueva_sesion()
    headers = {
        'User-Agent': network.UA,
        'Referer': referer,
        'Range': 'bytes=0-1023',
    }
    request = urllib.request.Request(base, headers=headers)
    try:
        with session.open(request, timeout=network.tiempo_peticion(10)) as response:
            ctype = (response.headers.get('Content-Type') or '').lower()
            chunk = response.read(1024)
    except Exception as exc:
        raise _error_red_a_no_disponible('El CDN de vídeo', exc)

    head_lower = chunk.lstrip().lower()
    if 'text/html' in ctype or head_lower.startswith((b'<!doctype', b'<html', b'<head', b'<script')):
        raise network.ServidorNoDisponible('El servidor devolvió una página HTML en lugar de vídeo.')

    is_hls = parsed.path.lower().endswith('.m3u8') or 'mpegurl' in ctype
    if is_hls:
        if not chunk.lstrip(b'\xef\xbb\xbf \t\r\n').startswith(b'#EXTM3U'):
            raise network.ServidorNoDisponible('El manifiesto HLS recibido no es válido.')
        stream = procesar_hls_local(base, referer, opener=session)
        if not stream:
            raise network.ServidorNoDisponible('El manifiesto HLS no tiene segmentos reproducibles.')
        return stream

    if len(chunk) < 12 or chunk[4:8] != b'ftyp':
        raise network.ServidorNoDisponible('El enlace no entregó una cabecera MP4 válida.')
    return _formatear_stream_con_referer(base, referer)


def resolver_hakunaymatata(url, opener=None):
    """Resuelve enlaces directos de HakunaMatata/MovieBox inyectando el Referer requerido."""
    base = (url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    if not parsed or not _es_host_hakunaymatata(parsed.hostname):
        raise network.ServidorNoDisponible('Enlace de HakunaMatata inválido.')
    return _verificar_y_formatear_video(base, referer=_MOVIEBOX_REFERER, opener=opener)


def resolver_netmirror(url, opener=None):
    """Resuelve rutas syntorq.com/api/netmirror/* consultando net79.cc y validando identidad y vídeo."""
    base = (url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    if not parsed or (parsed.hostname or '').lower() != 'syntorq.com':
        raise network.ServidorNoDisponible('Enlace de NetMirror inválido.')
    match = _NETMIRROR_PATH_RE.match(parsed.path or '')
    if not match:
        raise network.ServidorNoDisponible('Ruta de NetMirror no reconocida.')

    kind, tmdb_id, season_s, episode_s, res_s, idx_s = match.groups()
    season = int(season_s)
    episode = int(episode_s)
    req_res = int(res_s)
    req_idx = int(idx_s)
    if kind == 'tv':
        if season <= 0 or episode <= 0:
            raise network.ServidorNoDisponible('Episodio de NetMirror inválido.')
        api_url = f"{_NET79_API_BASE}{tmdb_id}?type=tv&season={season}&episode={episode}"
    else:
        api_url = f"{_NET79_API_BASE}{tmdb_id}"

    session = opener or network.nueva_sesion()
    request = urllib.request.Request(
        api_url,
        headers={
            'User-Agent': network.UA,
            'Accept': 'application/json',
            'Referer': 'https://net79.cc/',
        },
    )
    try:
        with session.open(request, timeout=network.tiempo_peticion(12)) as response:
            ctype = (response.headers.get('Content-Type') or '').lower()
            raw = response.read(1024 * 1024)
    except Exception as exc:
        raise _error_red_a_no_disponible('NetMirror', exc)

    text = raw.decode('utf-8', 'replace')
    stripped = text.lstrip().lower()
    if 'text/html' in ctype or stripped.startswith(('<!doctype', '<html', '<head')):
        raise network.ServidorNoDisponible('NetMirror devolvió HTML en lugar de JSON.')

    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        raise network.ServidorNoDisponible('NetMirror devolvió una respuesta JSON inválida.')

    if not isinstance(data, dict) or not data.get('ok'):
        raise network.ServidorNoDisponible('NetMirror no tiene fuentes disponibles para este título.')

    if data.get('tmdbId') is not None and str(data.get('tmdbId')) != str(tmdb_id):
        raise network.ServidorNoDisponible('NetMirror devolvió un título distinto al solicitado.')
    if kind == 'tv':
        if data.get('currentSeason') is not None and str(data.get('currentSeason')) != str(season):
            raise network.ServidorNoDisponible('NetMirror devolvió una temporada distinta a la solicitada.')
        if data.get('currentEpisode') is not None and str(data.get('currentEpisode')) != str(episode):
            raise network.ServidorNoDisponible('NetMirror devolvió un episodio distinto al solicitado.')

    streams = data.get('streams') if isinstance(data.get('streams'), list) else []
    media_url = ''
    if 0 <= req_idx < len(streams) and isinstance(streams[req_idx], dict):
        entry = streams[req_idx]
        if _parse_res_int(entry.get('resolution')) == req_res and entry.get('url'):
            media_url = entry['url']
    if not media_url:
        for entry in streams:
            if isinstance(entry, dict) and _parse_res_int(entry.get('resolution')) == req_res and entry.get('url'):
                media_url = entry['url']
                break
    if not media_url and data.get('mp4') and _parse_res_int(data.get('resolution')) == req_res:
        media_url = data['mp4']

    if not media_url:
        raise network.ServidorNoDisponible(f'NetMirror no tiene disponible la variante de {req_res}p.')

    return _verificar_y_formatear_video(media_url, opener=session)


_VIDSPARK_KEY_CACHE = {}
_VIDSPARK_KEY_LOCK = threading.Lock()


def resolver_uqload(embed_url, opener=None):
    """Resuelve embeds de uqload.* manejando bloqueo por Referer propio."""
    base = (embed_url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    if not parsed:
        raise network.ServidorNoDisponible('Enlace de Uqload inválido.')
    host = (parsed.hostname or '').lower()
    session = opener or network.nueva_sesion()
    headers = {'User-Agent': network.UA}
    if host != 'uqload.vc':
        headers['Referer'] = f"{parsed.scheme}://{parsed.netloc}/"
    try:
        req = urllib.request.Request(base, headers=headers)
        with session.open(req, timeout=network.tiempo_peticion(12)) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            final_url = response.geturl()
        if 'restricted for this domain' in page.lower() and 'Referer' in headers:
            req = urllib.request.Request(base, headers={'User-Agent': network.UA})
            with session.open(req, timeout=network.tiempo_peticion(12)) as response:
                page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                final_url = response.geturl()
    except Exception as exc:
        raise _error_red_a_no_disponible('Uqload', exc)

    lower_page = page.lower()
    if 'restricted for this domain' in lower_page:
        raise network.ServidorNoDisponible('Uqload restringió el embed por dominio.')
    if 'file is no longer available' in lower_page or 'file was deleted' in lower_page:
        raise network.ServidorNoDisponible('Uqload indica que el archivo fue eliminado.')
    if 'countries are not allowed' in lower_page:
        raise network.ServidorNoDisponible('Uqload restringe el acceso desde tu ubicación.')

    sources = extraer_fuentes_hls(page, final_url)
    if not sources:
        pattern = r"eval\(function\(p,a,c,k,e,[a-zA-Z]\).*?\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)"
        for match in re.finditer(pattern, page, re.S):
            p, a, c, k = match.groups()
            sources = extraer_fuentes_hls(unpack_js(p, int(a), int(c), k.split('|')), final_url)
            if sources:
                break
    for media in sources[:3]:
        if not _validar_url_https_publica(media):
            continue
        if '.mp4' in media.lower() and '.m3u8' not in media.lower():
            return _verificar_y_formatear_video(media, referer=final_url, opener=session)
        stream = procesar_hls_local(media, final_url, opener=session)
        if stream:
            return stream
    raise network.ServidorNoDisponible('Uqload no entregó un manifiesto o vídeo accesible.')


def resolver_pelispedia(url, opener=None):
    """Resuelve fichas pelispedia.mov -> iframe /vidurl/... (PoW SHA-256 + AES-CBC)."""
    base = (url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    if not parsed or (parsed.hostname or '').lower() not in ('pelispedia.mov', 'www.pelispedia.mov'):
        raise network.ServidorNoDisponible('Enlace de PelisPedia inválido.')
    session = opener or network.nueva_sesion()
    origin = f"{parsed.scheme}://{parsed.netloc}"

    try:
        if parsed.path.startswith('/vidurl/'):
            vidurl = base
            page_ref = origin + '/'
        else:
            req = urllib.request.Request(base, headers={'User-Agent': network.UA, 'Referer': origin + '/'})
            with session.open(req, timeout=network.tiempo_peticion(10)) as resp:
                page = resp.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                page_ref = resp.geturl()
            m_vid = re.search(r'<iframe[^>]+src=["\']([^"\']*\/vidurl\/[^"\']+)["\']', page, re.I)
            if not m_vid:
                raise network.ServidorNoDisponible('PelisPedia no publicó un reproductor /vidurl/ en esta ficha.')
            vidurl = urllib.parse.urljoin(page_ref, html.unescape(m_vid.group(1)))
        v_parsed = _validar_url_https_publica(vidurl)
        if not v_parsed or (v_parsed.hostname or '').lower() not in ('pelispedia.mov', 'www.pelispedia.mov'):
            raise network.ServidorNoDisponible('Reproductor de PelisPedia inválido.')
        req_v = urllib.request.Request(vidurl, headers={'User-Agent': network.UA, 'Referer': page_ref})
        with session.open(req_v, timeout=network.tiempo_peticion(10)) as resp_v:
            vid_html = resp_v.read(2 * 1024 * 1024).decode('utf-8', 'replace')
    except network.ServidorNoDisponible:
        raise
    except Exception as exc:
        raise _error_red_a_no_disponible('PelisPedia', exc)

    entries = _descifrar_datalink_pow(vid_html)
    if not entries:
        raise network.ServidorNoDisponible('PelisPedia no permitió descifrar servidores disponibles.')

    latino = [e for e in entries if e['lang'].upper() in ('LAT', 'LATINO')]
    candidates = latino if latino else entries
    last_error = None
    for entry in candidates:
        target = entry['url']
        t_host = (urllib.parse.urlsplit(target).hostname or '').lower()
        if not _validar_url_https_publica(target) or 'pelispedia.mov' in t_host:
            continue
        try:
            network.tiempo_peticion(1)
            stream = resolver_enlace_directo(target)
            if stream and '.m3u8' in stream.split('|', 1)[0].lower():
                stream = seleccionar_variante_optima(stream, conservar_master=True)
            if stream:
                return stream
        except TimeoutError as exc:
            raise _error_red_a_no_disponible('PelisPedia', exc)
        except Exception as exc:
            last_error = exc
            continue
    if isinstance(last_error, network.ServidorNoDisponible):
        raise last_error
    raise network.ServidorNoDisponible('PelisPedia no tiene ningún servidor externo accesible en este momento.')


def _vidspark_player_key(embed_url, session):
    try:
        req = urllib.request.Request(embed_url, headers={'User-Agent': network.UA, 'Referer': 'https://moviesapi.to/'})
        with session.open(req, timeout=network.tiempo_peticion(10)) as resp:
            final_url = resp.geturl()
            html_page = resp.read(512 * 1024).decode('utf-8', 'replace')
    except Exception as exc:
        raise _error_red_a_no_disponible('MoviesAPI', exc)

    p_final = _validar_url_https_publica(final_url)
    if not p_final:
        raise network.ServidorNoDisponible('MoviesAPI redirigió a un destino inválido.')
    origin = f"{p_final.scheme}://{p_final.netloc}"
    with _VIDSPARK_KEY_LOCK:
        cached = _VIDSPARK_KEY_CACHE.get(origin)
        if cached and time.monotonic() - cached[0] < 1800:
            return origin, final_url, cached[1]

    m_js = re.search(r'<script[^>]+src=["\']([^"\']*assets/[^"\']+\.js)["\']', html_page)
    if not m_js:
        raise network.ServidorNoDisponible('MoviesAPI no entregó el script del reproductor.')
    js_url = urllib.parse.urljoin(final_url, m_js.group(1))
    p_js = _validar_url_https_publica(js_url)
    if not p_js or p_js.netloc != p_final.netloc:
        raise network.ServidorNoDisponible('Script externo de MoviesAPI rechazado.')
    try:
        req_js = urllib.request.Request(js_url, headers={'User-Agent': network.UA, 'Referer': final_url})
        with session.open(req_js, timeout=network.tiempo_peticion(12)) as resp_js:
            js_text = resp_js.read(3 * 1024 * 1024).decode('utf-8', 'replace')
    except Exception as exc:
        raise _error_red_a_no_disponible('MoviesAPI', exc)

    key = ''
    m_hdr = re.search(r'["\']x-player-key["\']\s*:\s*([A-Za-z_$][\w$]*|["\'`][a-f0-9]{32,128}["\'`])', js_text)
    if m_hdr:
        token = m_hdr.group(1)
        if token[0] in ('"', "'", '`'):
            key = token.strip('"\'`')
        else:
            m_var = re.search(r'\b' + re.escape(token) + r'\s*=\s*[`"\']([a-f0-9]{32,128})[`"\']', js_text)
            if m_var:
                key = m_var.group(1)
    if not key:
        raise network.ServidorNoDisponible('MoviesAPI no expuso x-player-key en el reproductor.')
    with _VIDSPARK_KEY_LOCK:
        _VIDSPARK_KEY_CACHE[origin] = (time.monotonic(), key)
    return origin, final_url, key


def resolver_moviesapi(url, opener=None):
    """Resuelve moviesapi.to / vidspark.to mediante la API vidora cuando existe HLS directo."""
    base = (url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    host = (parsed.hostname or '').lower() if parsed else ''
    if host not in ('moviesapi.to', 'www.moviesapi.to', 'vidspark.to'):
        raise network.ServidorNoDisponible('Enlace de MoviesAPI inválido.')

    path = parsed.path or ''
    m_movie = re.fullmatch(r'/movie/(\d+|tt\d+)/?', path)
    m_tv_slash = re.fullmatch(r'/tv/(\d+|tt\d+)/(\d+)/(\d+)/?', path)
    m_tv_dash = re.fullmatch(r'/tv/(\d+|tt\d+)-(\d+)-(\d+)/?', path)
    if m_movie:
        api_sub = f"/v1/movie/{m_movie.group(1)}"
    elif m_tv_slash:
        api_sub = f"/v1/tv/{m_tv_slash.group(1)}/{m_tv_slash.group(2)}/{m_tv_slash.group(3)}"
    elif m_tv_dash:
        api_sub = f"/v1/tv/{m_tv_dash.group(1)}/{m_tv_dash.group(2)}/{m_tv_dash.group(3)}"
    else:
        raise network.ServidorNoDisponible('Ruta de MoviesAPI no soportada.')

    session = opener or network.nueva_sesion()
    origin, referer, key = _vidspark_player_key(base, session)
    api_url = f"{origin}/api/vidora{api_sub}"
    raw = b''
    ctype = ''
    for attempt in range(2):
        req = urllib.request.Request(
            api_url,
            headers={'User-Agent': network.UA, 'x-player-key': key, 'Referer': referer},
        )
        try:
            with session.open(req, timeout=network.tiempo_peticion(12)) as resp:
                ctype = (resp.headers.get('Content-Type') or '').lower()
                raw = resp.read(1024 * 1024)
            break
        except urllib.error.HTTPError as exc:
            if exc.code == 401 and attempt == 0:
                with _VIDSPARK_KEY_LOCK:
                    _VIDSPARK_KEY_CACHE.pop(origin, None)
                origin, referer, key = _vidspark_player_key(base, session)
                continue
            if exc.code == 404:
                raise network.ServidorNoDisponible('MoviesAPI/VidSpark no tiene stream HLS directo disponible (solo DASH en navegador).')
            raise _error_red_a_no_disponible('MoviesAPI', exc)
        except Exception as exc:
            raise _error_red_a_no_disponible('MoviesAPI', exc)

    text = raw.decode('utf-8', 'replace')
    if 'text/html' in ctype or text.lstrip().lower().startswith(('<!doctype', '<html')):
        raise network.ServidorNoDisponible('MoviesAPI devolvió HTML en lugar de JSON.')
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        raise network.ServidorNoDisponible('MoviesAPI devolvió JSON inválido.')

    sources = data.get('sources') if isinstance(data, dict) else None
    if not data.get('result') or not isinstance(sources, list) or not sources:
        raise network.ServidorNoDisponible('MoviesAPI no entregó fuentes HLS para este título.')
    media_url = (sources[0] or {}).get('url', '')
    p_media = _validar_url_https_publica(media_url)
    if not p_media:
        raise network.ServidorNoDisponible('MoviesAPI entregó un enlace de vídeo inválido.')
    if p_media.path.lower().endswith('.mpd'):
        raise network.ServidorNoDisponible('MoviesAPI entregó DASH (.mpd), formato no compatible con esta ruta.')
    if p_media.path.lower().endswith('.mp4'):
        return _verificar_y_formatear_video(media_url, referer=origin + '/', opener=session)
    stream = procesar_hls_local(media_url, origin + '/', opener=session)
    if not stream:
        raise network.ServidorNoDisponible('MoviesAPI no entregó un manifiesto HLS accesible.')
    return stream


def resolver_modocine(url, opener=None):
    """Resuelve modocine.com únicamente mediante su reproductor verificado play.tukiplay.com."""
    base = (url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    host = (parsed.hostname or '').lower() if parsed else ''
    if host not in ('modocine.com', 'www.modocine.com'):
        raise network.ServidorNoDisponible('Enlace de ModoCine inválido.')
    session = opener or network.nueva_sesion()
    origin = f"{parsed.scheme}://{parsed.netloc}/"
    try:
        req = urllib.request.Request(base, headers={'User-Agent': network.UA, 'Referer': origin})
        with session.open(req, timeout=network.tiempo_peticion(10)) as resp:
            page = resp.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            page_url = resp.geturl()
    except Exception as exc:
        raise _error_red_a_no_disponible('ModoCine', exc)

    m_iframe = re.search(
        r'(?:data-src|src)=["\'](https://play\.tukiplay\.com/f/embed/[^"\']+)["\']',
        page, re.I,
    )
    if not m_iframe:
        raise network.ServidorNoDisponible('ModoCine no expuso el reproductor play.tukiplay.com.')
    play_url = html.unescape(m_iframe.group(1))
    if not _validar_url_https_publica(play_url):
        raise network.ServidorNoDisponible('Iframe de ModoCine inválido.')

    try:
        req_p = urllib.request.Request(play_url, headers={'User-Agent': network.UA, 'Referer': page_url})
        with session.open(req_p, timeout=network.tiempo_peticion(12)) as resp_p:
            play_html = resp_p.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            play_final = resp_p.geturl()
    except Exception as exc:
        raise _error_red_a_no_disponible('ModoCine/PlayTukiPlay', exc)

    m_fp = re.search(r'finalizePlayer\(\s*\{', play_html)
    if not m_fp:
        raise network.ServidorNoDisponible('ModoCine no entregó lista finalizePlayer.')
    try:
        embeds, _ = json.JSONDecoder().raw_decode(play_html, m_fp.end() - 1)
    except (ValueError, TypeError):
        raise network.ServidorNoDisponible('ModoCine entregó metadatos de reproductor inválidos.')
    if not isinstance(embeds, dict) or not embeds:
        raise network.ServidorNoDisponible('ModoCine no tiene fuentes disponibles para esta ficha.')

    preferred_langs = ('latino', 'castellano', 'espanol', 'subtitulado')
    lang_keys = [k for k in preferred_langs if k in embeds] + [k for k in embeds if k not in preferred_langs]
    preferred_srvs = ('vimeos', 'streamwish 2', 'streamwish', 'voe', 'voe 2', 'vidhide', 'vidara')
    last_error = None
    for lkey in lang_keys:
        bucket = embeds.get(lkey)
        if not isinstance(bucket, dict):
            continue
        srv_keys = [k for k in preferred_srvs if k in bucket] + [
            k for k in bucket if k not in preferred_srvs and k.lower() not in ('full',)
        ]
        for skey in srv_keys:
            cand = bucket.get(skey)
            if not _validar_url_https_publica(cand):
                continue
            cand_parsed = urllib.parse.urlsplit(cand)
            cand_host = (cand_parsed.hostname or '').lower()
            try:
                network.tiempo_peticion(1)
                if (cand_host == 'play.tukiplay.com' and '/cps.php' in cand_parsed.path) or '.m3u8' in cand.lower():
                    stream = procesar_hls_local(cand, play_final, opener=session)
                elif 'modocine.com' in cand_host:
                    continue
                else:
                    stream = resolver_enlace_directo(cand)
                if stream and '.m3u8' in stream.split('|', 1)[0].lower():
                    stream = seleccionar_variante_optima(stream, conservar_master=True)
                if stream:
                    return stream
            except TimeoutError as exc:
                raise _error_red_a_no_disponible('ModoCine', exc)
            except Exception as exc:
                last_error = exc
                continue
    if isinstance(last_error, network.ServidorNoDisponible):
        raise last_error
    raise network.ServidorNoDisponible('ModoCine no entregó ningún servidor reproducible.')


_VIDEOAPP_HOSTS = ('videoapp.zip', 'www.videoapp.zip', 'videoapp.mov', 'www.videoapp.mov')


def resolver_videoapp(embed_url, opener=None):
    """Resuelve puentes videoapp.zip / videoapp.mov extrayendo su iframe seguro."""
    base = (embed_url or '').split('|', 1)[0].strip()
    parsed = _validar_url_https_publica(base)
    host = (parsed.hostname or '').lower() if parsed else ''
    if host not in _VIDEOAPP_HOSTS:
        raise network.ServidorNoDisponible('Enlace de VideoApp inválido.')
    origin = f"{parsed.scheme}://{parsed.netloc}/"
    session = opener or network.nueva_sesion(standard_tls=True)
    try:
        req = urllib.request.Request(base, headers={'User-Agent': network.UA})
        with session.open(req, timeout=network.tiempo_peticion(12)) as response:
            page = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            final_url = response.geturl()
    except Exception as exc:
        raise _error_red_a_no_disponible('VideoApp', exc)

    final_parsed = _validar_url_https_publica(final_url)
    final_origin = f"{final_parsed.scheme}://{final_parsed.netloc}/" if final_parsed else origin
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', page, re.I)
    last_error = None
    for raw_src in iframes:
        target = urllib.parse.urljoin(final_url, html.unescape(raw_src).strip())
        t_parsed = _validar_url_https_publica(target)
        if not t_parsed:
            continue
        t_host = (t_parsed.hostname or '').lower()
        if t_host in _VIDEOAPP_HOSTS:
            continue
        try:
            network.tiempo_peticion(1)
            if 'vimeos' in t_host:
                stream = resolver_vimeos(target, referer=final_origin, opener=session)
            else:
                stream = resolver_enlace_directo(target)
            if stream and '.m3u8' in stream.split('|', 1)[0].lower():
                stream = seleccionar_variante_optima(stream, conservar_master=True)
            if stream:
                return stream
        except TimeoutError as exc:
            raise _error_red_a_no_disponible('VideoApp', exc)
        except Exception as exc:
            last_error = exc
            continue
    if isinstance(last_error, network.ServidorNoDisponible):
        raise last_error
    lower_page = page.lower()
    if ('contenido no disponible' in lower_page
            or 'enlace del reproductor no es válido' in lower_page
            or 'enlace del reproductor no es valido' in lower_page):
        raise network.ServidorNoDisponible('VideoApp indica que este contenido no está disponible.')
    raise network.ServidorNoDisponible('VideoApp no entregó ningún reproductor disponible.')


def resolver_youtube(url_target):
    """Resuelve vídeos VOD de YouTube a stream HLS/MP4 directo sin fallback plugin://."""
    import tube_engine
    vid = tube_engine.extract_video_id(url_target)
    if not vid:
        return None
    stream = tube_engine.resolve(vid)
    if not stream or str(stream).startswith('plugin://'):
        raise network.ServidorNoDisponible('YouTube no entregó vídeo directo (bloqueado o privado).')
    return stream


def resolver_vimeo(url_target, referer='https://www.argflix.com/'):
    """Resuelve enlaces de Vimeo de forma best-effort respetando Cloudflare."""
    match = re.search(r'vimeo\.com/(?:video/)?(\d+)', str(url_target or ''), re.I)
    if not match:
        return None
    vid = match.group(1)
    h_match = re.search(r'[?&]h=([a-zA-Z0-9]+)', str(url_target or ''))
    h_token = h_match.group(1) if h_match else ''

    opener = network.nueva_sesion(standard_tls=True)
    headers = {'User-Agent': network.UA}
    try:
        page_req = urllib.request.Request(f'https://vimeo.com/{vid}', headers=headers)
        with opener.open(page_req, timeout=10) as resp:
            page_html = resp.read().decode('utf-8', errors='replace')
        if not h_token:
            href_m = re.search(rf'player\.vimeo\.com/video/{vid}\?h=([a-zA-Z0-9]+)', page_html)
            if href_m:
                h_token = href_m.group(1)
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise network.ServidorNoDisponible(f'Vimeo denegó el acceso ({exc.code}).') from exc
        if exc.code in (404, 410):
            raise network.ServidorNoDisponible('Vimeo: vídeo no encontrado o eliminado.') from exc
    except Exception:
        pass

    player_url = f'https://player.vimeo.com/video/{vid}?app_id=122963'
    if h_token:
        player_url += f'&h={h_token}'
    try:
        player_req = urllib.request.Request(
            player_url,
            headers={'User-Agent': network.UA, 'Referer': referer},
        )
        with opener.open(player_req, timeout=10) as resp:
            body = resp.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise network.ServidorNoDisponible(f'Vimeo requiere verificación Cloudflare ({exc.code}).') from exc
        raise network.ServidorNoDisponible(f'Vimeo respondió HTTP {exc.code}.') from exc
    except Exception as exc:
        raise network.ServidorNoDisponible(f'Vimeo no respondió ({type(exc).__name__}).') from exc

    if 'challenge-platform' in body or 'cf-turnstile' in body:
        raise network.ServidorNoDisponible('Vimeo requiere verificación Cloudflare (Turnstile).')

    hls_raw = re.findall(r'"url":"(https:[^"]+\.m3u8[^"]*)"', body)
    candidates = []
    for raw in hls_raw:
        try:
            u = raw.encode('utf-8').decode('unicode_escape').replace('\\/', '/')
        except Exception:
            u = raw.replace('\\/', '/')
        if u and u not in candidates:
            candidates.append(u)

    if not candidates:
        mp4_matches = re.findall(r'"(?:height)":(\d+)[^}]*"url":"(https:[^"]+\.mp4[^"]*)"', body)
        for _, raw in sorted(mp4_matches, key=lambda pair: int(pair[0]), reverse=True):
            u = raw.replace('\\/', '/')
            if u not in candidates:
                candidates.append(u)

    if not candidates:
        raise network.ServidorNoDisponible('Vimeo no entregó flujos reproducibles.')

    media_headers = {'User-Agent': network.UA, 'Referer': 'https://player.vimeo.com/'}
    for cand in candidates[:3]:
        try:
            probe_req = urllib.request.Request(cand, headers=dict(media_headers, Range='bytes=0-1023'))
            with network.abrir_url(probe_req, timeout=6) as probe_resp:
                head = probe_resp.read(1024)
            if not head or head.lstrip().lower().startswith((b'<html', b'<!doctype')):
                continue
            if '.m3u8' in cand.lower() and not head.lstrip(b'\xef\xbb\xbf \r\n').startswith(b'#EXTM3U'):
                continue
            return network.url_con_cabeceras(cand, media_headers)
        except Exception:
            continue
    raise network.ServidorNoDisponible('Vimeo no entregó un manifiesto o vídeo válido.')


def resolver_enlace_directo(url_target):
    """
    Resuelve el stream final reproducible por Kodi para cualquier servidor.
    Soporta GoodStream, Vimeos, Google Drive, OK.RU, VIDS.ST, PelisSeriesHoy, HLS/MP4 y ResolveURL.
    """
    if not url_target:
        return None
    if re.match(r'^(?:www\.)?(?:youtube\.com|youtu\.be)/', str(url_target).strip(), re.I):
        url_target = 'https://' + str(url_target).strip()

    if 'player.poseidonhd2.co' in url_target:
        import lolplus
        p_html = lolplus.make_request(url_target, headers={'User-Agent': lolplus.DEFAULT_UA, 'Referer': 'https://www.poseidonhd2.co/'})
        m_url = re.search(r"var\s+url\s*=\s*['\"]([^'\"]+)['\"]", p_html)
        if m_url:
            return resolver_enlace_directo(m_url.group(1))

    if 'player.cuevana3.eu' in url_target:
        import lolplus
        p_html = lolplus.make_request(url_target, headers={'User-Agent': lolplus.DEFAULT_UA, 'Referer': 'https://wv3.cuevana3.eu/'})
        if p_html:
            m_url = re.search(r"var\s+url\s*=\s*['\"]([^'\"]+)['\"]", p_html)
            if m_url:
                return resolver_enlace_directo(m_url.group(1))
            m_embeds = re.findall(r'https?://[a-zA-Z0-9_\-\.\/]+(?:/e/|/d/|/v/|/embed-|player|\.html)[a-zA-Z0-9_\-\.\/]*', p_html)
            for emb in m_embeds:
                if not any(ad in emb for ad in ['yandex', 'autorun', 'adme', 'google', 'facebook', 'cloudflare']):
                    return resolver_enlace_directo(emb)

    # 0. Desenvolver acortadores JWT (embedshortener.co / fkplayer.xyz)
    unwrapped_short = desenvolver_embed_shortener(url_target)
    if unwrapped_short:
        url_target = unwrapped_short

    parsed = urllib.parse.urlparse(url_target)

    # Desenvolver enlaces encapsulados en parámetros como ?link= o ?r= (Base64)
    if 'link=' in url_target:
        q_link = urllib.parse.parse_qs(parsed.query).get('link', [''])[0]
        if q_link and q_link.startswith('http'):
            url_target = q_link
            parsed = urllib.parse.urlparse(url_target)

    # Redirecciones base64 comunes (p. ej. blogfc13.blogspot.com/?m=1.html?r=...)
    m_b64 = re.search(r'[?&]r=([a-zA-Z0-9+/=]{16,})', url_target)
    if m_b64:
        try:
            unwrapped = base64.b64decode(m_b64.group(1)).decode('utf-8', errors='ignore').strip()
            if unwrapped.startswith('http'):
                url_target = unwrapped
                parsed = urllib.parse.urlparse(url_target)
        except Exception:
            pass

    host = (parsed.hostname or '').lower()
    if host in ('youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be', 'www.youtu.be', 'youtube-nocookie.com', 'www.youtube-nocookie.com'):
        return resolver_youtube(url_target)
    if host == 'vimeo.com' or host.endswith('.vimeo.com'):
        return resolver_vimeo(url_target)
    if host == 'iframe.andromedans.live':
        return resolver_andromedans(url_target)
    if host in ('mega.nz', 'www.mega.nz', 'mega.co.nz', 'www.mega.co.nz'):
        return resolver_mega(url_target)
    if 'filemoon' in host or host in ('bysefujedu.com', 'bysevepoin.com', 'bysedikamoum.com', 'bysekoze.com'):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_filemoon(url_target)

    # Esprinahy / Tokvoy
    if any(h in host for h in ('esprinahy', 'tokvoy')):
        return resolver_esprinahy(url_target)

    # VidHide y clones
    if any(h in host for h in ('vidhide', 'minochinos', 'streamhide', 'dintezuvio', 'movearnpre', 'luluvdo', 'barmonrey', 'fluxcedene', 'cvid.lat', 'byselapuix', 'bysesukior')):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_vidhide(url_target)

    if parsed.hostname in ('morencius.com', 'embedwish.com', 'fastream.to', 'flaswish.com', 'luluvido.com', 'lulustream.com', 'dingtezuni.com', 'callistanise.com'):
        return resolver_host_hls(url_target)

    # StreamWish y espejos
    if any(h in host for h in ('streamwish', 'strwish', 'wishfast', 'sfastwish', 'hglink', 'hanerix', 'hlswish', 'awish', 'filelions', 'wishembed', 'dhcplay', 'hglamioz')) or ('wish' in host and '/e/' in url_target):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_streamwish(url_target)

    # Pixeldrain
    if 'pixeldrain.com' in host:
        return resolver_pixeldrain(url_target)

    # Vidara
    if host in ('vidara.so', 'vidara.to'):
        return resolver_vidara(url_target)

    # Primeload
    if 'primeload.co' in host:
        return resolver_primeload(url_target)

    if host in ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com', 'playmogo.com', 'dsvplay.com', 'ds2play.com'):
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_dood(url_target)
    if host in ('streamtape.com', 'streamtape.to', 'streamtape.net', 'streamtape.cc'):
        return resolver_streamtape(url_target)
    if host in ('mixdrop.is', 'mixdrop.co', 'mixdrop.to', 'mixdrop.top', 'mixdrop.ag', 'mixdrop.bz', 'm1xdrop.bz', 'mxdrop.to', 'mxdrop.click'):
        return resolver_mixdrop(url_target)
    if 'yourupload.com' in host:
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_yourupload(url_target)
    if 'mp4upload.com' in host:
        res = _resolver_opcional(url_target)
        if res:
            return res
        return resolver_mp4upload(url_target)
    if 'zilla-networks' in host:
        return resolver_zilla(url_target)
    if host in ('mediafire.com', 'www.mediafire.com'):
        return resolver_mediafire(url_target)
    if host in ('uqload.vc', 'uqload.ws', 'uqload.com', 'uqload.to', 'uqload.net', 'uqload.io', 'strm1.uqload.is'):
        return resolver_uqload(url_target)
    if host == 'oneupload.to':
        return resolver_host_hls(url_target)

    # 1. GoodStream (HackStore2 / PelisJuanita)
    if parsed.hostname == 're.sololatino.net':
        return resolver_menu_antiguo(url_target)
    if parsed.hostname == 'fuegocineplayer.upns.online':
        return resolver_upns(url_target)
    if parsed.hostname in ('playhydrax.com', 'abyssplayer.com', 'player.abyssplayer.com', 'argtesa.top', 'abyss.to') or 'abyss' in (parsed.hostname or ''):
        return resolver_hydrax(url_target)
    if 'goodstream' in url_target:
        return resolver_goodstream(url_target)

    # 2. Vimeos y puentes VideoApp
    if parsed.hostname in _VIDEOAPP_HOSTS:
        return resolver_videoapp(url_target)
    if parsed.hostname in ('unlimplay.com', 'www.unlimplay.com'):
        return resolver_unlimplay(url_target)
    if parsed.hostname in ('playmate.to', 'www.playmate.to'):
        return resolver_playmate(url_target)
    if 'vimeos' in url_target:
        return resolver_vimeos(url_target)

    # VOE y clones
    if host.startswith('voe') or 'voe.' in host or 'voex.' in host or 'marissa.' in host or 'tubesquared.' in host:
        return resolver_voe(url_target)
    if 'nupload.' in host or 'nuupload.' in host:
        return resolver_nupload(url_target)

    if parsed.hostname in ('fastream.to',):
        return resolver_host_hls(url_target)

    if host == 'vixeo.io':
        stream = resolver_host_hls(url_target)
        if stream:
            return stream
        raise network.ServidorNoDisponible('Vidsonic no entrego un enlace compatible con Kodi. Elige otro servidor.')

    # 3. Google Drive
    if 'drive.google.com' in url_target or 'drive.usercontent.google.com' in url_target:
        return resolver_google_drive(url_target)

    # Internet Archive
    if host == 'archive.org' or host.endswith('.archive.org'):
        return resolver_archive_org(url_target)

    # 4. OK.RU y VK
    if 'ok.ru' in url_target:
        st_ok = resolver_ok_ru(url_target)
        if st_ok:
            return st_ok
    if 'vk.com' in host or 'vkvideo' in host:
        st_vk = resolver_vk(url_target)
        if st_vk:
            return st_vk

    # 5. VIDS.ST (VST)
    if 'vids.st' in url_target:
        st_vst = resolver_vids_st(url_target)
        if st_vst:
            return st_vst

    # MediaFire entrega los MP4 verificados de PelisSeriesHoy con sufijo .bin.
    # Kodi necesita la extension virtual; no volver a descargarlo como HTML.
    if host.endswith('.mediafire.com') and parsed.path.lower().endswith('.bin'):
        return (url_target + '|ext=.mp4&User-Agent=' +
                urllib.parse.quote(network.UA))

    # 5b. NetMirror (syntorq.com/api/netmirror), HakunaMatata, PelisPedia, MoviesAPI y ModoCine
    if host == 'syntorq.com' and _NETMIRROR_PATH_RE.match(parsed.path or ''):
        return resolver_netmirror(url_target)
    if _es_host_hakunaymatata(host):
        return resolver_hakunaymatata(url_target)
    if host in ('pelispedia.mov', 'www.pelispedia.mov'):
        return resolver_pelispedia(url_target)
    if host in ('moviesapi.to', 'www.moviesapi.to', 'vidspark.to'):
        return resolver_moviesapi(url_target)
    if host in ('modocine.com', 'www.modocine.com'):
        return resolver_modocine(url_target)

    # 6. Comprobar si ya es un stream de video directo (.m3u8, .mp4, .mpd)
    if parsed.path.lower().endswith(('.m3u8', '.mp4', '.mpd')) or '.m3u8' in url_target:
        sep = '&' if '|' in url_target else '|'
        ref = f"{parsed.scheme}://{parsed.netloc}/"
        return f"{url_target}{sep}User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(ref)}"

    # 7. Servidor PelisSeriesHoy
    if 'pelisserieshoy' in url_target:
        st = resolver_pelisserieshoy(url_target)
        if st:
            return st

    # 8. ResolveURL si está disponible
    if resolveurl and getattr(network._sondeo, 'deadline', None) is None:
        try:
            if resolveurl.relevant_resolvers(url_target):
                st = resolveurl.resolve(url_target)
                if st:
                    return st
        except Exception:
            pass

    # 9. Scraper directo con desempaquetado unpack_js
    try:
        html_src, _ = network.fetch_html(url_target, referer=f"{parsed.scheme}://{parsed.netloc}/")
        if html_src:
            lowered = html_src.lower()
            if any(message in lowered for message in ('video not found', 'file was deleted', 'file has been deleted')):
                raise network.ServidorNoDisponible('El servidor indica que el video fue eliminado o no existe.')
            m_pack = re.findall(r'eval\(function\((p,a,c,k,e,d|p,a,c,k,e,r)\)\{.*?return p\}\((.*?)\)\)', html_src, re.DOTALL)
            for _, raw_args in m_pack:
                try:
                    m_params = re.search(r"'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)", raw_args, re.DOTALL)
                    if m_params:
                        p_val, a_val, c_val, k_val = m_params.group(1), int(m_params.group(2)), int(m_params.group(3)), m_params.group(4).split('|')
                        unpacked = unpack_js(p_val, a_val, c_val, k_val)
                        m_m3u8 = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', unpacked)
                        if m_m3u8:
                            return f"{m_m3u8.group(1)}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(url_target)}"
                except Exception:
                    pass

            m_src = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', html_src)
            if m_src:
                return f"{m_src.group(1)}|User-Agent={urllib.parse.quote(network.UA)}&Referer={urllib.parse.quote(url_target)}"
    except network.ServidorNoDisponible:
        raise
    except Exception:
        pass

    return None


def verificar_clave_hls_keki(playlist_url, playlist, headers):
    """La variante no está disponible si su clave AES-128 no puede leerse."""
    if not (urllib.parse.urlsplit(playlist_url).hostname or '').endswith('.tnmr.org'):
        return
    key_tag = re.search(r'#EXT-X-KEY:[^\r\n]*METHOD=AES-128[^\r\n]*URI="([^"]+)"',
                        playlist, re.I)
    if not key_tag:
        return
    key_url = urllib.parse.urljoin(playlist_url, key_tag.group(1))
    key_request = urllib.request.Request(key_url, headers=headers)
    with network.abrir_url(key_request, timeout=4) as key_response:
        data = key_response.read(17)
        content_type = key_response.headers.get('Content-Type', '')
        if len(data) != 16 or str(content_type).lower().startswith('text/html') or data.lstrip().startswith(b'<'):
            raise network.ServidorNoDisponible('KeKi no entregó una clave HLS válida.')


def seleccionar_variante_optima(master_stream, conservar_master=False):
    """
    Si master_stream es un manifiesto multivariante (ej. master.m3u8 conteniendo 1080p, 720p, 480p),
    selecciona la variante de mayor resolucion disponible (1080p) y verifica que sus segmentos esten activos.
    Si el nodo de almacenamiento responde 502/error (servidor caido), descarta la variante y prueba la siguiente.
    Conserva cabeceras y pistas externas; adapta segmentos PNG+TS al proxy local.
    La reproduccion habitual conserva el master y todas sus resoluciones.
    """
    if not master_stream or not isinstance(master_stream, str):
        return master_stream

    url, _, options = master_stream.partition('|')
    if '.m3u8' not in url.lower():
        return master_stream

    headers = dict(urllib.parse.parse_qsl(options, keep_blank_values=True))
    if not any(k.lower() == 'user-agent' for k in headers):
        headers['User-Agent'] = network.UA

    try:
        req = urllib.request.Request(url, headers=headers)
        with network.abrir_url(req, timeout=5) as resp:
            content = resp.read().decode('utf-8', errors='replace')
            url = resp.geturl()

        if '#EXT-X-STREAM-INF' not in content:
            return master_stream

        master_quality = calidad_hls(content)
        CALIDADES_HLS[master_stream.split('|')[0]] = master_quality

        # A direct video playlist would lose external audio/subtitle renditions.
        if re.search(r'#EXT-X-MEDIA:[^\r\n]*URI=', content):
            return master_stream

        variants = []
        lines = content.splitlines()
        for idx, line in enumerate(lines):
            if line.startswith('#EXT-X-STREAM-INF:'):
                bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                bw = int(bw_match.group(1)) if bw_match else 0
                res_match = re.search(r'RESOLUTION=\d+x(\d+)', line)
                height = int(res_match.group(1)) if res_match else 0
                if idx + 1 < len(lines):
                    sub_uri = lines[idx + 1].strip()
                    if sub_uri and not sub_uri.startswith('#'):
                        full_sub_url = urllib.parse.urljoin(url, sub_uri)
                        variants.append((height, bw, full_sub_url))

        variants.sort(key=lambda x: (x[0], x[1]), reverse=True)

        for height, bw, v_url in variants:
            try:
                v_req = urllib.request.Request(v_url, headers=headers)
                with network.abrir_url(v_req, timeout=4) as v_resp:
                    v_content = v_resp.read().decode('utf-8', errors='replace')
                    v_url = v_resp.geturl()
                    if '#EXTINF' in v_content or '#EXT-X-TARGETDURATION' in v_content:
                        verificar_clave_hls_keki(v_url, v_content, headers)
                        segment = next((line.strip() for line in v_content.splitlines()
                                        if line.strip() and not line.startswith('#')), None)
                        if not segment:
                            continue
                        for map_uri in re.findall(r'#EXT-X-MAP:[^\n]*URI="([^"]+)"', v_content):
                            map_req = urllib.request.Request(
                                urllib.parse.urljoin(v_url, map_uri),
                                headers=dict(headers, Range='bytes=0-1023'))
                            with network.abrir_url(map_req, timeout=4) as map_response:
                                map_sample = map_response.read(1024)
                            if not map_sample or map_sample.lstrip().lower().startswith((b'<html', b'<!doctype')):
                                raise network.ServidorNoDisponible('EXT-X-MAP no entregó datos de vídeo')
                        segment_url = urllib.parse.urljoin(v_url, segment)
                        probe = urllib.request.Request(segment_url, headers=dict(headers, Range='bytes=0-1023'))
                        total_seg_size = 0
                        with network.abrir_url(probe, timeout=4) as response:
                            initial = response.read(1024)
                            if not initial or initial.lstrip().lower().startswith((b'<html', b'<!doctype')):
                                continue
                            try:
                                resp_headers = getattr(response, 'headers', None)
                                if resp_headers and hasattr(resp_headers, 'get'):
                                    cr_val = resp_headers.get('Content-Range', '')
                                    if isinstance(cr_val, str):
                                        m_cr = re.search(r'/(\d+)', cr_val)
                                        if m_cr:
                                            total_seg_size = int(m_cr.group(1))
                                    cl_val = resp_headers.get('Content-Length', '')
                                    if not total_seg_size and isinstance(cl_val, (str, int)):
                                        try:
                                            total_seg_size = int(cl_val)
                                        except (ValueError, TypeError):
                                            pass
                            except Exception:
                                total_seg_size = 0
                        if initial.startswith(b'\x89PNG\r\n\x1a\n'):
                            import hls_proxy
                            hls_proxy.unwrap_ts(initial)
                            local = hls_proxy.start(url if conservar_master else v_url, headers)
                            CALIDADES_HLS[local] = master_quality if conservar_master else ('{}p'.format(height) if height else '')
                            return local
                        if not conservar_master and total_seg_size > 8 * 1024 * 1024 and any(v[0] and v[0] < height for v in variants):
                            network.log_resolver(f"Variante {height}p descartada por tamano de segmento anomalo ({total_seg_size / (1024*1024):.1f} MB > 8 MB)")
                            continue
                        if conservar_master:
                            network.log_resolver('HLS: se conserva el manifiesto multirresolucion')
                            return master_stream
                        CALIDADES_HLS[v_url] = '{}p'.format(height) if height else ''
                        opt_part = f"|{urllib.parse.urlencode(headers)}" if headers else ""
                        network.log_resolver(f"Variante optima seleccionada: {height}p ({v_url[:60]}...)")
                        return v_url + opt_part
            except Exception as exc:
                network.log_resolver(f"Variante {height}p ({v_url[:45]}...) descartada por fallo en nodo: {exc}")
                continue

        network.log_resolver("Todas las variantes del manifiesto fallaron la verificacion de salud (nodo caido)")
        return None

    except Exception as exc:
        network.log_resolver(f"Error optimizando manifiesto HLS: {exc}")
        return master_stream


def resolver_stream(url_servidor):
    """
    Resuelve el enlace directo reproducible por Kodi.
    """
    if url_servidor.startswith('fxpplus://'):
        import fxpplus
        return fxpplus.resolve(url_servidor)
    pelisgo_source = url_servidor.startswith('vaquexsrc://pelisgo?')
    if url_servidor.startswith('vaquexsrc://'):
        import additional_sources
        url_servidor = additional_sources.resolve(url_servidor)
    if pelisgo_source and urllib.parse.urlsplit(url_servidor).hostname and \
            urllib.parse.urlsplit(url_servidor).hostname.endswith('.tnmr.org') and \
            urllib.parse.urlsplit(url_servidor).path.lower().endswith('.m3u8'):
        stream = network.url_con_cabeceras(url_servidor, additional_sources.pelisgo_media_headers())
        return seleccionar_variante_optima(stream, conservar_master=True)
    if url_servidor.startswith('jkanime://jkplayer?'):
        import anime
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(url_servidor).query)
        episode_url = params.get('episode', [''])[0]
        if not anime.is_anime_url(episode_url) or 'jkanime.net' not in (urllib.parse.urlsplit(episode_url).hostname or ''):
            return None
        page = anime._hacer_peticion(episode_url, referer=anime.JKANIME_BASE, use_jk_session=True)
        players = re.findall(r'''video\[\d+\]\s*=\s*['"]<iframe[^>]+src=['"]([^'"]+)''', page)
        for player_url in players:
            if 'jkanime.net/jkplayer/' not in player_url:
                continue
            player_html = anime._hacer_peticion(player_url, referer=episode_url)
            match = re.search(r'''['"](https?://[^'"]+\.m3u8[^'"]*)['"]''', player_html)
            if match:
                stream = procesar_hls_local(match.group(1), player_url)
                if stream:
                    return seleccionar_variante_optima(stream, conservar_master=True)
        return None
    if url_servidor.startswith('tubi://play?'):
        import servidores as tubi
        return resolver_tubi(url_servidor)
    if url_servidor.startswith('dorama://player?'):
        import doramas
        url_servidor = doramas.resolve(url_servidor)
    stream = resolver_enlace_directo(url_servidor)
    if stream:
        # El resolutor comprobó el manifiesto; el sondeo de servidores comprueba
        # el primer segmento. Evitar repetir aquí las solicitudes al CDN.
        if urllib.parse.urlsplit(url_servidor).hostname == 'iframe.andromedans.live':
            return stream
        return seleccionar_variante_optima(stream, conservar_master=True)
    return None


def resolver_tubi(url):
    import servidores as tubi
    if not tubi.tubi_is_available():
        raise network.ServidorNoDisponible('US_VPN: Tubi requiere una conexion VPN (US) activa para reproducirse.')
    params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    page_url = params.get('url', [''])[0]
    data = tubi.tubi_detail(page_url)
    if data.get('needs_login'):
        raise network.ServidorNoDisponible('US_VPN: este titulo requiere iniciar sesion en Tubi.')
    for resource in data.get('video_resources', []):
        if not str(resource.get('type', '')).startswith('hls') or resource.get('drm'):
            continue
        media = resource.get('manifest', {}).get('url', '')
        host = urllib.parse.urlsplit(media).hostname or ''
        if urllib.parse.urlsplit(media).scheme != 'https' or not host.endswith('.tubi.video'):
            continue
        stream = procesar_hls_local(media, tubi.tubi_BASE + '/', timeout=12)
        if stream:
            return stream
    raise network.ServidorNoDisponible('US_VPN: Tubi no entrego un HLS accesible. Comprueba la region/VPN o la disponibilidad del titulo.')


# Shared in-process Filemoon and Doodstream support.
_DOOD_HOSTS = ('doodstream.com', 'dood.to', 'dood.so', 'dood.watch', 'do7go.com', 'playmogo.com', 'dsvplay.com', 'ds2play.com', 'dooodster.com', 'doood.com')



_fm_py_P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
_fm_py_N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
_fm_py_G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
     0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)


def _fm_py_encode(b):
    return base64.urlsafe_b64encode(b).decode('ascii').rstrip('=')


def _fm_py_decode(s):
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))


def _fm_py_add(a, b):
    if a is None: return b
    if b is None: return a
    x, y = a; u, v = b
    if x == u and (y + v) % _fm_py_P == 0: return None
    slope = ((3*x*x-3) * pow(2*y, -1, _fm_py_P) if a == b else (v-y)*pow(u-x, -1, _fm_py_P)) % _fm_py_P
    w = (slope*slope-x-u) % _fm_py_P
    return w, (slope*(x-w)-y) % _fm_py_P


def _fm_py_multiply(k):
    result, point = None, _fm_py_G
    while k:
        if k & 1: result = _fm_py_add(result, point)
        point = _fm_py_add(point, point)
        k >>= 1
    return result


def _fm_py_sign(nonce):
    private = secrets.randbelow(_fm_py_N-1)+1
    public = _fm_py_multiply(private)
    digest = int.from_bytes(hashlib.sha256(nonce.encode('utf-8')).digest(), 'big')
    while True:
        k = secrets.randbelow(_fm_py_N-1)+1
        r = _fm_py_multiply(k)[0] % _fm_py_N
        s = pow(k, -1, _fm_py_N)*(digest+r*private) % _fm_py_N
        if r and s: break
    return {'signature': _fm_py_encode(r.to_bytes(32,'big')+s.to_bytes(32,'big')),
            'public_key': {'kty':'EC','crv':'P-256','x':_fm_py_encode(public[0].to_bytes(32,'big')),
                           'y':_fm_py_encode(public[1].to_bytes(32,'big'))}}


def _fm_py_gf_mul(x, y):
    z = 0
    for bit in range(127, -1, -1):
        if x >> bit & 1: z ^= y
        y = (y >> 1) ^ (0xe1000000000000000000000000000000 if y & 1 else 0)
    return z


def _fm_py_decrypt(envelope, aes_factory):
    parts = envelope['key_parts']
    version = int(envelope.get('version', 0))
    if 1 <= version <= 20 and max(version-1, 30-version) < len(parts):
        parts = [parts[version-1], parts[30-version]]
    key = b''.join(_fm_py_decode(x) for x in parts)
    iv, data = _fm_py_decode(envelope['iv']), _fm_py_decode(envelope['payload'])
    if len(key) not in (16,24,32) or len(iv) != 12 or len(data) < 16:
        raise ValueError('Invalid AES-GCM parameters')
    ciphertext, tag = data[:-16], data[-16:]
    aes = aes_factory(key)
    h = int.from_bytes(aes.encrypt_block(bytes(16)), 'big')
    accumulator = 0
    for i in range(0,len(ciphertext),16):
        block = ciphertext[i:i+16].ljust(16,b'\0')
        accumulator = _fm_py_gf_mul(accumulator ^ int.from_bytes(block,'big'), h)
    accumulator = _fm_py_gf_mul(accumulator ^ (len(ciphertext)*8), h)
    j0 = iv + b'\0\0\0\1'
    expected = (accumulator ^ int.from_bytes(aes.encrypt_block(j0),'big')).to_bytes(16,'big')
    if not hmac.compare_digest(expected,tag): raise ValueError('Invalid AES-GCM authentication tag')
    clear = aes.transform_ctr(ciphertext,int.from_bytes(j0,'big')+1)
    return json.loads(clear.decode('utf-8'))


def _fm_py_proof_word(text):
    # Scalar, inlined equivalent of the player's 32-bit mixing function.
    mask = 0xffffffff
    a,b,c,d = 1779033703,3144134277,1013904242,2773480762
    for ch in text.encode('utf-8'):
        a = (a+ch) & mask
        a = ((a << 7) | (a >> 25)) & mask
        a = (a+b) & mask
        d ^= a; d = ((d << 16) | (d >> 16)) & mask
        c = (c+d) & mask
        b ^= c; b = ((b << 12) | (b >> 20)) & mask
        a = (a+b) & mask
        d ^= a; d = ((d << 8) | (d >> 24)) & mask
        c = (c+d) & mask
        b ^= c; b = ((b << 7) | (b >> 25)) & mask
    for _ in range(8):
        a = (a+b) & mask
        d ^= a; d = ((d << 16) | (d >> 16)) & mask
        c = (c+d) & mask
        b ^= c; b = ((b << 12) | (b >> 20)) & mask
        a = (a+b) & mask
        d ^= a; d = ((d << 8) | (d >> 24)) & mask
        c = (c+d) & mask
        b ^= c; b = ((b << 7) | (b >> 25)) & mask
    mem = [0]*512
    for i in range(512):
        a = (a+b) & mask
        d ^= a; d = ((d << 16) | (d >> 16)) & mask
        c = (c+d) & mask
        b ^= c; b = ((b << 12) | (b >> 20)) & mask
        a = (a+b) & mask
        d ^= a; d = ((d << 8) | (d >> 24)) & mask
        c = (c+d) & mask
        b ^= c; b = ((b << 7) | (b >> 25)) & mask
        mem[i] = a ^ c
    for _ in range(2):
        for i in range(512):
            v = (mem[i]+mem[mem[i] & 511]) & mask
            v = (((v << 13) | (v >> 19)) ^ (mem[(i+1) & 511]*2654435761)) & mask
            mem[i] = v
            a ^= v
            a = (a+b) & mask
            d ^= a; d = ((d << 16) | (d >> 16)) & mask
            c = (c+d) & mask
            b ^= c; b = ((b << 12) | (b >> 20)) & mask
            a = (a+b) & mask
            d ^= a; d = ((d << 8) | (d >> 24)) & mask
            c = (c+d) & mask
            b ^= c; b = ((b << 7) | (b >> 25)) & mask
    a = (a+b) & mask
    d ^= a; d = ((d << 16) | (d >> 16)) & mask
    c = (c+d) & mask
    b ^= c; b = ((b << 12) | (b >> 20)) & mask
    a = (a+b) & mask
    d ^= a; d = ((d << 8) | (d >> 24)) & mask
    c = (c+d) & mask
    b ^= c; b = ((b << 7) | (b >> 25)) & mask
    n = a
    for v in mem[:64]:
        n = (n+v) & mask
        n = (((n << 5) | (n >> 27)) ^ (v*2246822519)) & mask
    return n ^ c




_fm_native_lock = threading.Lock()
_fm_native_library = None


def _fm_native_target():
    machine = (os.environ.get('PROCESSOR_ARCHITECTURE', '') if sys.platform == 'win32'
               else os.uname().machine if hasattr(os, 'uname') else '').lower()
    bits = ctypes.sizeof(ctypes.c_void_p)*8
    android = bool(os.environ.get('KODI_ANDROID_APK') or os.environ.get('ANDROID_ROOT'))
    if sys.platform == 'win32':
        if machine in ('arm64', 'aarch64'):
            return None
        return 'windows-x86_64' if bits == 64 else 'windows-x86'
    if not sys.platform.startswith('linux') and not android:
        return None
    prefix = 'android' if android else 'linux'
    if machine in ('aarch64', 'arm64') or machine.startswith('arm'):
        arch = 'aarch64' if bits == 64 else 'armv7'
    elif machine in ('x86_64', 'amd64', 'i686', 'i386'):
        arch = 'x86_64' if bits == 64 else 'x86'
    else:
        return None
    return prefix + '-' + arch


def _fm_native_load():
    global _fm_native_library
    with _fm_native_lock:
        if _fm_native_library is not None:
            return _fm_native_library
        name = _fm_native_target()
        if not name:
            raise OSError('Arquitectura sin acelerador Filemoon')
        filename = 'filemoon_pow.dll' if name.startswith('windows') else 'libfilemoon_pow.so'
        source = os.path.join(os.path.dirname(__file__), 'native', name, filename)
        if name.startswith('android'):
            # Kodi exports its private cache/lib directory for binary addons.
            root = os.environ.get('KODI_BINADDON_PATH')
            if not root or not os.path.isabs(root):
                raise OSError('Kodi no publica el directorio interno de bibliotecas')
            with open(source, 'rb') as handle:
                digest = hashlib.sha256(handle.read()).hexdigest()
            folder = os.path.join(root, 'vaquexflix', name, digest)
            os.makedirs(folder, exist_ok=True)
            destination = os.path.join(folder, filename)
            if not os.path.exists(destination):
                temporary = destination + '.%s.tmp' % os.getpid()
                shutil.copyfile(source, temporary)
                os.chmod(temporary, 0o500)
                os.replace(temporary, destination)
            source = destination
        lib = ctypes.CDLL(source)
        lib.fm_word.argtypes = [ctypes.c_char_p, ctypes.c_uint32]
        lib.fm_word.restype = ctypes.c_uint32
        lib.fm_batch.argtypes = [ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint32,
                                ctypes.c_uint32, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
        lib.fm_batch.restype = ctypes.c_int
        # Refuse a wrong or stale binary before using it to solve a challenge.
        if lib.fm_word(b'a:0', 3) != _fm_py_proof_word('a:0'):
            raise OSError('Acelerador Filemoon incompatible')
        _fm_native_library = lib
        return lib


def _fm_native_batch(lib, nonce, difficulty, start, count=128):
    result = ctypes.c_uint32()
    status = lib.fm_batch(nonce, len(nonce), difficulty, start, count, ctypes.byref(result))
    if status < 0:
        raise ValueError('Parametros Filemoon no validos')
    return str(result.value) if status == 1 else None





def _dood_configure(opener):
    from sessions import configure
    return configure(opener, 'dood', _DOOD_HOSTS)


_mega_lock = threading.RLock()
_mega_server = None
_mega_resources = {}


def _mega_aes():
    try:
        from Cryptodome.Cipher import AES
        return AES
    except (ImportError, OSError) as exc:
        raise network.ServidorNoDisponible('Mega necesita la biblioteca Python Crypto Library de Kodi.') from exc


def _mega_link(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.hostname not in ('mega.nz', 'www.mega.nz', 'mega.co.nz', 'www.mega.co.nz'):
        raise network.ServidorNoDisponible('Dominio Mega no valido.')
    match = re.fullmatch(r'/(?:embed|file)/([\w-]{8})/?', parsed.path)
    if match:
        node, encoded = match[1], parsed.fragment
    else:
        # TioAnime usa el formato antiguo dentro de /embed/.
        legacy = re.fullmatch(r'!([\w-]{8})!([\w-]{43})', parsed.fragment)
        if not legacy:
            legacy = re.fullmatch(r'/(?:embed|file)/!([\w-]{8})!([\w-]{43})/?', parsed.path)
        if not legacy:
            raise network.ServidorNoDisponible('Mega: usa un enlace de archivo con su clave, no una carpeta.')
        node, encoded = legacy.groups()
    if not re.fullmatch(r'[\w-]{43}', encoded):
        raise network.ServidorNoDisponible('Mega: falta la clave del archivo o tiene formato incorrecto.')
    import struct
    words = struct.unpack('>8I', base64.urlsafe_b64decode(encoded + '='))
    key = struct.pack('>4I', *(words[i] ^ words[i + 4] for i in range(4)))
    nonce = struct.pack('>2I', *words[4:6])
    return node, key, nonce


def _mega_file(url):
    node, key, nonce = _mega_link(url)
    AES = _mega_aes()
    request = urllib.request.Request('https://g.api.mega.co.nz/cs?id=' + str(int(time.time() * 1000)),
        data=json.dumps([{'a': 'g', 'g': 1, 'p': node, 'ssl': 1}]).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'User-Agent': network.UA})
    with network.nueva_sesion().open(request, timeout=15) as response:
        result = json.loads(response.read(1024 * 1024))
    result = result[0] if isinstance(result, list) and len(result) == 1 else result
    if isinstance(result, int):
        errors = {-16: 'archivo bloqueado por Mega', -9: 'archivo eliminado o inexistente',
                  -17: 'cuota de transferencia agotada', -18: 'archivo temporalmente no disponible',
                  -3: 'servicio ocupado; vuelve a intentarlo mas tarde'}
        raise network.ServidorNoDisponible('Mega: ' + errors.get(result, 'error del servicio (%s)' % result) + '.')
    if not isinstance(result, dict) or not isinstance(result.get('g'), str):
        raise network.ServidorNoDisponible('Mega no devolvio una descarga de archivo compatible.')
    target = urllib.parse.urlsplit(result['g'])
    host = target.hostname or ''
    if target.scheme != 'https' or not host.endswith(('.mega.co.nz', '.mega.nz')) or target.username:
        raise network.ServidorNoDisponible('Mega devolvio un servidor de descarga no reconocido.')
    size = result.get('s')
    if not isinstance(size, int) or size <= 0:
        raise network.ServidorNoDisponible('Mega: tamano de archivo no valido.')
    try:
        encoded = result['at']
        attributes = AES.new(key, AES.MODE_CBC, bytes(16)).decrypt(
            base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4))).rstrip(b'\0')
        if not attributes.startswith(b'MEGA{'):
            raise ValueError('Invalid key')
        name = json.loads(attributes[4:].decode('utf-8'))['n']
    except (KeyError, ValueError, TypeError) as exc:
        raise network.ServidorNoDisponible('Mega: la clave no permite descifrar este archivo.') from exc
    extension = os.path.splitext(name)[1].lower()
    if extension not in ('.mp4', '.mkv', '.webm', '.avi', '.mov', '.m4v', '.ts'):
        raise network.ServidorNoDisponible('Mega: el enlace no corresponde a un archivo de video compatible.')
    return {'url': result['g'], 'size': size, 'key': key, 'nonce': nonce,
            'extension': extension, 'used': time.monotonic()}


def _mega_range(value, size):
    if not value:
        return 0, size - 1, False
    match = re.fullmatch(r'bytes=(\d*)-(\d*)', value.strip())
    if not match or not any(match.groups()):
        raise ValueError('Invalid range')
    left, right = match.groups()
    if not left:
        count = int(right)
        if count <= 0:
            raise ValueError('Invalid suffix')
        return max(0, size - count), size - 1, True
    start, end = int(left), min(int(right), size - 1) if right else size - 1
    if start >= size or start > end:
        raise ValueError('Unsatisfiable range')
    return start, end, True


def _mega_open_range(resource, start, end):
    # MEGA's storage API accepts inclusive byte offsets in the URL path.
    aligned = start - start % 16
    request = urllib.request.Request(resource['url'] + '/%d-%d' % (aligned, end),
                                     headers={'User-Agent': network.UA})
    try:
        response = network.nueva_sesion().open(request, timeout=15)
    except urllib.error.HTTPError as exc:
        if exc.code == 509:
            raise network.ServidorNoDisponible('Mega: cuota de transferencia agotada. Intenta mas tarde.') from exc
        raise network.ServidorNoDisponible('Mega: el servidor de descarga rechazo la peticion (HTTP %s).' % exc.code) from exc
    length = response.headers.get('Content-Length')
    if response.status != 200 or (length and int(length) != end - aligned + 1):
        response.close()
        raise network.ServidorNoDisponible('Mega no entrego el intervalo solicitado.')
    AES = _mega_aes()
    cipher = AES.new(resource['key'], AES.MODE_CTR, nonce=resource['nonce'], initial_value=aligned // 16)
    return response, cipher, start - aligned


def _mega_start_server():
    global _mega_server
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def log_message(self, *args):
            pass  # Never log local capability tokens or upstream signed URLs.

        def do_HEAD(self):
            self.serve(head=True)

        def do_GET(self):
            self.serve(head=False)

        def serve(self, head):
            self.connection.settimeout(5)
            # Do not reuse a streaming connection for Kodi's subsequent Stat/HEAD.
            self.close_connection = True
            with _mega_lock:
                resource = _mega_resources.get(self.path)
                if resource:
                    resource['used'] = time.monotonic()
            if resource is None:
                self.send_error(404)
                return
            size = resource['size']
            try:
                start, end, partial = _mega_range(self.headers.get('Range'), size)
            except ValueError:
                self.send_response(416)
                self.send_header('Content-Range', 'bytes */%d' % size)
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            upstream = None
            sent_headers = False
            try:
                if not head:
                    block_end = min(end, start + 4 * 1024 * 1024 - 1)
                    upstream, cipher, skip = _mega_open_range(resource, start, block_end)
                self.send_response(206 if partial else 200)
                self.send_header('Content-Type', 'video/mp4' if resource['extension'] in ('.mp4', '.m4v', '.mov') else 'application/octet-stream')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Connection', 'close')
                if partial:
                    self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
                self.end_headers()
                sent_headers = True
                if not head:
                    position = start
                    while position <= end:
                        remaining = block_end - position + 1
                        while remaining:
                            data = upstream.read(min(256 * 1024, remaining + skip))
                            if not data:
                                raise OSError('Incomplete Mega block')
                            plain = cipher.decrypt(data)[skip:]
                            skip = 0
                            self.wfile.write(plain)
                            remaining -= len(plain)
                            position += len(plain)
                        upstream.close()
                        upstream = None
                        if position <= end:
                            block_end = min(end, position + 4 * 1024 * 1024 - 1)
                            upstream, cipher, skip = _mega_open_range(resource, position, block_end)
            except (OSError, ValueError, network.ServidorNoDisponible):
                if not sent_headers:
                    try:
                        self.send_error(502, 'Mega transfer unavailable')
                    except OSError:
                        pass
                self.close_connection = True
            finally:
                if upstream:
                    upstream.close()

    with _mega_lock:
        if _mega_server is None:
            _mega_server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
            _mega_server.daemon_threads = True
            threading.Thread(target=_mega_server.serve_forever, name='VaquexflixMega', daemon=True).start()
        return _mega_server.server_address[1]


def cerrar_streams_locales():
    import hls_proxy
    hls_proxy.close()
    global _mega_server
    with _mega_lock:
        server, _mega_server = _mega_server, None
        _mega_resources.clear()
    if server:
        server.shutdown()
        server.server_close()


def resolver_mega(url):
    resource = _mega_file(url)
    # Validate the decryption before handing a URL to Kodi or its metadata scan.
    response, cipher, skip = _mega_open_range(resource, 0, min(1023, resource['size'] - 1))
    try:
        first = cipher.decrypt(response.read(1024))
    finally:
        response.close()
    if not (first[4:8] == b'ftyp' or first.startswith(b'\x1a\x45\xdf\xa3') or
            first.startswith(b'RIFF') or first.startswith(b'\x47')):
        raise network.ServidorNoDisponible('Mega: el archivo descifrado no tiene una cabecera de video reconocida.')
    network.tiempo_peticion(1)
    port = _mega_start_server()
    path = '/' + secrets.token_urlsafe(24) + resource['extension']
    with _mega_lock:
        for old in [p for p, r in _mega_resources.items() if time.monotonic() - r['used'] > 6 * 3600]:
            del _mega_resources[old]
        if len(_mega_resources) >= 64:
            del _mega_resources[min(_mega_resources, key=lambda p: _mega_resources[p]['used'])]
        _mega_resources[path] = resource
    return 'http://127.0.0.1:%d%s' % (port, path)


# Enlaces cifrados de MegaDedeOficial
def _aes_decrypt(key, iv, ciphertext):
    try:
        from Cryptodome.Cipher import AES
    except ImportError:
        try:
            from Crypto.Cipher import AES
        except ImportError:
            try:
                from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
            except ImportError as exc:
                raise network.ServidorNoDisponible('MegaDede requiere PyCryptodome para descifrar sus enlaces.') from exc
            decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
            return decryptor.update(ciphertext) + decryptor.finalize()
    return AES.new(key, AES.MODE_CBC, iv).decrypt(ciphertext)


def resolver_megadedeoficial(url):
    from servidores import _MEGA_HOSTS, _get
    parsed = urlsplit(url)
    if parsed.scheme != 'vaquexsrc' or parsed.netloc != 'megadedeoficial':
        raise network.ServidorNoDisponible('MegaDede: enlace interno inválido.')
    params = urllib.parse.parse_qs(parsed.query)
    wrapper = params.get('wrapper', [''])[0]
    referer = params.get('referer', [''])[0]
    group_text = params.get('group', [''])[0]
    index_text = params.get('index', [''])[0]
    server_name = params.get('server', [''])[0]
    language_code = params.get('language', [''])[0]
    if urlsplit(wrapper).hostname not in _MEGA_HOSTS or \
            not urlsplit(wrapper).path.startswith('/vidurl/') or \
            urlsplit(referer).hostname not in _MEGA_HOSTS or \
            not group_text.isdigit() or not index_text.isdigit():
        raise network.ServidorNoDisponible('MegaDede: servidor inválido.')
    page = _get(wrapper, referer)
    challenge = re.search(r'\bPOW_CHALLENGE\s*=\s*["\']([^"\']+)', page)
    difficulty = re.search(r'\bPOW_DIFFICULTY\s*=\s*(\d+)', page)
    salt = re.search(r'\bPOW_SALT\s*=\s*["\']([^"\']+)', page)
    data = re.search(r'\bdataLink\s*=\s*(\[[\s\S]*?\]);', page)
    if not all((challenge, difficulty, salt, data)):
        raise network.ServidorNoDisponible('MegaDede no entregó el desafío o el enlace.')
    level = int(difficulty.group(1))
    if level > 5:
        raise network.ServidorNoDisponible('MegaDede exige una prueba de trabajo demasiado costosa.')
    try:
        groups = json.loads(data.group(1))
        group = groups[int(group_text)]
        embed = group['sortedEmbeds'][int(index_text)]
        encoded = embed['link']
        if embed.get('type') != 'video' or (server_name and embed.get('servername') != server_name) or \
                (language_code and group.get('video_language') != language_code):
            raise ValueError('no es video')
    except (ValueError, TypeError, KeyError, IndexError) as exc:
        raise network.ServidorNoDisponible('MegaDede ya no publicó ese servidor.') from exc
    nonce = None
    started = time.monotonic()
    prefix = '0' * level
    for candidate in range(1000000):
        if candidate % 1000 == 0:
            network.tiempo_peticion(1)
            if time.monotonic() - started > 5:
                break
        if hashlib.sha256((challenge.group(1) + str(candidate)).encode()).hexdigest().startswith(prefix):
            nonce = candidate
            break
    if nonce is None:
        raise network.ServidorNoDisponible('MegaDede no permitió completar la prueba de trabajo.')
    key = hashlib.sha256((challenge.group(1) + str(nonce) + salt.group(1)).encode()).digest()
    try:
        raw = base64.b64decode(encoded, validate=True)
        plain = _aes_decrypt(key, raw[:16], raw[16:])
        padding = plain[-1]
        if not 1 <= padding <= 16 or plain[-padding:] != bytes([padding]) * padding:
            raise ValueError('padding inválido')
        target = plain[:-padding].decode('utf-8')
    except (ValueError, TypeError, UnicodeDecodeError, IndexError, binascii.Error) as exc:
        raise network.ServidorNoDisponible('MegaDede no permitió descifrar este servidor.') from exc
    if urlsplit(target).scheme not in ('http', 'https') or not urlsplit(target).hostname:
        raise network.ServidorNoDisponible('MegaDede entregó un enlace de vídeo inválido.')
    return target
