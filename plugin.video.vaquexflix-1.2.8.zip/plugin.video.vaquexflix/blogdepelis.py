"""Proveedor y scraper para BlogdePelis (blogdepelis.net).

Permite listar catalogos (Peliculas, Estrenos, Tendencias, Series), buscar
titulos, extraer servidores y episodios de series, y resolver enlaces a
traves de paulinito.com / JWPlayer / Spark HLS y otros servidores embebidos.
"""
import html
import json
import re
import urllib.error
import urllib.parse
import urllib.request

import network
import resolvers

BASE_URL = 'https://blogdepelis.net'
DEFAULT_TIMEOUT = 12

# Mapeo de generos y colecciones de Vaquexflix a la taxonomia real de BlogdePelis
BDP_GENRE_MAP = {
    'accion': 'category/accion',
    'action-adventure': 'category/accion',
    'animacion': 'category/animacion',
    'cartoons': 'category/animacion',
    'anime': 'category/anime',
    'aventura': 'category/aventura',
    'belica': 'category/guerra',
    'war-politics': 'category/guerra',
    'ciencia-ficcion': 'category/ciencia-ficcion',
    'sci-fi-fantasy': 'category/ciencia-ficcion',
    'comedia': 'category/comedia',
    'documental': 'category/documental',
    'drama': 'category/drama',
    'fantasia': 'category/fantasia',
    'misterio': 'category/misterio-2',
    'misterio-2': 'category/misterio-2',
    'musica': 'category/musica',
    'musical': 'category/musical',
    'romance': 'category/romance',
    'suspense': 'category/suspenso',
    'suspenso': 'category/suspenso',
    'thriller': 'category/thriller',
    'terror': 'category/terror',
    'horror': 'category/horror',
    'western': 'category/western',
    'cortos': 'category/corto',
    'corto': 'category/corto',
    'k-drama': 'category/k-drama',
    'deporte': 'category/deporte',
    'superheroes': 'category/superheroes',
    'navidad': 'category/navidad',
    'pixar': 'category/pixar',
    'disney-channel': 'category/disney-channel',
    'disney-nature': 'category/disney-nature',
    # Colecciones de peliculas y series
    'populares': '?bdp_catalog=trending',
    'tendencias': '?bdp_catalog=trending',
    'lista-populares': '?bdp_catalog=trending',
    'lista-tendencias': '?bdp_catalog=trending',
    'recien-estrenadas': '?bdp_catalog=premieres',
    'lista-recien-estrenadas': '?bdp_catalog=premieres',
    'mejor-valoradas': '?bdp_catalog=movies',
    'lista-mejor-valoradas': '?bdp_catalog=movies',
    'retro': '?bdp_catalog=movies',
    'lista-retro': '?bdp_catalog=movies',
    'en-emision': 'category/series',
    'lista-en-emision': 'category/series',
}


def _headers(referer=None):
    h = {
        'User-Agent': network.UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
    }
    if referer:
        h['Referer'] = referer
    return h


def _peticion(url, referer=None, timeout=DEFAULT_TIMEOUT, opener=None, allow_404=False):
    """Realiza una peticion HTTP GET segura devolviendo el texto HTML."""
    opener = opener or network.nueva_sesion()
    req = urllib.request.Request(url, headers=_headers(referer))
    try:
        with opener.open(req, timeout=timeout) as resp:
            data = resp.read(1024 * 1024)
            return data.decode('utf-8', errors='replace')
    except urllib.error.HTTPError as exc:
        if exc.code == 404 and allow_404:
            return ""
        raise network.ServidorNoDisponible(f'BlogdePelis: error HTTP {exc.code}') from exc
    except (TimeoutError, urllib.error.URLError) as exc:
        raise network.ServidorNoDisponible('BlogdePelis: tiempo de espera agotado') from exc


def _parsear_tarjeta(html_tarjeta):
    """Extrae la informacion de una tarjeta bdp-card."""
    # 1. Intentar primero via data-bdp-media (JSON estructurado completo)
    m_json = re.search(r'data-bdp-media=["\']([^"\']+)["\']', html_tarjeta)
    if m_json:
        try:
            raw_json = html.unescape(m_json.group(1))
            media = json.loads(raw_json)
            if isinstance(media, dict) and media.get('url'):
                raw_type = str(media.get('type') or '').lower()
                raw_url = str(media.get('url') or '').lower()
                item_type = 'tvshow' if raw_type in ('tv', 'series') or 'temporada' in raw_url else 'movie'
                return {
                    'id': str(media.get('id') or ''),
                    'title': html.unescape(media.get('title') or '').strip(),
                    'url': media.get('url', '').strip(),
                    'poster': media.get('poster') or '',
                    'image': media.get('image') or '',
                    'year': str(media.get('year') or '').strip(),
                    'type': item_type,
                }
        except Exception:
            pass

    # 2. Fallback por DOM regex
    m_link = re.search(r'<a\s+[^>]*href=["\'](https://blogdepelis\.net/[^"\']+\.html)["\']([^>]*)>', html_tarjeta)
    if not m_link:
        return None
    url = m_link.group(1).strip()
    attrs = m_link.group(2)
    m_label = re.search(r'aria-label=["\']([^"\']+)["\']', attrs)
    m_title = re.search(r'<h3>(.*?)</h3>', html_tarjeta)
    title = html.unescape(m_label.group(1) if m_label else (m_title.group(1) if m_title else '')).strip()

    m_img = re.search(r'background-image:url\(["\']?([^"\'\)]+)["\']?\)', html_tarjeta)
    poster = m_img.group(1).strip() if m_img else ''

    m_year = re.search(r'<span>((?:19|20)\d{2})</span>', html_tarjeta)
    year = m_year.group(1) if m_year else ''

    item_type = 'tvshow' if 'temporada' in url.lower() or 'series' in url.lower() else 'movie'
    return {
        'id': url.rstrip('/').rsplit('/', 1)[-1].replace('.html', ''),
        'title': title,
        'url': url,
        'poster': poster,
        'image': poster,
        'year': year,
        'type': item_type,
    }


def _card(item):
    """Normaliza un item al formato de tarjeta de catalogo de Vaquexflix."""
    is_serie = item['type'] == 'tvshow'
    title = item['title']
    return {
        'title': title,
        'original_title': title,
        'url': item['url'],
        'source': 'blogdepelis',
        'section': 'series' if is_serie else 'peliculas',
        'is_serie': is_serie,
        'year': item.get('year') or '',
        'cover': item.get('poster') or '',
        'fanart': item.get('image') or item.get('poster') or '',
        'plot': '',
        'rating': 0,
    }


def owns(url):
    """Comprueba si una URL corresponde a BlogdePelis."""
    u = str(url or '').lower()
    return 'blogdepelis.net' in u or u.startswith('blogdepelis://')


def buscar(query, timeout=DEFAULT_TIMEOUT, opener=None):
    """Busca peliculas o series en BlogdePelis por texto."""
    q = str(query or '').strip()
    if not q:
        return []
    url = f"{BASE_URL}/?s={urllib.parse.quote_plus(q)}"
    html_doc = _peticion(url, timeout=timeout, opener=opener, allow_404=True)
    if not html_doc:
        return []
    cards = re.findall(r'<article[^>]*class=["\'][^"\']*bdp-card[^"\']*["\'][^>]*>.*?</article>', html_doc, re.DOTALL)
    if not cards:
        cards = re.findall(r'<article[^>]*>.*?</article>', html_doc, re.DOTALL)
    results = []
    vistos = set()
    for c in cards:
        item = _parsear_tarjeta(c)
        if item and item['url'] not in vistos:
            vistos.add(item['url'])
            results.append(item)
    return results


def search(query, section='all'):
    """Busqueda compatible con catalog.py de Vaquexflix."""
    items = buscar(query)
    out = []
    for it in items:
        card = _card(it)
        if section == 'all' or card['section'] == section:
            out.append(card)
    return out


def _resolver_url_catalogo(section, page, genre=None):
    """Resuelve la URL exacta para la seccion, pagina y genero de BlogdePelis."""
    page = max(1, int(page or 1))
    if not genre:
        if section == 'series':
            return f"{BASE_URL}/category/series/page/{page}/" if page > 1 else f"{BASE_URL}/category/series/"
        return f"{BASE_URL}/?bdp_catalog=movies&catalog_page={page}"

    clean_g = str(genre).lower().strip().replace(' ', '-')
    target = BDP_GENRE_MAP.get(clean_g)
    if not target:
        # Genero sin correspondencia en BlogdePelis (ej. crimen, familia, historia, etc.)
        return None

    if target.startswith('?'):
        return f"{BASE_URL}/{target}&catalog_page={page}"
    return f"{BASE_URL}/{target}/page/{page}/" if page > 1 else f"{BASE_URL}/{target}/"


def obtener_catalogo(catalog_type='movies', page=1, timeout=DEFAULT_TIMEOUT, opener=None):
    """Lista un catalogo paginado de BlogdePelis.
    
    catalog_type: 'movies', 'premieres', 'trending', 'series', o categoria especifica.
    Retorna tupla: (items, total_paginas)
    """
    page = max(1, int(page or 1))
    if catalog_type in ('movies', 'premieres', 'trending'):
        url = f"{BASE_URL}/?bdp_catalog={catalog_type}&catalog_page={page}"
    elif catalog_type == 'series':
        url = f"{BASE_URL}/category/series/page/{page}/" if page > 1 else f"{BASE_URL}/category/series/"
    elif catalog_type.startswith('category/'):
        url = f"{BASE_URL}/{catalog_type}/page/{page}/" if page > 1 else f"{BASE_URL}/{catalog_type}/"
    else:
        url = f"{BASE_URL}/category/{catalog_type}/page/{page}/" if page > 1 else f"{BASE_URL}/category/{catalog_type}/"

    html_doc = _peticion(url, timeout=timeout, opener=opener, allow_404=True)
    if not html_doc:
        return [], 1

    # Extraer total de paginas
    page_nums = [int(p) for p in re.findall(r'(?:catalog_page=|/page/)(\d+)', html_doc)]
    total_pages = max(page_nums) if page_nums else 1

    cards = re.findall(r'<article[^>]*class=["\'][^"\']*bdp-card[^"\']*["\'][^>]*>.*?</article>', html_doc, re.DOTALL)
    if not cards:
        cards = re.findall(r'<article[^>]*>.*?</article>', html_doc, re.DOTALL)

    items = []
    vistos = set()
    for c in cards:
        item = _parsear_tarjeta(c)
        if item and item['url'] not in vistos:
            vistos.add(item['url'])
            items.append(item)
    return items, total_pages


def page(section, number, genre=None, preview=False):
    """Paginacion de catalogo compatible con catalog.py de Vaquexflix.
    
    Garantiza el filtrado estricto por seccion (peliculas vs series) para que
    peliculas individuales como 'Allen' no aparezcan clasificadas como series.
    """
    if section not in ('peliculas', 'series'):
        return [], False

    page_num = max(1, int(number or 1))
    target_url = _resolver_url_catalogo(section, page_num, genre)
    if not target_url:
        return [], False

    html_doc = _peticion(target_url, referer=BASE_URL, allow_404=True)
    if not html_doc:
        return [], False

    # Extraer total de paginas
    page_nums = [int(p) for p in re.findall(r'(?:catalog_page=|/page/)(\d+)', html_doc)]
    total_pages = max(page_nums) if page_nums else 1

    cards = re.findall(r'<article[^>]*class=["\'][^"\']*bdp-card[^"\']*["\'][^>]*>.*?</article>', html_doc, re.DOTALL)
    if not cards:
        cards = re.findall(r'<article[^>]*>.*?</article>', html_doc, re.DOTALL)

    items = []
    vistos = set()
    for c in cards:
        it = _parsear_tarjeta(c)
        if not it or it['url'] in vistos:
            continue
        # FILTRADO ESTRICTO DE SECCION:
        # En la seccion de peliculas solo se admiten peliculas (excluye series)
        # En la seccion de series solo se admiten series (excluye peliculas como Allen)
        is_serie = (it['type'] == 'tvshow')
        if section == 'peliculas' and is_serie:
            continue
        if section == 'series' and not is_serie:
            continue
        vistos.add(it['url'])
        items.append(_card(it))

    has_more = page_num < total_pages
    return items, has_more


def obtener_servidores(page_url, timeout=DEFAULT_TIMEOUT, opener=None):
    """Extrae los servidores de reproduccion disponibles para una pagina de pelicula o capitulo."""
    html_doc = _peticion(page_url, referer=BASE_URL, timeout=timeout, opener=opener)
    servidores = []
    vistos = set()

    # 1. Buscar iframe principal dentro de theater__screen
    m_iframes = re.findall(r'<div class="theater__screen"[^>]*>\s*<iframe[^>]+src=["\']([^"\']+)["\']', html_doc, re.I)
    if not m_iframes:
        m_iframes = re.findall(r'<iframe[^>]+src=["\'](https?://[^"\']+)["\']', html_doc, re.I)

    for ifr in m_iframes:
        ifr = html.unescape(ifr).strip()
        if ifr and ifr not in vistos and not any(ad in ifr for ad in ['google', 'ads', 'wpadmngr', 'adsterra']):
            vistos.add(ifr)
            host = urllib.parse.urlsplit(ifr).hostname or 'Servidor'
            nombre = f"BlogdePelis - {host} (1080p)" if 'paulinito' in host else f"BlogdePelis - {host}"
            servidores.append({
                'nombre': nombre,
                'url': ifr,
                'source': 'blogdepelis',
                'idioma': 'Español',
                'calidad': '1080p' if 'paulinito' in host else 'HD',
                'tipo': 'embed',
            })

    # 2. Buscar botones con data-iframe (utilizado en series o multiples servidores)
    buttons = re.findall(r'<button[^>]+class=["\'][^"\']*server-button[^"\']*["\'][^>]*data-iframe=["\']([^"\']+)["\'][^>]*>(.*?)</button>', html_doc, re.DOTALL | re.I)
    for data_ifr, label in buttons:
        unescaped = html.unescape(data_ifr)
        m_src = re.search(r'src=["\']([^"\']+)["\']', unescaped)
        if m_src:
            src = m_src.group(1).strip()
            if src and src not in vistos and not any(ad in src for ad in ['google', 'ads', 'wpadmngr']):
                vistos.add(src)
                lbl = html.unescape(label).strip() or 'Servidor'
                host = urllib.parse.urlsplit(src).hostname or ''
                servidores.append({
                    'nombre': f"BlogdePelis - {lbl} ({host})",
                    'url': src,
                    'source': 'blogdepelis',
                    'idioma': 'Español',
                    'calidad': 'HD',
                    'tipo': 'embed',
                })

    return servidores


def servers(item, series=None):
    """Devuelve servidores de reproduccion para un elemento (compatible con catalog.py)."""
    target_url = item.get('url') or (series and series.get('url')) or ''
    if 'videoembed' in target_url or 'voe.sx' in target_url or 'paulinito.com' in target_url:
        host = urllib.parse.urlsplit(target_url).hostname or 'Servidor'
        return [{
            'nombre': f"BlogdePelis - {host}",
            'url': target_url,
            'source': 'blogdepelis',
            'idioma': 'Español',
            'calidad': 'HD',
            'tipo': 'embed',
        }]
    page_url = item.get('page_url') or target_url
    if not page_url or not page_url.startswith('http'):
        return []
    return obtener_servidores(page_url)


def obtener_episodios(page_url, timeout=DEFAULT_TIMEOUT, opener=None):
    """Extrae la lista estructurada de episodios para una serie."""
    html_doc = _peticion(page_url, referer=BASE_URL, timeout=timeout, opener=opener)
    episodios = []
    buttons = re.findall(r'<button[^>]+class=["\'][^"\']*server-button[^"\']*["\'][^>]*data-iframe=["\']([^"\']+)["\'][^>]*>(.*?)</button>', html_doc, re.DOTALL | re.I)
    for data_ifr, label in buttons:
        lbl = html.unescape(label).strip()
        m_ep = re.match(r'T(\d+)X(\d+)', lbl, re.I)
        if not m_ep:
            continue
        temp = int(m_ep.group(1))
        num = int(m_ep.group(2))
        unescaped = html.unescape(data_ifr)
        m_src = re.search(r'src=["\']([^"\']+)["\']', unescaped)
        iframe_url = m_src.group(1).strip() if m_src else ''
        if iframe_url:
            episodios.append({
                'temporada': temp,
                'episodio': num,
                'label': lbl,
                'iframe': iframe_url,
                'url_pagina': page_url,
                'servidores': [{
                    'nombre': f'BlogdePelis - {lbl}',
                    'url': iframe_url,
                    'source': 'blogdepelis',
                    'idioma': 'Español',
                    'calidad': 'HD',
                }]
            })
    return episodios


def episodes(series):
    """Devuelve diccionario {str(season): [episodes...]} compatible con catalog.py."""
    url = series.get('url') or ''
    if not url.startswith('http'):
        return {}
    ep_list = obtener_episodios(url)
    res = {}
    title = series.get('title') or ''
    cover = series.get('cover') or ''
    for ep in ep_list:
        s_num = str(ep['temporada'])
        if s_num not in res:
            res[s_num] = []
        res[s_num].append({
            'title': f'T{ep["temporada"]}:E{ep["episodio"]} - Episodio {ep["episodio"]}',
            'url': ep['iframe'],
            'page_url': url,
            'source': 'blogdepelis',
            'section': 'series',
            'is_serie': True,
            'is_episode': True,
            'season': s_num,
            'episode': str(ep['episodio']),
            'serie_title': title,
            'cover': cover,
        })
    return res


def metadata(item):
    """Devuelve metadatos estructurados del item."""
    return item


def resolver(embed_url, timeout=DEFAULT_TIMEOUT):
    """Resuelve un iframe o reproductor de BlogdePelis al enlace final reproducible en Kodi."""
    return resolvers.resolver_stream(embed_url)
