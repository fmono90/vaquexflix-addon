import json
import ssl
import threading
import time
from urllib.request import Request, build_opener, HTTPSHandler, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit

class NetworkError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status

def validate_url(url):
    if not isinstance(url,str) or any(ord(c)<32 for c in url) or '|' in url:
        raise ValueError('URL no válida')
    parsed = urlsplit(url)
    if parsed.scheme not in ('https','http') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Solo se admiten URLs HTTP(S) sin credenciales en la dirección')
    return url

class SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_url(newurl)
        if urlsplit(req.full_url).scheme=='https' and urlsplit(newurl).scheme!='https':
            raise NetworkError('Redirección insegura bloqueada')
        redirected=super().redirect_request(req,fp,code,msg,headers,newurl)
        if redirected and urlsplit(req.full_url).netloc!=urlsplit(newurl).netloc:
            for key in list(redirected.headers):
                if key.lower() in ('authorization','cookie','content-auth','content-license'):
                    del redirected.headers[key]
        return redirected

class HTTPClient:
    def __init__(self, timeout=15, cancelled=lambda:False, retries=2, opener=None):
        self.timeout=max(3,min(60,int(timeout)))
        self.cancelled=cancelled
        self.retries=retries
        self.lock=threading.BoundedSemaphore(2)
        self.opener=opener or build_opener(SafeRedirect(),HTTPSHandler(context=ssl.create_default_context()))

    def request(self,url,data=None,headers=None):
        validate_url(url)
        for attempt in range(self.retries+1):
            if self.cancelled(): raise NetworkError('Operación cancelada')
            try:
                with self.lock:
                    with self.opener.open(Request(url,data=data,headers=headers or {}),timeout=self.timeout) as response:
                        raw=response.read(8*1024*1024+1)
                        if len(raw)>8*1024*1024: raise NetworkError('Respuesta demasiado grande')
                        return raw
            except HTTPError as error:
                if error.code not in (429,500,502,503,504) or attempt==self.retries:
                    raise NetworkError('El servicio devolvió HTTP %s'%error.code,error.code) from None
                pause=min(5,float(error.headers.get('Retry-After','1'))) if str(error.headers.get('Retry-After','1')).isdigit() else 1
            except (URLError,TimeoutError,OSError):
                if attempt==self.retries:raise NetworkError('Red no disponible o tiempo de espera agotado') from None
                pause=.5*2**attempt
            deadline=time.monotonic()+pause
            while time.monotonic()<deadline:
                if self.cancelled():raise NetworkError('Operación cancelada')
                time.sleep(min(.1,max(0,deadline-time.monotonic())))

    def json(self,url,data=None,headers=None):
        try:return json.loads(self.request(url,data,headers).decode('utf-8'))
        except (ValueError,UnicodeError):raise NetworkError('Respuesta JSON no válida') from None
