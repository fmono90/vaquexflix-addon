import re
def text(value):return '' if value is None else str(value)
def series_key(title):return 'series:'+re.sub(r'\s*(?:-|–|—)?\s*(?:T(?:emp(?:orada)?)?\.?|Season)\s*\d+\s*$','',title,flags=re.I).strip().casefold()
def duration(value):
    try:
        raw=str(value or '0');parts=raw.split(':');number=0
        for p in parts:number=number*60+float(p)
        return number/1000 if number>100000 else number
    except (TypeError,ValueError):return 0
def item(asset,live=False):
    if not isinstance(asset,dict):asset={}
    images=(asset.get('posterList') or [])+(asset.get('imageList') or [])
    def image(kind):return next((x.get('fileUrl','') for x in images if x.get('fileType',x.get('imageType'))==kind and x.get('fileUrl')),asset.get('posterUrl',''))
    try:count=int(asset.get('volumnCount') or 0)
    except (ValueError,TypeError):count=0
    series=asset.get('programType') in ('series','teleplay') or count>1
    return {'id':text(asset.get('channelCode' if live else 'contentId')),'title':text(asset.get('name',asset.get('title'))),'kind':'channel' if live else 'series' if series else 'movie','plot':text(asset.get('description',asset.get('synopsis'))),'poster':image('icon'),'fanart':image('stage') or image('poster'),'year':text(asset.get('releaseTime',asset.get('releaseDate')))[:4],'duration':duration(asset.get('duration')),'genres':[v.strip() for v in text(asset.get('tags')).split(',') if v.strip()],'cast':text(asset.get('actorDisplay',asset.get('actors')))}
