from urllib.parse import urlencode
from .http_client import validate_url

def stream_path(stream,adaptive=False):
    url=validate_url(stream['url']);headers=stream.get('headers') or {}
    for k,v in headers.items():
        if any(c in str(k)+str(v) for c in '\r\n'):raise ValueError('Cabecera no válida')
    # Kodi 21's FFmpeg HLS demuxer ignores unknown protocol options. The ! prefix
    # explicitly forwards custom headers and masks their values in Kodi logs.
    # CurlFile strips the same prefix, so progressive HTTP sources also work.
    options={key if key.lower() in ('user-agent','referer','cookie','authorization','origin','accept','accept-language') else '!'+key:value for key,value in headers.items()}
    return url if adaptive or not headers else url+'|'+urlencode(options)

class PlaybackResolver:
    def __init__(self,provider,gui,plugin,xbmc):self.provider=provider;self.gui=gui;self.plugin=plugin;self.xbmc=xbmc
    def resolve(self,handle,item,position=0,quality='',prefer_adaptive=True):
        stream=self.provider.resolve(item,quality=quality)
        mime=stream.get('mime','video/mp4')
        manifest=mime in ('application/dash+xml','application/vnd.apple.mpegurl','application/x-mpegurl')
        adaptive=manifest and prefer_adaptive and self.xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
        if mime=='application/dash+xml' and not adaptive:raise ValueError('Instala InputStream Adaptive desde el repositorio oficial de Kodi para reproducir DASH.')
        path=stream_path(stream,adaptive)
        result=self.gui.ListItem(label=item.get('title',''),path=path,offscreen=True)
        result.setMimeType(mime);result.setContentLookup(False)
        if adaptive:
            result.setProperty('inputstream','inputstream.adaptive')
            encoded=urlencode(stream.get('headers') or {})
            result.setProperty('inputstream.adaptive.manifest_headers',encoded)
            result.setProperty('inputstream.adaptive.stream_headers',encoded)
        if position>0:result.setProperty('StartOffset',str(position))
        subtitles=[]
        for sub in stream.get('subtitles') or []:subtitles.append(validate_url(sub['url']))
        if subtitles:result.setSubtitles(subtitles)
        self.plugin.setResolvedUrl(handle,True,result)
        return stream
