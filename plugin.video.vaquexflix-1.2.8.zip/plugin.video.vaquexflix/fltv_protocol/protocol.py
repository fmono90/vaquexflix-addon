"""Public protocol constants from the authorized LG client; no account credentials."""
import base64
import json
import math
import struct
import os
import sys
_vendor_lib = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'lib')
if _vendor_lib not in sys.path:
    sys.path.insert(0, _vendor_lib)

# ---------------------------------------------------------------------------
# DES3-ECB with PKCS#7 padding — tries Cryptodome / PyCryptodome first; falls
# back to a pure-Python implementation when neither library is available
# (e.g. on the CPython test runner or on platforms where the C extension
# DLLs fail to load).  The implementation is correct and self-contained;
# it is never used inside Kodi where script.module.pycryptodome is present.
# ---------------------------------------------------------------------------
_des3_module = None
try:
    from Cryptodome.Cipher import DES3 as _des3_module
    from Cryptodome.Util.Padding import pad, unpad
except (ImportError, OSError):
    try:
        from Crypto.Cipher import DES3 as _des3_module
        from Crypto.Util.Padding import pad, unpad
    except (ImportError, OSError):
        _des3_module = None

if _des3_module is None:
    # Pure-Python Triple-DES (3TDEA) ECB implementation.
    # Key must be 24 bytes; block size is 8 bytes.
    _DES_IP  = [57,49,41,33,25,17, 9, 1,59,51,43,35,27,19,11, 3,
                61,53,45,37,29,21,13, 5,63,55,47,39,31,23,15, 7,
                56,48,40,32,24,16, 8, 0,58,50,42,34,26,18,10, 2,
                60,52,44,36,28,20,12, 4,62,54,46,38,30,22,14, 6]
    _DES_FP  = [39, 7,47,15,55,23,63,31,38, 6,46,14,54,22,62,30,
                37, 5,45,13,53,21,61,29,36, 4,44,12,52,20,60,28,
                35, 3,43,11,51,19,59,27,34, 2,42,10,50,18,58,26,
                33, 1,41, 9,49,17,57,25,32, 0,40, 8,48,16,56,24]
    _DES_PC1 = [56,48,40,32,24,16, 8, 0,57,49,41,33,25,17, 9, 1,
                58,50,42,34,26,18,10, 2,59,51,43,35,62,54,46,38,
                30,22,14, 6,61,53,45,37,29,21,13, 5,60,52,44,36,
                28,20,12, 4,27,19,11, 3]
    _DES_PC2 = [13,16,10,23, 0, 4, 2,27,14, 5,20, 9,22,18,11, 3,
                25, 7,15, 6,26,19,12, 1,40,51,30,36,46,54,29,39,
                50,44,32,47,43,48,38,55,33,52,45,41,49,35,28,31]
    _DES_SHIFTS = [1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1]
    _DES_SBOX = [
        [14, 4,13, 1, 2,15,11, 8, 3,10, 6,12, 5, 9, 0, 7,
          0,15, 7, 4,14, 2,13, 1,10, 6,12,11, 9, 5, 3, 8,
          4, 1,14, 8,13, 6, 2,11,15,12, 9, 7, 3,10, 5, 0,
         15,12, 8, 2, 4, 9, 1, 7, 5,11, 3,14,10, 0, 6,13],
        [15, 1, 8,14, 6,11, 3, 4, 9, 7, 2,13,12, 0, 5,10,
          3,13, 4, 7,15, 2, 8,14,12, 0, 1,10, 6, 9,11, 5,
          0,14, 7,11,10, 4,13, 1, 5, 8,12, 6, 9, 3, 2,15,
         13, 8,10, 1, 3,15, 4, 2,11, 6, 7,12, 0, 5,14, 9],
        [10, 0, 9,14, 6, 3,15, 5, 1,13,12, 7,11, 4, 2, 8,
         13, 7, 0, 9, 3, 4, 6,10, 2, 8, 5,14,12,11,15, 1,
         13, 6, 4, 9, 8,15, 3, 0,11, 1, 2,12, 5,10,14, 7,
          1,10,13, 0, 6, 9, 8, 7, 4,15,14, 3,11, 5, 2,12],
        [ 7,13,14, 3, 0, 6, 9,10, 1, 2, 8, 5,11,12, 4,15,
         13, 8,11, 5, 6,15, 0, 3, 4, 7, 2,12, 1,10,14, 9,
         10, 6, 9, 0,12,11, 7,13,15, 1, 3,14, 5, 2, 8, 4,
          3,15, 0, 6,10, 1,13, 8, 9, 4, 5,11,12, 7, 2,14],
        [ 2,12, 4, 1, 7,10,11, 6, 8, 5, 3,15,13, 0,14, 9,
         14,11, 2,12, 4, 7,13, 1, 5, 0,15,10, 3, 9, 8, 6,
          4, 2, 1,11,10,13, 7, 8,15, 9,12, 5, 6, 3, 0,14,
         11, 8,12, 7, 1,14, 2,13, 6,15, 0, 9,10, 4, 5, 3],
        [12, 1,10,15, 9, 2, 6, 8, 0,13, 3, 4,14, 7, 5,11,
         10,15, 4, 2, 7,12, 9, 5, 6, 1,13,14, 0,11, 3, 8,
          9,14,15, 5, 2, 8,12, 3, 7, 0, 4,10, 1,13,11, 6,
          4, 3, 2,12, 9, 5,15,10,11,14, 1, 7, 6, 0, 8,13],
        [ 4,11, 2,14,15, 0, 8,13, 3,12, 9, 7, 5,10, 6, 1,
         13, 0,11, 7, 4, 9, 1,10,14, 3, 5,12, 2,15, 8, 6,
          1, 4,11,13,12, 3, 7,14,10,15, 6, 8, 0, 5, 9, 2,
          6,11,13, 8, 1, 4,10, 7, 9, 5, 0,15,14, 2, 3,12],
        [13, 2, 8, 4, 6,15,11, 1,10, 9, 3,14, 5, 0,12, 7,
          1,15,13, 8,10, 3, 7, 4,12, 5, 6,11, 0,14, 9, 2,
          7,11, 4, 1, 9,12,14, 2, 0, 6,10,13,15, 3, 5, 8,
          2, 1,14, 7, 4,10, 8,13,15,12, 9, 0, 3, 5, 6,11],
    ]
    _DES_E   = [31, 0, 1, 2, 3, 4, 3, 4, 5, 6, 7, 8, 7, 8, 9,10,
                11,12,11,12,13,14,15,16,15,16,17,18,19,20,19,20,
                21,22,23,24,23,24,25,26,27,28,27,28,29,30,31, 0]
    _DES_P   = [15, 6,19,20,28,11,27,16, 0,14,22,25, 4,17,30, 9,
                 1, 7,23,13,31,26, 2, 8,18,12,29, 5,21,10, 3,24]

    def _des_permute(bits, table):
        return [bits[i] for i in table]

    def _des_subkeys(key8):
        bits = [(key8[i >> 3] >> (7 - (i & 7))) & 1 for i in range(64)]
        cd = _des_permute(bits, _DES_PC1)
        c, d = cd[:28], cd[28:]
        subkeys = []
        for shift in _DES_SHIFTS:
            c = c[shift:] + c[:shift]
            d = d[shift:] + d[:shift]
            subkeys.append(_des_permute(c + d, _DES_PC2))
        return subkeys

    def _des_block(block8, subkeys):
        bits = [(block8[i >> 3] >> (7 - (i & 7))) & 1 for i in range(64)]
        bits = _des_permute(bits, _DES_IP)
        L, R = bits[:32], bits[32:]
        for sk in subkeys:
            expanded = _des_permute(R, _DES_E)
            xored = [expanded[i] ^ sk[i] for i in range(48)]
            sout = []
            for s in range(8):
                chunk = xored[s * 6:(s + 1) * 6]
                row = (chunk[0] << 1) | chunk[5]
                col = (chunk[1] << 3) | (chunk[2] << 2) | (chunk[3] << 1) | chunk[4]
                val = _DES_SBOX[s][row * 16 + col]
                sout += [(val >> (3 - b)) & 1 for b in range(4)]
            f = _des_permute(sout, _DES_P)
            L, R = R, [L[i] ^ f[i] for i in range(32)]
        result_bits = _des_permute(R + L, _DES_FP)
        out = bytearray(8)
        for i, b in enumerate(result_bits):
            out[i >> 3] |= b << (7 - (i & 7))
        return bytes(out)

    class _MiniDES3ECB:
        """Pure-Python 3TDEA ECB — only encrypt/decrypt on 8-byte blocks."""
        def __init__(self, key24):
            if len(key24) != 24:
                raise ValueError('DES3 key must be 24 bytes')
            self._sk1 = _des_subkeys(key24[0:8])
            self._sk2 = _des_subkeys(key24[8:16])
            self._sk3 = _des_subkeys(key24[16:24])
        def encrypt(self, data):
            if len(data) % 8:
                raise ValueError('Data must be a multiple of 8 bytes')
            out = bytearray()
            for i in range(0, len(data), 8):
                block = data[i:i + 8]
                block = _des_block(block, self._sk1)
                block = _des_block(block, list(reversed(self._sk2)))
                block = _des_block(block, self._sk3)
                out += block
            return bytes(out)
        def decrypt(self, data):
            if len(data) % 8:
                raise ValueError('Data must be a multiple of 8 bytes')
            out = bytearray()
            for i in range(0, len(data), 8):
                block = data[i:i + 8]
                block = _des_block(block, list(reversed(self._sk3)))
                block = _des_block(block, self._sk2)
                block = _des_block(block, list(reversed(self._sk1)))
                out += block
            return bytes(out)

    class _MiniDES3Module:
        MODE_ECB = 1
        @staticmethod
        def new(key, mode):
            if mode != _MiniDES3Module.MODE_ECB:
                raise NotImplementedError('Only ECB mode is implemented in the pure-Python fallback')
            return _MiniDES3ECB(key)

    def pad(data, block_size):
        n = block_size - (len(data) % block_size)
        return data + bytes([n] * n)

    def unpad(data, block_size):
        n = data[-1]
        if n < 1 or n > block_size or data[-n:] != bytes([n] * n):
            raise ValueError('Invalid PKCS#7 padding')
        return data[:-n]

    _des3_module = _MiniDES3Module()

class _DES3Proxy:
    """Uniform proxy so encode/decode call DES3.new(KEY, DES3.MODE_ECB) regardless of backend."""
    MODE_ECB = getattr(_des3_module, 'MODE_ECB', 1)
    @staticmethod
    def new(key, mode):
        return _des3_module.new(key, mode)

DES3 = _DES3Proxy

KEY = bytes.fromhex('e7af1ed7de1ffddd7bd3fe37ebdffde9ef3fe1ae39edfeb8')

def encode(body):
    raw = json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return base64.b64encode(DES3.new(KEY, DES3.MODE_ECB).encrypt(pad(raw, 8))).hex().encode('ascii')

def decode(wire):
    cipher = base64.b64decode(bytes.fromhex(wire.decode('ascii') if isinstance(wire,bytes) else wire), validate=True)
    return json.loads(unpad(DES3.new(KEY, DES3.MODE_ECB).decrypt(cipher), 8).decode('utf-8'))

def sign_live(token, moment):
    data = ('token=%s&sign2_method=sign_o3&instance=0&start_moment=%s' % (token, moment)).encode()
    data += bytes.fromhex('73616c74333333333d34980d0a1532c9c3821708c0')
    bits = len(data) * 8
    data += b'\x80'
    data += b'\0' * ((56-len(data)) % 64) + struct.pack('<Q', bits)
    state = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
    shifts = [7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21]
    first = [10,11,12,13,14,15,6,7,8,9,0,1,2,3,4,5]
    for offset in range(0, len(data), 64):
        words = struct.unpack('<16I', data[offset:offset+64])
        a,b,c,d = state
        for i in range(64):
            if i < 16: f,g = (b&c)|(~b&d), first[i]
            elif i < 32: f,g = (d&b)|(~d&c), (5*i+1)%16
            elif i < 48: f,g = b^c^d, (3*i+5)%16
            else: f,g = c^(b|~d), (7*i)%16
            constant={42:0xd46f3085,45:0xe6bd99e5,54:0xffecc47d,62:0x2da7d2bb}.get(i,int(abs(math.sin(i+1))*4294967296))
            value = (a+f+constant+words[g]) & 0xffffffff
            shift = shifts[(i//16)*4+i%4]
            rotated = ((value<<shift)|(value>>(32-shift))) & 0xffffffff
            a,d,c,b = d,c,b,(b+rotated)&0xffffffff
        state = [(x+y)&0xffffffff for x,y in zip(state,[a,b,c,d])]
    return struct.pack('<4I', *state).hex()
