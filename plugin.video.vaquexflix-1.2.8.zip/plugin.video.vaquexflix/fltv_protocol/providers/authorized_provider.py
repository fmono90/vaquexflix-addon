"""Direct Python adaptation of the user's authorized portal API."""
import hashlib
import json
import os
import re
import secrets
import time
from urllib.parse import urlsplit
from .base import Provider
from ..protocol import encode,decode,sign_live
from ..http_client import HTTPClient,NetworkError,validate_url
from ..metadata import item as normalize,text,duration,series_key

APP='com.android.msandroid'
VERSION='49902'
PACKAGE='2025-08-07 05:40:11_36_16_'
HOSTS=('osuhk.m3x8o50te.com','oogoy.f30c96w8.com')

class PortalError(NetworkError):
    def __init__(self,code):
        message=('El servidor no permite activar el catálogo en tu región (portal100024). El administrador del servicio debe revisar la autorización regional.' if code=='portal100024' else 'El portal respondió %s'%code)
        super().__init__(message)
        self.code=code

class AuthorizedProvider(Provider):
    name='XUPER TV+'
    def __init__(self,profile,http=None,cache=None):
        self.exclusive=None
        self.http=http or HTTPClient();self.cache=cache;self.last=0;self.session={};self.profile=profile
        self.session_path=os.path.join(profile,'session.json')
        try:
            with open(self.session_path,encoding='utf-8') as f:self.session=json.load(f)
        except (OSError,ValueError):pass

    def post(self,path,bean):
        pause=.45-(time.monotonic()-self.last)
        if pause>0:time.sleep(pause)
        self.last=time.monotonic()
        body=dict(bean)
        body.update({'apkVersion':VERSION,'sysVersion':PACKAGE,'appId':APP,'sn':self.session.get('sn',''),'loginType':'2','appLanguage':'en','hardwareInfo':'ranchu','model':'sdk_gphone64_arm64','product':'sdk_gphone64_arm64','cpu':'arm64-v8a','B29':'','reserve1':'','deviceToken':'','drmId':'','sdkVer':36})
        payload=encode(body)
        headers={'apk':APP,'apkVer':'43404','spkgVer':PACKAGE,'User-Agent':'okhttp/3.12.12','Content-Type':'application/json;charset=utf-8'}
        last=None
        for host in HOSTS:
            try:
                result=self.http.json('https://'+host+'/api/portalCore/'+path,payload,headers)
                if not isinstance(result,dict):raise NetworkError('Respuesta del portal incompleta')
                code=str(result.get('returnCode') or '')
                if code not in ('','0'):raise PortalError(code)
                data=result.get('data',result)
                return decode(data) if isinstance(data,str) and data else data
            except PortalError:raise
            except NetworkError as error:last=error
        raise last or NetworkError('Portal no disponible')

    def activate(self):
        if self.session.get('userToken'):return
        fingerprint={'board':'goldfish_arm64','brand':'google','cpuAbi':'arm64-v8a','device':'emu64a','diskInfo':'8GB','display':'sdk_gphone64_arm64','fingerprint':'google/sdk_gphone64_arm64/emu64a:14/UE1A.230829.036/11228894:user/release-keys','hardware':'ranchu','host':'abfarm','manufacturer':'Google','ramSize':'4GB','romSize':'8GB','tags':'release-keys','verId':''}
        fingerprint.update({key:secrets.token_hex(8) for key in ('androidId','cpuId','serialNumber','etheMac','gatewayMac','wifiMac')})
        mint=self.post('v3/snToken',fingerprint);token=text(mint.get('snToken'))
        if not token:raise NetworkError('No se pudo crear la sesión de dispositivo')
        self.session={'sn':text(mint.get('sn')) or hashlib.md5((token+'ntFT65w6itH!lHCPw7D=@qnsFC5adD28').encode()).hexdigest()}
        answer=self.post('v8/active',{'snToken':token,'authVersion':'','authCode':'','preCode':'','macAddr':'02:00:00:00:00:00','reserve1':'','openNum':4,'channel':'default','matadata':'','signdata':''})
        if not answer.get('userToken'):raise NetworkError('El portal no activó la sesión')
        self.session.update({key:answer[key] for key in ('userToken','userId')})
        os.makedirs(self.profile,exist_ok=True)
        with open(self.session_path+'.tmp','w',encoding='utf-8') as f:json.dump(self.session,f)
        os.replace(self.session_path+'.tmp',self.session_path)
        try:os.chmod(self.session_path,0o600)
        except OSError:pass

    def call(self,path,bean):
        for attempt in range(2):
            self.activate()
            try:return self.post(path,dict({'portalCode':'masnew','userId':self.session['userId'],'userToken':self.session['userToken']},**bean))
            except PortalError as e:
                if e.code not in ('aaa100027','aaa100028') or attempt:raise
                self.session={}

    def cached(self,key,callback):
        data=self.cache.get(key) if self.cache else None
        if data is not None:return data
        data=callback()
        if self.cache:self.cache.put(key,data)
        return data

    def catalog(self,root='featured',page=1):
        def query():
            data=self.call('getNextColumns',{'columnCode':'masnew_'+root,'pageNum':page,'pageSize':50,'version':''})
            result=[]
            for row in data.get('recommendList') or []:
                for asset in row.get('assetList') or []:
                    value=normalize(asset);value['category']=row.get('name','')
                    if value['id']:result.append(value)
            return {'items':result,'more':bool(data.get('hasNext'))}
        return self.cached('catalog:%s:%s'%(root,page),query)

    def search(self,query,page=1):
        if not query.strip():return {'items':[],'more':False}
        def run():
            data=self.call('v3/searchByName',{'value':query,'type':'0','columnId':'','filter':'','pageNum':page,'pageSize':20})
            items={}
            for group in data.get('searchItemList') or []:
                for asset in group.get('itemList') or []:
                    value=normalize(asset)
                    if value['id']:items[value['id']]=value
            total=int(data.get('totalSize') or 0)
            return {'items':list(items.values()),'more':page*20<total}
        return self.cached('search:%s:%s'%(query,page),run)

    def detail(self,item):
        group=item.get('series_id') or series_key(item.get('showtitle',item['title']))
        try:data=self.call('v4/getItemData',{'contentId':item['id'],'type':'0','sortType':'0','language':'en','macAddr':'02:00:00:00:00:00'}).get('assetData') or {}
        except PortalError as e:
            if e.code=='portal100006' and item.get('kind')=='movie':return {'item':item,'episodes':[],'seasons':[]}
            raise
        current=normalize(data) if data else item
        episodes=[]
        for n,e in enumerate(data.get('simpleProgramList') or []):
            episodes.append({'id':text(e.get('contentId')),'title':text(e.get('name')),'number':int(e.get('seriesNumber') or n+1),'series_id':group,'season_id':item['id'],'kind':'episode','poster':e.get('picture') or current.get('poster',''),'fanart':current.get('fanart',''),'plot':text(e.get('description')),'duration':duration(e.get('duration')),'showtitle':item.get('showtitle',item['title'])})
        seasons=[{'id':text(e.get('contentId')),'title':'Temporada '+text(e.get('seasonNumber')),'number':e.get('seasonNumber'),'kind':'season','series_id':group,'showtitle':item.get('showtitle',item['title']),'poster':current.get('poster',''),'fanart':current.get('fanart','')} for e in data.get('sameSeasonSeriesList') or [] if e.get('contentId')]
        return {'item':current,'episodes':episodes,'seasons':seasons}

    def categories(self):
        data=self.cached('live:categories',lambda:self.call('getNextColumns',{'columnCode':'masnew_live','pageNum':1,'pageSize':50,'version':''}))
        return [{'id':text(r.get('columnId')),'title':'Todos' if r.get('name')=='ChannelList' else text(r.get('name'))} for r in data.get('recommendList') or [] if r.get('columnId')]

    def channels(self,category='76182',page=1):
        data=self.call('v6/getLiveData',{'columnId':int(category or 76182),'dataVersion':'','pageSize':50,'pageNum':page,'expireTimeStr':''})
        items=[normalize(a,True) for a in data.get('channelList') or []]
        return {'items':[i for i in items if i['id']],'more':len(items)==50}

    def slb(self,codes):return self.call('v14/getSlbInfo',{'hasPay':'0','userIdentity':'1','type':'merge','appVer':VERSION,'lang':'es','encMediaSupported':1,'liveCodeList':codes,'appParams':'','reserve1':'02:00:00:00:00:00','pipFlag':'0'})

    def resolve(self,item,quality=''):
        live=item.get('kind')=='channel'
        play=self.call('v4/startPlayLive',{'channelCode':item['id'],'columnId':0,'type':'1'}) if live else self.call('v10/startPlayVOD',{'contentId':item['id'],'seriesContentId':item.get('season_id',''),'startTime':0,'type':'1','columnId':0,'authType':''})
        subtitles=[]
        if live:
            track=next((a for a in play.get('liveAddressList') or [] if a.get('license')),None)
            if not track:raise NetworkError('Canal no disponible')
            license=track['license'];code=track.get('playCode') or item['id']
        else:
            episodes=play.get('episodeList') or []
            if not episodes:raise NetworkError('El título no ofreció pistas')
            episode=episodes[0];tracks=[t for group in episode.get('totalMovieList') or [] for t in group.get('movieList') or []]
            tracks.sort(key=lambda t:(0 if text(t.get('videoFormat')).lower()=='mp4' else 100)+(0 if text(t.get('encodeFormat')).lower() in ('h264','h.264','avc') else 50))
            valid=[t for t in tracks if any(v.get('license') for v in t.get('licenseList') or [])]
            track=next((t for t in valid if quality and quality in text(t.get('quality'))),valid[0] if valid else None)
            if not track:raise NetworkError('No hay una pista autorizada')
            license=next(v['license'] for v in track['licenseList'] if v.get('license'))
            for row in episode.get('subtitleList') or []:
                for file in row.get('file') or []:
                    if file.get('url'):subtitles.append({'url':validate_url(file['url']),'language':text(row.get('language'))})
        cdns=self.slb([item['id'] if live else 'masnew_live'])
        for cdn in cdns.get('cdn_list') or []:
            if cdn.get('tag')!=('live' if live else 'vod'):continue
            for entry in cdn.get('url_list') or []:
                auth=text(entry.get('url'))
                if entry.get('sign_type')!='cfl' and 'sign_type=cfl' not in auth:continue
                if not live and entry.get('tag')!='free':continue
                base=text(cdn.get('main_addr'));base=base if '://' in base else 'https://'+base
                if live:
                    match=re.search('token=([0-9a-fA-F]{32})',auth)
                    if not match:continue
                    moment=int(time.time()*1000);auth+='&sign2_method=sign_o3&instance=0&start_moment=%s&sign2=%s'%(moment,sign_live(match[1],moment))
                    url='http://'+urlsplit(base).netloc+'/live/'+code+'.m3u8';mime='application/vnd.apple.mpegurl'
                else:
                    ext='ts' if text(track.get('videoFormat')).lower()=='ts' else 'mp4'
                    url=base.rstrip('/')+'/vod/'+text(track.get('contentId'))+'_media.'+ext;mime='video/mp2t' if ext=='ts' else 'video/mp4'
                headers={'Content-Auth':auth,'Content-License':license,'User-Agent':'Ranger/4.9.4-17294ac0','App':APP,'App-Version':VERSION}
                return {'url':validate_url(url),'mime':mime,'headers':headers,'subtitles':subtitles,'duration':duration(track.get('duration')),'audio':text(track.get('audioInfo'))}
        raise NetworkError('El proveedor no devolvió un origen compatible')
