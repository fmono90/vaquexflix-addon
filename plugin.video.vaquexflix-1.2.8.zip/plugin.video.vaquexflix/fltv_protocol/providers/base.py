class Provider:
    name='Proveedor'
    def catalog(self,root='featured',page=1):raise NotImplementedError
    def search(self,query,page=1):raise NotImplementedError
    def detail(self,item):raise NotImplementedError
    def categories(self):raise NotImplementedError
    def channels(self,category='',page=1):raise NotImplementedError
    def resolve(self,item):raise NotImplementedError
