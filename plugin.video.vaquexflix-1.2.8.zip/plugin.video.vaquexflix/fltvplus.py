"""FLTV+ portal adapter with bundled protocol code.

The portal session and CDN selection are independent of XUPER TV+ and Android.
No session value is logged or embedded in a media URL.
"""
import os
import json
import hashlib
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

SOURCE = 'fltvplus'
HOSTS = ('fuxok.nguvmqhpk.com', 'mptec.dhkrxuzcy.com')
_lock = threading.RLock()
_portal_lock = threading.RLock()
_provider_type = None
_provider_instance = None
_cache = {}
_stream_cache = {}


def _provider():
    global _provider_type, _provider_instance
    with _lock:
        if _provider_type is None:
            from fltv_protocol.providers import authorized_provider as portal

            class FLTVProvider(portal.AuthorizedProvider):
                name = 'FLTV+'

                def call(self, path, bean):
                    with _portal_lock:
                        return super().call(path, bean)

                def post(self, path, bean):
                    body = dict(bean)
                    body.update({'apkVersion': portal.VERSION, 'sysVersion': portal.PACKAGE,
                                 'appId': portal.APP, 'sn': self.session.get('sn', ''),
                                 'loginType': '2', 'appLanguage': 'es',
                                 'hardwareInfo': 'ranchu', 'model': 'sdk_gphone64_arm64',
                                 'product': 'sdk_gphone64_arm64', 'cpu': 'arm64-v8a',
                                 'B29': '', 'reserve1': '', 'deviceToken': '',
                                 'drmId': '', 'sdkVer': 36})
                    payload = portal.encode(body)
                    headers = {'apk': portal.APP, 'apkVer': '43404',
                               'spkgVer': portal.PACKAGE,
                               'User-Agent': 'okhttp/3.12.12',
                               'Content-Type': 'application/json;charset=utf-8'}
                    last = None
                    for host in HOSTS:
                        try:
                            pause = 1.0 - (time.monotonic() - self.last)
                            if pause > 0:
                                time.sleep(pause)
                            self.last = time.monotonic()
                            result = self.http.json('https://' + host + '/api/portalCore/' + path,
                                                    payload, headers)
                            if not isinstance(result, dict):
                                raise portal.NetworkError('Respuesta FLTV+ incompleta')
                            code = str(result.get('returnCode') or '')
                            if code not in ('', '0'):
                                if code == 'portal200001':
                                    last = portal.PortalError(code)
                                    continue
                                raise portal.PortalError(code)
                            data = result.get('data', result)
                            return portal.decode(data) if isinstance(data, str) and data else data
                        except portal.PortalError:
                            raise
                        except portal.NetworkError as error:
                            last = error
                    raise last or portal.NetworkError('Portal FLTV+ no disponible')

            _provider_type = FLTVProvider
        profile = ''
        try:
            import xbmcvfs
            profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vaquexflix/fltvplus')
        except ImportError:
            pass
        if not profile:
            profile = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                                   'userdata', 'addon_data', 'plugin.video.vaquexflix', 'fltvplus')
        if _provider_instance is None or _provider_instance.profile != profile:
            _provider_instance = _provider_type(profile)
        return _provider_instance


def _card(item, section):
    identifier = str(item.get('id') or '')
    if not identifier:
        return None
    is_series = item.get('kind') == 'series'
    title = str(item.get('title') or '')
    if is_series:
        title = re.sub(r'\s+T\d+$', '', title, flags=re.I)
    return {'title': title, 'url': 'fltvplus://vod/' + urllib.parse.quote(identifier, safe=''),
            'source': SOURCE, 'fltv_id': identifier, 'is_serie': is_series,
            'section': 'series' if is_series else section,
            'cover': item.get('poster', ''), 'fanart': item.get('fanart', ''),
            'plot': item.get('plot', ''), 'year': item.get('year', ''),
            'genres': item.get('genres', [])}


def search(query, section='all', strict=False):
    if not str(query).strip():
        return []
    try:
        rows = _provider().search(query).get('items') or []
    except Exception:
        if strict:
            raise
        return []
    cards = []
    for row in rows:
        kind = 'series' if row.get('kind') == 'series' else 'peliculas'
        if section not in ('all', kind):
            continue
        card = _card(row, kind)
        if card:
            cards.append(card)
    return cards


def page(section, number, genre=None, preview=False):
    root = {'peliculas': 'movies', 'series': 'series', 'animes': 'anime',
            'anime': 'anime', 'infantil': 'kids'}.get(section)
    if not root or int(number) < 1:
        return [], False
    key = (root, int(number))
    with _lock:
        cached = _cache.get(key)
    if cached and time.monotonic() - cached[0] < 600:
        data = cached[1]
    else:
        try:
            data = _provider().catalog(root, int(number))
        except Exception:
            return [], False
        with _lock:
            _cache[key] = (time.monotonic(), data)
    cards = [_card(row, section) for row in data.get('items') or []]
    cards = [card for card in cards if card and card.get('is_serie') == (section in ('series', 'animes', 'anime', 'infantil'))]
    if preview:
        return cards[:3], False
    return cards, bool(data.get('more'))


def episodes(series):
    identifier = str(series.get('fltv_id') or '')
    if not identifier:
        return {}
    provider = _provider()
    cache_path = os.path.join(provider.profile, 'episodes_' +
                              hashlib.sha256(identifier.encode('utf-8')).hexdigest() + '.json')
    cached = None
    try:
        with open(cache_path, encoding='utf-8') as handle:
            cached = json.load(handle)
        if time.time() - cached.get('updated', 0) < 1800 and isinstance(cached.get('seasons'), dict):
            return cached['seasons']
    except (OSError, ValueError, TypeError, AttributeError):
        cached = None
    try:
        detail = provider.detail({'id': identifier, 'title': series.get('title', ''), 'kind': 'series'})
    except Exception:
        if cached and time.time() - cached.get('updated', 0) < 86400:
            return cached.get('seasons') or {}
        raise
    seasons = detail.get('seasons') or [{'id': identifier, 'number': 1}]
    result = {}
    for index, season in enumerate(seasons, 1):
        season_id = str(season.get('id') or identifier)
        current = detail if season_id == identifier else provider.detail(
            {'id': season_id, 'title': series.get('title', ''), 'kind': 'series'})
        number = str(season.get('number') or index)
        rows = []
        for n, episode in enumerate(current.get('episodes') or [], 1):
            episode_id = str(episode.get('id') or '')
            if not episode_id:
                continue
            url = 'fltvplus://vod/' + urllib.parse.quote(episode_id, safe='') + '?' + urllib.parse.urlencode({'season_id': season_id})
            rows.append({'title': episode.get('title') or 'Episodio {}'.format(n),
                         'url': url, 'source': SOURCE, 'fltv_id': episode_id,
                         'fltv_season_id': season_id, 'is_serie': True,
                         'section': 'series', 'season': number,
                         'episode': str(episode.get('number') or n),
                         'cover': episode.get('poster') or series.get('cover', ''),
                         'plot': episode.get('plot', '')})
        if rows:
            result[number] = rows
    if result:
        try:
            os.makedirs(provider.profile, exist_ok=True)
            with open(cache_path + '.tmp', 'w', encoding='utf-8') as handle:
                json.dump({'updated': time.time(), 'seasons': result}, handle)
            os.replace(cache_path + '.tmp', cache_path)
        except OSError:
            pass
    return result


def match_episode(item, series):
    """Find an exact FLTV+ episode for a saved or merged series card."""
    def normalized(value):
        value = re.sub(r'\s+T\d+$', '', str(value or ''), flags=re.I)
        return ' '.join(re.sub(r'[^\w]+', ' ', value.lower()).split())

    season = str(item.get('season') or '')
    number = str(item.get('episode') or '')
    wanted = normalized(series.get('title'))
    if not wanted or not season.isdigit() or not number.isdigit():
        return None
    for candidate in search(series['title'], 'series'):
        if normalized(candidate['title']) != wanted:
            continue
        expected_year = str(series.get('year') or '')[:4]
        actual_year = str(candidate.get('year') or '')[:4]
        if expected_year.isdigit() and actual_year.isdigit() and expected_year != actual_year:
            continue
        try:
            matches = episodes(candidate).get(season, [])
        except Exception:
            continue
        for episode in matches:
            if str(episode.get('episode')) == number:
                return episode
    return None


def match_series(series):
    """Match a catalogue card to the same FLTV+ series without guessing IDs."""
    wanted = ' '.join(re.sub(r'[^\w]+', ' ', str(series.get('title') or '').lower()).split())
    if not wanted:
        return None
    for candidate in search(series['title'], 'series', strict=True):
        found = ' '.join(re.sub(r'[^\w]+', ' ', candidate['title'].lower()).split())
        expected_year = str(series.get('year') or '')[:4]
        actual_year = str(candidate.get('year') or '')[:4]
        title_matches = found == wanted or (len(wanted.split()) >= 3 and found.endswith(' ' + wanted))
        if title_matches and not (expected_year.isdigit() and actual_year.isdigit()
                                  and expected_year != actual_year):
            return candidate
    return None


def match_movie(item):
    """Match a general movie card to an exact FLTV+ catalogue entry."""
    import unicodedata

    def normalized(value):
        value = unicodedata.normalize('NFKD', str(value or '').lower())
        value = ''.join(ch for ch in value if not unicodedata.combining(ch))
        return ' '.join(re.sub(r'[^\w]+', ' ', value).split())

    def spaceless(value):
        """Secondary key: strip all spaces for titles like 'Spiderman' vs 'Spider Man'."""
        return normalized(value).replace(' ', '')

    titles = [str(item.get(key) or '').strip() for key in ('title', 'original_title')]
    wanted = {normalized(title) for title in titles if title}
    wanted_sl = {spaceless(title) for title in titles if title}
    if not wanted:
        return None
    expected_year = str(item.get('year') or '')[:4]
    best_sl = None
    for query in dict.fromkeys(title for title in titles if title):
        for candidate in search(query, 'peliculas'):
            norm_c = normalized(candidate.get('title'))
            actual_year = str(candidate.get('year') or '')[:4]
            year_ok = not (expected_year.isdigit() and actual_year.isdigit()
                           and expected_year != actual_year)
            if norm_c in wanted and year_ok:
                return candidate
            # Fallback: match ignoring spaces (handles 'Spiderman' vs 'Spider-Man')
            if best_sl is None and spaceless(candidate.get('title')) in wanted_sl and year_ok:
                best_sl = candidate
    return best_sl


def _parse(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ('fltvplus', 'fltv'):
        raise ValueError('Enlace FLTV+ inválido')
    identifier = urllib.parse.unquote(parsed.path.lstrip('/') or parsed.netloc)
    if not identifier or len(identifier) > 160 or any(ord(ch) < 32 or ch in '/?#\\' for ch in identifier):
        raise ValueError('Identificador FLTV+ inválido')
    params = urllib.parse.parse_qs(parsed.query)
    return parsed.scheme, identifier, params


def owns(value):
    if isinstance(value, dict):
        return value.get('source') == SOURCE or owns(value.get('url', ''))
    return isinstance(value, str) and value.startswith(('fltvplus://', 'fltv://'))


def categories():
    try:
        rows = _provider().categories()
    except Exception:
        return []
    return [{'key': 'fltv_group_' + str(row['id']), 'title': 'FLTV+ · ' + str(row['title']),
             'url': 'tv://fltv_group_' + str(row['id']), 'cover': '',
             'plot': 'Canales FLTV+: ' + str(row['title'])}
            for row in rows if str(row.get('id', '')).isdigit() and str(row['id']) != '76208']


def channels(category, page_number=1):
    if not str(category).isdigit() or str(category) == '76208':
        return [], False
    try:
        data = _provider().channels(str(category), int(page_number))
    except Exception:
        return [], False
    cards = []
    for row in data.get('items') or []:
        identifier = str(row.get('id') or '')
        if not identifier:
            continue
        cards.append({'title': row.get('title', ''),
                      'url': 'fltv://channel/' + urllib.parse.quote(identifier, safe=''),
                      'source': SOURCE, 'cover': row.get('poster', ''),
                      'plot': row.get('plot', '')})
    return cards, bool(data.get('more'))


def _streams(item):
    cache_key = (item['kind'], item['id'], item.get('season_id', ''))
    with _lock:
        cached = _stream_cache.get(cache_key)
    if cached and time.monotonic() - cached[0] < 90:
        return cached[1]
    provider = _provider()
    live = item['kind'] == 'channel'
    if live:
        play = provider.call('v4/startPlayLive', {'channelCode': item['id'], 'columnId': 0, 'type': '1'})
        tracks = [row for row in play.get('liveAddressList') or [] if row.get('license')]
    else:
        play = provider.call('v10/startPlayVOD', {'contentId': item['id'],
            'seriesContentId': item.get('season_id', ''), 'startTime': 0,
            'type': '1', 'columnId': 0, 'authType': ''})
        tracks = [(group.get('quality', ''), row) for episode in play.get('episodeList') or []
                  for group in episode.get('totalMovieList') or []
                  for row in group.get('movieList') or [] if row.get('licenseList')]
    slb = provider.slb([item['id'] if live else 'masnew_live'])
    result = []
    for cdn in slb.get('cdn_list') or []:
        if cdn.get('tag') != ('live' if live else 'vod'):
            continue
        base = str(cdn.get('main_addr') or '')
        base = base if '://' in base else 'https://' + base
        host = urllib.parse.urlsplit(base).hostname or ''
        if not host:
            continue
        for entry in cdn.get('url_list') or []:
            if entry.get('tag') != 'free' or not entry.get('url'):
                continue
            auth = str(entry['url'])
            for quality, track in tracks if not live else [('', t) for t in tracks]:
                license_value = track.get('license') if live else next(
                    (row.get('license') for row in track.get('licenseList') or [] if row.get('license')), None)
                if not license_value:
                    continue
                if live:
                    # Live signing differs from VOD; the installed client's resolver handles it.
                    continue
                ext = 'ts' if str(track.get('videoFormat')).lower() == 'ts' else 'mp4'
                media = base.rstrip('/') + '/vod/' + str(track.get('contentId') or '') + '_media.' + ext
                headers = {'Content-Auth': auth, 'Content-License': license_value,
                           'User-Agent': 'Ranger/4.9.4-17294ac0',
                           'App': 'com.android.msandroid', 'App-Version': '49902'}
                result.append({'host': host, 'quality': quality, 'track_id': str(track.get('contentId') or ''),
                               'url': media, 'headers': headers,
                               'mime': 'video/mp2t' if ext == 'ts' else 'video/mp4'})
    if result:
        with _lock:
            _stream_cache[cache_key] = (time.monotonic(), result)
    return result


def servers(item, series=None):
    import source_switches
    if not source_switches.allowed(item):
        return []
    url = item.get('url', '')
    if not owns(url):
        return []
    kind, identifier, params = _parse(url)
    if kind == 'fltv':
        return [{'nombre': 'FLTV+ · TV', 'url': url, 'source': SOURCE, 'calidad': 'Sin verificar'}]
    # For VOD/episodes: delegate full CDN resolution to resolve() (which uses
    # provider.resolve() internally).  _streams() pre-builds CDN×track combos
    # but requires sign_type=cfl entries that may not always appear for every
    # title.  Offering the base URL with no cdn/track params lets resolve()
    # pick the best available server automatically — exactly what works in
    # practice.  We attempt _streams() only as a fallback to surface quality
    # labels if the portal returns usable combos; otherwise we surface a single
    # "FLTV+ · directo" entry that always resolves.
    base_entry = {'nombre': 'FLTV+ · directo',
                  'url': url, 'source': SOURCE, 'calidad': 'Sin verificar'}
    try:
        streams = _streams({'id': identifier, 'kind': 'movie',
                            'season_id': params.get('season_id', [''])[0]})
    except Exception as error:
        code = getattr(error, 'code', type(error).__name__)
        return [base_entry,
                {'nombre': 'FLTV+ · reintentar consulta ({})'.format(code),
                 'url': url + ('&' if '?' in url else '?') + 'retry=1',
                 'source': SOURCE, 'calidad': 'Sin verificar',
                 'fltv_retry': True,
                 'resolver_error': 'Consulta de servidores: {}'.format(code)}]
    if not streams:
        return [base_entry]
    return [{'nombre': 'FLTV+ · ' + row['host'],
             'url': url + ('&' if '?' in url else '?') + urllib.parse.urlencode(
                 {'cdn': row['host'], 'track': row['track_id']}),
             'source': SOURCE, 'calidad': row.get('quality') or 'Sin verificar'}
            for row in streams]


def resolve(url):
    kind, identifier, params = _parse(url)
    if kind == 'fltv':
        stream = _provider().resolve({'id': identifier, 'kind': 'channel'})
    else:
        host = params.get('cdn', [''])[0]
        track = params.get('track', [''])[0]
        if not host and not track:
            stream = _provider().resolve({'id': identifier, 'kind': 'episode',
                                          'season_id': params.get('season_id', [''])[0]})
        else:
            streams = _streams({'id': identifier, 'kind': 'movie',
                                'season_id': params.get('season_id', [''])[0]})
            stream = next((row for row in streams if row['host'] == host and row['track_id'] == track), None)
        if not stream:
            raise ValueError('Servidor FLTV+ no disponible')
    is_hls = urllib.parse.urlsplit(stream['url']).path.lower().endswith('.m3u8')
    headers = dict(stream['headers'])
    if not is_hls:
        headers['Range'] = 'bytes=0-1879'
    try:
        with urllib.request.urlopen(urllib.request.Request(stream['url'], headers=headers), timeout=8) as response:
            first = response.read(262144 if is_hls else 1880)
    except urllib.error.HTTPError as error:
        raise ValueError('FLTV+ · {}: HTTP {}'.format(urllib.parse.urlsplit(stream['url']).hostname, error.code)) from None
    if not first or first.lstrip().lower().startswith((b'<html', b'<!doctype')):
        raise ValueError('FLTV+ no entregó bytes de vídeo')
    if is_hls:
        manifest_url = stream['url']
        for _ in range(3):
            if not first.startswith(b'#EXTM3U'):
                raise ValueError('FLTV+ no entregó un manifiesto HLS válido')
            lines = first.decode('utf-8', 'replace').splitlines()
            media = next((line.strip() for line in lines if line.strip() and not line.startswith('#')), '')
            if not media:
                raise ValueError('FLTV+ no entregó segmentos HLS')
            media_url = urllib.parse.urljoin(manifest_url, media)
            with urllib.request.urlopen(urllib.request.Request(media_url, headers=stream['headers']), timeout=8) as response:
                first = response.read(1880)
            if not first or first.lstrip().lower().startswith((b'<html', b'<!doctype')):
                raise ValueError('FLTV+ no entregó bytes del primer segmento')
            if not first.startswith(b'#EXTM3U'):
                break
            manifest_url = media_url
        else:
            raise ValueError('FLTV+ excedió la profundidad HLS')
    if stream['mime'] == 'video/mp2t' and first[0] != 0x47:
        raise ValueError('FLTV+ no entregó transporte TS')
    from fltv_protocol.playback import stream_path
    return stream_path(stream)
