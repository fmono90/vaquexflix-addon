"""Public Pluto VOD catalog and short lived playback sessions."""
import json
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
import uuid

import network

UA = 'Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/122.0.0.0 Mobile Safari/537.36'
BOOT = 'https://boot.pluto.tv/v4/start'
VOD = 'https://service-vod.clusters.pluto.tv/v4/vod'
CATALOG = 'https://api.pluto.tv/v3/vod/categories'
_lock = threading.RLock()
_cached = (0, [])

_CINE_KEYWORDS = ('cine', 'peli', 'pelicula', 'pelis', 'adrenalina', 'hollywood',
                  'estrellas de accion', 'plutoween')

GENRE_RULES = {
    'accion': {'genres': ['action & adventure'], 'keywords': ['accion', 'adrenalina', 'aventura', 'combate']},
    'action-adventure': {'genres': ['action & adventure'], 'keywords': ['accion', 'aventura']},
    'animacion': {'genres': ['children & family', 'anime'], 'keywords': ['animad', 'animacion', 'caricaturas', 'nicktoons', 'kids', 'peli-kids']},
    'anime': {'genres': ['anime'], 'keywords': ['anime', 'shonen', 'manga']},
    'aventura': {'genres': ['action & adventure'], 'keywords': ['aventura', 'rescate', 'viajes']},
    'belica': {'genres': ['war'], 'keywords': ['belic', 'guerra', 'militar', 'conflictos']},
    'war-politics': {'genres': ['war'], 'keywords': ['guerra', 'conflictos', 'belic']},
    'ciencia-ficcion': {'genres': ['sci-fi & fantasy'], 'keywords': ['sci-fi', 'ciencia ficcion', 'ciencia y tecnologia', 'futuro']},
    'sci-fi-fantasy': {'genres': ['sci-fi & fantasy'], 'keywords': ['sci-fi', 'fantasia', 'star trek']},
    'comedia': {'genres': ['comedy'], 'keywords': ['comedia', 'humor', 'stand up', 'bromas', 'sketch', 'funny']},
    'crimen': {'genres': ['crime'], 'keywords': ['crimen', 'policial', 'investigacion', 'narcotrafico']},
    'documental': {'genres': ['documentary', 'faith & spirituality', 'food & cooking', 'home & lifestyle'], 'keywords': ['documental', 'historia', 'biografia', 'naturaleza', 'smithsonian', 'arqueologia']},
    'drama': {'genres': ['drama'], 'keywords': ['drama']},
    'familia': {'genres': ['children & family'], 'keywords': ['familia', 'infantil', 'kids', 'junior', 'preescolar', 'perruno', 'mascotas']},
    'fantasia': {'genres': ['sci-fi & fantasy'], 'keywords': ['fantasia', 'magia']},
    'historia': {'genres': ['documentary'], 'keywords': ['historia', 'conflictos', 'civilizaciones']},
    'kids': {'genres': ['children & family'], 'keywords': ['kids', 'junior', 'nick jr', 'preescolar', 'caricaturas']},
    'misterio': {'genres': ['thriller', 'crime', 'horror', 'paranormal'], 'keywords': ['misterio', 'paranormal', 'suspenso', 'ovnis', 'investigacion']},
    'musica': {'genres': ['music', 'musical'], 'keywords': ['musica', 'musical', 'canta y baila', 'mtv', 'concierto']},
    'pelicula-de-tv': {'genres': ['drama', 'comedy', 'thriller'], 'keywords': ['cine']},
    'reality': {'genres': ['reality', 'game show', 'talk show'], 'keywords': ['reality', 'shores', 'competencia', 'desafios']},
    'romance': {'genres': ['romance'], 'keywords': ['romance', 'amor', 'citas']},
    'soap': {'genres': ['telenovela'], 'keywords': ['telenovela', 'novela']},
    'series-turcas': {'genres': ['telenovela'], 'keywords': ['turcas', 'telenovela']},
    'suspense': {'genres': ['thriller', 'horror'], 'keywords': ['suspenso', 'thriller', 'atrapados']},
    'talk': {'genres': ['talk show', 'news & information'], 'keywords': ['talk show', 'entrevistas', 'discursion']},
    'terror': {'genres': ['horror'], 'keywords': ['terror', 'horror', 'miedo', 'plutoween', 'malditos', 'monstruos', 'escalofriantes', 'sangre', 'pesadilla']},
    'western': {'genres': ['western'], 'keywords': ['western', 'vaquero', 'oeste']},
    'argentinas': {'genres': [], 'keywords': ['argentin', 'latino', 'latina']},
    'mexicanas': {'genres': [], 'keywords': ['mexican', 'latino', 'latina']},
    'cartoons': {'genres': ['children & family', 'anime'], 'keywords': ['caricaturas', 'nicktoons', 'animad']},
    'lista-populares': {'genres': [], 'keywords': ['destacado', 'popular', 'imperdibles', 'maratonear']},
    'lista-mejor-valoradas': {'genres': [], 'keywords': ['imperdibles', 'destacado', 'maratonear']},
    'lista-tendencias': {'genres': [], 'keywords': ['destacado', 'nuevo', 'semana']},
    'lista-recien-estrenadas': {'genres': [], 'keywords': ['nuevo en pluto', 'nuevo']},
    'lista-retro': {'genres': [], 'keywords': ['clasic', 'retro', 'nostalgia']},
    'lista-en-emision': {'genres': [], 'keywords': []},
}


def _is_movie(raw):
    if raw.get('type') == 'movie' or raw.get('_is_movie_override'):
        return True
    if raw.get('type') == 'series' and raw.get('seasonsNumbers') == [1]:
        cats = raw.get('_categories') or set()
        cats_norm = {_norm(c) for c in cats}
        if any(any(k in cn for k in _CINE_KEYWORDS) for cn in cats_norm):
            return True
    return False


def _match_genre(item, genre_slug):
    slug = _norm(genre_slug).strip()
    if not slug:
        return True
    rule = GENRE_RULES.get(slug)
    it_g = _norm(item.get('genre'))
    it_cats = {_norm(c) for c in (item.get('_categories') or ())}
    if rule:
        if it_g and any(g in it_g for g in rule['genres']):
            return True
        if any(any(k in c for k in rule['keywords']) for c in it_cats):
            return True
        if not rule['genres'] and not rule['keywords'] and slug == 'lista-en-emision':
            return True
        return False
    clean = slug.replace('-', ' ')
    return clean in it_g or any(clean in c for c in it_cats)


def _json(url, headers=None):
    request = urllib.request.Request(url, headers=dict({'User-Agent': UA, 'Accept': 'application/json'}, **(headers or {})))
    with network.abrir_url(request, timeout=15) as response:
        data = response.read(16 * 1024 * 1024 + 1)
    if len(data) > 16 * 1024 * 1024:
        raise network.ServidorNoDisponible('Pluto VOD: respuesta excesiva')
    return json.loads(data)


def _boot():
    params = {'appName': 'web', 'appVersion': '9.1.0', 'deviceVersion': '122.0.0',
              'deviceModel': 'web', 'deviceMake': 'chrome', 'deviceType': 'web',
              'clientID': str(uuid.uuid4()), 'clientModelNumber': '1.0.0'}
    data = _json(BOOT + '?' + urllib.parse.urlencode(params))
    if not data.get('sessionToken'):
        raise network.ServidorNoDisponible('Pluto VOD: sesión no disponible')
    return data


def _catalog():
    global _cached
    with _lock:
        if _cached[1] and time.monotonic() - _cached[0] < 600:
            return _cached[1]
    params = {'deviceId': str(uuid.uuid4()), 'deviceType': 'web', 'deviceMake': 'chrome',
              'deviceModel': 'web', 'appName': 'web', 'appVersion': '9.1.0',
              'includeItems': 'true', 'offset': 1000}
    data = _json(CATALOG + '?' + urllib.parse.urlencode(params))
    items = {}
    for category in data.get('categories') or []:
        cat_name = category.get('name') or ''
        for entry in category.get('items') or []:
            if entry.get('type') in ('movie', 'series') and entry.get('_id'):
                item = items.setdefault(entry['_id'], entry)
                if cat_name:
                    item.setdefault('_categories', set()).add(cat_name)
    for item in items.values():
        if _is_movie(item):
            item['_is_movie_override'] = True
    with _lock:
        _cached = (time.monotonic(), list(items.values()))
        return _cached[1]


def _norm(value):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(value or '').casefold())
                   if not unicodedata.combining(c))


def _card(raw):
    series = not _is_movie(raw)
    ident = raw['_id']
    covers = raw.get('covers') or []
    return {'title': raw.get('name') or ident, 'url': 'plutovod://{}/{}'.format('series' if series else 'movie', ident),
            'source': 'plutovod', 'section': 'series' if series else 'peliculas', 'is_serie': series,
            'cover': (covers[0].get('url') if covers else '') or '',
            'fanart': (raw.get('featuredImage') or {}).get('path') or '',
            'plot': raw.get('summary') or raw.get('description') or '',
            'genres': [raw['genre']] if raw.get('genre') else []}


def search(query, section='all'):
    needle = _norm(query).strip()
    if not needle:
        return []
    return [_card(item) for item in _catalog() if needle in _norm(item.get('name'))
            and (section == 'all' or (not _is_movie(item)) == (section == 'series'))]


def page(section, number, genre=None, preview=False):
    if section not in ('peliculas', 'series'):
        return [], False
    is_sec_series = (section == 'series')
    entries = [item for item in _catalog() if (not _is_movie(item)) == is_sec_series
               and (not genre or _match_genre(item, genre))]
    start = (max(1, int(number)) - 1) * 40
    count = 3 if preview else 40
    return [_card(item) for item in entries[start:start + count]], start + count < len(entries)


def episodes(series):
    ident = urllib.parse.urlsplit(series.get('url', '')).path.strip('/')
    if not ident or not series.get('url', '').startswith('plutovod://series/'):
        return {}
    session = _boot()
    url = VOD + '/series/' + urllib.parse.quote(ident) + '/seasons?offset=1000&page=1'
    data = _json(url, {'Authorization': 'Bearer ' + session['sessionToken']})
    result = {}
    for season in data.get('seasons') or []:
        number = str(season.get('number') or '')
        for episode in season.get('episodes') or []:
            ep = str(episode.get('number') or '')
            if not number.isdigit() or not ep.isdigit() or not episode.get('_id'):
                continue
            result.setdefault(number, []).append({
                'title': 'T{}:E{} - {}'.format(number, ep, episode.get('name') or 'Episodio'),
                'url': 'plutovod://episode/{}/{}'.format(ident, episode['_id']),
                'source': 'plutovod', 'section': 'series', 'is_serie': True, 'is_episode': True,
                'season': number, 'episode': ep, 'serie_title': series.get('title') or '',
                'cover': series.get('cover') or ''})
    return result


def servers(item, series=None):
    url = item.get('url', '')
    if not url.startswith('plutovod://'):
        return []
    return [{'nombre': 'PLUTO TV con Publicidad', 'url': url, 'source': 'plutovod',
             'calidad': 'Sin verificar'}]


def resolve(url):
    parsed = urllib.parse.urlsplit(url)
    kind, ids = parsed.netloc, parsed.path.strip('/').split('/')
    if kind not in ('movie', 'episode') or not ids or not all(ids):
        raise network.ServidorNoDisponible('Pluto VOD: identificador inválido')
    session = _boot()
    headers = {'Authorization': 'Bearer ' + session['sessionToken']}
    if kind == 'movie':
        data = _json(VOD + '/items?ids=' + urllib.parse.quote(ids[0]), headers)
        item = data[0] if isinstance(data, list) and data else {}
        path = (item.get('stitched') or {}).get('path') or ''
        if not path:
            try:
                sdata = _json(VOD + '/series/' + urllib.parse.quote(ids[0]) + '/seasons?offset=1000&page=1', headers)
                if isinstance(sdata, dict):
                    ep = next((e for s in sdata.get('seasons') or [] for e in s.get('episodes') or []
                               if (e.get('stitched') or {}).get('path')), None)
                    if ep:
                        path = (ep.get('stitched') or {}).get('path') or ''
            except Exception:
                pass
    else:
        data = _json(VOD + '/series/' + urllib.parse.quote(ids[0]) + '/seasons?offset=1000&page=1', headers)
        item = next((ep for season in data.get('seasons') or [] for ep in season.get('episodes') or []
                     if ep.get('_id') == ids[-1]), {})
        path = (item.get('stitched') or {}).get('path') or ''
    if not path.startswith(('/stitch/hls/', '/v2/stitch/hls/')):
        raise network.ServidorNoDisponible('Pluto VOD: título sin HLS')
    if path.startswith('/stitch/'):
        path = '/v2' + path
    root = (session.get('servers') or {}).get('stitcher') or ''
    if not root.startswith('https://'):
        raise network.ServidorNoDisponible('Pluto VOD: stitcher inválido')
    params = {'jwt': session['sessionToken'], 'masterJWTPassthrough': 'true',
              'includeExtendedEvents': 'true'}
    extra = session.get('stitcherParams') or {}
    if isinstance(extra, str):
        extra = dict(urllib.parse.parse_qsl(extra.lstrip('?&')))
    if isinstance(extra, dict):
        params.update({k: str(v) for k, v in extra.items()})
    media = root.rstrip('/') + path + '?' + urllib.parse.urlencode(params)
    kodi_headers = {'Origin': 'https://pluto.tv', 'Referer': 'https://pluto.tv/', 'User-Agent': UA}
    return media + '|' + urllib.parse.urlencode(kodi_headers)
