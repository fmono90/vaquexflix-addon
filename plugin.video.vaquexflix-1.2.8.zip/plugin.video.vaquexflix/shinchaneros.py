# -*- coding: utf-8 -*-
"""
shinchaneros.py - Módulo de integración para ShinChaneros (https://shinchaneros.tv/).
Proporciona acceso de alta velocidad a:
  - Las 33 películas completas de Shin-chan (1993 - 2025) en doblaje castellano.
  - Las 27 temporadas (+1,000 episodios) de la serie de televisión.
  - Canal 24/7 en directo con sincronización en tiempo real (/api/live/state).
Los vídeos están alojados en play.shinchaneros.tv con soporte HTTP 206 (Range requests).
"""

import json
import os
import re
import threading
import unicodedata
import urllib.parse
import urllib.request
import source_switches

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SEED_FILE = os.path.join(BASE_DIR, "resources", "shinchaneros_seed.json")

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
DEFAULT_REFERER = "https://shinchaneros.tv/"


def _formatear_stream(video_url):
    """Genera la URL con cabeceras HTTP necesarias para bypass de protección Cloudflare."""
    clean = str(video_url or "").split("|", 1)[0].strip()
    return (
        f"{clean}|User-Agent={urllib.parse.quote_plus(DEFAULT_UA)}"
        f"&Referer={urllib.parse.quote_plus(DEFAULT_REFERER)}"
    )

# TMDb IDs oficiales
TMDB_SERIES_JAPAN = 30623   # Crayon Shin-chan (Canónica TMDb con micro-segmentos)
TMDB_SERIES_SPAIN = 333589  # Shin Chan (TMDb 27 temporadas en orden español)
TMDB_SERIES_IDS = {TMDB_SERIES_JAPAN, TMDB_SERIES_SPAIN}

# 33 Películas de Shin-chan mapeadas por TMDb Movie ID
TMDB_MOVIE_IDS = {
    128868, 109526, 104154, 128871, 89458, 128875, 128878, 117087,
    37280, 117084, 103124, 160446, 128881, 128883, 128884, 128867,
    128887, 117352, 163754, 163772, 163786, 305143, 371236, 424656,
    453575, 507562, 596302, 731249, 795564, 955666, 1059572, 1221404,
    1404404
}

LIVE_API_URL = "https://shinchaneros.tv/api/live/state"

_LOCK = threading.RLock()
_SEED_DATA = None


def _normalizar_texto(texto):
    if not texto:
        return ""
    texto = unicodedata.normalize("NFKD", str(texto))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"[^\w\s]", " ", texto.lower()).strip()


def _cargar_seed():
    global _SEED_DATA
    with _LOCK:
        if _SEED_DATA is not None:
            return _SEED_DATA
        if os.path.isfile(SEED_FILE):
            try:
                with open(SEED_FILE, "r", encoding="utf-8") as f:
                    _SEED_DATA = json.load(f)
            except Exception:
                _SEED_DATA = {}
        else:
            _SEED_DATA = {}
        return _SEED_DATA


def owns(item_or_series):
    """Comprueba si un elemento o serie pertenece a ShinChaneros."""
    if not item_or_series:
        return False
    if isinstance(item_or_series, str):
        url = item_or_series
        if "shinchaneros" in url:
            return True
        m_tv = re.search(r"lolplus://tv/(\d+)", url)
        if m_tv:
            try:
                if int(m_tv.group(1)) in TMDB_SERIES_IDS:
                    return True
            except (ValueError, TypeError):
                pass
        m_movie = re.search(r"lolplus://movie/(\d+)", url)
        if m_movie:
            try:
                if int(m_movie.group(1)) in TMDB_MOVIE_IDS:
                    return True
            except (ValueError, TypeError):
                pass
        return False

    if not isinstance(item_or_series, dict):
        return False

    tmdb = item_or_series.get("tmdb_id")
    if tmdb is not None:
        try:
            val = int(tmdb)
            if val in TMDB_SERIES_IDS or val in TMDB_MOVIE_IDS:
                return True
        except (ValueError, TypeError):
            pass

    url = str(item_or_series.get("url") or "")
    if "shinchaneros" in url:
        return True

    m_tv = re.search(r"lolplus://tv/(\d+)", url)
    if m_tv:
        try:
            if int(m_tv.group(1)) in TMDB_SERIES_IDS:
                return True
        except (ValueError, TypeError):
            pass

    m_movie = re.search(r"lolplus://movie/(\d+)", url)
    if m_movie:
        try:
            if int(m_movie.group(1)) in TMDB_MOVIE_IDS:
                return True
        except (ValueError, TypeError):
            pass

    # Comprobar títulos representativos
    for key in ("title", "serie_title", "original_title", "name"):
        val = _normalizar_texto(item_or_series.get(key))
        if not val:
            continue
        val_compact = re.sub(r"[\s\-_]+", "", val)
        if "shinchan" in val_compact or "shinchan" in val or "crayonshinchan" in val_compact:
            return True

    return False


def get_movie_by_item(item):
    """Localiza los datos de la película en la base de datos de ShinChaneros."""
    if not item or not isinstance(item, dict):
        return None

    seed = _cargar_seed()
    movies_map = seed.get("movies", {})

    # 1. Búsqueda por TMDb ID
    tmdb = item.get("tmdb_id")
    if tmdb is not None:
        try:
            tmdb_str = str(int(tmdb))
            if tmdb_str in movies_map:
                return movies_map[tmdb_str]
        except (ValueError, TypeError):
            pass

    # 2. Búsqueda por slug en URL
    url = str(item.get("url") or "")
    for movie in movies_map.values():
        slug = movie.get("slug")
        if slug and (f"/{slug}" in url or f"/{slug}.mp4" in url):
            return movie

    # 3. Búsqueda por título y año
    for key in ("title", "name", "original_title"):
        raw_val = item.get(key)
        if not raw_val:
            continue
        val = _normalizar_texto(raw_val)
        val_compact = re.sub(r"[\s\-_]+", "", val)
        if not val or ("shinchan" not in val_compact and "shin chan" not in val):
            continue
        for movie in movies_map.values():
            m_title = _normalizar_texto(movie.get("title"))
            if not m_title:
                continue
            # Comprobar coincidencia de palabras clave únicas
            m_keywords = [w for w in m_title.split() if w not in ("shin", "chan", "la", "el", "los", "las", "en", "de", "y")]
            if m_keywords and all(k in val for k in m_keywords[:2]):
                return movie

    return None


def extract_season_episode(item, series=None):
    """Extrae temporada y episodio de un elemento de serie."""
    season = item.get("season") if isinstance(item, dict) else None
    episode = item.get("episode") if isinstance(item, dict) else None

    if season is None and isinstance(item, dict):
        url = str(item.get("url") or "")
        m = re.search(r"[Ss](\d+)[Ee](\d+)", url)
        if m:
            season, episode = m.group(1), m.group(2)
        else:
            m2 = re.search(r"/seasons/(\d+)/(\d+)", url)
            if m2:
                season, episode = m2.group(1), m2.group(2)

    if series and isinstance(series, dict) and (season is None or episode is None):
        if season is None:
            season = series.get("season")
        if episode is None:
            episode = series.get("episode")

    try:
        s_int = int(season) if season is not None else None
    except (ValueError, TypeError):
        s_int = None

    try:
        e_int = int(episode) if episode is not None else None
    except (ValueError, TypeError):
        e_int = None

    return s_int, e_int


def get_episode_url(season, episode, tmdb_id=None):
    """
    Calcula la URL directa del episodio en play.shinchaneros.tv
    soportando tanto numeración relativa por temporada como índices globales y segmentos TMDb.
    """
    if season is None or episode is None:
        return None

    seed = _cargar_seed()
    seasons_summary = seed.get("seasons_summary", {})

    target_season = season
    target_global_id = None

    # Caso A: Ficha japonesa canónica TMDb 30623 (micro-segmentos de 7 min)
    # Ejemplo: T1 Ep 1-3 -> Cap 1, Ep 4-6 -> Cap 2, etc.
    if tmdb_id == TMDB_SERIES_JAPAN and season == 1:
        broadcast_ep = (episode - 1) // 3 + 1
        # Determinar a qué temporada pertenece el episodio emitido
        for s_str, s_info in seasons_summary.items():
            s_num = int(s_str)
            min_e = s_info.get("min_ep")
            max_e = s_info.get("max_ep")
            if min_e is not None and max_e is not None and min_e <= broadcast_ep <= max_e:
                target_season = s_num
                target_global_id = broadcast_ep
                break
        if target_global_id is None:
            target_global_id = broadcast_ep

    # Caso B: Temporada 1..27 normal
    if target_global_id is None:
        s_info = seasons_summary.get(str(target_season))
        if s_info:
            min_e = s_info.get("min_ep", 1)
            max_e = s_info.get("max_ep", 9999)
            ep_count = s_info.get("episode_count", 0)

            # Si el episodio solicitado está en el rango global (ej. S2 Ep 34..84)
            if min_e <= episode <= max_e:
                target_global_id = episode
            # Si el episodio solicitado es relativo a la temporada (ej. S2 Ep 1..51)
            elif 1 <= episode <= ep_count:
                target_global_id = min_e + episode - 1
            else:
                target_global_id = episode
        else:
            target_global_id = episode

    if target_season is not None and target_global_id is not None:
        return f"https://play.shinchaneros.tv/{target_season:02d}x{target_global_id:03d}.mp4"

    return None


def resolve_live():
    """
    Obtiene la URL directa y metadata de la emisión en vivo 24/7 con cabeceras anti-hotlink.
    """
    try:
        req = urllib.request.Request(
            LIVE_API_URL,
            headers={"User-Agent": DEFAULT_UA, "Referer": DEFAULT_REFERER}
        )
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            current = data.get("current", {})
            src = current.get("src")
            if src:
                return _formatear_stream(src)
    except Exception:
        pass
    # Fallback predeterminado de respaldo
    return _formatear_stream("https://play.shinchaneros.tv/01x001.mp4")


def resolve(url_servidor):
    """Resuelve o formatea un enlace de ShinChaneros para reproducción directa en Kodi."""
    if not url_servidor:
        return None
    clean = str(url_servidor).split("|", 1)[0].strip()
    if clean.startswith("shinchaneros://") or clean == "live":
        return resolve_live()
    return _formatear_stream(clean)


def search(query, section="all"):
    """
    Busca películas y la serie de Shin-chan en la base de datos de ShinChaneros.
    Permite encontrar todo el catálogo mediante búsquedas como 'shinchan', 'shin-chan', 'shin'
    o por el título específico de cualquiera de las 33 películas.
    """
    if not source_switches.enabled("shinchaneros"):
        return []

    q_norm = _normalizar_texto(query)
    if not q_norm:
        return []

    q_compact = re.sub(r"[\s\-_]+", "", q_norm)
    is_general_query = any(k in q_compact for k in ("shin", "shinchan", "crayon", "nohara", "kasukabe"))

    seed = _cargar_seed()
    movies_map = seed.get("movies", {})
    results = []

    # 1. Serie Shin-chan (si la sección es all, series o animes)
    if section in ("all", "series", "animes", "anime") and is_general_query:
        results.append({
            "title": "Shin Chan (Serie Completa - 27 Temporadas)",
            "original_title": "Crayon Shin-chan",
            "url": "lolplus://tv/333589",
            "cover": "https://shinchaneros.tv/shinchaneros-logo.png",
            "plot": "Las divertidas y alocadas aventuras de Shinnosuke Nohara (Shin-chan), su hermana Himawari, sus padres Misae y Hiroshi, y su perro Nevado en Kasukabe.",
            "year": "1992",
            "is_serie": True,
            "section": "series",
            "source": "shinchaneros",
            "tmdb_id": TMDB_SERIES_SPAIN
        })

    # 2. Películas de Shin-chan (si la sección es all, peliculas o animes)
    if section in ("all", "peliculas", "animes", "anime"):
        for tmdb_id_str, movie in movies_map.items():
            m_title = movie.get("title", "")
            m_norm = _normalizar_texto(m_title)
            m_compact = re.sub(r"[\s\-_]+", "", m_norm)

            # Coincidencia si es búsqueda general de Shin-chan o si coincide el título específico
            if (is_general_query or q_norm in m_norm or q_compact in m_compact
                    or any(w in m_norm for w in q_norm.split() if len(w) > 3)):
                try:
                    tid = int(tmdb_id_str)
                except Exception:
                    tid = None
                slug = movie.get("slug", "")
                video = movie.get("video") or f"https://play.shinchaneros.tv/{slug}.mp4"
                poster = movie.get("poster") or f"https://shinchaneros.tv/posters/{slug}.webp"
                results.append({
                    "title": m_title,
                    "original_title": m_title,
                    "url": video,
                    "cover": poster,
                    "plot": f"Película completa en castellano: {m_title} ({movie.get('year', '')}).",
                    "year": str(movie.get("year", "")),
                    "is_serie": False,
                    "section": "peliculas",
                    "source": "shinchaneros",
                    "tmdb_id": tid
                })

    return results


def servers(item, series=None):
    """
    Devuelve los servidores de reproducción directa de ShinChaneros
    para películas o episodios de serie con cabeceras completas User-Agent y Referer.
    """
    if not source_switches.enabled("shinchaneros"):
        return []

    root = series or item
    if not owns(root) and not owns(item):
        return []

    # 1. Comprobar si es el canal en directo
    url_req = str((item or {}).get("url") or "")
    if "shinchaneros://live" in url_req or url_req == "live":
        stream_url = resolve_live()
        return [{
            "nombre": "ShinChaneros [Directo 24/7]",
            "url": stream_url,
            "source": "shinchaneros",
            "calidad": "1080p",
            "idioma": "Castellano",
        }]

    # 2. Comprobar si es una película
    movie = get_movie_by_item(item)
    if movie:
        video_url = movie.get("video")
        if not video_url:
            slug = movie.get("slug")
            video_url = f"https://play.shinchaneros.tv/{slug}.mp4"
        stream_url = _formatear_stream(video_url)
        return [{
            "nombre": "ShinChaneros [Directo]",
            "url": stream_url,
            "source": "shinchaneros",
            "calidad": "1080p",
            "idioma": "Castellano",
        }]

    # 3. Comprobar si es un episodio de serie
    season, episode = extract_season_episode(item, series)
    if season is not None and episode is not None:
        tmdb_val = None
        for c in (item, series):
            if isinstance(c, dict) and c.get("tmdb_id"):
                try:
                    tmdb_val = int(c.get("tmdb_id"))
                    break
                except (ValueError, TypeError):
                    pass
        video_url = get_episode_url(season, episode, tmdb_id=tmdb_val)
        if video_url:
            stream_url = _formatear_stream(video_url)
            return [{
                "nombre": "ShinChaneros [Directo]",
                "url": stream_url,
                "source": "shinchaneros",
                "calidad": "1080p",
                "idioma": "Castellano",
            }]

    return []


def obtener_servidores(item, series=None):
    """Alias canónico para compatibilidad con servidores.py."""
    return servers(item, series=series)
