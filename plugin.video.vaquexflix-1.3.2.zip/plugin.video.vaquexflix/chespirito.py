"""
Módulo de integración para la Colección Chespirito desde MediaFire.
Series integradas:
  1. El Chavo (TMDb ID: 47) - 7 temporadas (1973-1979)
  2. El Chapulín Colorado (TMDb ID: 13023) - 7 temporadas (1973-1979)
  3. Chespirito (TMDb ID: 105590) - 16 temporadas (1980-1995)
Sincroniza los episodios con las fichas de TMDb y entrega enlaces directos
de MediaFire para su resolución y reproducción en streaming.
"""

import json
import os
import re
import threading
import unicodedata

TMDB_IDS = {47, 13023, 105590}
TMDB_CHAVO = 47
TMDB_CHAPULIN = 13023
TMDB_CHESPIRITO = 105590

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SEED_FILE = os.path.join(BASE_DIR, "resources", "chespirito_seed.json")

_LOCK = threading.RLock()
_SEED_DATA = None


def _normalizar_texto(texto):
    if not texto:
        return ""
    texto = unicodedata.normalize("NFKD", str(texto))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"[^\w\s]", " ", texto.lower()).strip()


def _cargar_seed():
    global _SEED_DATA
    with _LOCK:
        if _SEED_DATA is not None:
            return _SEED_DATA
        if os.path.isfile(SEED_FILE):
            try:
                with open(SEED_FILE, "r", encoding="utf-8") as f:
                    _SEED_DATA = json.load(f)
            except Exception:
                _SEED_DATA = {}
        else:
            _SEED_DATA = {}
        return _SEED_DATA


def owns(item_or_series):
    """Comprueba si un elemento o serie pertenece a la Colección Chespirito."""
    if not item_or_series or not isinstance(item_or_series, dict):
        return False

    tmdb = item_or_series.get("tmdb_id")
    if tmdb is not None:
        try:
            if int(tmdb) in TMDB_IDS:
                return True
        except (ValueError, TypeError):
            pass

    url = str(item_or_series.get("url") or "")
    m_url = re.search(r"lolplus://tv/(\d+)", url)
    if m_url:
        try:
            if int(m_url.group(1)) in TMDB_IDS:
                return True
        except (ValueError, TypeError):
            pass

    if "chespirito_seed" in url or item_or_series.get("source") == "chespirito":
        return True

    # Comprobar títulos representativos
    for key in ("title", "serie_title", "original_title", "name"):
        val = _normalizar_texto(item_or_series.get(key))
        if not val:
            continue
        if "el chavo" in val or "el chapulin colorado" in val:
            return True
        if val == "chespirito" or val.startswith("chespirito "):
            # Evitar confundir con documentales como "sin querer queriendo"
            if "sin querer queriendo" not in val and "biografia" not in val:
                return True

    return False


def get_tmdb_id(item, series=None):
    """Extrae el TMDb ID asociado a la serie Chespirito."""
    candidates = [item, series]
    for c in candidates:
        if not c or not isinstance(c, dict):
            continue
        tmdb = c.get("tmdb_id")
        if tmdb is not None:
            try:
                val = int(tmdb)
                if val in TMDB_IDS:
                    return val
            except (ValueError, TypeError):
                pass
        url = str(c.get("url") or "")
        m = re.search(r"lolplus://tv/(\d+)", url)
        if m:
            try:
                val = int(m.group(1))
                if val in TMDB_IDS:
                    return val
            except (ValueError, TypeError):
                pass

    for c in candidates:
        if not c or not isinstance(c, dict):
            continue
        for key in ("title", "serie_title", "original_title", "name"):
            val = _normalizar_texto(c.get(key))
            if not val:
                continue
            if "el chavo" in val:
                return TMDB_CHAVO
            if "el chapulin colorado" in val:
                return TMDB_CHAPULIN
            if "chespirito" in val and "sin querer" not in val:
                return TMDB_CHESPIRITO

    return None


def extract_season_episode(item, series=None):
    """Extrae temporada y episodio tanto de claves estándar como de URL o títulos."""
    season = None
    episode = None

    if item and isinstance(item, dict):
        season = item.get("season")
        episode = item.get("episode")
        if season is None or episode is None:
            url = str(item.get("url") or "")
            m_ep = re.search(r"lolplus://tv/\d+/(\d+)/(\d+)", url)
            if m_ep:
                season = int(m_ep.group(1))
                episode = int(m_ep.group(2))

        if season is None or episode is None:
            name_str = f"{item.get('name', '')} {item.get('title', '')}"
            m_sx = re.search(r"(\d+)[xX](\d+)", name_str)
            if m_sx:
                season = int(m_sx.group(1))
                episode = int(m_sx.group(2))
            else:
                m_se = re.search(r"T(\d+)[\s:_-]*E(\d+)", name_str, re.IGNORECASE)
                if m_se:
                    season = int(m_se.group(1))
                    episode = int(m_se.group(2))

    if series and isinstance(series, dict) and (season is None or episode is None):
        if season is None:
            season = series.get("season")
        if episode is None:
            episode = series.get("episode")

    try:
        s_int = int(season) if season is not None else None
    except (ValueError, TypeError):
        s_int = None

    try:
        e_int = int(episode) if episode is not None else None
    except (ValueError, TypeError):
        e_int = None

    return s_int, e_int


def servers(item, series=None):
    """
    Devuelve los servidores de MediaFire para el episodio solicitado
    de El Chavo, El Chapulín Colorado o Chespirito.
    """
    root = series or item
    if not owns(root) and not owns(item):
        return []

    tmdb_id = get_tmdb_id(item, series)
    if not tmdb_id:
        return []

    season, episode = extract_season_episode(item, series)
    if season is None or episode is None:
        return []

    seed = _cargar_seed()
    series_map = seed.get(str(tmdb_id), {})
    key = f"{season}x{episode}"
    entries = series_map.get(key)
    if not entries:
        return []

    results = []
    for idx, entry in enumerate(entries):
        url = entry.get("url")
        if not url:
            continue
        filename = entry.get("file", "")
        suffix = ""
        if "portugués" in filename.lower() or "portugues" in filename.lower():
            suffix = " (Portugués)"
        elif len(entries) > 1 and idx > 0:
            suffix = f" (Opción {idx + 1})"

        nombre = entry.get("nombre")
        if not nombre:
            if "ok.ru" in url:
                nombre = f"Ok.ru [Colección Chespirito{suffix}]"
            else:
                nombre = f"MediaFire [Colección Chespirito{suffix}]"

        idioma = entry.get("idioma")
        if not idioma:
            idioma = "Latino" if "portugu" not in suffix.lower() else "Portugués"

        results.append({
            "nombre": nombre,
            "url": url,
            "source": "chespirito",
            "calidad": "Sin verificar",
            "idioma": idioma,
        })

    return results


def enrich_episodes(episodes_by_season):
    """
    Enriquece la lista de episodios de Chespirito cuando faltan datos en TMDb
    (como el episodio 1 de la temporada 1980, el cual es un episodio perdido).
    """
    if not isinstance(episodes_by_season, dict):
        return episodes_by_season

    s1 = episodes_by_season.get("1") or episodes_by_season.get(1)
    if s1 and isinstance(s1, list):
        for ep in s1:
            if str(ep.get("episode")) == "1":
                name = ep.get("name", "")
                if not name or name.lower() in ("episode 1", "episodio 1", "t1:e1"):
                    ep["name"] = "Episodio perdido"
                    ep["title"] = "T1:E1 - Episodio perdido"
                elif "[episodio perdido]" not in name.lower():
                    ep["name"] = f"{name} [Episodio perdido]"
                    ep["title"] = f"{ep.get('title', name)} [Episodio perdido]"
                if not ep.get("plot"):
                    ep["plot"] = (
                        "Primer episodio de la temporada 1980 "
                        "(Episodio perdido mundial transmitido originalmente por Chilevisión)."
                    )
    return episodes_by_season


def obtener_servidores(item, series=None):
    """Alias para compatibilidad con servidores.py."""
    return servers(item, series=series)
