"""MGDK: public catalog and per-server playback routes.

The provider owns its catalog and the three players. Signed media URLs are
never persisted in cards; a server is resolved again when selected.
"""
import hashlib
import html
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import network

CATALOG_URL = 'https://bigscreen-api.aratrok599.workers.dev/catalogo.json'
BASE = 'https://mangadake.com'
UA = 'Mozilla/5.0'
_PAGE_SIZE = 40
_lock = threading.RLock()
_catalog_data = (0.0, [])
_server_state = {}
_inventory_cache = {}


def _read(url, headers=None, limit=2 * 1024 * 1024, timeout=12):
    req = urllib.request.Request(url, headers=dict({'User-Agent': UA}, **(headers or {})))
    with network.abrir_url(req, timeout=timeout) as response:
        body = response.read(limit + 1)
        if len(body) > limit:
            raise network.ServidorNoDisponible('MGDK: respuesta demasiado grande')
        return body.decode('utf-8-sig', 'replace'), response.geturl()


def _json(url, headers=None, data=None, timeout=12):
    hdr = dict({'User-Agent': UA, 'Accept': 'application/json'}, **(headers or {}))
    if data is not None:
        hdr['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8') if data is not None else None,
                                 headers=hdr)
    with network.abrir_url(req, timeout=timeout) as response:
        raw = response.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise network.ServidorNoDisponible('MGDK: respuesta JSON demasiado grande')
    return json.loads(raw)


def _catalog():
    global _catalog_data
    with _lock:
        updated, items = _catalog_data
        if items and time.monotonic() - updated < 900:
            return items
    error = None
    for url in (CATALOG_URL, BASE + '/catalogo.json'):
        try:
            data = _json(url)
            if not isinstance(data, list):
                raise ValueError('MGDK: catálogo inválido')
            items = [x for x in data if isinstance(x, dict) and not x.get('hidden')
                     and x.get('tmdb_id') and x.get('type') in ('pelicula', 'serie')]
            with _lock:
                _catalog_data = (time.monotonic(), items)
            return items
        except (OSError, ValueError, TypeError, urllib.error.URLError) as exc:
            error = exc
    with _lock:
        if _catalog_data[1]:
            return _catalog_data[1]
    raise network.ServidorNoDisponible('MGDK: catálogo no disponible ({})'.format(type(error).__name__))


def _card(raw):
    tv = raw['type'] == 'serie'
    ident = str(raw['tmdb_id'])
    return {
        'title': raw.get('title') or ident,
        'original_title': raw.get('title') or ident,
        'url': 'mgdk://{}/{}'.format('tv' if tv else 'movie', ident),
        'source': 'mgdk', 'section': 'series' if tv else 'peliculas',
        'is_serie': tv, 'tmdb_id': int(ident),
        'year': str(raw.get('year') or ''), 'cover': raw.get('poster') or '',
        'fanart': raw.get('backdrop') or '', 'plot': raw.get('synopsis') or '',
        'genres': list(raw.get('genres') or []), 'rating': raw.get('rating') or 0,
        'mgdk_seasons': list(raw.get('seasons_detail') or []),
        'mgdk_episodes': raw.get('episodes') or 0,
    }


def owns(url):
    return isinstance(url, str) and url.startswith('mgdk://')


def _kind(section):
    return 'serie' if section in ('series', 'tv') else 'pelicula'


def search(query, section='all'):
    import unicodedata
    def norm(value):
        return ''.join(c for c in unicodedata.normalize('NFKD', str(value or '').casefold())
                       if not unicodedata.combining(c))
    needle = norm(query).strip()
    if not needle:
        return []
    return [_card(x) for x in _catalog() if needle in norm(x.get('title'))
            and (section == 'all' or x.get('type') == _kind(section))]


def page(section, number, genre=None, preview=False):
    if section not in ('peliculas', 'series'):
        return [], False
    import unicodedata
    def norm(value):
        return ''.join(c for c in unicodedata.normalize('NFKD', str(value or '').casefold())
                       if not unicodedata.combining(c)).replace(' ', '-').replace('&', '-')
    aliases = {
        'ciencia-ficcion': {'ciencia-ficcion', 'sci-fi---fantasy'},
        'fantasia': {'fantasia', 'sci-fi---fantasy'},
        'accion': {'accion', 'action---adventure'},
        'aventura': {'aventura', 'action---adventure'},
        'suspense': {'suspense', 'suspenso'},
        'guerra': {'belica', 'war---politics'},
        'infantil': {'kids', 'familia'},
    }
    matched_genres = aliases.get(norm(genre), {norm(genre)}) if genre else set()
    entries = [x for x in _catalog() if x.get('type') == _kind(section)
               and (not genre or matched_genres.intersection(norm(g) for g in x.get('genres') or []))]
    entries.sort(key=lambda x: int(x.get('id') or 0), reverse=True)
    size = 3 if preview else _PAGE_SIZE
    start = (max(1, int(number)) - 1) * _PAGE_SIZE
    result = entries[start:start + size]
    return [_card(x) for x in result], start + size < len(entries)


def episodes(series):
    ident = series.get('tmdb_id')
    if not ident:
        return {}
    seasons = series.get('mgdk_seasons') or []
    if not seasons:
        raw = next((x for x in _catalog() if str(x.get('tmdb_id')) == str(ident)
                    and x.get('type') == 'serie'), None)
        seasons = (raw or {}).get('seasons_detail') or []
    if not seasons and series.get('mgdk_episodes'):
        seasons = [{'season_number': 1, 'episode_count': series['mgdk_episodes']}]
    result = {}
    for season in seasons:
        number = int(season.get('season_number') or 0)
        count = min(1000, int(season.get('episode_count') or 0))
        if number < 1 or count < 1:
            continue
        result[str(number)] = [{
            'title': 'T{}:E{} - Episodio {}'.format(number, ep, ep),
            'url': 'mgdk://tv/{}/{}/{}'.format(ident, number, ep),
            'source': 'mgdk', 'section': 'series', 'is_serie': True,
            'is_episode': True, 'tmdb_id': ident, 'season': str(number),
            'episode': str(ep), 'serie_title': series.get('title') or '',
            'cover': series.get('cover') or '',
        } for ep in range(1, count + 1)]
    return result


def _embed_urls(ident, season=None, episode=None):
    if season and episode:
        return (
            'https://unlimplay.com/f/embed/tv/{}/{}/{}'.format(ident, season, episode),
            'https://api.moviemaster.lat/e/tv/{}/{}/{}?skin=cine&color=f59e0b'.format(ident, season, episode),
            'https://facilitoplay.com/e/serie/{}/{}/{}'.format(ident, season, episode),
        )
    return (
        'https://unlimplay.com/f/embed/movie/{}'.format(ident),
        'https://api.moviemaster.lat/e/movie/{}?skin=cine&color=f59e0b'.format(ident),
        'https://facilitoplay.com/e/pelicula/{}'.format(ident),
    )


def _unlim(embed):
    page, final = _read(embed, headers={'Referer': BASE + '/'})
    match = re.search(r'const\s+EMBEDS\s*=\s*(\{.*?\});', page, re.S)
    if not match:
        raise network.ServidorNoDisponible('MGDK UnLimPlay: no publicó servidores')
    data = json.loads(match.group(1))
    return [(lang, name, url, final) for lang, group in data.items() if isinstance(group, dict)
            for name, url in group.items() if isinstance(url, str) and url.startswith('https://')]


def _movie(embed, ident, season, episode):
    page, _ = _read(embed, headers={'Referer': BASE + '/'})
    match = re.search(r'window\.PM_UI\s*=\s*"([A-Za-z0-9_-]+)"', page)
    if not match:
        raise network.ServidorNoDisponible('MGDK MovieMaster: falta token del iframe')
    params = {'tmdb': ident, 'type': 'tv' if season and episode else 'movie', 'ui': match.group(1)}
    if season and episode:
        params.update(season=season, episode=episode)
    data = _json('https://api.moviemaster.lat/servers?' + urllib.parse.urlencode(params),
                 headers={'Referer': embed})
    return [x for x in data.get('servers', []) if isinstance(x, dict) and x.get('video')]


def _facil(embed):
    page, _ = _read(embed, headers={'Referer': BASE + '/'})
    match = re.search(r'<script\s+id="config"\s+type="application/json">(.*?)</script>', page, re.S)
    if not match:
        raise network.ServidorNoDisponible('MGDK FacilitoPlay: falta configuración')
    token = json.loads(match.group(1)).get('token')
    if not token:
        raise network.ServidorNoDisponible('MGDK FacilitoPlay: falta token')
    headers = {'x-token': token, 'Referer': embed, 'Origin': 'https://facilitoplay.com'}
    data = _json('https://facilitoplay.com/api/links', headers=headers)
    result = [(lang.get('slug'), index, server, headers)
              for lang in data.get('languages', []) if isinstance(lang, dict)
              for index, server in enumerate(lang.get('servers') or [], 1)
              if isinstance(server, dict) and server.get('link_id')]
    return result


_LANGS = {'latino': 'Latino', 'español': 'Castellano', 'spanish': 'Castellano',
          'subtitulado': 'Subtitulado', 'english': 'Subtitulado',
          'LAT': 'Latino', 'ESP': 'Castellano', 'SUB': 'Subtitulado'}


def _stable_url(player, ident, season, episode, lang, index, fingerprint):
    key = hashlib.sha256(str(fingerprint).encode('utf-8')).hexdigest()[:16]
    return 'mgdk://server/{}/{}/{}/{}/{}/{}/{}'.format(
        player, ident, season or 0, episode or 0, urllib.parse.quote(str(lang), safe=''), index, key)


def _fingerprint(player, lang, entry):
    if player == 1:
        _, name, url, _ = entry
        return (lang, name, urllib.parse.urlsplit(url).hostname)
    if player == 2:
        return (lang, entry.get('name'), entry.get('site'), entry.get('src'))
    # FacilitoPlay gives only an opaque link_id for several otherwise identical
    # hosts. Keep it in the identity so a changed order cannot reuse quality.
    return (lang, entry.get('server'), entry.get('kind'), entry.get('link_id'))


def servers(item, series=None):
    root = series or item
    ident = item.get('tmdb_id') or root.get('tmdb_id')
    if not ident:
        return []
    season, episode = (item.get('season'), item.get('episode')) if series else (None, None)
    embeds = _embed_urls(ident, season, episode)
    with _lock:
        expired = [key for key, state in _server_state.items()
                   if time.monotonic() - state[0] > 900]
        for key in expired:
            _server_state.pop(key, None)
    result = []
    errors = []
    def load(entry):
        player, embed = entry
        try:
            if player == 1:
                inventory = _unlim(embed)
            elif player == 2:
                inventory = _movie(embed, ident, season, episode)
            else:
                inventory = _facil(embed)
            with _lock:
                previous = _inventory_cache.get(embed)
                if previous and time.monotonic() - previous[0] < 900 and len(previous[1]) > len(inventory):
                    return previous[1]
                _inventory_cache[embed] = (time.monotonic(), inventory)
            return inventory
        except Exception as exc:
            with _lock:
                previous = _inventory_cache.get(embed)
                if previous and time.monotonic() - previous[0] < 900:
                    network.log_resolver('MGDK: inventario anterior conservado para opción {} ({})'.format(player, exc))
                    return previous[1]
            return exc
    with ThreadPoolExecutor(max_workers=3) as pool:
        inventories = list(pool.map(load, enumerate(embeds, 1)))
    is_cross_content = bool(series and str(ident) == '105590')
    cross_error = ('Contenido cruzado: el proveedor entrega la serie biográfica '
                   'Chespirito: Sin querer queriendo (2025) por error de indexación.')
    for player, (embed, inventory) in enumerate(zip(embeds, inventories), 1):
        try:
            if isinstance(inventory, Exception):
                raise inventory
            if player == 1:
                for idx, (lang, name, url, referer) in enumerate(inventory, 1):
                    virtual = _stable_url(player, ident, season, episode, lang, idx,
                                          _fingerprint(player, lang, (lang, name, url, referer)))
                    nombre = 'MGDK Opción 1 · {} {}'.format(name, idx)
                    if is_cross_content:
                        nombre += ' [Contenido cruzado]'
                    card = {'nombre': nombre,
                            'url': virtual, 'source': 'mgdk', 'idioma': _LANGS.get(lang, lang),
                            'origin_url': url, 'calidad': 'Sin verificar'}
                    if is_cross_content:
                        card['resolver_status'] = 'pending'
                        card['resolver_error'] = cross_error
                    result.append(card)
                    with _lock:
                        _server_state[virtual] = (time.monotonic(), url, referer)
            elif player == 2:
                for idx, server in enumerate(inventory, 1):
                    lang = server.get('lang') or ''
                    virtual = _stable_url(player, ident, season, episode, lang, idx,
                                          _fingerprint(player, lang, server))
                    nombre = 'MGDK Opción 2 · {}'.format(server.get('name') or idx)
                    if is_cross_content:
                        nombre += ' [Contenido cruzado]'
                    card = {'nombre': nombre,
                            'url': virtual, 'source': 'mgdk', 'idioma': _LANGS.get(lang, lang),
                            'origin_url': server['video'], 'calidad': 'Sin verificar'}
                    if is_cross_content:
                        card['resolver_status'] = 'pending'
                        card['resolver_error'] = cross_error
                    result.append(card)
                    with _lock:
                        _server_state[virtual] = (time.monotonic(), server['video'], embed)
            else:
                for lang, idx, server, headers in inventory:
                    virtual = _stable_url(player, ident, season, episode, lang, idx,
                                          _fingerprint(player, lang, server))
                    state = server.get('status') or ''
                    label = 'MGDK Opción 3 · {} {}'.format(server.get('server') or 'Servidor', idx)
                    if is_cross_content:
                        label += ' [Contenido cruzado]'
                    elif state in ('fail', 'unconfirmed'):
                        label += ' [{}]'.format('Proveedor: falló' if state == 'fail' else 'Sin confirmar')
                    card = {'nombre': label, 'url': virtual, 'source': 'mgdk',
                            'idioma': _LANGS.get(lang, lang), 'calidad': 'Sin verificar',
                            'origin_url': embed}
                    if is_cross_content:
                        card['resolver_status'] = 'pending'
                        card['resolver_error'] = cross_error
                    result.append(card)
                    with _lock:
                        _server_state[virtual] = (time.monotonic(), server['link_id'], headers)
        except Exception as exc:
            errors.append('Opción {}: {}'.format(player, exc))
            result.append({'nombre': 'MGDK Opción {} · No disponible'.format(player),
                           'url': 'mgdk://error/{}/{}'.format(player, ident),
                           'source': 'mgdk', 'idioma': 'Otro', 'calidad': 'Sin verificar',
                           'origin_url': embed, 'resolver_status': 'pending',
                           'resolver_error': 'MGDK Opción {}: {}'.format(player, exc)[:180]})
    if errors:
        network.log_resolver('MGDK: ' + '; '.join(errors)[:300])
    return result


def _media(url, referer, use_proxy=False):
    import hls_proxy
    import resolvers
    host = (urllib.parse.urlsplit(url).hostname or '').lower()
    if not url.startswith('https://'):
        raise network.ServidorNoDisponible('MGDK: enlace inválido')
    path = urllib.parse.urlsplit(url).path.lower()
    query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    if host == 'unlimplay.com' and path == '/mf.php' and 'man' in query:
        url = url.replace('&ulpmf=1', '') + '&mode=hls'
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    is_hls = (path.endswith('.m3u8') or '/manifest' in path or '/video' in path or
              path.endswith('.txt') or (path == '/mf.php' and query.get('mode') == ['hls']) or
              (path.endswith('/cps.php') and
              any('.m3u8' in value for value in query.get('x', []))))
    if not is_hls:
        stream = resolvers.resolver_enlace_directo(url)
        if not stream:
            raise network.ServidorNoDisponible('MGDK: el iframe no entregó vídeo')
        return stream
    headers = {'User-Agent': UA, 'Referer': referer,
               'Origin': '{}://{}'.format(urllib.parse.urlsplit(referer).scheme,
                                        urllib.parse.urlsplit(referer).netloc)}
    manifest, final = _read(url, headers=headers, timeout=10)
    if not manifest.lstrip().startswith('#EXTM3U'):
        raise network.ServidorNoDisponible('MGDK: el servidor devolvió HTML o JSON, no HLS')
    if host == 'unlimplay.com':
        direct_match = re.search(r'/ulpx/([^/?#\s]+)(/vod/[^?#\s]+_media\.ts)', manifest)
        if direct_match:
            cdn_host = direct_match.group(1)
            cdn_path = direct_match.group(2)
            direct_url = 'http://' + cdn_host + cdn_path
            try:
                probe_req = urllib.request.Request(direct_url, headers={'Range': 'bytes=0-1000', 'User-Agent': UA})
                with urllib.request.urlopen(probe_req, timeout=3) as probe_resp:
                    if probe_resp.status in (200, 206):
                        return network.url_con_cabeceras(direct_url, {'User-Agent': UA})
            except Exception:
                pass
    if use_proxy or host in ('api-encrypted.moviemaster.lat', 'vsembed.com', 'vsembed.ru'):
        return hls_proxy.start(final, headers)
    if not urllib.parse.urlsplit(final).path.lower().endswith('.m3u8'):
        headers['ext'] = '.m3u8'
    return network.url_con_cabeceras(final, headers)


def resolve(virtual):
    parsed = urllib.parse.urlsplit(virtual)
    parts = parsed.path.strip('/').split('/')
    if parsed.scheme != 'mgdk' or parsed.netloc != 'server' or len(parts) != 7:
        raise network.ServidorNoDisponible('MGDK: servidor inválido')
    player, ident, season, episode, lang, index, fingerprint = parts
    if player not in ('1', '2', '3') or not ident.isdigit() or not index.isdigit():
        raise network.ServidorNoDisponible('MGDK: servidor inválido')
    season = season if season != '0' else None
    episode = episode if episode != '0' else None
    embed = _embed_urls(ident, season, episode)[int(player) - 1]
    with _lock:
        cached = _server_state.get(virtual)
    if player == '1':
        if cached and time.monotonic() - cached[0] < 90:
            url, referer = cached[1:]
        else:
            entries = _unlim(embed)
            entry = next((entry for entry in entries if entry[0] == urllib.parse.unquote(lang)
                          and _stable_url(player, ident, season, episode, lang, index,
                                          _fingerprint(1, entry[0], entry)).rsplit('/', 1)[-1] == fingerprint), None)
            if entry is None:
                raise network.ServidorNoDisponible('MGDK: servidor cambió en el proveedor; recarga la ficha')
            _, _, url, referer = entry
        return _media(url, referer)
    if player == '2':
        if cached and time.monotonic() - cached[0] < 90:
            url, referer = cached[1:]
        else:
            entries = _movie(embed, ident, season, episode)
            entry = next((entry for entry in entries if entry.get('lang') == urllib.parse.unquote(lang)
                          and _stable_url(player, ident, season, episode, lang, index,
                                          _fingerprint(2, entry.get('lang'), entry)).rsplit('/', 1)[-1] == fingerprint), None)
            if entry is None:
                raise network.ServidorNoDisponible('MGDK: servidor cambió en el proveedor; recarga la ficha')
            url, referer = entry['video'], embed
        return _media(url, referer, use_proxy=True)
    if cached and time.monotonic() - cached[0] < 900:
        link_id, headers = cached[1:]
    else:
        entries = _facil(embed)
        entry = next((x for x in entries if x[0] == urllib.parse.unquote(lang)
                      and x[1] == int(index)), None)
        if not entry:
            raise network.ServidorNoDisponible('MGDK: servidor cambió en el proveedor; recarga la ficha')
        if _stable_url(player, ident, season, episode, lang, index,
                       _fingerprint(3, entry[0], entry[2])).rsplit('/', 1)[-1] != fingerprint:
            raise network.ServidorNoDisponible('MGDK: servidor cambió en el proveedor; recarga la ficha')
        link_id, headers = entry[2]['link_id'], entry[3]
    data = _json('https://facilitoplay.com/api/resolve', headers=headers,
                 data={'link_id': link_id, 'iframe': False})
    url = data.get('url')
    if not url:
        raise network.ServidorNoDisponible('MGDK FacilitoPlay: no entregó enlace')
    return _media(url, embed, use_proxy=data.get('kind') == 'hls')
