# -*- coding: utf-8 -*-
"""
tgtv2.py - Proveedor y resolutor de TV en Vivo para TGTV2 (telegratis2.com / televisiongratishd.org).
Proporciona acceso al catálogo de señales en directo de TGTV2, resolviendo streams HLS (.m3u8)
con firma dinámica, tokens efímeros y cabeceras anti-hotlink requeridas por los CDN de origen.
"""
import os
import re
import json
import time
import html
import urllib.request
import urllib.parse
import ssl
import threading

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

MIRRORS = [
    "https://www.telegratis2.com",
    "https://www.televisiongratishd.org"
]

_SSL_CTX = None


def _get_ssl_context():
    global _SSL_CTX
    if _SSL_CTX is None:
        try:
            _SSL_CTX = ssl.create_default_context()
            _SSL_CTX.check_hostname = False
            _SSL_CTX.verify_mode = ssl.CERT_NONE
        except Exception:
            _SSL_CTX = None
    return _SSL_CTX


_CACHE_LOCK = threading.Lock()
_CHANNELS_DATA = None
_RESOLVE_CACHE = {}  # slug -> (kodi_url, timestamp)
_RESOLVE_TTL = 300   # 5 minutos


def _load_channels():
    global _CHANNELS_DATA
    with _CACHE_LOCK:
        if _CHANNELS_DATA is not None:
            return list(_CHANNELS_DATA)

        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, 'resources', 'tgtv2_channels.json')
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    _CHANNELS_DATA = json.load(f)
                    return list(_CHANNELS_DATA)
            except Exception:
                pass
        _CHANNELS_DATA = []
        return []


def is_enabled():
    try:
        import source_switches
        return source_switches.enabled('tgtv2')
    except Exception:
        return True


def get_channels(category_filter=None):
    """Retorna los canales registrados de TGTV2 si la fuente está activa."""
    if not is_enabled():
        return []
    channels = _load_channels()
    if category_filter:
        cat_lower = str(category_filter).lower().strip()
        channels = [c for c in channels if str(c.get('category', '')).lower() == cat_lower]
    return channels


def owns(url):
    """Determina si una URL o protocolo pertenece a TGTV2."""
    if not url or not isinstance(url, str):
        return False
    u = url.lower()
    return (
        u.startswith('tgtv2://')
        or 'telegratis2.com' in u
        or 'televisiongratishd.org' in u
        or 'ksdjugfssddeports.com' in u
        or 'saohgdassregions.com' in u
    )


def extract_slug(stream_url):
    """Extrae y normaliza el identificador del canal a partir de cualquier variante de enlace."""
    if not stream_url:
        return ''
    raw = stream_url.strip()
    if raw.startswith('tgtv2://'):
        raw = raw[8:].strip('/')
    if 'canal=' in raw:
        m = re.search(r'canal=([^&]+)', raw)
        if m:
            raw = m.group(1)
    if '?' in raw:
        raw = raw.split('?')[0]
    raw = raw.split('/')[-1]
    raw = re.sub(r'-en-vivo(?:\.php)?$', '', raw, flags=re.IGNORECASE)
    raw = raw.replace('.php', '').strip()
    return raw


def resolve(stream_url, raise_on_failure=False, timeout=8):
    """
    Resuelve un enlace de canal TGTV2 a su URL HLS .m3u8 final con firma efímera
    y cabeceras HTTP de reproducción requeridas por el CDN.
    """
    if not stream_url:
        if raise_on_failure:
            raise RuntimeError("TGTV2: URL de canal vacía.")
        return None

    slug = extract_slug(stream_url)
    if not slug:
        if raise_on_failure:
            raise RuntimeError(f"TGTV2: No se pudo extraer el slug del canal de '{stream_url}'.")
        return None

    # Opción preferida si se especificó explícitamente (ej. ?opt=2 o ?target=3)
    opt_m = re.search(r'[?&](?:opt|target)=(\d+)', stream_url)
    preferred_opt = int(opt_m.group(1)) if opt_m else None
    cache_key = f"{slug}_opt{preferred_opt}" if preferred_opt else slug

    # Comprobar si hay un stream cacheado vigente
    now = time.time()
    with _CACHE_LOCK:
        cached = _RESOLVE_CACHE.get(cache_key)
        if cached and (now - cached[1]) < _RESOLVE_TTL:
            return cached[0]

    ctx = _get_ssl_context()
    last_error = None

    # Priorizar la opción solicitada si existe
    opt_order = ['live', 'live2', 'live3']
    if preferred_opt == 2:
        opt_order = ['live2', 'live', 'live3']
    elif preferred_opt == 3:
        opt_order = ['live3', 'live', 'live2']

    # Probar candidatos en orden de prioridad: telegratis2.com y televisiongratishd.org
    candidates = []
    for mirror in MIRRORS:
        for opt_prefix in opt_order:
            candidates.append((mirror, f"{mirror}/{opt_prefix}/core.php?canal={slug}"))

    for mirror_base, core_url in candidates:
        try:
            # 1. Obtener el iframe con la firma HMAC efímera
            req_core = urllib.request.Request(
                core_url,
                headers={
                    'User-Agent': UA,
                    'Referer': f"{mirror_base}/"
                }
            )
            with urllib.request.urlopen(req_core, context=ctx, timeout=timeout) as resp_core:
                core_html = resp_core.read().decode('utf-8', errors='ignore')

            iframe_m = re.search(r'<iframe\s+[^>]*src=["\']([^"\']+)["\']', core_html)
            if iframe_m:
                stream_page_url = html.unescape(iframe_m.group(1))
            else:
                raw_m = re.search(r'(https?://[^\s"\'<>]+\.com/stream\.php[^\s"\'<>]*)', core_html)
                if raw_m:
                    stream_page_url = html.unescape(raw_m.group(1))
                else:
                    continue

            # 2. Obtener la página del reproductor en el CDN del stream
            req_stream = urllib.request.Request(
                stream_page_url,
                headers={
                    'User-Agent': UA,
                    'Referer': core_url
                }
            )
            with urllib.request.urlopen(req_stream, context=ctx, timeout=timeout) as resp_stream:
                stream_html = resp_stream.read().decode('utf-8', errors='ignore')

            # Unescape slashes comunes en variables JS (ej. https:\/\/...)
            clean_stream_html = stream_html.replace(r'\/', '/')
            m3u8_matches = re.findall(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*', clean_stream_html)
            if not m3u8_matches:
                continue

            m3u8_url = m3u8_matches[0]

            # 3. Comprobar que el manifiesto HLS responda #EXTM3U
            req_m3u8 = urllib.request.Request(
                m3u8_url,
                headers={
                    'User-Agent': UA,
                    'Referer': stream_page_url
                }
            )
            with urllib.request.urlopen(req_m3u8, context=ctx, timeout=timeout) as resp_m3u8:
                chunk = resp_m3u8.read(384).decode('utf-8', errors='ignore')
                if '#EXTM3U' not in chunk:
                    continue

            # 4. Inyectar cabeceras requeridas para Kodi VideoPlayer (anti-hotlink)
            # El CDN exige Referer del stream_page_url o del espejo originador
            kodi_headers = (
                f"|User-Agent={urllib.parse.quote(UA, safe='')}"
                f"&Referer={urllib.parse.quote(stream_page_url, safe='')}"
            )
            final_stream = m3u8_url + kodi_headers

            with _CACHE_LOCK:
                _RESOLVE_CACHE[cache_key] = (final_stream, now)

            return final_stream

        except urllib.error.HTTPError as e:
            last_error = f"HTTP {e.code}"
            continue
        except Exception as e:
            last_error = str(e)
            continue

    if raise_on_failure:
        raise RuntimeError(f"TGTV2: La señal de '{slug}' no está disponible o está fuera de emisión ({last_error}).")
    return None
