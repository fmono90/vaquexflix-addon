# -*- coding: utf-8 -*-
"""
tv_en_vivo.py - Módulo de TV en Vivo para Vaquexflix (Kodi 20/21)
Gestiona subcategorías, proveedores de listas M3U (Pluto TV, TDT España, IPTV-Org),
fuentes deportivas dinámicas (agenda de eventos, ESPN, Fox, DSports), webcams mundiales 24/7,
guía electrónica de programación (EPG en tiempo real) y resolución de señales en vivo.
"""

import os
import re
import json
import time
import base64
import urllib.request
import urllib.error
import urllib.parse
import threading

import tv_epg

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"


def _default_channel_cover():
    base = os.path.dirname(os.path.abspath(__file__))
    candidates = (
        os.path.join(base, 'resources', 'skins', 'Default', 'media', 'img_channel.jpg'),
        os.path.join(base, 'resources', 'skins', 'Default', 'media', 'icons', 'icon_tv.png'),
    )
    return next((path for path in candidates if os.path.exists(path)), candidates[0])


DEFAULT_CHANNEL_COVER = _default_channel_cover()

# 1. Definición canónica de las subcategorías (Portadas horizontales 16:9 para vista en lista)
SUBCATEGORIAS = [
    {
        'key': 'deportes',
        'title': 'DEPORTES Y EVENTOS EN VIVO',
        'url': 'tv://deportes',
        'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&h=450&fit=crop&q=80',
        'plot': 'Transmisiones deportivas en directo: partidos de fútbol internacional, ligas del mundo, canales 24/7 (ESPN, Fox Sports, DSports, TyC) y eventos oficiales.'
    },
    {
        'key': 'cine',
        'title': 'CINE Y PELÍCULAS 24/7',
        'url': 'tv://cine',
        'cover': 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales temáticos de cine 24/7: Acción, Terror, Comedia, Drama, Suspenso y Cine Clásico sin interrupciones.'
    },
    {
        'key': 'series',
        'title': 'SERIES Y RETRO 24/7',
        'url': 'tv://series',
        'cover': 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=800&h=450&fit=crop&q=80',
        'plot': 'Maratones continuos de series icónicas, clásicos retro de televisión, novelas y comedias legendarias.'
    },
    {
        'key': 'infantil',
        'title': 'ANIMACIÓN E INFANTIL',
        'url': 'tv://infantil',
        'cover': 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales continuos de anime, clásicos de Nickelodeon, caricaturas infantiles y programación para toda la familia.'
    },
    {
        'key': 'noticias',
        'title': 'NOTICIAS Y ACTUALIDAD',
        'url': 'tv://noticias',
        'cover': 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&h=450&fit=crop&q=80',
        'plot': 'Información y noticias en directo 24 horas: Euronews en español, 24h TVE, Actualidad 360 y cobertura global.'
    },
    {
        'key': 'musica',
        'title': 'MÚSICA Y ENTRETENIMIENTO',
        'url': 'tv://musica',
        'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales musicales en vivo, videoclips mundiales, señales MTV, documentales, realities y entretenimiento continuo.'
    },
    {
        'key': 'espana',
        'title': 'CANALES DE ESPAÑA (TDT)',
        'url': 'tv://espana',
        'cover': 'https://images.unsplash.com/photo-1543783207-ec64e4d95325?w=800&h=450&fit=crop&q=80',
        'plot': 'Emisiones nacionales y autonómicas de la TDT de España en vivo y alta definición con guía EPG en tiempo real.'
    },
    {
        'key': 'latam',
        'title': 'CANALES DE LATINOAMÉRICA',
        'url': 'tv://latam',
        'cover': 'https://images.unsplash.com/photo-1589556264800-08ae9e129a8c?w=800&h=450&fit=crop&q=80',
        'plot': 'Canales de televisión abierta y regional de México, Argentina, Colombia, Chile, Perú y toda Latinoamérica en vivo.'
    },
    {
        'key': 'webcams',
        'title': 'WEBCAMS DEL MUNDO (EN VIVO)',
        'url': 'tv://webcams',
        'cover': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop&q=80',
        'plot': 'Cámaras públicas 24/7 en directo: vistas desde la Estación Espacial Internacional (ISS), playas paradisíacas, ciudades icónicas, volcanes y reservas naturales.'
    }
]

NOVA_COUNTRIES = (
    ('PE', 'PERÚ'), ('MX', 'MÉXICO'), ('AR', 'ARGENTINA'),
    ('CO', 'COLOMBIA'), ('CL', 'CHILE'), ('EC', 'ECUADOR'),
    ('VE', 'VENEZUELA'), ('BO', 'BOLIVIA'), ('BR', 'BRASIL'),
    ('ES', 'ESPAÑA'), ('US', 'ESTADOS UNIDOS'), ('INT', 'INTERNACIONALES'),
)
NOVA_COUNTRY_CATEGORIES = tuple({
    'key': 'nova_' + code.lower(),
    'title': 'CANALES ' + ('INTERNACIONALES' if code == 'INT' else 'DE ' + name),
    'url': 'tv://nova_' + code.lower(),
    'cover': DEFAULT_CHANNEL_COVER,
    'plot': 'Canales en vivo de {}. La señal se comprueba al abrir cada canal.'.format(name.title()),
} for code, name in NOVA_COUNTRIES)
NOVA_GENRES = (
    ('noticias', 'NOTICIAS'), ('deportes', 'DEPORTES'),
    ('peliculas', 'PELÍCULAS'), ('musica', 'MÚSICA'),
    ('infantil', 'INFANTIL'), ('documentales', 'DOCUMENTALES'),
    ('entretenimiento', 'ENTRETENIMIENTO'), ('educacion', 'EDUCACIÓN'),
    ('religioso', 'RELIGIOSOS'),
)
NOVA_GENRE_CATEGORIES = tuple({
    'key': 'nova_genre_' + genre.lower().replace(' ', '_'),
    'title': 'CANALES DE ' + label,
    'url': 'tv://nova_genre_' + genre.lower().replace(' ', '_'),
    'cover': DEFAULT_CHANNEL_COVER,
    'plot': 'Canales en vivo de {}.'.format(label.lower()),
} for genre, label in NOVA_GENRES)
NOVA_ALL_CATEGORY = {
    'key': 'nova_page_0', 'title': 'EXPLORAR TODOS LOS CANALES',
    'url': 'tv://nova_page_0',
    'cover': DEFAULT_CHANNEL_COVER,
    'plot': 'Catálogo completo por páginas, incluidos otros países y categorías.',
}

# Canales destacados inmediatos (Garantía instantánea de arranque sin latencia de red)
CANALES_BASE = {
    'deportes': [
        {
            'title': 'ESPN (Deportes en Vivo)',
            'url': 'tv_sport://espn',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Canal principal de ESPN: fútbol internacional, Champions League, ligas europeas, torneos de tenis y SportsCenter.'
        },
        {
            'title': 'ESPN 2',
            'url': 'tv_sport://espn2',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Transmisiones deportivas de ESPN 2: fútbol de primera división, tenis Grand Slam, baloncesto y rugby.'
        },
        {
            'title': 'ESPN 3',
            'url': 'tv_sport://espn3',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Señal complementaria de ESPN: fútbol sudamericano, torneos de tenis ATP, ciclismo mundial y automovilismo.'
        },
        {
            'title': 'ESPN Premium',
            'url': 'tv_sport://espnpremium',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Canal exclusivo de fútbol profesional: partidos en vivo, coberturas previas y análisis detallado de la fecha.'
        },
        {
            'title': 'Fox Sports 1',
            'url': 'tv_sport://foxsports',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Copa Libertadores, Copa Sudamericana, fútbol internacional, artes marciales mixtas y debates deportivos.'
        },
        {
            'title': 'Fox Sports 2',
            'url': 'tv_sport://foxsports2',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Copa Libertadores en simultáneo, fútbol de México y Sudamérica, lucha libre WWE y deportes de motor.'
        },
        {
            'title': 'DSports (DirecTV)',
            'url': 'tv_sport://dsports',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Canal deportivo de DirecTV con LaLiga española, Copa del Rey, Conmebol y los mejores programas de debate.'
        },
        {
            'title': 'DSports 2',
            'url': 'tv_sport://dsports2',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Segunda señal de DSports con partidos en directo de ligas europeas, baloncesto y transmisiones simultáneas.'
        },
        {
            'title': 'DSports+',
            'url': 'tv_sport://dsportsplus',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Eventos premium de DSports: ciclismo World Tour, pádel, automovilismo y partidos definitorios.'
        },
        {
            'title': 'TyC Sports',
            'url': 'tv_sport://tycsports',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'La señal deportiva líder de Argentina: fútbol de primera, Copa Argentina, Selección Argentina y básquetbol.'
        },
        {
            'title': 'Liga 1 Max',
            'url': 'tv_sport://liga1max',
            'cover': 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Canal oficial del fútbol profesional peruano: todos los partidos de la Liga 1 Te Apuesto en directo.'
        },
        {
            'title': 'Teledeporte (TVE)',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/tdp/tdp_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/teledeporteRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal temático deportivo de RTVE en vivo: fútbol, atletismo, ciclismo, tenis y competiciones oficiales.'
        },
        {
            'title': 'Claro Sports FAST',
            'url': 'https://jmp2.uk/plu-6320d2755e54db000783fd87.m3u8',
            'cover': 'https://images.pluto.tv/channels/6320d2755e54db000783fd87/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Transmisión deportiva continua con eventos en directo, análisis, fútbol, ciclismo y resúmenes.'
        },
        {
            'title': 'Pluto TV Deportes',
            'url': 'https://jmp2.uk/plu-5dcde07af1c85b0009b18651.m3u8',
            'cover': 'https://images.pluto.tv/channels/5dcde07af1c85b0009b18651/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Transmisión ininterrumpida de eventos deportivos, fútbol playa, combates y deportes de acción.'
        },
        {
            'title': 'Pluto TV Motor',
            'url': 'https://jmp2.uk/plu-6080345ebb49b90007ce0baf.m3u8',
            'cover': 'https://images.pluto.tv/channels/6080345ebb49b90007ce0baf/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Automovilismo, carreras de resistencia, motociclismo, rallies y el mundo de la velocidad 24/7.'
        },
        {
            'title': 'PFL MMA & Combate',
            'url': 'https://jmp2.uk/plu-64f6163a30ab3300083d870e.m3u8',
            'cover': 'https://images.pluto.tv/channels/64f6163a30ab3300083d870e/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Artes marciales mixtas, veladas de combate de la Professional Fighters League y boxeo profesional.'
        },
        {
            'title': 'World Poker Tour',
            'url': 'https://jmp2.uk/plu-6080381ab7c9ea00074ec64c.m3u8',
            'cover': 'https://images.pluto.tv/channels/6080381ab7c9ea00074ec64c/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Los mejores torneos de póker del planeta con las mesas finales y leyendas de Las Vegas.'
        }
    ],
    'cine': [
        {
            'title': 'Pluto TV Cine Acción',
            'url': 'https://jmp2.uk/plu-5f1ac2591dd8880007bb7d6d.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f1ac2591dd8880007bb7d6d/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Películas de acción, artes marciales, explosiones y thrillers de adrenalina las 24 horas.'
        },
        {
            'title': 'Pluto TV Cine Terror',
            'url': 'https://jmp2.uk/plu-5dcddf1ed95e740009fef7ab.m3u8',
            'cover': 'https://images.pluto.tv/channels/5dcddf1ed95e740009fef7ab/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Cine de terror psicológico, gore, casas encantadas y criaturas de la noche sin pausas.'
        },
        {
            'title': 'Pluto TV Cine Clásico',
            'url': 'https://jmp2.uk/plu-61373bb45168fe000773eecd.m3u8',
            'cover': 'https://images.pluto.tv/channels/61373bb45168fe000773eecd/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Obras maestras de la época dorada del cine, cine negro, westerns y directores consagrados.'
        },
        {
            'title': 'Pluto TV Cine Comedia',
            'url': 'https://jmp2.uk/plu-5f1ac8099c49f600076579b2.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f1ac8099c49f600076579b2/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Las comedias más divertidas, humor inteligente, parodias y situaciones disparatadas.'
        }
    ],
    'series': [
        {
            'title': 'Shin-chan 24/7 (Castellano)',
            'url': 'shinchaneros://live',
            'cover': 'https://shinchaneros.tv/shinchaneros-logo.png',
            'rating': '1080p',
            'plot': 'Emisión continua y sincronizada de Shin-chan en directo con películas y episodios de todas las temporadas en castellano.'
        },
        {
            'title': 'Doctor Who (Canal 24/7)',
            'url': 'https://jmp2.uk/plu-60d3574e97f10800078455de.m3u8',
            'cover': 'https://images.pluto.tv/channels/60d3574e97f10800078455de/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Las aventuras a través del espacio y el tiempo de El Doctor y su TARDIS sin interrupciones.'
        },
        {
            'title': 'BBC Drama & Series',
            'url': 'https://jmp2.uk/plu-60dafb9a0df1ba000758d37b.m3u8',
            'cover': 'https://images.pluto.tv/channels/60dafb9a0df1ba000758d37b/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Aclamadas producciones de la BBC británica, suspense policíaco y dramas de época.'
        },
        {
            'title': 'Curro Jiménez',
            'url': 'https://jmp2.uk/plu-5f1acd36779de70007a680d1.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f1acd36779de70007a680d1/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'El legendario bandolero andaluz de la Sierra de Ronda en sus aventuras más célebres.'
        }
    ],
    'infantil': [
        {
            'title': 'Shin-chan 24/7 (Castellano)',
            'url': 'shinchaneros://live',
            'cover': 'https://shinchaneros.tv/shinchaneros-logo.png',
            'rating': '1080p',
            'plot': 'Emisión continua y sincronizada de Shin-chan en directo con películas y episodios de todas las temporadas en castellano.'
        },
        {
            'title': 'Clan TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/clan/clan_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/clanRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal infantil público de RTVE con las mejores series de animación educativa y entretenimiento.'
        },
        {
            'title': 'Detective Conan 24/7',
            'url': 'https://jmp2.uk/plu-629a066860ef810008267b70.m3u8',
            'cover': 'https://images.pluto.tv/channels/629a066860ef810008267b70/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Shinichi Kudo resuelve los crímenes más intrincados en el cuerpo del pequeño detective Conan.'
        },
        {
            'title': 'Pluto TV Anime',
            'url': 'https://jmp2.uk/plu-608035b8d8705f0007260287.m3u8',
            'cover': 'https://images.pluto.tv/channels/608035b8d8705f0007260287/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Grandes sagas de la animación japonesa: combates Shonen, fantasía y aventuras épicas.'
        },
        {
            'title': 'Bob Esponja 24/7',
            'url': 'https://jmp2.uk/plu-5f1aca0b4e448e00075e7c5e.m3u8',
            'cover': 'https://images.pluto.tv/channels/5f1aca0b4e448e00075e7c5e/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Fondo de Bikini en su máxima diversión con Patricio, Calamardo y Bob en el Crustáceo Cascarudo.'
        },
        {
            'title': 'South Park en Español',
            'url': 'https://jmp2.uk/plu-628751bb7154a40007168843.m3u8',
            'cover': 'https://images.pluto.tv/channels/628751bb7154a40007168843/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Sátira, irreverencia y humor con Stan, Kyle, Cartman y Kenny en audio latino.'
        }
    ],
    'noticias': [
        {
            'title': 'Canal 24 Horas (RTVE)',
            'url': 'https://ztnr.rtve.es/ztnr/1694255.m3u8',
            'cover': 'https://graph.facebook.com/24hRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal de información continua de Televisión Española: directo, debates y noticias al minuto.'
        },
        {
            'title': 'Actualidad 360',
            'url': 'https://jmp2.uk/plu-67517fae5534bb0008187997.m3u8',
            'cover': 'https://images.pluto.tv/channels/67517fae5534bb0008187997/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Noticias globales, reportajes de investigación y coberturas especiales de última hora.'
        },
        {
            'title': 'Euronews en Español',
            'url': 'https://euronews-live-spa-es.fast.rakuten.tv/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6571/bitok/eyJzdGlkIjoiMDA0YjY0NTMtYjY2MC00ZTZkLTlkNzEtMTk3YTM3ZDZhZWIxIiwibWt0IjoiZXMiLCJjaCI6NjU3MSwicHRmIjoxfQ==/26034/euronews-es.m3u8',
            'cover': 'https://graph.facebook.com/es.euronews/picture?width=500&height=500',
            'rating': 'DIRECTO',
            'plot': 'Toda la actualidad europea y mundial analizada con rigor periodístico independiente.'
        },
        {
            'title': 'RCN Noticias',
            'url': 'https://jmp2.uk/plu-67d9b0ebc290c9499046e88f.m3u8',
            'cover': 'https://images.pluto.tv/channels/67d9b0ebc290c9499046e88f/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Canal de noticias internacional de RCN Colombia con información de actualidad, política y reportajes.'
        }
    ],
    'musica': [
        {
            'title': 'MTV Classic',
            'url': 'https://jmp2.uk/plu-66a11a21a79dea0008aa90ca.m3u8',
            'cover': 'https://images.pluto.tv/channels/66a11a21a79dea0008aa90ca/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Los grandes éxitos y videoclips de la época dorada de MTV.'
        },
        {
            'title': 'MTV Flow Latino',
            'url': 'https://jmp2.uk/plu-62b218fc511d4b00070ddc0c.m3u8',
            'cover': 'https://images.pluto.tv/channels/62b218fc511d4b00070ddc0c/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Reguetón, trap, música urbana y los ritmos latinos más pegados.'
        },
        {
            'title': 'MTV Biggest Pop',
            'url': 'https://jmp2.uk/plu-6047fabfce6e8e00070bcc9f.m3u8',
            'cover': 'https://images.pluto.tv/channels/6047fabfce6e8e00070bcc9f/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Grandes estrellas mundiales del pop internacional y listas de éxitos.'
        },
        {
            'title': 'MTV Rocks',
            'url': 'https://jmp2.uk/plu-66a01b52a4ee27000808ea36.m3u8',
            'cover': 'https://images.pluto.tv/channels/66a01b52a4ee27000808ea36/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Lo mejor del rock alternativo, indie, punk y clásicos del rock en MTV.'
        }
    ],
    'espana': [
        {
            'title': 'Shin-chan 24/7 (Castellano)',
            'url': 'shinchaneros://live',
            'cover': 'https://shinchaneros.tv/shinchaneros-logo.png',
            'rating': '1080p',
            'plot': 'Emisión continua y sincronizada de Shin-chan en directo con películas y episodios de todas las temporadas en castellano.'
        },
        {
            'title': 'La 1 de TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/la1/la1_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/la1detve/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Primer canal generalista de RTVE con informativos Telediario, series, películas y entretenimiento.'
        },
        {
            'title': 'La 2 de TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/la2/la2_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/la2detve/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal cultural de RTVE: grandes documentales de naturaleza, cine clásico, arte y Saber y Ganar.'
        },
        {
            'title': 'Canal 24 Horas (RTVE)',
            'url': 'https://ztnr.rtve.es/ztnr/1694255.m3u8',
            'cover': 'https://graph.facebook.com/24hRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Información y noticias ininterrumpidas de España y del mundo 24/7.'
        },
        {
            'title': 'Teledeporte',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/tdp/tdp_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/teledeporteRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'El canal del deporte español en vivo. [Geobloqueo oficial RTVE: Requiere IP de España o VPN].'
        },
        {
            'title': 'Clan TVE',
            'url': 'https://rtvelivestream.rtve.es/rtvesec/clan/clan_main_dvr.m3u8',
            'cover': 'https://graph.facebook.com/clanRTVE/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Dibujos animados, contenidos didácticos y las series infantiles más populares.'
        },
        {
            'title': 'Real Madrid TV',
            'url': 'https://rmtv.akamaized.net/hls/live/2043153/rmtv-es-web/master.m3u8',
            'cover': 'https://graph.facebook.com/RealMadrid/picture?width=500&height=500',
            'rating': '1080p',
            'plot': 'Canal oficial del Real Madrid C.F. con partidos, entrenamientos, informativos y coberturas exclusivas.'
        },
        {
            'title': 'TRECE TV',
            'url': 'https://play.cdn.enetres.net/091DB7AFBD77442B9BA2F141DCC182F5021/021/playlist.m3u8',
            'cover': 'https://graph.facebook.com/TRECEtves/picture?width=500&height=500',
            'rating': 'DIRECTO',
            'plot': 'Canal nacional de televisión con cine clásico, westerns, actualidad informativa y debate.'
        },
        {
            'title': 'Canal Sur Andalucía',
            'url': 'https://dfk2a268yviz9.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-ddiii1m6jt6of/CanalSurAndaluciaES.m3u8',
            'cover': 'https://graph.facebook.com/canalsur/picture?width=500&height=500',
            'rating': 'DIRECTO',
            'plot': 'Canal autonómico de Andalucía: tradiciones, noticias, fiestas populares y entretenimiento.'
        }
    ],
    'latam': [
        {
            'title': 'ADN 40 (México)',
            'url': 'https://jmp2.uk/plu-646ccd3681844c000974d6f4.m3u8',
            'cover': 'https://images.pluto.tv/channels/646ccd3681844c000974d6f4/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Canal informativo de México con análisis político, debate, economía y noticias al momento.'
        },
        {
            'title': 'Azteca Internacional',
            'url': 'https://jmp2.uk/plu-646cce4d1593940008a33f09.m3u8',
            'cover': 'https://images.pluto.tv/channels/646cce4d1593940008a33f09/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Señal internacional de TV Azteca con los mejores programas de espectáculos, noticias y novelas.'
        },
        {
            'title': 'RCN Noticias',
            'url': 'https://jmp2.uk/plu-67d9b0ebc290c9499046e88f.m3u8',
            'cover': 'https://images.pluto.tv/channels/67d9b0ebc290c9499046e88f/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Canal de noticias internacional de RCN Colombia con información de actualidad, política y reportajes.'
        },
        {
            'title': 'Imagen TV+',
            'url': 'https://jmp2.uk/plu-64e35aff6b1fdb0008ea8441.m3u8',
            'cover': 'https://images.pluto.tv/channels/64e35aff6b1fdb0008ea8441/colorLogoPNG.png',
            'rating': 'DIRECTO',
            'plot': 'Canal mexicano de televisión abierta con entretenimiento, noticieros, realities y ficciones.'
        }
    ],
    'webcams': [
        {
            'title': 'Estación Espacial Internacional ISS (Tierra en Directo HD)',
            'url': 'https://www.youtube.com/watch?v=ROboUHfPUrU',
            'cover': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Cámaras exteriores de alta definición a bordo de la Estación Espacial Internacional transmitiendo la Tierra en directo.'
        },
        {
            'title': 'Nueva York — Times Square en Directo',
            'url': 'https://www.youtube.com/watch?v=KHy_n-EMWY8',
            'cover': 'https://images.unsplash.com/photo-1534430480872-3498386e7856?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Cámara en vivo transmitiendo el movimiento continuo y las luces de Times Square en Nueva York.'
        },
        {
            'title': 'Tokio — Cruce de Shibuya en Vivo 24/7',
            'url': 'https://www.youtube.com/watch?v=5B4LmH4JbnY',
            'cover': 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'El icónico y transitado cruce peatonal de Shibuya en Tokio, Japón en transmisión ininterrumpida.'
        },
        {
            'title': 'Venecia — Gran Canal y Puente de Rialto',
            'url': 'https://www.youtube.com/watch?v=r8N6IsoIkTk',
            'cover': 'https://images.unsplash.com/photo-1514890547357-a9ee288728e0?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Góndolas y vistas panorámicas del Gran Canal de Venecia frente al Puente de Rialto en tiempo real.'
        },
        {
            'title': 'Volcán Popocatépetl — México en Directo',
            'url': 'https://www.youtube.com/watch?v=xytHO8TgCBE',
            'cover': 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Transmisión 24 horas del Volcán Popocatépetl en México monitoreado en tiempo real desde la estación Tlamacas.'
        },
        {
            'title': 'Playas de Cataluña y Costa Brava (Multicámara)',
            'url': 'https://directes-tv-int.3catdirectes.cat/live-content/beauties-hls/master.m3u8',
            'cover': 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Cámaras fijas del litoral mediterráneo de Cataluña y la Costa Brava en alta definición.'
        },
        {
            'title': 'Costa de Almería y Mar Mediterráneo',
            'url': 'https://interalmeria.tv/directo/live.m3u8',
            'cover': 'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&h=450&fit=crop&q=80',
            'rating': 'DIRECTO',
            'plot': 'Panorámica de la bahía y el puerto de Almería sobre el mar Mediterráneo.'
        }
    ]
}

_cache_lock = threading.Lock()
_cache_memoria = {}
_cache_file_path = None
_actualizando_bg = False

_agenda_lock = threading.Lock()
_agenda_cache = []
_agenda_timestamp = 0
_logo_status = {}
_logo_status_lock = threading.Lock()


def logo_cache_estado(url):
    """Última comprobación HTTP de un logo, sin bloquear la interfaz."""
    with _logo_status_lock:
        entry = _logo_status.get(url)
    if entry and time.time() - entry[1] < (86400 if entry[0] else 600):
        return entry[0]
    return None


def logo_disponible(url):
    """Comprueba que el enlace entregue datos de imagen reales."""
    cached = logo_cache_estado(url)
    if cached is not None:
        return cached
    image_url, _, options = (url or '').partition('|')
    parsed = urllib.parse.urlsplit(image_url)
    if parsed.scheme not in ('http', 'https'):
        return bool(url and os.path.isfile(url))
    try:
        headers = {'User-Agent': UA, 'Accept': 'image/*', 'Range': 'bytes=0-127'}
        for key, value in urllib.parse.parse_qsl(options):
            if key.lower() in ('user-agent', 'referer', 'origin'):
                headers[key] = value
        request = urllib.request.Request(image_url, headers=headers)
        with urllib.request.urlopen(request, timeout=5) as response:
            mime = response.headers.get('Content-Type', '').split(';', 1)[0].lower()
            prefix = response.read(128).lstrip()
        image_magic = (prefix.startswith(b'\x89PNG\r\n\x1a\n') or
                       prefix.startswith(b'\xff\xd8\xff') or
                       prefix.startswith((b'GIF87a', b'GIF89a')) or
                       (prefix.startswith(b'RIFF') and prefix[8:12] == b'WEBP'))
        valid = bool(prefix and (image_magic or
                     (mime.startswith('image/') and not prefix.lower().startswith((b'<html', b'<!doctype')))))
    except Exception:
        valid = False
    with _logo_status_lock:
        _logo_status[url] = (valid, time.time())
    return valid


def set_cache_path(base_dir):
    global _cache_file_path
    if not os.path.exists(base_dir):
        try:
            os.makedirs(base_dir, exist_ok=True)
        except Exception:
            pass
    _cache_file_path = os.path.join(base_dir, 'tv_channels_cache.json')


def get_subcategories():
    """Devuelve la lista canónica de subcategorías temáticas de TV en Vivo."""
    import source_switches
    if source_switches.only_enabled('tgtv2'):
        return [{
            'key': 'tgtv2',
            'title': 'CANALES EN VIVO HD',
            'url': 'tv://tgtv2',
            'cover': 'https://www.telegratis2.com/imge/telegratishdd.png',
            'plot': 'Catálogo completo de señales de televisión en directo en alta definición.'
        }]
    if source_switches.only_enabled('fltvplus'):
        import fltvplus
        return fltvplus.categories()
    if source_switches.only_enabled('fxpplus'):
        import fxpplus
        return fxpplus.categories()
    if source_switches.only_enabled('nova'):
        return [dict(NOVA_ALL_CATEGORY)] + [dict(category) for category in
                                            NOVA_COUNTRY_CATEGORIES + NOVA_GENRE_CATEGORIES]
    categories = list(SUBCATEGORIAS)
    if source_switches.enabled('tgtv2'):
        categories.append({
            'key': 'tgtv2',
            'title': 'CANALES EN VIVO HD',
            'url': 'tv://tgtv2',
            'cover': 'https://www.telegratis2.com/imge/telegratishdd.png',
            'plot': 'Canales en vivo de alta definición: deportes premium (ESPN, Fox Sports, TyC, Liga 1 Max), cine, infantiles, series y señales latinas.'
        })
    if source_switches.enabled('nova'):
        categories.append(dict(NOVA_ALL_CATEGORY))
        categories.extend(dict(category) for category in NOVA_COUNTRY_CATEGORIES + NOVA_GENRE_CATEGORIES)
    if source_switches.enabled('fxpplus'):
        try:
            import fxpplus
            categories.extend(fxpplus.categories())
        except Exception as exc:
            import network
            network.log_resolver('FXP+: categorías no disponibles ({})'.format(type(exc).__name__))
    if source_switches.enabled('fltvplus'):
        import fltvplus
        categories.extend(fltvplus.categories())
    return categories


def _clasificar_canal(ch, source_id=""):
    """Clasifica un canal M3U dentro de una de las subcategorías canónicas."""
    name = ch.get('title', '').lower()
    group = ch.get('group', '').lower()

    if any(k in group for k in ['deporte', 'sport', 'competencia', 'motor', 'auto']) or \
       any(k in name for k in ['sport', 'deporte', 'futbol', 'fútbol', 'teledeporte', 'gol play', 'motor', 'fifa']):
        return 'deportes'
    if any(k in group for k in ['cine', 'película', 'pelicula', 'movie']):
        return 'cine'
    if any(k in group for k in ['anime', 'infantil', 'kids', 'animation', 'animación', 'animacion', 'south park', 'cartoon']):
        return 'infantil'
    if any(k in group for k in ['noticia', 'news', 'actualidad', 'business', 'información']):
        return 'noticias'
    if any(k in group for k in ['serie', 'novela', 'retro', 'policiaca', 'crimen', 'misterio', 'paranormal', 'investigación']):
        return 'series'
    if any(k in group for k in ['música', 'musica', 'music', 'mtv', 'reality', 'lifestyle', 'estilo', 'cultura']):
        return 'musica'
    if source_id == 'tdt':
        return 'espana'
    return 'latam'


def _parsear_m3u(content, source_id=""):
    """Parsea el contenido de texto de una lista M3U y extrae metadatos limpios sin omitir canales sin logo."""
    channels = []
    lines = content.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('#EXTINF:'):
            logo_m = re.search(r'tvg-logo="([^"]*)"', line)
            logo = logo_m.group(1) if logo_m else ''

            group_m = re.search(r'group-title="([^"]*)"', line)
            group = group_m.group(1) if group_m else ''

            name_m = re.search(r',([^,]+)$', line)
            name = name_m.group(1).strip() if name_m else 'Canal'

            url = ""
            if i + 1 < len(lines):
                next_l = lines[i + 1].strip()
                if next_l.startswith('http'):
                    url = next_l

            if url and not any(r in name.lower() for r in ['radio', 'rne acces', 'ondacero', 'ser ']):
                res_m = re.search(r'\((\d+p)\)', name)
                res = res_m.group(1) if res_m else ('1080p' if 'pluto' in url or 'rtve' in url else 'DIRECTO')
                clean_name = re.sub(r'\s*\(\d+p\)', '', name)
                clean_name = re.sub(r'\s*\[Geo-blocked\]', '', clean_name)
                clean_name = re.sub(r'\s*\[Not 24/7\]', '', clean_name).strip()

                channels.append({
                    'title': clean_name,
                    'url': url,
                    'cover': logo,
                    'group': group,
                    'source': source_id,
                    'rating': res,
                    'plot': f"Transmisión en directo de {clean_name}. Señal de televisión en vivo."
                })
            i += 2
        else:
            i += 1
    return channels


def _descargar_texto(url, timeout=10, referer=None):
    """Descarga de red segura con headers y timeout explícito."""
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8', errors='ignore')


def _cargar_cache_disco():
    """Lee el catálogo de canales desde el archivo de caché si es reciente y asegura canales base."""
    global _cache_memoria
    if not _cache_file_path or not os.path.exists(_cache_file_path):
        return None
    try:
        with open(_cache_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        ts = data.get('_updated', 0)
        if (time.time() - ts) < 86400 and 'canales' in data:
            _cache_memoria = data['canales']
            # Asegurar que los canales base declarados siempre estén presentes al frente de cada categoría
            modificado = False
            for sub_k, base_list in CANALES_BASE.items():
                if sub_k not in _cache_memoria:
                    _cache_memoria[sub_k] = list(base_list)
                    modificado = True
                else:
                    existing_urls = {c.get('url') for c in _cache_memoria[sub_k]}
                    for bc in reversed(base_list):
                        if bc.get('url') not in existing_urls:
                            _cache_memoria[sub_k].insert(0, dict(bc))
                            existing_urls.add(bc.get('url'))
                            modificado = True
            if modificado:
                _guardar_cache_disco(_cache_memoria)
            return _cache_memoria
    except Exception:
        pass
    return None


def _guardar_cache_disco(canales_dict):
    """Escribe de forma atómica el catálogo a disco en userdata."""
    if not _cache_file_path:
        return
    tmp = _cache_file_path + '.tmp'
    try:
        data = {
            '_updated': time.time(),
            'canales': canales_dict
        }
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, _cache_file_path)
    except Exception:
        pass


def _actualizar_canales_en_segundo_plano():
    """Descarga en hilo de fondo las listas oficiales y construye el índice agrupado."""
    global _actualizando_bg, _cache_memoria
    if _actualizando_bg:
        return
    _actualizando_bg = True

    try:
        sources = [
            ('pluto_es', 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plutotv_es.m3u'),
            ('pluto_mx', 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plutotv_mx.m3u'),
            ('tdt', 'https://www.tdtchannels.com/lists/tv.m3u')
        ]

        nuevos_canales = {sub['key']: list(CANALES_BASE.get(sub['key'], [])) for sub in SUBCATEGORIAS}
        titulos_vistos = {sub['key']: {c['title'].lower() for c in CANALES_BASE.get(sub['key'], [])} for sub in SUBCATEGORIAS}

        for src_id, src_url in sources:
            try:
                raw_text = _descargar_texto(src_url, timeout=10)
                parsed = _parsear_m3u(raw_text, src_id)
                for ch in parsed:
                    categoria = _clasificar_canal(ch, src_id)
                    if categoria not in nuevos_canales:
                        categoria = 'latam'

                    norm_title = ch['title'].lower()
                    if norm_title not in titulos_vistos[categoria]:
                        titulos_vistos[categoria].add(norm_title)
                        nuevos_canales[categoria].append(ch)
            except Exception:
                continue

        with _cache_lock:
            _cache_memoria = nuevos_canales
            _guardar_cache_disco(nuevos_canales)

    except Exception:
        pass
    finally:
        _actualizando_bg = False


def init_background_cache(userdata_dir):
    """Inicializa las rutas de caché de canales y de guía EPG."""
    set_cache_path(userdata_dir)
    tv_epg.init_epg_cache(userdata_dir)
    cached = _cargar_cache_disco()
    if not cached:
        threading.Thread(target=_actualizar_canales_en_segundo_plano, daemon=True).start()


def obtener_agenda_deportes():
    """
    Consulta las APIs unificadas de deportes (api.wqxag.com / agenda18.com)
    y retorna la lista de partidos programados y en vivo del día.
    """
    global _agenda_cache, _agenda_timestamp
    now = time.time()
    with _agenda_lock:
        if _agenda_cache and (now - _agenda_timestamp) < 180:
            return list(_agenda_cache)

    urls = [
        'https://api.wqxag.com/diaries.json',
        'https://agenda18.com/agenda.json'
    ]
    data = None
    for u in urls:
        try:
            req = urllib.request.Request(u, headers={'User-Agent': UA, 'Referer': 'https://futbol-libre.cam/'})
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data:
                    break
        except Exception:
            continue

    if not data:
        with _agenda_lock:
            return list(_agenda_cache) if _agenda_cache else []

    eventos = data if isinstance(data, list) else data.get('data', [])
    items_agenda = []

    for ev in eventos:
        attrs = ev if 'diary_description' in ev else ev.get('attributes', {})
        desc = attrs.get('diary_description', '').replace('\r', '').replace('\n', ' ').strip()
        hora_str = attrs.get('diary_hour', '00:00:00')
        fecha_str = attrs.get('date_diary', '')
        embeds_data = attrs.get('embeds', {})
        embed_list = embeds_data if isinstance(embeds_data, list) else embeds_data.get('data', [])

        try:
            h_parts = hora_str.split(':')
            ev_hora = int(h_parts[0])
            ev_min = int(h_parts[1]) if len(h_parts) > 1 else 0
            hora_humana = f"{ev_hora:02d}:{ev_min:02d}"
        except Exception:
            hora_humana = hora_str[:5]

        pais_img = ""
        try:
            p_data = attrs.get('country', {}).get('data', {})
            img_rel = p_data.get('attributes', {}).get('image', {}).get('data', {}).get('attributes', {}).get('url', '')
            if img_rel:
                pais_img = "https://img.wqxag.com" + img_rel
        except Exception:
            pass

        if not embed_list:
            continue

        for emb in embed_list:
            e_attrs = emb if 'embed_name' in emb else emb.get('attributes', {})
            emb_name = e_attrs.get('embed_name', 'Señal 1').strip()
            emb_iframe = e_attrs.get('embed_iframe', '')
            if not emb_iframe:
                continue

            target_url = emb_iframe
            if '?r=' in emb_iframe:
                b64 = emb_iframe.split('?r=')[-1]
                try:
                    target_url = base64.b64decode(b64).decode('utf-8')
                except Exception:
                    pass

            item_title = f"[{hora_humana}] {desc} ({emb_name})"
            items_agenda.append({
                'title': item_title,
                'url': f"tv_sport://{target_url}",
                'cover': pais_img or 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=900&fit=crop&q=80',
                'rating': 'VIVO',
                'is_event': True,
                'is_match': True,
                'plot': f"Partido: {desc}\nCanal / Señal: {emb_name}\nHora programada: {hora_humana}\nFecha: {fecha_str}\n(La transmisión se activa al iniciar el evento deportivo)."
            })

    with _agenda_lock:
        _agenda_cache = items_agenda
        _agenda_timestamp = now
        return list(_agenda_cache)


def resolver_canal_stream(stream_url, raise_on_failure=False):
    if stream_url.startswith('fltv://'):
        import fltvplus
        return fltvplus.resolve(stream_url)
    if stream_url.startswith('fxptv://'):
        import fxpplus
        return fxpplus.resolve(stream_url)
    if stream_url.startswith('shinchaneros://'):
        import shinchaneros
        return shinchaneros.resolve_live()
    if stream_url.startswith('tgtv2://'):
        import tgtv2
        return tgtv2.resolve(stream_url, raise_on_failure=raise_on_failure)
    """
    Resuelve enlaces dinámicos de TV (como tv_sport:// o vídeos de YouTube) a su stream HLS (.m3u8)
    o URL reproducible con los headers HTTP necesarios para Kodi VideoPlayer.
    """
    if not stream_url:
        return None

    if stream_url.startswith('novatv://'):
        import nova_sources
        return nova_sources.channel_stream(stream_url, raise_on_failure=raise_on_failure)

    # Si es una emisión o vídeo de YouTube (ej. webcams mundiales)
    if 'youtube.com' in stream_url or 'youtu.be' in stream_url or stream_url.startswith('tube://'):
        try:
            import tube_engine
            return tube_engine.resolve(stream_url)
        except Exception:
            return None

    if not stream_url.startswith('tv_sport://'):
        return stream_url

    raw_url = stream_url.replace('tv_sport://', '').strip()

    # Si es un slug de canal deportivo simple
    if not raw_url.startswith('http'):
        raw_url = f"https://tvf90.com/5.php?stream={raw_url}"

    # Extraer slug para consulta y fallback
    slug = 'espn'
    stream_m = re.search(r'stream=([^&]+)', raw_url)
    if stream_m:
        slug = stream_m.group(1).lower().strip()
    elif not raw_url.startswith('http'):
        slug = raw_url.lower().strip()

    final_stream = None

    # Normalizar tvf90 o respetar endpoints específicos (plus1.php, hd.php, 1.php, etc.)
    if 'tvf90.com' in raw_url:
        php_match = re.search(r'([a-zA-Z0-9_]+\.php)\?stream=([^&]+)', raw_url)
        endpoints = []
        if php_match:
            php_file = php_match.group(1)
            endpoints.append(f"https://tvf90.com/{php_file}?stream={slug}")
            if php_file != '5.php':
                endpoints.append(f"https://tvf90.com/5.php?stream={slug}")
        else:
            endpoints.append(f"https://tvf90.com/5.php?stream={slug}")

        headers = {'User-Agent': UA, 'Referer': 'https://tvf90.com/'}
        for ep in endpoints:
            try:
                req = urllib.request.Request(ep, headers=headers)
                with urllib.request.urlopen(req, timeout=6) as resp:
                    html = resp.read().decode('utf-8', errors='ignore')
                    m3u8s = re.findall(r'https?://[^\s"\'<>]+(?:\.m3u8|mono\.m3u8)[^\s"\'<>]*', html)
                    if m3u8s:
                        kodi_headers = f"|User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote('https://tvf90.com/')}"
                        final_stream = m3u8s[0] + kodi_headers
                        break
            except Exception:
                pass

    # Si es la18hd o fallback de slug
    if not final_stream and ('la18hd' in raw_url or 'canal.php' in raw_url):
        fallback_tvf = f"https://tvf90.com/5.php?stream={slug}"
        try:
            req = urllib.request.Request(fallback_tvf, headers={'User-Agent': UA, 'Referer': 'https://tvf90.com/'})
            with urllib.request.urlopen(req, timeout=6) as resp:
                html = resp.read().decode('utf-8', errors='ignore')
                m3u8s = re.findall(r'https?://[^\s"\'<>]+(?:\.m3u8|mono\.m3u8)[^\s"\'<>]*', html)
                if m3u8s:
                    kodi_headers = f"|User-Agent={urllib.parse.quote(UA)}&Referer={urllib.parse.quote('https://tvf90.com/')}"
                    final_stream = m3u8s[0] + kodi_headers
        except Exception:
            pass

    # Fallback dinámico automático a TGTV2 si tvf90 no entregó stream
    if not final_stream and source_switches.enabled('tgtv2'):
        try:
            import tgtv2
            sport_slug_map = {
                'espn': 'espn', 'espn2': 'espn2', 'espn3': 'espn3', 'espnpremium': 'espnpremiumlat',
                'foxsports': 'foxsports', 'foxsports2': 'foxsports2', 'foxsports3': 'foxsports3',
                'dsports': 'directvsports', 'dsports2': 'directvsports2', 'dsportsplus': 'directvsportsplus',
                'tycsports': 'tycsports', 'liga1max': 'liga1max', 'tudn': 'tudn'
            }
            tgt_slug = sport_slug_map.get(slug, slug)
            final_stream = tgtv2.resolve(f"tgtv2://{tgt_slug}")
        except Exception:
            pass

    return final_stream


def _enriquecer_con_epg(canales):
    """Inyecta en la sinopsis la programación actual y próxima si está disponible en el EPG, y fallback de carátula de canal."""
    for c in canales:
        if not c.get('cover'):
            c['cover'] = DEFAULT_CHANNEL_COVER
        try:
            epg = tv_epg.obtener_info_epg(c.get('title', ''))
            if epg:
                c['plot'] = f"{epg}\n\n{c.get('plot', '')}"
            prog = tv_epg.obtener_programa_actual(c.get('title', ''))
            if prog:
                c['current_program'] = prog
        except Exception:
            pass
    return canales


def _filtrar_canales_deportivos(canales):
    """Filtra canales deportivos estrictos, excluyendo eventos agendados y contenidos infantiles colados."""
    excluir = (
        'bob esponja', 'spongebob', 'patricio estrella', 'calamardo',
        'nickelodeon', 'cartoon network', 'cartoonito', 'disney',
        'baby tv', 'babyfirst', 'clan tve', 'boing', 'peppa pig',
        'pocoyo', 'south park', 'animación', 'animacion', 'infantil',
        'toons', 'discovery kids', 'nick jr', 'nick', 'boomerang'
    )
    limpios = []
    for c in canales:
        if not c or not isinstance(c, dict):
            continue
        title_lower = str(c.get('title', '')).lower()
        group_lower = str(c.get('group', '')).lower()
        if any(bad in title_lower for bad in excluir) or any(bad in group_lower for bad in ('infantil', 'kids', 'animacion', 'animación')):
            continue
        if c.get('is_match') or c.get('is_event') or str(c.get('url', '')).startswith('tv_sport://'):
            continue
        limpios.append(c)
    return limpios


def _match_busqueda_canal(query, canal):
    if not query or not canal:
        return False
    q = query.lower().strip()
    title = canal.get('title', '').lower()
    plot = canal.get('plot', '').lower()
    if q in title or q in plot:
        return True
    q_compact = re.sub(r'[\s\-_]+', '', q)
    title_compact = re.sub(r'[\s\-_]+', '', title)
    plot_compact = re.sub(r'[\s\-_]+', '', plot)
    if q_compact and (q_compact in title_compact or q_compact in plot_compact):
        return True
    return False


def get_channels(category_url_or_key):
    """
    Obtiene la lista de canales para una categoría dada:
    - 'tv://todo' o 'todo': Catálogo global agregado de todas las señales.
    - 'tv://buscar?q=...': Búsqueda por texto en nombres y sinopsis.
    - 'tv://deportes' o 'deportes': Canales base fijos + Agenda de partidos del día.
    - 'tv://webcams' o 'webcams': Cámaras públicas mundiales en vivo.
    - Subcategorías temáticas: Catálogo base instantáneo + canales parseados de fondo enriquecidos con EPG.
    """
    raw = category_url_or_key.replace('tv://', '').strip()
    key = raw.lower()
    import source_switches
    if key.startswith(('fltv_group_', 'fltv_page_')):
        if not source_switches.enabled('fltvplus'):
            return []
        import fltvplus
        if key.startswith('fltv_page_'):
            group, _, page = key[10:].partition('_')
        else:
            group, page = key[11:], '1'
        if not group.isdecimal() or not page.isdecimal():
            return []
        channels, more = fltvplus.channels(group, int(page))
        if more:
            channels.append({'title': 'Página siguiente', 'url': 'tv://fltv_page_{}_{}'.format(group, int(page) + 1),
                             'source': 'fltvplus', 'cover': '', 'plot': ''})
        return channels
    if key.startswith('fxp_group_') or key.startswith('fxp_page_'):
        if not source_switches.enabled('fxpplus'):
            return []
        import fxpplus
        if key.startswith('fxp_page_'):
            group, _, page = key[9:].partition('_')
        else:
            group, page = key[10:], '1'
        if not group.isdecimal() or not page.isdecimal() or group == '76208':
            return []
        channels, more = fxpplus.channels(group, int(page))
        if more:
            channels.append({'title': 'Página siguiente', 'url': 'tv://fxp_page_{}_{}'.format(group, int(page) + 1),
                             'source': 'fxpplus', 'cover': '', 'plot': ''})
        return channels

    if key.startswith('nova_page_'):
        page = key[10:]
        if not source_switches.enabled('nova') or not page.isdecimal():
            return []
        import nova_sources
        return nova_sources.channels_page(int(page))

    if key.startswith('nova_country_') and '_page_' in key:
        country, _, page = key[13:].partition('_page_')
        if not source_switches.enabled('nova') or country.upper() not in dict(NOVA_COUNTRIES) or not page.isdecimal():
            return []
        import nova_sources
        return nova_sources.channels_page(int(page), country.upper())

    if key.startswith('nova_genre_'):
        genre = key[11:]
        genre_map = {name.lower().replace(' ', '_'): name for name, _ in NOVA_GENRES}
        if not source_switches.enabled('nova') or genre not in genre_map:
            return []
        import nova_sources
        return nova_sources.channels_by_category(genre_map[genre])

    if key.startswith('nova_') and key[5:].upper() in dict(NOVA_COUNTRIES):
        if not source_switches.enabled('nova'):
            return []
        import nova_sources
        return nova_sources.channels_page(0, key[5:].upper())

    if key in ('tgtv2', 'tv://tgtv2'):
        if not source_switches.enabled('tgtv2'):
            return []
        import tgtv2
        return _enriquecer_con_epg(tgtv2.get_channels())

    if key.startswith('tgtv2_') or key.startswith('tv://tgtv2_'):
        if not source_switches.enabled('tgtv2'):
            return []
        import tgtv2
        sub_cat = key.split('tgtv2_', 1)[1]
        return _enriquecer_con_epg(tgtv2.get_channels(category_filter=sub_cat))

    if key.startswith('buscar?q='):
        query = urllib.parse.unquote_plus(raw.split('=', 1)[1]).lower()
        if source_switches.only_enabled('tgtv2'):
            import tgtv2
            return _enriquecer_con_epg([c for c in tgtv2.get_channels() if _match_busqueda_canal(query, c)])
        if source_switches.only_enabled('nova'):
            import nova_sources
            return nova_sources.search_channels(query)
        todos = get_channels('todo')
        found = [c for c in todos if _match_busqueda_canal(query, c)]
        if source_switches.enabled('tgtv2'):
            import tgtv2
            seen = {c.get('url') for c in found}
            found.extend(c for c in tgtv2.get_channels() if _match_busqueda_canal(query, c) and c.get('url') not in seen)
        if source_switches.enabled('nova'):
            import nova_sources
            seen = {c.get('url') for c in found}
            found.extend(c for c in nova_sources.search_channels(query) if c.get('url') not in seen)
        return found

    if key in ('todo', 'todos', 'all'):
        if source_switches.only_enabled('tgtv2'):
            import tgtv2
            return _enriquecer_con_epg(tgtv2.get_channels())
        if source_switches.only_enabled('nova'):
            return get_channels('nova_pe')
        canales_totales = []
        vistos = set()
        for c in get_channels('deportes'):
            if c.get('is_match') or c.get('is_event') or str(c.get('url', '')).startswith('tv_sport://'):
                continue
            norm = c['title'].lower()
            if norm not in vistos:
                vistos.add(norm)
                canales_totales.append(c)
        for sub in SUBCATEGORIAS:
            if sub['key'] in ('deportes', 'eventos_deportivos'):
                continue
            for c in get_channels(sub['key']):
                if c.get('is_match') or c.get('is_event') or str(c.get('url', '')).startswith('tv_sport://'):
                    continue
                norm = c['title'].lower()
                if norm not in vistos:
                    vistos.add(norm)
                    canales_totales.append(c)
        if source_switches.enabled('tgtv2'):
            import tgtv2
            for c in tgtv2.get_channels():
                norm = c['title'].lower()
                if norm not in vistos:
                    vistos.add(norm)
                    canales_totales.append(c)
        return canales_totales

    if key in ('eventos_deportivos', 'agenda', 'deportes_agenda'):
        return _enriquecer_con_epg(obtener_agenda_deportes())

    res_channels = []
    if key == 'deportes':
        base_sports = list(CANALES_BASE.get('deportes', []))
        with _cache_lock:
            if _cache_memoria and 'deportes' in _cache_memoria:
                seen_titles = {c['title'].lower() for c in base_sports}
                for mc in _cache_memoria['deportes']:
                    if mc['title'].lower() not in seen_titles:
                        base_sports.append(mc)
                        seen_titles.add(mc['title'].lower())
        if not any(c.get('source') for c in base_sports):
            disco = _cargar_cache_disco()
            if disco and 'deportes' in disco:
                seen_titles = {c['title'].lower() for c in base_sports}
                for mc in disco['deportes']:
                    if mc['title'].lower() not in seen_titles:
                        base_sports.append(mc)
                        seen_titles.add(mc['title'].lower())
        res_channels = _filtrar_canales_deportivos(base_sports)
    elif key == 'webcams':
        res_channels = list(CANALES_BASE.get('webcams', []))
    else:
        with _cache_lock:
            if _cache_memoria and key in _cache_memoria:
                res_channels = list(_cache_memoria[key])

        if not res_channels:
            disco = _cargar_cache_disco()
            if disco and key in disco:
                res_channels = list(disco[key])

        if not res_channels:
            if not _actualizando_bg:
                threading.Thread(target=_actualizar_canales_en_segundo_plano, daemon=True).start()
            res_channels = list(CANALES_BASE.get(key, []))

    if source_switches.enabled('tgtv2'):
        try:
            import tgtv2
            tgt_list = tgtv2.get_channels(category_filter=key)
            seen_urls = {c.get('url') for c in res_channels}
            for tc in tgt_list:
                if tc.get('url') not in seen_urls:
                    res_channels.append(tc)
                    seen_urls.add(tc.get('url'))
        except Exception:
            pass

    return _enriquecer_con_epg(res_channels)


# =========================================================================
# CATEGORÍAS UNIFICADAS Y NORMALIZADAS PARA LA INTERFAZ MODERNA DE TV
# =========================================================================

UNIFIED_CATEGORIES = [
    ('todo', 'Todo'),
    ('deportes', 'Deportes'),
    ('cine', 'Cine'),
    ('series', 'Series'),
    ('infantil', 'Infantil'),
    ('noticias', 'Noticias'),
    ('musica', 'Música'),
    ('argentina', 'Argentina'),
    ('espana', 'España'),
    ('mexico', 'México'),
    ('colombia', 'Colombia'),
    ('peru', 'Perú'),
    ('chile', 'Chile'),
    ('ecuador', 'Ecuador'),
    ('venezuela', 'Venezuela'),
    ('bolivia', 'Bolivia'),
    ('uruguay', 'Uruguay'),
    ('paraguay', 'Paraguay'),
    ('estados_unidos', 'Estados Unidos'),
    ('costa_rica', 'Costa Rica'),
    ('panama', 'Panamá'),
    ('puerto_rico', 'Puerto Rico'),
    ('republica_dominicana', 'Rep. Dominicana'),
    ('honduras', 'Honduras'),
    ('el_salvador', 'El Salvador'),
    ('centroamerica', 'Centroamérica'),
    ('brasil', 'Brasil'),
    ('latam', 'Latinoamérica'),
    ('documentales', 'Documentales'),
    ('entretenimiento', 'Entretenimiento'),
    ('educacion', 'Educación'),
    ('religioso', 'Religioso'),
    ('webcams', 'Webcams'),
    ('eventos_ppv', 'Eventos PPV'),
    ('nfl_pass', 'NFL PASS'),
    ('nba_pass', 'NBA PASS'),
    ('mlb_pass', 'MLB PASS'),
    ('tgtv2', 'Directo HD'),
]

UNIFIED_SOURCE_MAP = {
    'todo': ['tv://todo', 'tv://fltv_group_76182'],
    'tgtv2': ['tv://tgtv2'],
    'deportes': ['tv://deportes', 'tv://fltv_group_76206', 'tv://nova_genre_deportes', 'tv://fxp_group_76206'],
    'cine': ['tv://cine', 'tv://fltv_group_76205', 'tv://nova_genre_peliculas', 'tv://fxp_group_76205'],
    'series': ['tv://series', 'tv://fltv_group_76189', 'tv://fxp_group_76189'],
    'infantil': ['tv://infantil', 'tv://fltv_group_79146', 'tv://nova_genre_infantil', 'tv://fxp_group_79146'],
    'noticias': ['tv://noticias', 'tv://fltv_group_76193', 'tv://nova_genre_noticias', 'tv://fxp_group_76193'],
    'musica': ['tv://musica', 'tv://fltv_group_76183', 'tv://nova_genre_musica', 'tv://fxp_group_76183'],
    'argentina': ['tv://nova_ar', 'country:argentina'],
    'espana': ['tv://espana', 'tv://fltv_group_76191', 'tv://nova_es', 'tv://fxp_group_76191'],
    'mexico': ['tv://nova_mx', 'tv://fltv_group_76197', 'tv://fxp_group_76197', 'country:mexico'],
    'colombia': ['tv://nova_co', 'tv://fltv_group_76188', 'tv://fxp_group_76188', 'country:colombia'],
    'peru': ['tv://nova_pe', 'tv://fltv_group_76187', 'tv://fxp_group_76187', 'country:peru'],
    'chile': ['tv://nova_cl', 'tv://fltv_group_76207', 'tv://fxp_group_76207', 'country:chile'],
    'ecuador': ['tv://nova_ec', 'tv://fltv_group_76190', 'tv://fxp_group_76190', 'country:ecuador'],
    'venezuela': ['tv://nova_ve', 'tv://fltv_group_77690', 'tv://fxp_group_77690', 'country:venezuela'],
    'bolivia': ['tv://nova_bo', 'tv://fltv_group_76202', 'tv://fxp_group_76202', 'country:bolivia'],
    'uruguay': ['tv://fltv_group_76201', 'tv://fxp_group_76201', 'country:uruguay'],
    'paraguay': ['tv://fltv_group_77688', 'tv://fxp_group_77688', 'country:paraguay'],
    'estados_unidos': ['tv://nova_us', 'tv://fltv_group_76194', 'tv://fxp_group_76194', 'country:estados_unidos'],
    'costa_rica': ['tv://fltv_group_77691', 'tv://fxp_group_77691', 'country:costa_rica'],
    'panama': ['tv://fltv_group_77689', 'tv://fxp_group_77689', 'country:panama'],
    'puerto_rico': ['tv://fltv_group_77988', 'tv://fxp_group_77988', 'country:puerto_rico'],
    'republica_dominicana': ['tv://fltv_group_79147', 'tv://fxp_group_79147', 'country:republica_dominicana'],
    'honduras': ['tv://fltv_group_79134', 'tv://fxp_group_79134', 'country:honduras'],
    'el_salvador': ['tv://fltv_group_79145', 'tv://fxp_group_79145', 'country:el_salvador'],
    'centroamerica': ['tv://fltv_group_79127', 'tv://fxp_group_79127', 'country:centroamerica'],
    'brasil': ['tv://nova_br', 'country:brasil'],
    'latam': ['tv://latam', 'tv://nova_int'],
    'documentales': ['tv://nova_genre_documentales', 'tv://fltv_group_76196', 'tv://fxp_group_76196'],
    'entretenimiento': ['tv://nova_genre_entretenimiento'],
    'educacion': ['tv://nova_genre_educacion'],
    'religioso': ['tv://nova_genre_religioso', 'tv://fltv_group_79148', 'tv://fxp_group_79148'],
    'webcams': ['tv://webcams'],
    'eventos_ppv': ['tv://fltv_group_76200', 'tv://fxp_group_76200'],
    'nfl_pass': ['tv://fltv_group_76186', 'tv://fxp_group_76186'],
    'nba_pass': ['tv://fltv_group_76184', 'tv://fxp_group_76184'],
    'mlb_pass': ['tv://fltv_group_76195', 'tv://fxp_group_76195'],
}


def _normalize_title_key(title):
    return re.sub(r'[^a-zA-Z0-9]', '', str(title or '')).lower()


def _canales_pais_m3u(country_key):
    country_patterns = {
        'argentina': [r'\b(argentina|arg)\b'],
        'mexico': [r'\b(m[eé]xico|mx)\b'],
        'colombia': [r'\b(colombia|co)\b'],
        'peru': [r'\b(per[uú]|pe)\b'],
        'chile': [r'\b(chile|cl)\b'],
        'ecuador': [r'\b(ecuador|ec)\b'],
        'venezuela': [r'\b(venezuela|ve)\b'],
        'bolivia': [r'\b(bolivia|bo)\b'],
        'uruguay': [r'\b(uruguay|uy)\b'],
        'paraguay': [r'\b(paraguay|py)\b'],
        'estados_unidos': [r'\b(ee\.?uu\.?|usa|estados unidos)\b'],
        'costa_rica': [r'\b(costa rica|cr)\b'],
        'panama': [r'\b(panam[aá]|pa)\b'],
        'puerto_rico': [r'\b(puerto rico|pr)\b'],
        'republica_dominicana': [r'\b(rep[uú]blica dominicana|rd)\b'],
        'honduras': [r'\b(honduras|hn)\b'],
        'el_salvador': [r'\b(el salvador|sv)\b'],
        'centroamerica': [r'\bcentroam[eé]rica\b'],
        'brasil': [r'\b(brasil|brazil|br)\b'],
    }
    patterns = country_patterns.get(country_key, [country_key])
    regex = re.compile('|'.join(patterns), re.IGNORECASE)

    canales = []
    fuente = list(CANALES_BASE.get('latam', [])) + list(CANALES_BASE.get('deportes', []))
    disco = _cargar_cache_disco()
    if disco and 'latam' in disco:
        fuente = fuente + list(disco['latam'])

    vistos = set()
    for c in fuente:
        texto = f"{c.get('title', '')} {c.get('plot', '')} {c.get('group', '')}"
        if regex.search(texto):
            k = _normalize_title_key(c.get('title', ''))
            if k not in vistos:
                vistos.add(k)
                canales.append(c)
    return canales


def get_unified_chips():
    """Retorna la lista de pastillas (chips) unificadas considerando los interruptores activos."""
    import source_switches
    nova_on = source_switches.enabled('nova')
    fxp_on = source_switches.enabled('fxpplus')
    fltv_on = source_switches.enabled('fltvplus')
    tgtv2_on = source_switches.enabled('tgtv2')

    chips = []
    for key, label in UNIFIED_CATEGORIES:
        sources = UNIFIED_SOURCE_MAP.get(key, [])
        has_source = False
        for src in sources:
            if src.startswith('tv://nova_'):
                if nova_on:
                    has_source = True
                    break
            elif src.startswith('tv://fxp_'):
                if fxp_on:
                    has_source = True
                    break
            elif src.startswith('tv://fltv_'):
                if fltv_on:
                    has_source = True
                    break
            elif src.startswith('tv://tgtv2'):
                if tgtv2_on:
                    has_source = True
                    break
            else:
                has_source = True
                break
        if has_source:
            chips.append((key, label))
    return chips


def get_channels_unified(category_key):
    """Obtiene y consolida los canales unificados para una categoría dada sin duplicados."""
    key = str(category_key).lower().strip()
    if key in ('eventos_deportivos', 'agenda', 'deportes_agenda'):
        return _enriquecer_con_epg(obtener_agenda_deportes())

    sources = UNIFIED_SOURCE_MAP.get(key)
    if not sources:
        return get_channels(key)

    canales_totales = []
    vistos = set()

    for src in sources:
        try:
            if src.startswith('country:'):
                country_key = src.split(':', 1)[1]
                chs = _canales_pais_m3u(country_key)
            else:
                chs = get_channels(src)

            for c in chs:
                if not c or not isinstance(c, dict):
                    continue
                k = _normalize_title_key(c.get('title', ''))
                if not k or k in vistos:
                    continue
                vistos.add(k)
                canales_totales.append(c)
        except Exception:
            pass

    if key == 'todo':
        canales_totales = [c for c in canales_totales if not c.get('is_match') and not c.get('is_event') and not str(c.get('url', '')).startswith('tv_sport://')]

    if key == 'deportes':
        canales_totales = _filtrar_canales_deportivos(canales_totales)

    return _enriquecer_con_epg(canales_totales)

