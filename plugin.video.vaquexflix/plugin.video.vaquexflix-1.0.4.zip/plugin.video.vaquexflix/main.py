# -*- coding: utf-8 -*-
import sys, os, time, json, re, hashlib, threading, random
import urllib.parse, urllib.request, base64
import xbmc, xbmcgui, xbmcaddon, xbmcvfs, xbmcplugin

for path_req in ['script.module.six/lib', 'script.module.kodi-six/libs', 'script.module.resolveurl/lib']:
    p = xbmcvfs.translatePath(f'special://home/addons/{path_req}')
    if p and xbmcvfs.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

try:
    import resolveurl
except Exception:
    resolveurl = None

SITE_URL = "https://sololatino.net"
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_FILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/userdata.json')
CATEGORIES_FILE = os.path.join(ADDON_PATH, 'resources', 'categories.json')

def limpiar_texto(texto):
    if not texto: return ""
    t = str(texto).replace('★', '').replace('☆', '').replace('•', '-').replace('⭐', '').replace('🕒', '')
    return re.sub(r'[^\x20-\x7E\u00A0-\u017F]', '', t).strip()

def cargar_userdata():
    if xbmcvfs.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except: pass
    return {'favoritos': [], 'historial': {}}

def guardar_userdata(data):
    dir_p = os.path.dirname(DATA_FILE)
    if not xbmcvfs.exists(dir_p): xbmcvfs.mkdirs(dir_p)
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False, indent=2)
    except: pass

def cargar_catalogo_categorias():
    if xbmcvfs.exists(CATEGORIES_FILE):
        try:
            with open(CATEGORIES_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except: pass
    return {'peliculas': {}, 'series': {}}

CATALOGO_GENEROS = cargar_catalogo_categorias()

def fetch_html(url, cookies="", referer=""):
    try:
        headers = {'User-Agent': UA, 'Referer': referer or f"{SITE_URL}/"}
        if cookies: headers['Cookie'] = cookies
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=9) as r:
            return r.read().decode('utf-8', errors='ignore'), r.headers.get_all('Set-Cookie') or []
    except Exception: return "", []

def extraer_caratula_de_bloque(bloque):
    m_tmdb = re.search(r'src=[\"\'](https?://image\.tmdb\.org/[^\"\']+)[\"\']', bloque)
    if m_tmdb and 'no-poster' not in m_tmdb.group(1):
        return m_tmdb.group(1)
    
    m_img = re.search(r'<img[^>]+?src=[\"\'](https?://[^\"\']+)[\"\']', bloque)
    if m_img:
        url_i = m_img.group(1)
        if 'no-poster' not in url_i: return url_i
        
    all_imgs = re.findall(r'src=[\"\'](https?://[^\"\']+)[\"\']', bloque)
    for u in all_imgs:
        if 'no-poster' not in u and ('tmdb.org' in u or 'media' in u or '.jpg' in u or '.png' in u):
            return u
    return ""

def unpack_js(p, a, c, k, e=None, d=None):
    def _baseN(num, b):
        chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        res = ""
        while num > 0:
            res = chars[num % b] + res
            num //= b
        return res or "0"
    lookup = {}
    for i in range(c):
        key = _baseN(i, a)
        lookup[key] = k[i] if i < len(k) and k[i] else key
    def _replace(match):
        w = match.group(0)
        return lookup.get(w, w)
    return re.sub(r'\b\w+\b', _replace, p)

class MiniAES:
    SBOX = [
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
    ]
    INV_SBOX = [0] * 256
    RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]
    @classmethod
    def _init_tables(cls):
        if cls.INV_SBOX[0] != 0 or cls.INV_SBOX[1] != 0: return
        for i in range(256): cls.INV_SBOX[cls.SBOX[i]] = i
    @staticmethod
    def _xt(a): return ((a << 1) ^ 0x1b) & 0xff if (a & 0x80) else (a << 1)
    @classmethod
    def _mul(cls, a, b):
        res = 0
        while b:
            if b & 1: res ^= a
            a = cls._xt(a)
            b >>= 1
        return res
    def __init__(self, key):
        self._init_tables()
        self.key = key
        self.Nk = len(key) // 4
        self.Nr = self.Nk + 6
        self.w = self._key_expansion()
    def _key_expansion(self):
        w = [0] * (4 * (self.Nr + 1))
        for i in range(self.Nk):
            w[i] = (self.key[4*i] << 24) | (self.key[4*i+1] << 16) | (self.key[4*i+2] << 8) | self.key[4*i+3]
        for i in range(self.Nk, 4 * (self.Nr + 1)):
            temp = w[i - 1]
            if i % self.Nk == 0:
                rw = ((temp << 8) & 0xffffffff) | (temp >> 24)
                sub = (self.SBOX[(rw >> 24) & 0xff] << 24) | (self.SBOX[(rw >> 16) & 0xff] << 16) | (self.SBOX[(rw >> 8) & 0xff] << 8) | self.SBOX[rw & 0xff]
                temp = sub ^ (self.RCON[i // self.Nk] << 24)
            elif self.Nk > 6 and (i % self.Nk == 4):
                temp = (self.SBOX[(temp >> 24) & 0xff] << 24) | (self.SBOX[(temp >> 16) & 0xff] << 16) | (self.SBOX[(temp >> 8) & 0xff] << 8) | self.SBOX[temp & 0xff]
            w[i] = w[i - self.Nk] ^ temp
        return w
    def decrypt_block(self, block):
        state = [[block[r + 4 * c] for c in range(4)] for r in range(4)]
        for c in range(4):
            w = self.w[self.Nr * 4 + c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        for rnd in range(self.Nr - 1, 0, -1):
            state[1] = state[1][3:] + state[1][:3]
            state[2] = state[2][2:] + state[2][:2]
            state[3] = state[3][1:] + state[3][:1]
            for r in range(4):
                for c in range(4): state[r][c] = self.INV_SBOX[state[r][c]]
            for c in range(4):
                w = self.w[rnd * 4 + c]
                state[0][c] ^= (w >> 24) & 0xff
                state[1][c] ^= (w >> 16) & 0xff
                state[2][c] ^= (w >> 8) & 0xff
                state[3][c] ^= w & 0xff
            for c in range(4):
                u = [state[r][c] for r in range(4)]
                state[0][c] = self._mul(u[0], 0x0e) ^ self._mul(u[1], 0x0b) ^ self._mul(u[2], 0x0d) ^ self._mul(u[3], 0x09)
                state[1][c] = self._mul(u[0], 0x09) ^ self._mul(u[1], 0x0e) ^ self._mul(u[2], 0x0b) ^ self._mul(u[3], 0x0d)
                state[2][c] = self._mul(u[0], 0x0d) ^ self._mul(u[1], 0x09) ^ self._mul(u[2], 0x0e) ^ self._mul(u[3], 0x0b)
                state[3][c] = self._mul(u[0], 0x0b) ^ self._mul(u[1], 0x0d) ^ self._mul(u[2], 0x09) ^ self._mul(u[3], 0x0e)
        state[1] = state[1][3:] + state[1][:3]
        state[2] = state[2][2:] + state[2][:2]
        state[3] = state[3][1:] + state[3][:1]
        for r in range(4):
            for c in range(4): state[r][c] = self.INV_SBOX[state[r][c]]
        for c in range(4):
            w = self.w[c]
            state[0][c] ^= (w >> 24) & 0xff
            state[1][c] ^= (w >> 16) & 0xff
            state[2][c] ^= (w >> 8) & 0xff
            state[3][c] ^= w & 0xff
        return bytes(state[r][c] for c in range(4) for r in range(4))
    def decrypt_cbc(self, ciphertext, iv):
        plaintext = bytearray()
        prev = iv
        for i in range(0, len(ciphertext), 16):
            blk = ciphertext[i:i+16]
            dec = self.decrypt_block(blk)
            plaintext.extend(dec[j] ^ prev[j] for j in range(16))
            prev = blk
        pad = plaintext[-1]
        if 1 <= pad <= 16: return bytes(plaintext[:-pad])
        return bytes(plaintext)

def fnv1a_32(val_str):
    h = 2166136261
    for ch in val_str:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return f'{h:x}'

def resolver_pelisserieshoy(url_player):
    try:
        headers_get = {'User-Agent': UA, 'Referer': f"{SITE_URL}/"}
        req_p = urllib.request.Request(url_player, headers=headers_get)
        with urllib.request.urlopen(req_p, timeout=8) as r_p:
            html = r_p.read().decode('utf-8', errors='ignore')

        m_tok = re.search(r"const\s+_t\s*=\s*'([^']+)'", html)
        m_qk = re.search(r'var\s+_qk\s*=\s*(\[[^\]]+\]);', html)
        m_qc = re.search(r'var\s+_qc\s*=\s*[\"\']([^\"\']+)[\"\'];', html)
        m_src = re.search(r'var\s+_qsrc\s*=\s*[\"\']([^\"\']+)[\"\'];', html)
        if not (m_tok and m_qk and m_qc): return None

        tok = m_tok.group(1)
        qk = json.loads(m_qk.group(1))
        rt = qk[1] + qk[3] + qk[0] + qk[2]
        qc = m_qc.group(1)
        tk = fnv1a_32(f'{rt}|clk|{qc}')
        qsrc = m_src.group(1) if m_src else ""

        url_s = 'https://player.pelisserieshoy.com/s.php'
        headers_post = {
            'User-Agent': UA,
            'Referer': url_player,
            'Origin': 'https://player.pelisserieshoy.com',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        body_scan = {'a': '1', 'tok': tok, 'rt': rt, 'tk': tk}
        if qsrc: body_scan['src'] = qsrc
        req_scan = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_scan).encode('utf-8'), headers=headers_post)
        with urllib.request.urlopen(req_scan, timeout=7) as r_scan:
            scan_json = json.loads(r_scan.read().decode('utf-8'))
            servers = scan_json.get('s', [])

        body_click = {'a': 'click', 'tok': tok, 'rt': rt, 'tk': tk}
        if qsrc: body_click['src'] = qsrc
        try:
            req_click = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_click).encode('utf-8'), headers=headers_post)
            with urllib.request.urlopen(req_click, timeout=7) as r_click: pass
        except Exception: pass

        def _srv_priority(item):
            nom = item[0].lower()
            if 'player+' in nom or 'player' in nom: return 0
            if 'premium' in nom: return 1
            if 'vip' in nom: return 2
            return 3

        servers_sorted = sorted(servers, key=_srv_priority)

        for srv_nombre, v_target in servers_sorted:
            try:
                body_play = {'a': '2', 'v': v_target, 'tok': tok, 'rt': rt, 'tk': tk}
                if qsrc: body_play['src'] = qsrc
                req_play = urllib.request.Request(url_s, data=urllib.parse.urlencode(body_play).encode('utf-8'), headers=headers_post)
                with urllib.request.urlopen(req_play, timeout=7) as r_play:
                    data = json.loads(r_play.read().decode('utf-8'))
                    raw_u = data.get('u') or data.get('stream')
                    if not raw_u: continue
                    u_full = raw_u if raw_u.startswith('http') else 'https://player.pelisserieshoy.com' + raw_u

                    if 'p.php' in u_full:
                        try:
                            req_cdn = urllib.request.Request(u_full, headers={'User-Agent': UA, 'Referer': url_player})
                            req_cdn.get_method = lambda: 'HEAD'
                            with urllib.request.urlopen(req_cdn, timeout=7) as r_cdn:
                                if r_cdn.url and r_cdn.url.startswith('http') and 'p.php' not in r_cdn.url:
                                    return r_cdn.url
                        except Exception: pass
                        # p.php es un 302 que Kodi puede seguir directamente
                        return u_full
                    elif u_full.startswith('http'):
                        return u_full
            except Exception: continue
        return None
    except Exception: return None

def resolver_enlace_directo(url_target):
    if 'pelisserieshoy' in url_target:
        st = resolver_pelisserieshoy(url_target)
        if st: return st

    if resolveurl:
        try:
            if resolveurl.relevant_resolvers(url_target):
                st = resolveurl.resolve(url_target)
                if st: return st
        except Exception: pass

    try:
        html, _ = fetch_html(url_target)
        if html:
            m_pack = re.findall(r'eval\(function\((p,a,c,k,e,d|p,a,c,k,e,r)\)\{.*?return p\}\((.*?)\)\)', html, re.DOTALL)
            for _, raw_args in m_pack:
                try:
                    m_params = re.search(r"'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)", raw_args, re.DOTALL)
                    if m_params:
                        p_val, a_val, c_val, k_val = m_params.group(1), int(m_params.group(2)), int(m_params.group(3)), m_params.group(4).split('|')
                        unpacked = unpack_js(p_val, a_val, c_val, k_val)
                        m_m3u8 = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', unpacked)
                        if m_m3u8: return f"{m_m3u8.group(1)}|{urllib.parse.urlencode({'User-Agent': UA, 'Referer': url_target})}"
                except Exception: pass

            m_src = re.search(r'["\'](https?://[^\"\']+\.m3u8[^\"\']*)["\']', html)
            if m_src: return f"{m_src.group(1)}|{urllib.parse.urlencode({'User-Agent': UA, 'Referer': url_target})}"
    except Exception: pass
    return None

def resolver_embed69_hosts(url_embed):
    hosts = []
    try:
        req = urllib.request.Request(url_embed, headers={'User-Agent': UA, 'Referer': f"{SITE_URL}/"})
        with urllib.request.urlopen(req, timeout=8) as r:
            html = r.read().decode('utf-8', errors='ignore')

        m_c = re.search(r"const\s+POW_CHALLENGE\s*=\s*['\"]([^'\"]+)", html)
        m_d = re.search(r"const\s+POW_DIFFICULTY\s*=\s*(\d+)", html)
        m_s = re.search(r"const\s+POW_SALT\s*=\s*['\"]([^'\"]+)", html)
        if m_c and m_d and m_s:
            c, d, salt = m_c.group(1), int(m_d.group(1)), m_s.group(1)
            prefix = '0' * d
            nonce = 0
            aes_key_bytes = None
            while nonce < 500000:
                if hashlib.sha256(f'{c}{nonce}'.encode('utf-8')).hexdigest().startswith(prefix):
                    aes_key_bytes = hashlib.sha256(f'{c}{nonce}{salt}'.encode('utf-8')).digest()
                    break
                nonce += 1

            m_links = re.search(r'let\s+dataLink\s*=\s*(\[\{.*?\}\]);', html, re.DOTALL)
            if m_links and aes_key_bytes:
                cipher = MiniAES(aes_key_bytes)
                for grp in json.loads(m_links.group(1)):
                    lang = grp.get('video_language', 'LAT')
                    for srv in grp.get('sortedEmbeds', []):
                        try:
                            raw = base64.b64decode(srv['link'])
                            iv, ct = raw[:16], raw[16:]
                            dec = cipher.decrypt_cbc(ct, iv)
                            url_host = dec.decode('utf-8', errors='ignore').replace('`', '').strip()
                            s_name = srv.get('servername', 'Servidor')
                            hosts.append({'nombre': f"{s_name} ({lang})", 'url': url_host})
                        except Exception: pass
    except Exception: pass
    return hosts

def obtener_servidores_desde_tokens(url_pagina):
    servidores = []
    try:
        html_csrf, cookies = fetch_html(f"{SITE_URL}/sanctum/csrf-cookie")
        cookie_str = "; ".join([c.split(';')[0] for c in cookies])
        xsrf_token = ""
        for c in cookies:
            m = re.search(r'XSRF-TOKEN=([^;]+)', c)
            if m: xsrf_token = urllib.parse.unquote(m.group(1))

        html_page, _ = fetch_html(url_pagina, cookie_str)
        btns = re.findall(r'<button[^>]*data-player-token=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</button>', html_page, re.DOTALL)

        headers_api = {
            'Content-Type': 'application/json', 'Accept': 'application/json',
            'X-XSRF-TOKEN': xsrf_token, 'Cookie': cookie_str,
            'Origin': SITE_URL, 'Referer': url_pagina, 'User-Agent': UA
        }

        # 1. Buscar prioritariamente el servidor PREMIUM de alta velocidad
        for tok, nom_raw in btns:
            try:
                data_post = json.dumps({'t': tok}).encode('utf-8')
                req_api = urllib.request.Request(f"{SITE_URL}/api/player-url", data=data_post, headers=headers_api)
                with urllib.request.urlopen(req_api, timeout=7) as r_api:
                    data = json.loads(r_api.read().decode('utf-8'))
                    url_player = data.get('url')
                    if url_player and 'pelisserieshoy' in url_player:
                        servidores.append({'nombre': 'PREMIUM (Mediafire - Alta Velocidad)', 'url': url_player})
                        break
            except Exception: pass

        # 2. Si no hay pelisserieshoy, cargar los demas hosts
        if not servidores:
            for tok, nom_raw in btns:
                try:
                    data_post = json.dumps({'t': tok}).encode('utf-8')
                    req_api = urllib.request.Request(f"{SITE_URL}/api/player-url", data=data_post, headers=headers_api)
                    with urllib.request.urlopen(req_api, timeout=7) as r_api:
                        data = json.loads(r_api.read().decode('utf-8'))
                        url_player = data.get('url')
                        if url_player:
                            if 'embed69' in url_player or 'xupalace' in url_player:
                                sub = resolver_embed69_hosts(url_player)
                                if sub: servidores.extend(sub)
                                else: servidores.append({'nombre': 'Servidor Alternativo', 'url': url_player})
                            else:
                                servidores.append({'nombre': 'Servidor Alternativo', 'url': url_player})
                except Exception: pass

    except Exception: pass

    if not servidores:
        try:
            html, _ = fetch_html(url_pagina)
            m_id = re.search(r'(tt\d{7,10}(?:-\d+x\d+)?)', html) or re.search(r'data-id=[\"\']([^\"\']+)[\"\']', html)
            if m_id:
                servidores.append({'nombre': 'PREMIUM (Mediafire - Alta Velocidad)', 'url': f'https://player.pelisserieshoy.com/f/{m_id.group(1)}'})
        except Exception: pass

    return servidores

def configurar_item_video(item, titulo, thumb="", plot="", year="", rating=""):
    tit_clean = limpiar_texto(titulo)
    plot_clean = limpiar_texto(plot)
    y_clean = limpiar_texto(year)
    r_clean = limpiar_texto(rating)

    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(tit_clean)
        if plot_clean: tag.setPlot(plot_clean)
        if str(y_clean).isdigit(): tag.setYear(int(y_clean))
        if r_clean:
            try: tag.setRating(float(str(r_clean).replace('★', '').strip()))
            except: pass
    except Exception:
        info = {'title': tit_clean}
        if plot_clean: info['plot'] = plot_clean
        if str(y_clean).isdigit(): info['year'] = int(y_clean)
        item.setInfo('video', info)
        
    if thumb:
        item.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    if y_clean: item.setProperty('year', str(y_clean))
    if r_clean: item.setProperty('rating', str(r_clean))

class VaquexflixPlayer(xbmc.Player):
    def __init__(self, ui=None):
        super().__init__()
        self.ui = ui

    def onPlayBackEnded(self):
        if self.ui and self.ui.activa:
            self.ui.on_playback_ended()

    def onPlayBackStopped(self):
        if self.ui and self.ui.activa:
            self.ui.on_playback_stopped()

class VaquexflixUI(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.seccion_actual = "peliculas"
        self.estado = "categorias"
        self.categoria_actual_url = ""
        self.items_actuales = []
        self.items_originales = []
        self.serie_actual = {}
        self.episodios_actuales = []
        self.episodio_index_actual = -1
        self.temporadas_disponibles = []
        self.episodios_por_temporada = {}
        
        self.pagina_actual = 1
        self.hay_mas_paginas = True
        self.cargando_mas = False
        self.vistos_urls = set()
        self.cache_sinopsis = {}
        self.pos_anterior = -1
        self.activa = True
        self.reproduciendo_video = False
        self.en_dialogo_salida = False
        self._en_fullscreen = False
        self.session_reproduccion_activa = 0
        
        self._inicializado = False
        self._last_x_time = 0.0
        self._x_timer = None
        self.player = VaquexflixPlayer(self)

    def onInit(self):
        self.setProperty('fanart_image', os.path.join(ADDON_PATH, 'fanart.jpg'))
        if not self._inicializado:
            self._inicializado = True
            xbmc.sleep(100)
            self.actualizar_pie_de_pagina()
            self.cargar_categorias("peliculas")
            threading.Thread(target=self._monitor_scroll_y_foco, daemon=True).start()
        else:
            self.actualizar_pie_de_pagina()
            lista_ctrl = self.getControl(100)
            if lista_ctrl and self.pos_anterior >= 0:
                try: lista_ctrl.selectItem(self.pos_anterior)
                except Exception: pass

    def on_playback_stopped(self):
        self.reproduciendo_video = False
        self._en_fullscreen = False

    def _mostrar_dialogo_control_reproductor(self):
        if self.en_dialogo_salida:
            return
        self.en_dialogo_salida = True
        diag = xbmcgui.Dialog()

        # Si estamos viendo un episodio de serie con lista de episodios disponible
        if self.episodio_index_actual >= 0 and self.episodios_actuales:
            curr_idx = self.episodio_index_actual
            curr_ep = self.episodios_actuales[curr_idx]
            hay_sig = (curr_idx + 1) < len(self.episodios_actuales)
            hay_ant = curr_idx > 0

            opciones = ["Continuar viendo"]
            acciones = ["continuar"]

            if hay_sig:
                sig_tit = self.episodios_actuales[curr_idx + 1]['title']
                opciones.append(f"Siguiente capitulo: {sig_tit}")
                acciones.append("siguiente")

            if hay_ant:
                ant_tit = self.episodios_actuales[curr_idx - 1]['title']
                opciones.append(f"Capitulo anterior: {ant_tit}")
                acciones.append("anterior")

            opciones.append("Salir del reproductor")
            acciones.append("salir")

            sel = diag.select(f"Vaquexflix - {curr_ep['title']}", opciones)
            if sel == -1 or acciones[sel] == "continuar":
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            elif acciones[sel] == "siguiente":
                self.player.stop()
                self.reproducir_episodio_por_indice(curr_idx + 1)
            elif acciones[sel] == "anterior":
                self.player.stop()
                self.reproducir_episodio_por_indice(curr_idx - 1)
            elif acciones[sel] == "salir":
                self.player.stop()
                self.reproduciendo_video = False
                self._en_fullscreen = False
        else:
            resp = diag.yesno("Vaquexflix", "Deseas salir del reproductor de video?", yeslabel="Salir", nolabel="Continuar")
            if resp:
                self.player.stop()
                self.reproduciendo_video = False
                self._en_fullscreen = False
            else:
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")

        self.en_dialogo_salida = False

    def _monitor_scroll_y_foco(self):
        while self.activa and not xbmc.Monitor().abortRequested():
            try:
                # 0. Deteccion de salida de pantalla completa a la ventana principal de la app
                if self.reproduciendo_video and not self.en_dialogo_salida:
                    if self.player.isPlaying():
                        is_fs = xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
                        is_osd = xbmc.getCondVisibility("Window.IsActive(videoosd)")
                        if is_fs or is_osd:
                            self._en_fullscreen = True
                        elif self._en_fullscreen and not is_fs and not is_osd:
                            self._en_fullscreen = False
                            self._mostrar_dialogo_control_reproductor()
                    else:
                        self.reproduciendo_video = False
                        self._en_fullscreen = False

                lista_ctrl = self.getControl(100)
                if lista_ctrl:
                    pos = lista_ctrl.getSelectedPosition()
                    tot = lista_ctrl.size()

                    # Evitar salto espurio a la posicion 0 provocado por recarga de items de Kodi en segundo plano
                    if pos == 0 and self.pos_anterior > 0 and self.cargando_mas:
                        try:
                            lista_ctrl.selectItem(self.pos_anterior)
                        except Exception: pass
                        pos = self.pos_anterior

                    # 2. Deteccion de cambio de foco para actualizar sinopsis real en ID 303
                    if pos != self.pos_anterior and 0 <= pos < len(self.items_actuales):
                        self.pos_anterior = pos
                        sel = self.items_actuales[pos]
                        self._actualizar_sinopsis_de_elemento(sel)

                    # 3. Scroll infinito continuo
                    if self.estado == "elementos" and self.hay_mas_paginas and not self.cargando_mas:
                        if not self.categoria_actual_url.startswith("local://") and not self.categoria_actual_url.startswith("search://"):
                            if tot > 0 and pos >= (tot - 18):
                                self.cargar_siguiente_pagina()
            except Exception: pass
            xbmc.sleep(250)

    def _actualizar_sinopsis_de_elemento(self, sel):
        plot = sel.get('plot', '')
        if plot:
            self.actualizar_sinopsis_texto(plot)
            return

        u = sel.get('url', '')
        if not u or u.startswith('local://'):
            self.actualizar_sinopsis_texto('')
            return

        if u in self.cache_sinopsis:
            sin = self.cache_sinopsis[u]
            sel['plot'] = sin
            self.actualizar_sinopsis_texto(sin)
            return

        def _fetch_desc():
            try:
                req = urllib.request.Request(u, headers={'User-Agent': UA, 'Referer': f"{SITE_URL}/"})
                with urllib.request.urlopen(req, timeout=4) as r:
                    html_head = r.read(6000).decode('utf-8', errors='ignore')
                m_desc = re.search(r'<meta[^>]+name=[\"\']description[\"\'][^>]+content=[\"\']([^\"\']+)[\"\']', html_head, re.IGNORECASE)
                if m_desc:
                    raw_d = m_desc.group(1).strip()
                    limpia_d = re.sub(r'^Ver\s+.*?\s+online\.\s*', '', raw_d, flags=re.IGNORECASE)
                    limpia_d = limpiar_texto(limpia_d)
                    if limpia_d:
                        self.cache_sinopsis[u] = limpia_d
                        sel['plot'] = limpia_d
                        lista_ctrl = self.getControl(100)
                        if lista_ctrl and lista_ctrl.getSelectedPosition() == self.pos_anterior:
                            self.actualizar_sinopsis_texto(limpia_d)
            except Exception: pass

        threading.Thread(target=_fetch_desc, daemon=True).start()

    def actualizar_etiqueta(self, texto):
        try: self.getControl(400).setLabel(f"[B]{limpiar_texto(texto)}[/B]")
        except Exception: pass

    def actualizar_sinopsis_texto(self, texto):
        try: self.getControl(303).setText(limpiar_texto(texto))
        except Exception: pass

    def cargar_categorias(self, seccion=None):
        if seccion: self.seccion_actual = seccion
        self.estado = "categorias"
        self.actualizar_etiqueta("PELICULAS" if self.seccion_actual == "peliculas" else "SERIES")
        
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        self.items_actuales = []
        ui_items = []

        catalogo_sec = CATALOGO_GENEROS.get(self.seccion_actual, {})
        todos_posters = []
        for g_data in catalogo_sec.values():
            todos_posters.extend(g_data.get('posters', []))

        cover_todo = random.choice(todos_posters) if todos_posters else ""

        # Favoritos e historial con portadas reales filtrados por seccion actual
        data_u = cargar_userdata()
        is_sec_serie = (self.seccion_actual == "series")

        hist_items = [
            h for u, h in data_u.get('historial', {}).items()
            if h.get('is_serie', any(x in u for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-'])) == is_sec_serie
        ]
        cover_hist = hist_items[-1].get('cover', '') if hist_items else ""

        favs_items = [
            f for f in data_u.get('favoritos', [])
            if f.get('is_serie', any(x in f.get('url', '') for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-'])) == is_sec_serie
        ]
        cover_fav = favs_items[-1].get('cover', '') if favs_items else ""

        tipo_str = "peliculas" if self.seccion_actual == "peliculas" else "series"
        self.items_actuales.append({'title': "FAVORITOS", 'url': "local://favoritos", 'cover': cover_fav, 'is_serie': False, 'plot': f"Tus {tipo_str} favoritas guardadas."})
        self.items_actuales.append({'title': "RECIEN VISTOS", 'url': "local://historial", 'cover': cover_hist, 'is_serie': False, 'plot': f"Reanuda tus {tipo_str} donde las dejaste."})
        self.items_actuales.append({'title': f"TODO ({tipo_str.upper()})", 'url': f"{SITE_URL}/{self.seccion_actual}", 'cover': cover_todo, 'is_serie': False, 'plot': f"Catalogo completo de {tipo_str}."})

        # Cargar UNICAMENTE categorias con contenido real
        for g_key, g_info in catalogo_sec.items():
            posters_gen = g_info.get('posters', [])
            if not posters_gen: continue
            
            # Caratula aleatoria de contenido real de esa categoria
            portada_azar = random.choice(posters_gen)
            url_cat = f"{SITE_URL}/{self.seccion_actual}?genero={g_key}"
            nom_cat = limpiar_texto(g_info.get('nom', g_key.capitalize()))
            self.items_actuales.append({
                'title': nom_cat,
                'url': url_cat,
                'cover': portada_azar,
                'is_serie': False,
                'plot': f"Explora {tipo_str} del genero {nom_cat}."
            })

        self.items_originales = list(self.items_actuales)
        for obj in self.items_actuales:
            item = xbmcgui.ListItem(label=obj['title'])
            configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''))
            ui_items.append(item)

        lista_ctrl.addItems(ui_items)
        xbmc.sleep(40)
        self.setFocus(lista_ctrl)
        lista_ctrl.selectItem(0)
        self.pos_anterior = 0
        if self.items_actuales:
            self.actualizar_sinopsis_texto(self.items_actuales[0].get('plot', ''))

    def _parsear_tarjetas(self, html):
        items_encontrados = []
        bloques = re.findall(r'<div[^>]*class=[\"\'][^\"\']*\bcard\b[^\"\']*[\"\'].*?</a>.*?</div>', html, re.DOTALL | re.IGNORECASE)
        for bloque in bloques:
            m_link = re.search(r'href=[\"\']([^\"\']+/(pelicula|peliculas|serie|series|tv|anime)/[^\"\']+)[\"\']', bloque, re.IGNORECASE)
            if not m_link: continue
            
            href = urllib.parse.urljoin(SITE_URL, m_link.group(1))
            is_serie = any(x in href for x in ['/serie/', '/series/', '/tv/', '/anime/'])

            if self.seccion_actual == "series" and not is_serie: continue
            if self.seccion_actual == "peliculas" and is_serie: continue
            if href in self.vistos_urls: continue

            self.vistos_urls.add(href)
            img_url = extraer_caratula_de_bloque(bloque)
            
            m_title = re.search(r'alt=[\"\']([^\"\']+)[\"\']', bloque) or re.search(r'class=[\"\']card__title[\"\'][^>]*>([^<]+)<', bloque)
            titulo = limpiar_texto(m_title.group(1) if m_title else "Sin titulo")

            m_year = re.search(r'class=[\"\']card__year[\"\'][^>]*>([^<]+)<', bloque)
            year_str = limpiar_texto(m_year.group(1).strip() if m_year else "")

            m_rat = re.search(r'class=[\"\']card__rating[\"\'][^>]*>([^<]+)<', bloque)
            rating_str = limpiar_texto(m_rat.group(1).strip() if m_rat else "")

            items_encontrados.append({
                'title': titulo,
                'url': href,
                'cover': img_url,
                'is_serie': is_serie,
                'year': year_str,
                'rating': rating_str,
                'plot': ""
            })
        return items_encontrados

    def _buscar_contenido(self, query):
        def _fetch_q(q):
            try:
                u = f"{SITE_URL}/api/search/suggest?q={urllib.parse.quote_plus(q)}"
                html, _ = fetch_html(u)
                if not html: return []
                data = json.loads(html)
                return data if isinstance(data, list) else []
            except Exception:
                return []

        q_clean = query.strip()
        data = _fetch_q(q_clean)

        validos = [x for x in data if isinstance(x, dict) and x.get('type') != 'person' and '/persona/' not in x.get('url', '')]

        if not validos:
            palabras = [p for p in q_clean.split() if len(p) > 2]
            if len(palabras) > 1:
                vistos = set()
                candidatos = []
                for p in palabras:
                    sub_data = _fetch_q(p)
                    for x in sub_data:
                        if not isinstance(x, dict) or x.get('type') == 'person' or '/persona/' in x.get('url', ''):
                            continue
                        u = x.get('url', '')
                        if u and u not in vistos:
                            vistos.add(u)
                            candidatos.append(x)
                def _coincidencias(item):
                    tit = (item.get('title') or '').lower()
                    return sum(1 for p in palabras if p.lower() in tit)
                candidatos.sort(key=_coincidencias, reverse=True)
                validos = candidatos

        items_encontrados = []
        for obj in validos:
            raw_url = obj.get('url', '')
            if not raw_url: continue
            href = urllib.parse.urljoin(SITE_URL, raw_url)
            if href in self.vistos_urls: continue
            self.vistos_urls.add(href)

            tipo = obj.get('type', '')
            is_serie = any(x in href for x in ['/serie/', '/series/', '/tv/', '/anime/']) or tipo in ['series', 'tv', 'anime']
            titulo = limpiar_texto(obj.get('title') or "Sin titulo")

            year_val = obj.get('year', '')
            year_str = str(year_val).strip() if year_val is not None else ""
            poster = obj.get('poster') or ""

            items_encontrados.append({
                'title': titulo,
                'url': href,
                'cover': poster,
                'is_serie': is_serie,
                'year': year_str,
                'rating': "",
                'plot': ""
            })
        return items_encontrados

    def cargar_elementos(self, url_target, reset=True):
        self.estado = "elementos"
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return

        if reset:
            lista_ctrl.reset()
            self.items_actuales = []
            self.items_originales = []
            self.vistos_urls.clear()
            self.pagina_actual = 1
            self.hay_mas_paginas = True
            self.cargando_mas = False
            self.pos_anterior = -1
            self.categoria_actual_url = url_target

        if url_target.startswith("local://"):
            data = cargar_userdata()
            is_sec_serie = (self.seccion_actual == "series")
            tipo_str = "series" if is_sec_serie else "peliculas"
            elementos = []
            if "favoritos" in url_target:
                for f in data.get('favoritos', []):
                    u_f = f.get('url', '')
                    f_is_serie = f.get('is_serie', any(x in u_f for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))
                    if f_is_serie == is_sec_serie:
                        elementos.append(f)
            elif "historial" in url_target:
                for u, h in reversed(list(data.get('historial', {}).items())):
                    h_is_serie = h.get('is_serie', any(x in u for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))
                    if h_is_serie == is_sec_serie:
                        m, s = divmod(h.get('time', 0), 60)
                        elementos.append({
                            'title': f"{limpiar_texto(h.get('title', 'Video'))} ({m:02d}:{s:02d})",
                            'url': u,
                            'cover': h.get('cover', ''),
                            'is_serie': h_is_serie,
                            'plot': f"Reanudar reproduccion en el minuto {m:02d}:{s:02d}."
                        })
            
            if not elementos:
                elementos = [{
                    'title': "Ninguno",
                    'url': "",
                    'cover': "",
                    'is_serie': is_sec_serie,
                    'plot': f"No tienes {tipo_str} en esta seccion todavia."
                }]

            self.items_actuales = elementos
            self.items_originales = list(elementos)
            self.hay_mas_paginas = False
            ui_items = []
            for f in elementos:
                item = xbmcgui.ListItem(label=f['title'])
                configurar_item_video(item, f['title'], thumb=f.get('cover', ''), plot=f.get('plot', ''))
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            if reset and ui_items:
                xbmc.sleep(40)
                lista_ctrl.selectItem(0)
                self.pos_anterior = 0
                self.actualizar_sinopsis_texto(elementos[0].get('plot', ''))
            return

        if url_target.startswith("search://") or "/buscar" in url_target or "/api/search/suggest" in url_target:
            query = ""
            if url_target.startswith("search://"):
                query = urllib.parse.unquote_plus(url_target.replace("search://", ""))
            elif "q=" in url_target:
                query = urllib.parse.parse_qs(urllib.parse.urlparse(url_target).query).get('q', [''])[0]

            self.seccion_actual = "busqueda"
            self.actualizar_etiqueta(f"BUSQUEDA: {limpiar_texto(query).upper()}")
            self.hay_mas_paginas = False

            def _hilo_busqueda():
                self.cargando_mas = True
                xbmcgui.Dialog().notification("Vaquexflix", "Buscando contenido...", xbmcgui.NOTIFICATION_INFO, 1200)
                nuevos = self._buscar_contenido(query)
                self.items_actuales = nuevos
                self.items_originales = list(nuevos)

                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=obj['title'])
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''))
                    ui_items.append(item)

                lista_ctrl.addItems(ui_items)
                if reset and ui_items:
                    cur_p = lista_ctrl.getSelectedPosition()
                    if cur_p <= 0:
                        lista_ctrl.selectItem(0)
                        self.pos_anterior = 0
                        if self.items_actuales:
                            self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

                self.cargando_mas = False
                if not nuevos and reset:
                    xbmcgui.Dialog().notification("Vaquexflix", "No se encontraron elementos.", xbmcgui.NOTIFICATION_WARNING)

            threading.Thread(target=_hilo_busqueda, daemon=True).start()
            return

        def _hilo_fetch_inicial():
            self.cargando_mas = True
            pag = 1
            acumulados = 0
            xbmcgui.Dialog().notification("Vaquexflix", "Cargando contenido...", xbmcgui.NOTIFICATION_INFO, 1200)

            while pag <= 3 and self.hay_mas_paginas:
                sep = '&' if '?' in url_target else '?'
                url_pag = url_target if pag == 1 else f"{url_target}{sep}page={pag}"
                html, _ = fetch_html(url_pag)
                if not html:
                    self.hay_mas_paginas = False
                    break

                nuevos = self._parsear_tarjetas(html)
                if not nuevos:
                    self.hay_mas_paginas = False
                    break

                self.items_actuales.extend(nuevos)
                self.items_originales = list(self.items_actuales)
                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=obj['title'])
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''))
                    ui_items.append(item)

                pos_guardada = lista_ctrl.getSelectedPosition()
                if pos_guardada < 0:
                    pos_guardada = self.pos_anterior

                lista_ctrl.addItems(ui_items)
                acumulados += len(nuevos)

                if pag == 1 and reset and ui_items:
                    cur_p = lista_ctrl.getSelectedPosition()
                    if cur_p <= 0 and pos_guardada <= 0:
                        lista_ctrl.selectItem(0)
                        self.pos_anterior = 0
                        if self.items_actuales:
                            self._actualizar_sinopsis_de_elemento(self.items_actuales[0])
                    elif pos_guardada > 0:
                        try:
                            lista_ctrl.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass
                else:
                    if pos_guardada > 0:
                        try:
                            lista_ctrl.selectItem(pos_guardada)
                            self.pos_anterior = pos_guardada
                        except Exception: pass

                self.pagina_actual = pag
                pag += 1

            self.cargando_mas = False
            if acumulados == 0 and reset:
                xbmcgui.Dialog().notification("Vaquexflix", "No se encontraron elementos.", xbmcgui.NOTIFICATION_WARNING)

        threading.Thread(target=_hilo_fetch_inicial, daemon=True).start()

    def cargar_siguiente_pagina(self):
        if not self.hay_mas_paginas or self.cargando_mas or self.categoria_actual_url.startswith("local://") or self.categoria_actual_url.startswith("search://"):
            return

        self.cargando_mas = True
        prox_pag = self.pagina_actual + 1

        def _hilo_mas():
            try:
                sep = '&' if '?' in self.categoria_actual_url else '?'
                url_pag = f"{self.categoria_actual_url}{sep}page={prox_pag}"
                html, _ = fetch_html(url_pag)
                if not html:
                    self.hay_mas_paginas = False
                    self.cargando_mas = False
                    return

                nuevos = self._parsear_tarjetas(html)
                if not nuevos:
                    self.hay_mas_paginas = False
                    self.cargando_mas = False
                    return

                lista_ctrl = self.getControl(100)
                if not lista_ctrl:
                    self.cargando_mas = False
                    return

                self.items_actuales.extend(nuevos)
                self.items_originales = list(self.items_actuales)
                ui_items = []
                for obj in nuevos:
                    item = xbmcgui.ListItem(label=obj['title'])
                    configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''))
                    ui_items.append(item)

                pos_guardada = lista_ctrl.getSelectedPosition()
                if pos_guardada < 0:
                    pos_guardada = self.pos_anterior

                lista_ctrl.addItems(ui_items)

                if pos_guardada > 0:
                    try:
                        lista_ctrl.selectItem(pos_guardada)
                        self.pos_anterior = pos_guardada
                    except Exception: pass

                self.pagina_actual = prox_pag
            except Exception: pass
            finally:
                self.cargando_mas = False

        threading.Thread(target=_hilo_mas, daemon=True).start()

    def cargar_temporadas(self, serie_obj):
        self.estado = "temporadas"
        self.serie_actual = serie_obj
        self.actualizar_etiqueta(limpiar_texto(serie_obj['title']).upper())
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        html, _ = fetch_html(serie_obj['url'])
        if not html:
            xbmcgui.Dialog().notification("Vaquexflix", "Error al cargar temporadas", xbmcgui.NOTIFICATION_ERROR)
            return

        self.episodios_por_temporada = {}
        pattern_ep = r'<a[^>]+href=[\"\']([^\"\']+/temporada-(\d+)/episodio-(\d+)[^\"\']*)[\"\'][^>]*>(.*?)</a>'
        matches = re.findall(pattern_ep, html, re.DOTALL | re.IGNORECASE)

        for href, num_t, num_e, inner in matches:
            m_name = re.search(r'<p[^>]*class=[\"\'][^\"\']*text-sm[^\"\']*font-semibold[^\"\']*[\"\'][^>]*>\s*(.*?)\s*</p>', inner, re.DOTALL)
            raw_name = limpiar_texto(m_name.group(1).strip() if m_name else "")

            m_plot = re.search(r'<p[^>]*class=[\"\'][^\"\']*line-clamp-2[^\"\']*[\"\'][^>]*>\s*(.*?)\s*</p>', inner, re.DOTALL)
            raw_plot = limpiar_texto(m_plot.group(1).strip() if m_plot else "")

            m_thumb = re.search(r'<img[^>]+?src=[\"\'](https?://[^\"\']+)[\"\']', inner)
            thumb = m_thumb.group(1) if m_thumb else serie_obj.get('cover', '')

            ep_label = f"T{num_t}:E{num_e} - {raw_name}" if raw_name else f"T{num_t}:E{num_e} Episodio {num_e}"
            self.episodios_por_temporada.setdefault(num_t, []).append({
                'title': ep_label,
                'name': raw_name,
                'url': urllib.parse.urljoin(SITE_URL, href),
                'cover': thumb,
                'season': num_t,
                'episode': num_e,
                'plot': raw_plot
            })

        self.temporadas_disponibles = sorted(self.episodios_por_temporada.keys(), key=lambda x: int(x) if x.isdigit() else 0)
        self.items_actuales = []
        ui_items = []
        for t_key in self.temporadas_disponibles:
            label = f"Temporada {t_key}"
            num_eps = len(self.episodios_por_temporada[t_key])
            t_plot = f"{serie_obj['title']} - Temporada {t_key} ({num_eps} episodios)"
            self.items_actuales.append({
                'title': label,
                'season': t_key,
                'cover': serie_obj.get('cover', ''),
                'plot': t_plot,
                'is_serie': True
            })
            item = xbmcgui.ListItem(label=label)
            configurar_item_video(item, label, thumb=serie_obj.get('cover', ''), plot=t_plot)
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self.actualizar_sinopsis_texto(self.items_actuales[0]['plot'])
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "No hay episodios disponibles.", xbmcgui.NOTIFICATION_WARNING)

    def cargar_episodios(self, num_temp):
        self.estado = "episodios"
        lista_ctrl = self.getControl(100)
        if not lista_ctrl: return
        lista_ctrl.reset()

        self.episodios_actuales = self.episodios_por_temporada.get(str(num_temp), [])
        self.items_actuales = self.episodios_actuales
        self.actualizar_etiqueta(f"{limpiar_texto(self.serie_actual['title']).upper()} - T{num_temp}")
        ui_items = []
        for ep in self.episodios_actuales:
            item = xbmcgui.ListItem(label=ep['title'])
            configurar_item_video(item, ep['title'], thumb=ep.get('cover', ''), plot=ep.get('plot', ''))
            ui_items.append(item)

        if ui_items:
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            self.setFocus(lista_ctrl)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.episodios_actuales:
                self._actualizar_sinopsis_de_elemento(self.episodios_actuales[0])

    def reproducir_con_historial(self, titulo, url_video, cover_url="", is_serie=False, plot="", ep_index=-1):
        self.episodio_index_actual = ep_index
        url_norm = url_video.split('?')[0].rstrip('/')
        diag = xbmcgui.Dialog()
        prog = xbmcgui.DialogProgress()
        prog.create("Vaquexflix", "Conectando con el servidor...")
        servidores = obtener_servidores_desde_tokens(url_video)
        prog.close()

        if not servidores:
            diag.notification("Vaquexflix", "No se detectaron servidores disponibles", xbmcgui.NOTIFICATION_WARNING)
            return

        # Si el servidor PREMIUM esta disponible se reproduce directamente
        idx = 0
        if len(servidores) > 1:
            nombres = [s['nombre'] for s in servidores]
            idx = diag.select(f"Vaquexflix - {limpiar_texto(titulo)}", nombres)
            if idx == -1: return

        url_target = servidores[idx]['url']
        prog.create("Vaquexflix", "Resolviendo enlace de video...")
        stream_final = resolver_enlace_directo(url_target)
        prog.close()

        if not stream_final:
            diag.notification("Vaquexflix", "No se pudo reproducir este servidor", xbmcgui.NOTIFICATION_ERROR)
            return

        data_user = cargar_userdata()
        segundo_reanudar = 0
        historial = data_user.get('historial', {})
        if url_norm in historial:
            seg = historial[url_norm].get('time', 0)
            m, s = divmod(seg, 60)
            if seg > 20:
                if diag.yesno("Vaquexflix", f"Deseas reanudar desde {m:02d}:{s:02d}?", nolabel="Inicio", yeslabel="Reanudar"):
                    segundo_reanudar = seg

        stream_kodi = stream_final
        if 'ext=' not in stream_kodi and '.m3u8' not in stream_kodi:
            sep = '&' if '|' in stream_kodi else '|'
            stream_kodi = f"{stream_kodi}{sep}User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64)&ext=.mp4"

        play_item = xbmcgui.ListItem(label=limpiar_texto(titulo), path=stream_kodi)
        configurar_item_video(play_item, titulo, thumb=cover_url, plot=plot)
        play_item.setProperty('IsPlayable', 'true')

        self.session_reproduccion_activa += 1
        current_session = self.session_reproduccion_activa
        self.reproduciendo_video = True
        self._en_fullscreen = False

        # Guardar inmediatamente en historial para que aparezca en Recien Vistos de inmediato
        data_user = cargar_userdata()
        hist = data_user.setdefault('historial', {})
        hist[url_norm] = {
            'title': limpiar_texto(titulo),
            'time': max(int(segundo_reanudar), 5),
            'total': 0,
            'cover': cover_url,
            'is_serie': is_serie,
            'plot': plot
        }
        guardar_userdata(data_user)

        self.player.play(stream_kodi, play_item)

        def _guardador_en_segundo_plano():
            xbmc.sleep(1500)
            if segundo_reanudar > 0:
                for _ in range(40):
                    if not self.activa or self.session_reproduccion_activa != current_session:
                        return
                    if self.player.isPlayingVideo():
                        self.player.seekTime(segundo_reanudar)
                        break
                    xbmc.sleep(200)

            while self.activa and self.session_reproduccion_activa == current_session and self.player.isPlaying() and not xbmc.Monitor().abortRequested():
                try:
                    t = int(self.player.getTime())
                    tt = int(self.player.getTotalTime())
                    if t > 2:
                        d = cargar_userdata()
                        h = d.setdefault('historial', {})
                        if tt > 0 and (tt - t) < 45:
                            h.pop(url_norm, None)
                        else:
                            h[url_norm] = {
                                'title': limpiar_texto(titulo),
                                'time': t,
                                'total': tt,
                                'cover': cover_url,
                                'is_serie': is_serie,
                                'plot': plot
                            }
                        guardar_userdata(d)
                except Exception: pass
                xbmc.sleep(2000)

            if self.session_reproduccion_activa == current_session:
                self.reproduciendo_video = False
                self._en_fullscreen = False

        threading.Thread(target=_guardador_en_segundo_plano, daemon=True).start()

    def reproducir_episodio_por_indice(self, idx):
        if 0 <= idx < len(self.episodios_actuales):
            ep = self.episodios_actuales[idx]
            self.pos_anterior = idx
            lista_ctrl = self.getControl(100)
            if lista_ctrl and self.estado == "episodios":
                try: lista_ctrl.selectItem(idx)
                except Exception: pass
            self.reproducir_con_historial(
                ep['title'], ep['url'], cover_url=ep.get('cover', ''), is_serie=True, plot=ep.get('plot', ''), ep_index=idx
            )

    def on_playback_ended(self):
        self.reproduciendo_video = False
        self._en_fullscreen = False
        if self.episodio_index_actual >= 0 and self.episodios_actuales:
            sig_idx = self.episodio_index_actual + 1
            if sig_idx < len(self.episodios_actuales):
                sig_ep = self.episodios_actuales[sig_idx]
                xbmc.sleep(600)
                if not self.activa: return
                resp = xbmcgui.Dialog().yesno(
                    "Vaquexflix",
                    f"Deseas reproducir el siguiente episodio?\n{sig_ep['title']}",
                    yeslabel="Reproducir",
                    nolabel="Cancelar"
                )
                if resp:
                    self.reproducir_episodio_por_indice(sig_idx)

    def alternar_favorito(self, item_obj):
        data = cargar_userdata()
        favs = data.setdefault('favoritos', [])
        u = item_obj.get('url', '')
        url_norm = u.split('?')[0].rstrip('/')
        idx = next((i for i, f in enumerate(favs) if f.get('url', '').split('?')[0].rstrip('/') == url_norm), -1)
        is_serie = item_obj.get('is_serie', any(x in u for x in ['/serie/', '/series/', '/tv/', '/anime/', '/temporada-', '/episodio-']))

        if idx >= 0:
            favs.pop(idx)
            xbmcgui.Dialog().notification("Vaquexflix", "Eliminado de Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
        else:
            favs.append({
                'title': limpiar_texto(item_obj['title']),
                'url': u,
                'cover': item_obj.get('cover', ''),
                'is_serie': is_serie,
                'plot': item_obj.get('plot', '')
            })
            xbmcgui.Dialog().notification("Vaquexflix", "Anadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 1500)
        guardar_userdata(data)
        if self.categoria_actual_url == "local://favoritos":
            self.cargar_elementos("local://favoritos", reset=True)

    def eliminar_del_historial(self, item_obj):
        url_norm = item_obj.get('url', '').split('?')[0].rstrip('/')
        data = cargar_userdata()
        historial = data.get('historial', {})
        encontrado = False
        for k in list(historial.keys()):
            if k.split('?')[0].rstrip('/') == url_norm or k == item_obj.get('url', ''):
                del historial[k]
                encontrado = True
        if encontrado:
            guardar_userdata(data)
            xbmcgui.Dialog().notification("Vaquexflix", "Eliminado de Recien Vistos", xbmcgui.NOTIFICATION_INFO, 1500)
            if self.categoria_actual_url == "local://historial":
                self.cargar_elementos("local://historial", reset=True)
        else:
            xbmcgui.Dialog().notification("Vaquexflix", "No se encontro en el historial", xbmcgui.NOTIFICATION_INFO, 1200)

    def mostrar_menu_ordenar(self):
        if self.estado not in ["elementos"] or not self.items_actuales:
            return
        opciones = [
            "Por defecto (Metadata original)",
            "Ano (Mas recientes primero)",
            "Ano (Mas antiguos primero)",
            "Alfabetico (A - Z)",
            "Alfabetico (Z - A)",
            "Calificacion (Mayor a menor)"
        ]
        diag = xbmcgui.Dialog()
        sel = diag.select("Vaquexflix - Ordenar contenido", opciones)
        if sel == -1: return

        if sel == 0:
            if self.items_originales:
                self.items_actuales = list(self.items_originales)
        elif sel == 1:
            self.items_actuales.sort(
                key=lambda x: int(re.sub(r'\D', '', str(x.get('year', 0))) or 0),
                reverse=True
            )
        elif sel == 2:
            self.items_actuales.sort(
                key=lambda x: int(re.sub(r'\D', '', str(x.get('year', 9999))) or 9999)
            )
        elif sel == 3:
            self.items_actuales.sort(
                key=lambda x: limpiar_texto(x.get('title', '')).lower()
            )
        elif sel == 4:
            self.items_actuales.sort(
                key=lambda x: limpiar_texto(x.get('title', '')).lower(),
                reverse=True
            )
        elif sel == 5:
            def _get_rating(x):
                r = str(x.get('rating', '0')).replace('★', '').replace(',', '.').strip()
                try: return float(r)
                except: return 0.0
            self.items_actuales.sort(key=_get_rating, reverse=True)

        lista_ctrl = self.getControl(100)
        if lista_ctrl:
            lista_ctrl.reset()
            ui_items = []
            for obj in self.items_actuales:
                item = xbmcgui.ListItem(label=obj['title'])
                configurar_item_video(item, obj['title'], thumb=obj.get('cover', ''), plot=obj.get('plot', ''), year=obj.get('year', ''), rating=obj.get('rating', ''))
                ui_items.append(item)
            lista_ctrl.addItems(ui_items)
            xbmc.sleep(40)
            lista_ctrl.selectItem(0)
            self.pos_anterior = 0
            if self.items_actuales:
                self._actualizar_sinopsis_de_elemento(self.items_actuales[0])

    def actualizar_pie_de_pagina(self):
        txt = "[COLOR 0xFFFF3344][X][/COLOR] Buscar   [COLOR 0xFFFF3344][Y][/COLOR] Ordenar   [COLOR 0xFFFF3344][XX / C][/COLOR] Favorito/Quitar   [COLOR 0xFFFF3344][A / Enter][/COLOR] Seleccionar   [COLOR 0xFFFF3344][B / Esc][/COLOR] Volver"
        try:
            ctrl = self.getControl(501)
            if ctrl:
                ctrl.setLabel(txt)
        except Exception:
            pass

    def _on_x_pressed(self):
        now = time.time()
        if (now - self._last_x_time) < 0.42:
            self._last_x_time = 0.0
            if self._x_timer:
                self._x_timer.cancel()
                self._x_timer = None
            self._ejecutar_accion_secundaria()
        else:
            self._last_x_time = now
            if self._x_timer:
                self._x_timer.cancel()
            self._x_timer = threading.Timer(0.38, self._ejecutar_single_x)
            self._x_timer.start()

    def _ejecutar_single_x(self):
        self._x_timer = None
        if self.activa and not self.reproduciendo_video and not self.player.isPlaying():
            self.abrir_busqueda()

    def _ejecutar_accion_secundaria(self):
        if self.estado in ["elementos"]:
            lista_ctrl = self.getControl(100)
            if lista_ctrl:
                idx = lista_ctrl.getSelectedPosition()
                if 0 <= idx < len(self.items_actuales):
                    sel = self.items_actuales[idx]
                    if not sel.get('url'):
                        return
                    if self.categoria_actual_url == "local://historial":
                        self.eliminar_del_historial(sel)
                    else:
                        self.alternar_favorito(sel)

    def abrir_busqueda(self):
        kb = xbmc.Keyboard('', "Buscar peliculas o series")
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            txt = kb.getText().strip()
            if txt:
                self.seccion_actual = "busqueda"
                self.actualizar_etiqueta(f"BUSQUEDA: {limpiar_texto(txt).upper()}")
                url_busqueda = f"search://{urllib.parse.quote_plus(txt)}"
                self.cargar_elementos(url_busqueda, reset=True)

    def onClick(self, controlId):
        if controlId == 100:
            lista_ctrl = self.getControl(100)
            idx = lista_ctrl.getSelectedPosition()

            if self.estado == "categorias":
                if 0 <= idx < len(self.items_actuales):
                    cat_sel = self.items_actuales[idx]
                    self.actualizar_etiqueta(cat_sel['title'].upper())
                    self.cargar_elementos(cat_sel['url'], reset=True)
            elif self.estado == "elementos":
                if 0 <= idx < len(self.items_actuales):
                    sel = self.items_actuales[idx]
                    u = sel.get('url', '')
                    if not u:
                        return
                    if '/episodio-' in u or '/temporada-' in u:
                        self.reproducir_con_historial(sel['title'], u, cover_url=sel.get('cover', ''), is_serie=True, plot=sel.get('plot', ''), ep_index=-1)
                    elif sel.get('is_serie', False):
                        self.cargar_temporadas(sel)
                    else:
                        self.reproducir_con_historial(sel['title'], u, cover_url=sel.get('cover', ''), is_serie=False, plot=sel.get('plot', ''), ep_index=-1)
            elif self.estado == "temporadas":
                if 0 <= idx < len(self.temporadas_disponibles):
                    self.cargar_episodios(self.temporadas_disponibles[idx])
            elif self.estado == "episodios":
                if 0 <= idx < len(self.episodios_actuales):
                    ep = self.episodios_actuales[idx]
                    self.reproducir_con_historial(ep['title'], ep['url'], cover_url=ep.get('cover', ''), is_serie=True, plot=ep.get('plot', ''), ep_index=idx)

        elif controlId == 201: self.abrir_busqueda()
        elif controlId == 202: self.cargar_categorias("peliculas")
        elif controlId == 203: self.cargar_categorias("series")

    def onAction(self, action):
        aid = action.getId()
        btn_code = action.getButtonCode()

        # 1. Controles durante la reproduccion activa de video
        if self.player.isPlaying():
            # Siguiente capitulo directo
            if aid in [xbmcgui.ACTION_NEXT_ITEM, 14, 86, 88]:
                if self.episodio_index_actual >= 0 and (self.episodio_index_actual + 1) < len(self.episodios_actuales):
                    self.player.stop()
                    self.reproducir_episodio_por_indice(self.episodio_index_actual + 1)
                    return
            # Capitulo anterior directo
            elif aid in [xbmcgui.ACTION_PREV_ITEM, 15, 87, 89]:
                if self.episodio_index_actual > 0:
                    self.player.stop()
                    self.reproducir_episodio_por_indice(self.episodio_index_actual - 1)
                    return
            # Confirmacion / menu al salir del reproductor de video
            elif aid in [10, 92, 9, 13, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP]:
                self._mostrar_dialogo_control_reproductor()
                return

        # 2. Tecla 'C' en teclado: Favorito / Quitar directo
        if btn_code in [99, 67, 61507] and not self.player.isPlaying():
            self._ejecutar_accion_secundaria()
            return

        # 3. Boton X en gamepad O teclas X / F en teclado (Buscar / Doble X: Favorito o Quitar)
        es_boton_x = (
            aid in [117, 11] or
            btn_code in [120, 88, 61528, 102, 70, 61510]
        )
        if es_boton_x and not self.player.isPlaying():
            self._on_x_pressed()
            return

        # 4. Boton Y en gamepad O teclas Y / O en teclado (Ordenar contenido)
        es_boton_y = (
            aid in [18, 19, 27, 34, 175] or
            btn_code in [121, 89, 61529, 111, 79, 61519]
        )
        if es_boton_y and not self.player.isPlaying():
            self.mostrar_menu_ordenar()
            return

        # 5. Navegacion atras / Volver (B en gamepad, Esc en teclado)
        if aid in [10, 92, 9, xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            if self.estado == "episodios":
                self.cargar_temporadas(self.serie_actual)
            elif self.estado == "temporadas":
                self.cargar_elementos(self.categoria_actual_url, reset=True)
            elif self.estado == "elementos":
                self.cargar_categorias(self.seccion_actual if self.seccion_actual != "busqueda" else "peliculas")
            else:
                if xbmcgui.Dialog().yesno("Vaquexflix", "Deseas salir del complemento?", yeslabel="Salir", nolabel="Cancelar"):
                    self.activa = False
                    if self.player.isPlaying():
                        self.player.stop()
                    self.close()
            return

        super().onAction(action)

if __name__ == '__main__':
    ui = VaquexflixUI('main.xml', ADDON_PATH, 'Default', '720p')
    ui.doModal()
    del ui
