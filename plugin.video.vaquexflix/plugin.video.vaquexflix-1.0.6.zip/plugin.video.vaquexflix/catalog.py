"""Catalogo visible unico; las rutas originales se conservan como alternativas."""
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit
import servidores as s


def title(value):
    value = re.sub(r'\s*-?\s*(?:todas?\s+las?\s+)?temporadas?\b.*$', '', value, flags=re.I)
    return re.sub(r'\s*\(\d{4}(?:\s*-\s*\d{4})?\)\s*$', '', value).strip()


def same(a, b):
    if bool(a.get('is_serie')) != bool(b.get('is_serie')):
        return False
    if a.get('tmdb_id') and b.get('tmdb_id'):
        return str(a['tmdb_id']) == str(b['tmdb_id'])
    ya, yb = str(a.get('year') or '')[:4], str(b.get('year') or '')[:4]
    if ya.isdigit() and yb.isdigit() and ya != yb:
        return False
    return s.titulo_coincide(title(a.get('title', '')), title(b.get('title', '')))


def variants(item):
    return item.get('variants') or [{k: v for k, v in item.items() if k not in ('variants', 'history_keys')}]


def merge(items):
    result = []
    for original in items:
        if not original.get('url'):
            continue
        matches = [x for x in result if x['url'] == original['url'] or same(x, original)]
        if len(matches) == 1:
            item = matches[0]
            seen = {v['url'] for v in item['variants']}
            item['variants'].extend(v for v in variants(original) if v['url'] not in seen)
            for field in ('cover', 'plot', 'year', 'rating', 'tmdb_id'):
                if not item.get(field) and original.get(field):
                    item[field] = original[field]
        else:
            item = dict(original, title=title(original['title']), variants=list(variants(original)))
            result.append(item)
    return result


def parallel(calls):
    def safe(call):
        try:
            return call()
        except Exception as exc:
            s.log_resolver('Consulta de catalogo no disponible ({})'.format(type(exc).__name__))
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(safe, calls))


def search(query, experimental=False):
    if not experimental:
        return visible(s.sololatino_buscar(query), False)
    pages = parallel([lambda: s.sololatino_buscar(query), lambda: s.hackstore_search(query),
                      lambda: s.pelisjuanita_search(query), lambda: s.fuegocine_buscar(query)])
    return merge([item for page in pages if page for item in page])


def page(section, number, experimental=False):
    is_series = section == 'series'
    def primary():
        html, _ = s.fetch_html('{}/{}?page={}'.format(s.SOLOLATINO_BASE, section, number))
        items = s.sololatino_parsear_tarjetas(html, section)
        return items, bool(items)
    if not experimental:
        items, more = primary()
        return visible(items, False), more
    calls = [primary]
    for kind in (('tvshow', 'anime') if is_series else ('movie',)):
        calls.extend([lambda kind=kind: s.hackstore_catalog(kind, number),
                      lambda kind=kind: s.pelisjuanita_catalog(kind, number)])
    for label in (('Serie', 'Anime') if is_series else ('Movie',)):
        def external(label=label):
            items = s.fuegocine_catalogo(label, number)
            return items, len(items) >= s.FUEGOCINE_PAGE_SIZE
        calls.append(external)
    pages = [x for x in parallel(calls) if x]
    return merge([i for items, _ in pages for i in items if bool(i.get('is_serie')) == is_series]), any(more for _, more in pages)


def expand(item, premium_only=False):
    candidates = s.sololatino_buscar(title(item['title'])) if premium_only else search(title(item['title']), experimental=True)
    matches = [c for c in candidates if same(c, item)]
    # No adivinar entre remakes cuando faltan fechas o identificadores.
    if len(matches) == 1:
        return merge([item, matches[0]])[0]
    return item


def episodes(series, experimental=False):
    roots = [v for v in variants(series) if experimental or is_primary(v)]
    results = parallel([lambda item=item: s.obtener_episodios(item) for item in roots])
    grouped = {}
    for seasons in results:
        for season, entries in (seasons or {}).items():
            for ep in entries:
                number = str(ep.get('episode', ''))
                if not str(season).isdigit() or not number.isdigit():
                    continue
                key = (str(int(season)), str(int(number)))
                if key in grouped:
                    grouped[key]['variants'].extend(variants(ep))
                else:
                    grouped[key] = dict(ep, variants=list(variants(ep)), season=key[0], episode=key[1])
    result = {}
    for (season, _), ep in sorted(grouped.items(), key=lambda pair: tuple(map(int, pair[0]))):
        result.setdefault(season, []).append(ep)
    return result


def is_primary(item):
    host = urlsplit(item.get('url', '')).hostname or ''
    return host == 'sololatino.net' or host.endswith('.sololatino.net')


def visible(items, experimental=False):
    """Project saved entries into the active catalog without changing user data."""
    if experimental:
        return list(items)
    result = []
    for item in items:
        roots = [dict(v) for v in variants(item) if is_primary(v)]
        if roots:
            projected = dict(item)
            projected.update(roots[0])
            projected['variants'] = roots
            result.append(projected)
    return result


def visible_server(server):
    name = re.sub(r'(?i)\b(?:fuegocine|hackstore2?|pelisjuanita|sololatino)\b(?:\.[a-z]+)?', '', server.get('nombre', ''))
    return dict(server, nombre=re.sub(r'\s+', ' ', name).strip(' -') or 'Servidor')


def servers(item, experimental=False, series=None):
    options = variants(item)
    if not experimental:
        options = [v for v in options if is_primary(v)]
        if not options:
            if series and item.get('season') and item.get('episode'):
                parent = expand(series, premium_only=True)
                roots = [v for v in variants(parent) if is_primary(v)]
                for root in roots:
                    eps = s.obtener_episodios(root).get(str(item['season']), [])
                    options.extend(e for e in eps if str(e.get('episode')) == str(item['episode']))
            elif not item.get('is_serie'):
                options = [v for v in variants(expand(item, premium_only=True)) if is_primary(v)]
        # Solo se consultan los reproductores Premium de la fuente principal.
        calls = [lambda v=v: s.sololatino_obtener_servidores(v['url'], premium_only=True) for v in options]
    else:
        if not item.get('season') and not item.get('episode'):
            options = variants(expand(item))
        def fetch(v):
            url = v['url']
            if s.es_url_hackstore(url):
                return s.hackstore_servers(url)
            if s.es_url_pelisjuanita(url):
                return s.pelisjuanita_servers(url)
            if s.es_url_fuegocine(url):
                return s.fuegocine_obtener_servidores(url)
            return s.sololatino_obtener_servidores(url)
        calls = [lambda v=v: fetch(v) for v in options]
    found = parallel(calls) if calls else []
    unique = {}
    for entries in found:
        for server in entries or []:
            if not experimental and urlsplit(server['url']).hostname != 'player.pelisserieshoy.com':
                continue
            unique.setdefault(server['url'], visible_server(server))
    return s.ordenar_servidores_por_calidad(list(unique.values()))
