"""Historial por episodio, presentado como catalogo de series."""
import re


def key(url):
    return url.split('?')[0].rstrip('/')


def series_title(title):
    title = re.sub(r'^T\d+:E\d+\s*-\s*', '', title, flags=re.I)
    return re.sub(r'\s+\d+x\d+\s*$', '', title, flags=re.I).strip()


def parent(url, entry):
    if entry.get('series', {}).get('url'):
        return dict(entry['series'])
    base = re.split(r'/temporada-\d+', url)[0]
    item = {'url': base, 'title': series_title(entry.get('title', 'Serie')),
            'cover': entry.get('cover', ''), 'plot': '', 'is_serie': True}
    if base == url:
        # FuegoCine usa URLs sin relacion estructural con la serie.
        item['legacy_episode'] = url
    return item


def recent(history, series=False):
    result, seen = [], set()
    ordered = sorted(history.items(), key=lambda pair: pair[1].get('updated', 0), reverse=True)
    # Los registros antiguos no tienen fecha; conservar su orden mas reciente.
    if not any(h.get('updated') for h in history.values()):
        ordered = list(reversed(list(history.items())))
    for url, entry in ordered:
        is_series = entry.get('is_serie', '/temporada-' in url or '/episodio-' in url)
        if bool(is_series) != series:
            continue
        if series:
            item = parent(url, entry)
            identity = ('legacy', item['title'].casefold()) if item.get('legacy_episode') else key(item['url'])
        else:
            item = dict(entry, url=url, is_serie=False)
            identity = key(url)
        if identity in seen:
            continue
        seen.add(identity)
        item['history_keys'] = [u for u, h in history.items() if
            (series and h.get('is_serie') and
             (key(parent(u, h)['url']) == key(item['url']) or
              (item.get('legacy_episode') and parent(u, h)['title'].casefold() == item['title'].casefold())))
            or (not series and key(u) == key(url))]
        result.append(item)
    return result


def entry_for(history, item):
    urls = {key(item.get('url', ''))}
    urls.update(key(v.get('url', '')) for v in item.get('variants', []))
    matches = [(index, entry) for index, (url, entry) in enumerate(history.items()) if key(url) in urls]
    return max(matches, key=lambda pair: (pair[1].get('updated', 0), pair[0]))[1] if matches else {}


def resume_text(history, url):
    entry = entry_for(history, url) if isinstance(url, dict) else history.get(key(url), {})
    seconds = int(entry.get('time', 0))
    if seconds <= 0:
        return ''
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    stamp = '{:02d}:{:02d}:{:02d}'.format(hours, minutes, seconds) if hours else '{:02d}:{:02d}'.format(minutes, seconds)
    return '[COLOR yellow]Seguir viendo - {}[/COLOR]'.format(stamp)
