# Doodstream portable — 1.1.2

El resolutor en resolvers.py usa urllib y el almacen de cookies de network.py en Windows, Android y Linux/Batocera. No carga bibliotecas nativas ni ejecuta procesos auxiliares. Se eliminaron libcurl-impersonate y su codigo.

El contexto TLS conserva la validacion de certificados y hostname, anuncia HTTP/1.1 y habilita post_handshake_auth cuando esta disponible, como el contexto predeterminado de urllib. Esa diferencia permitio resolver Cleaner: Rescate vertical sin cookies y obtener MP4 HTTP 206 con Python 3.8 de Kodi. El usuario confirmo la reproduccion de la version ligera corregida en Android.

Se conservan la sesion, las cabeceras de reproduccion y el Referer final. Los espejos incluyen playmogo.com y do7go.com. Las cookies configuradas siguen siendo opcionales; un bloqueo futuro del proveedor puede requerir verificacion. Ninguna prueba garantiza todos los videos ni todas las redes.

Pruebas: tests/test_dood_portable.py, tests/test_dood_session.py y tests/test_review_regressions.py. Filemoon conserva sus aceleradores en native/ y no depende de este transporte.
