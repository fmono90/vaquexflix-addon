Estado tras la limpieza: toda la logica Python de estos resolutores reside en `resolvers.py`; los modulos auxiliares mencionados en el registro historico se han integrado y eliminado. Las bibliotecas necesarias permanecen en `native/`.

# Filemoon: calculo integrado multiplataforma

La ruta de Filemoon no ejecuta Node.js ni otro Python. ECDSA P-256 y AES-GCM usan Python del addon. La prueba de trabajo usa una biblioteca C incluida, cargada dentro de Kodi por ctypes. Si no puede cargarla, queda la ruta Python lenta y se registra el fallo.

## Plataformas incluidas

Windows x86/x86_64; Linux x86/x86_64/ARMv7/AArch64 (incluido Batocera); Android x86/x86_64/ARMv7/AArch64. La seleccion usa el sistema y los bits del proceso Python, no solamente el procesador del equipo. No se promete soporte universal para plataformas no incluidas.

En Android se copia exclusivamente la biblioteca incluida al directorio privado KODI_BINADDON_PATH que exporta Kodi, en una subcarpeta propia identificada por SHA-256. No se descarga codigo al reproducir, no se cambia la configuracion de seguridad, no requiere root ni una instalacion de Node. Los ELF estan alineados a 16 KiB y no tienen dependencias DT_NEEDED. Falta confirmar carga y reproduccion en dispositivos Android/Batocera reales.

La biblioteca no usa red, archivos, asignacion dinamica ni API de Python: recibe un nonce y calcula candidatos. Trabaja en lotes de 128; Python comprueba cancelacion y plazo entre lotes. Las cookies, tokens y enlaces firmados no se guardan en la biblioteca.

## Compilacion

Fuente: native/filemoon_pow.c. Ejecutar `python native/build.py RUTA_A_ZIG` con Zig 0.14.1. El compilador solo se necesita para desarrollar, nunca en el dispositivo del usuario. native/manifest.json registra hashes de la fuente y de cada binario.

## Evidencia del 13 de octubre de 2026

- Resolucion real de La Noche del Demonio: HLS 800p, 4.26 s desde Python Windows, sin procesos auxiliares.
- Resolucion real de Spider-Man: HLS HTTP 200 en 5.2 s con la DLL Python 3.8.15 de Kodi y subprocess.run deshabilitado.
- ARMv7 y AArch64 de Android/Linux: ejecucion emulada del kernel, coincidente con Python; no equivale a probar Android o Batocera ni sus restricciones de carga.
- Regresiones, equivalencia de hashes, seleccion ABI 32/64 bits y limites de parametros cubiertos por pruebas.

El intento anterior de Python puro tardo 157.81 s, por encima de la espera habitual de Kodi. Recuperar Node solo arreglaba Windows; esta implementacion sustituye ese atajo mediante bibliotecas incluidas por plataforma.
