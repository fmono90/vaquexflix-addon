# Actualizacion: Filemoon y DoramaExpress � 12 de octubre de 2026

La revision del repositorio latinokodi/latinuvio-V2 aporta las rutas de atestacion, pero sus resolutores inspeccionados usan una firma fija. No se copiaron esas firmas ni se ejecuto el repositorio.

Se implemento una firma ECDSA P-256 nueva por sesion, el envio del fingerprint aceptado y el descifrado AES-GCM autenticado del bloque playback. Los helpers locales usan Node.js sin paquetes adicionales. Sin Node disponible en PATH, se informa la dependencia; no se ha verificado esta ruta en Android.

Prueba real con el enlace Filemoon de Spider-Man indicado: atestacion aceptada, comprobacion automatica aceptada, respuesta playback descifrada, manifiesto HLS HTTP 200, lista de segmentos HTTP 200 y lectura de 500000 bytes del primer segmento HTTP 200. Esto verifica acceso al flujo desde Python, no reproduccion en Kodi ni el archivo completo.

DoramaExpress devuelve HTTP 403 con verificacion de Cloudflare desde Python. Se incorporaron ajustes separados para un archivo Netscape de cookies exportado por el usuario y el User-Agent del navegador que verifico el sitio. Solo se importan cf_clearance y __cf_bm de DoramaExpress; no se leen perfiles de navegadores. La verificacion puede estar ligada a IP, navegador y caducidad: la importacion no garantiza acceso. Falta probar con una exportacion vigente del usuario. Los errores no se convierten en resultados vacios exitosos.

En Kodi: Ajustes del addon > DoramaExpress. Seleccionar el archivo de cookies del sitio e introducir el User-Agent exacto del navegador con el que abre. No compartir ese archivo en el chat ni publicarlo en el repositorio.

---

Registro anterior (el HTTP 405 de abajo queda superado por la atestacion descrita arriba):

# Revisión de 1.1.1 y Filemoon — 12 de octubre de 2026

## Resultado

Filemoon sigue sin entregar un vídeo reproducible en la prueba con Spider-Man: Un nuevo día. Se avanzó en el protocolo, pero no se verificó reproducción en Kodi.

- La API `embed/details` publica `embed_frame_url`, con un dominio y ruta que pueden cambiar. Se sigue esa dirección para el mismo identificador de archivo.
- La comprobación pública del reproductor usa un cálculo con memoria aunque el campo `algorithm` de la respuesta anuncie SHA-256. Las pruebas con SHA-256 fueron rechazadas; la implementación equivalente al reproductor recibió `status: ok` y un token válido durante 1800 segundos.
- Con el token aceptado, `embed/playback` respondió HTTP 405 tanto a GET como a POST. No se obtuvo un manifiesto. No se guardan ni reutilizan tokens de esas pruebas.
- `filemoon_native.py` conserva la sesión HTTP y transmite el token al endpoint. No inicia comprobaciones durante el sondeo de metadatos.
- `filemoon_pow.js` calcula únicamente la prueba local, sin acceso a red ni ejecución de JavaScript descargado. Requiere Node.js disponible en PATH, de manera opcional. No se instaló Node ni ningún paquete. En dispositivos sin Node, el mensaje explica esa limitación; este cambio no promete compatibilidad automática con Android.
- Los reproductores antiguos conservan el intento mediante extracción HLS/JWPlayer cuando no está disponible la API nueva. No se resuelven desafíos visuales ni se integra ningún servicio de CAPTCHA de pago.

## Errores corregidos en el addon

1. Cinecalidad y Tubi figuraban en la búsqueda, pero no se consultaban al paginar el catálogo experimental. Se restauraron: Cinecalidad solo en películas; Tubi en películas y series.
2. La carga de metadatos omitía los lectores específicos de esos proveedores.
3. La etiqueta `[US VPN]` podía duplicarse y no reconocía entradas antiguas de Tubi sin `source`.
4. Cuatro rutas llamaban a `resolveurl.relevant_resolvers` fuera del bloque de manejo de errores. Si el complemento opcional fallaba, se interrumpía la reproducción antes de intentar el resolutor nativo.

## Archivo adjunto embeds.js

Se revisó el original del escritorio sin modificarlo ni ejecutarlo:

- Sus seis rutas de desempaquetado pasan `evalMatch[0]`, que contiene solo el inicio de la función, a `unpackEval`; falta el cuerpo con los argumentos y el diccionario.
- La condición genérica de StreamWish captura cualquier URL `/e/` que no contenga `vidhide`, antes de comprobar Filemoon. Termina probando códigos de otros proveedores en dominios equivocados.
- Filemoon se limita al formato antiguo con fuentes en HTML; no implementa `embed_frame_url`, la comprobación ni la API nueva.
- `crypto-js` se importa pero no se usa: agrega una dependencia que puede impedir cargar el módulo sin aportar resolución.
- `Promise.allSettled` espera todos los espejos, no devuelve el primero que funciona, y las peticiones carecen de tiempo máximo.

Por esas razones no se incorporó directamente al addon Python.

## Validación

51 pruebas automatizadas correctas, frente a las 44 iniciales. Incluyen las regresiones del catálogo, metadatos, ResolveURL, sesión/token de Filemoon, error HTTP 405 y ausencia de Node. Compilación de Python, sintaxis de JavaScript y `git diff --check` correctos. Las pruebas simuladas de respuesta de reproducción no sustituyen el fallo observado en la API real.
