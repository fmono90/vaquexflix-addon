# Revisión general — 12 de octubre de 2026

Versión instalada: 1.1.1. Se conservaron los cambios locales previos de fuentes, sesiones, reproducción y ajustes. No se creó commit ni ZIP.

## Correcciones

- Obtención de servidores y resolución del seleccionado con cancelación y un máximo de 45 segundos de espera. Los resultados tardíos no inician reproducción. Las solicitudes conservan sus tiempos individuales normales; el límite de seis segundos continúa siendo exclusivo del sondeo.
- Los trabajadores paralelos de catálogo y Doramas heredan presupuesto y cancelación. GraphQL de DoramasFlix utiliza la sesión HTTP con límite compartido.
- Cerrar el scanner cancela sus operaciones activas. Omitir, agotar el tiempo o fallar la actualización del progreso también cancela el sondeo. Se descartan resultados posteriores a la cancelación.
- Si falta el evento de cierre, después de cinco segundos se comprueba si Kodi dejó de reproducir y se permite continuar. Si aún reproduce tras quince segundos, se cancela la reproducción pendiente y se informa de la espera.
- Se evita iniciar reproducción y consultar la sinopsis al cerrar una ventana inactiva. Un error inmediato de Player.play restaura el estado del reproductor.
- El protocolo Filemoon y sus auxiliares Python ahora residen en servidores.py. Se retiró filemoon_native.py y se adaptaron sus pruebas. Los dos auxiliares JavaScript siguen siendo necesarios.
- Se retiró cache_sinopsis, sustituida por la caché de metadatos, y una importación obsoleta.

## Organización y limpieza

Separación final solicitada:

- `servidores.py`: fuentes generales, incluidas SoloLatino, Cinecalidad, Tubi, FuegoCine, HackStore, PelisJuanita y Pelisflix.
- `doramas.py`: DoramasYT, DoramasFlix y DoramaExpress, con extracción de sus páginas de reproductor.
- `resolvers.py`: todos los resolutores de hosts y conversión final a video, incluido Tubi. Una URL `dorama://` consulta primero el reproductor de la fuente y después pasa al resolutor compartido.
- `network.py`: sesiones HTTP, cookies, errores, utilidades y presupuestos compartidos. Hay una sola instancia del estado de cancelación.

Se retiraron `filemoon_native.py`, `cinecalidad.py` y `tubi.py` después de trasladar sus implementaciones y actualizar consumidores y pruebas. `dood_browser.py` y los auxiliares JavaScript siguen en uso. Los módulos de sesión, índices, historial y presentación mantienen sus responsabilidades.

La eliminación de las carpetas regenerables __pycache__ fue bloqueada por la revisión automática de seguridad; permanecen intactas.

## Verificación

- 78 pruebas automáticas correctas, incluidas comprobaciones de propiedad de fuentes/resolutores y rutas compartidas; 66 al iniciar la revisión.
- Sintaxis de los módulos raíz compatible con Python 3.8 y XML de addon/recursos válido.
- Sin definiciones globales duplicadas en los módulos raíz; revisión de referencias/importadores.
- El registro de Kodi del 12 de octubre contiene una espera de un hilo Python al salir, seguida del cierre de la aplicación. No demuestra por sí sola un bloqueo permanente ni identifica ese hilo.
- No se controló Kodi ni se certificó reproducción real. Cancelar no interrumpe instantáneamente una lectura de red ya iniciada o un proceso externo: deben alcanzar su timeout. Sí libera la espera de la interfaz y evita reproducir el resultado tardío.

## Recomendaciones pendientes

1. Probar en Kodi: cancelar durante resolución; servidor que no inicia; salir del reproductor; abrir otro servidor; cambiar de episodio. Registrar título, servidor y hora si reaparece el bloqueo.
2. Serializar userdata como operaciones completas de lectura/modificación/escritura. El guardado actual usa un temporal compartido y llamadas desde varios hilos; puede perder cambios concurrentes de favoritos/progreso.
3. Limitar el actualizador ZIP al directorio del addon y validar el paquete antes de reemplazar archivos.
4. Filemoon necesita Node.js y Dood puede usar un Python externo configurado. Verificar esos caminos en Android/Batocera antes de afirmar compatibilidad de dichos servidores.
