# Revisión de Vaquexflix — 10 de octubre de 2026

## Estado actual tras los fallos reportados dentro de Kodi

El registro real mostró `DLL load failed while importing _cffi_backend`. La prueba anterior con Python 3.8.10 oficial no reproducía esta diferencia: Kodi distribuye Python 3.8.15 como `python3.8.dll`, mientras que el wheel de CFFI importa `python38.dll`. Además, `_wrapper.pyd` importaba `python3.dll`, cuyas exportaciones en esta instalación redirigen a `python38`.

Se corrigieron las referencias de importación de ambos módulos nativos, dentro de `script.module.curlcffi/lib/windows_x64/cp38`, para enlazar directamente con `python3.8.dll`. No se modificaron las DLL de Kodi. Los originales están respaldados en `%TEMP%/vaquexflix-cffi-before-kodi-dll-fix.pyd` y `%TEMP%/vaquexflix-wrapper-before-kodi-dll-fix.pyd`. Estos binarios quedan adaptados a Kodi para Windows/Python 3.8; no son los binarios originales del wheel.

La verificación se repitió en un proceso aislado que carga la DLL y la biblioteca estándar de la instalación real de Kodi. Ambos módulos cargan correctamente y **34 pruebas y compilación pasan con Python 3.8.15 de Kodi**. El script reproducible está en `tests/verify_kodi_runtime.ps1`; admite la biblioteca estándar oficial como suplemento de pruebas, porque Kodi omite unittest. No controla el proceso ni el reproductor abierto de Kodi.

**Bloqueo externo actual:** al comprobar la web de nuevo, respondió HTTP 403 y una página explícita Cloudflare **1006**, informando que el propietario del sitio bloqueó la IP de salida. Esto sustituye el diagnóstico anterior de un simple CAPTCHA. No se ha determinado cuándo ni por qué se aplicó el bloqueo. La [documentación oficial](https://developers.cloudflare.com/support/troubleshooting/http-status-codes/cloudflare-1xxx-errors/error-1006/) indica que el propietario del sitio debe revisar o permitir el acceso.

Se añadió una pausa de solicitudes de 15 minutos tras detectar ese bloqueo, compartida entre hilos del proceso del addon, y un aviso específico al intentar abrir temporadas o reproducir. El catálogo guardado se conserva. Las pruebas finales fueron locales, sin repetir solicitudes a la web bloqueada.

La reproducción sigue sin poder confirmarse dentro de Kodi. Reiniciar Kodi cargará las bibliotecas corregidas, pero no elimina el bloqueo 1006 del sitio.

Los siguientes apartados conservan los resultados de las etapas anteriores; el estado vigente es el descrito arriba.

## Estado más reciente: sesión importada y acceso en vivo recuperado

Se importó la solicitud cURL entregada por el usuario en `C:\Users\Usuario\Desktop\sololatino.txt`, analizándola como texto sin ejecutarla. Se extrajeron únicamente la cookie de verificación y el User-Agent. Se guardaron en el perfil local del addon y en sus ajustes, conservando el valor existente de Experimental. No se copiaron las cookies de cuenta del navegador.

Se corrigieron dos problemas adicionales encontrados durante la prueba real:

- Un vencimiento `0` en un archivo Netscape representa una cookie de sesión; el importador ahora lo convierte al formato que espera Python.
- Una página normal de SoloLatino incluye `/cdn-cgi/challenge-platform/`. Ese script no prueba que exista un bloqueo. La detección ahora identifica la página de desafío por su título, formulario o configuración de desafío.

TODO prioriza nuevamente la web en vivo y recurre al catálogo publicado local solo cuando el acceso inicial falla. La navegación conserva el origen elegido para no mezclar la paginación de la web (36 títulos) con la local (30).

Comprobaciones reales con Python 3.8 y la sesión importada:

- Películas: HTTP 200, 36 tarjetas por página; se consultaron las páginas 1 y 2. La fuente repitió cuatro títulos entre ellas; el catálogo ya deduplica por URL al agregarlos.
- Series: 36 tarjetas. La ficha de prueba «Rage (Furia)» entregó 2 temporadas y 9 episodios.
- Modo normal: un servidor Premium para la película «Solo necesitas matar» y para un episodio de la serie probada.
- El Premium de la película resolvió a un enlace de `download2297.mediafire.com`.
- **33 pruebas correctas**, compilación en Python 3.8 y `git diff --check` correctos.

Se requiere reiniciar Kodi para cargar módulos y ajustes actualizados. No se inició reproducción en el reproductor de Kodi. La cookie de Cloudflare puede caducar o ser revocada; en ese caso se deberá renovar la verificación. El catálogo local permanece disponible como respaldo.

Los apartados siguientes describen las etapas previas, cuyos bloqueos de acceso quedaron superados en las comprobaciones anteriores.

## Seguimiento prioritario: SoloLatino y TODO en modo normal

El registro posterior de Kodi confirmó que el paquete 0.16.3 no bastaba: Kodi 21.3 de esta instalación usa Python 3.8, mientras que ese paquete requiere Python >=3.10; además, faltaba `_cffi_backend`.

Se añadieron paquetes oficiales de PyPI compatibles dentro de `../script.module.curlcffi/lib/windows_x64/cp38`: curl_cffi 0.9.0, cffi 1.17.1, certifi 2026.7.22 y pycparser 2.23. El cargador existente selecciona cp38 según el intérprete. Se verificó importación nativa y funcionamiento de las pruebas con Python 3.8.10 embebido oficial, separado de Kodi. Sigue pendiente comprobar esa importación dentro de Kodi tras reabrirlo.

`TODO` ahora usa el catálogo publicado de SoloLatino: páginas de 30 títulos, separación de películas/series, orden por título y actualización en segundo plano. No expone un índice incompleto. Con la base real, las primeras páginas de ambas secciones devuelven 30 títulos de SoloLatino en aproximadamente 14 ms. Si no existe catálogo guardado y la web falla, muestra un aviso de acceso en lugar de afirmar que no hay contenido. Al usar la copia local se muestra «Mostrando catalogo guardado».

También se corrigió el reconocimiento de enlaces relativos `/pelicula/...` en las tarjetas.

El usuario completó la verificación de Cloudflare en el navegador y se comprobó que la web muestra películas. Una nueva petición HTTP independiente sigue recibiendo 403: el permiso del navegador no se transmite automáticamente a Kodi.

Se agregó una sesión persistente para las solicitudes de SoloLatino y dos ajustes de conexión:

1. Cookies de verificación del navegador en un archivo local Netscape `.txt`.
2. User-Agent del mismo navegador que completó la verificación.

La importación está preparada en Ajustes del complemento → SoloLatino. Solo toma `cf_clearance` y `__cf_bm` vigentes de sololatino.net/www.sololatino.net; omite cookies de cuenta y otros dominios. Conserva las cookies de sesión/CSRF que entrega el sitio y utiliza un User-Agent consistente. Se contempla el formato `#HttpOnly_`, que Python 3.8 ignora de forma predeterminada. No se registran valores de cookies.

**Pendiente de un archivo exportado por el usuario:** verificar que esa sesión permite acceder a fichas, episodios y servidores desde Kodi. La herramienta de navegador disponible no ofrece exportación de cookies. La importación por sí sola no garantiza que Cloudflare acepte una sesión trasladada; se comprobará con una petición real. No se afirma que la reproducción esté resuelta.

Verificación actual: **31 pruebas correctas en Python 3.8**, compilación de los módulos modificados y `git diff --check` correctos. Respaldo previo a este seguimiento: `C:\Users\Usuario\AppData\Local\Temp\vaquexflix-sololatino-20261010-083224`.

Lo siguiente conserva el diagnóstico de la primera revisión para distinguir ambas verificaciones.

Se revisaron los cambios locales contra HEAD, el resumen entregado, las pruebas existentes, el registro de Kodi y los catálogos SQLite en modo de lectura. Se conservaron los cambios previos y las fuentes existentes.

## Correcciones aplicadas

- Cinecalidad vuelve a participar en búsquedas experimentales globales y de películas. Sus fichas usan su propio extractor de servidores.
- Las fichas de Pelisflix usan su extractor de servidores; antes se enviaban al de SoloLatino.
- Dood recupera el flujo anterior con una sesión de cookies compartida entre las dos solicitudes y la URL final de redirección como origen y referente. No se verificó reproducción real de Dood.
- Tubi tolera cambios de artículos/preposiciones sin dejar de exigir las palabras significativas. La consulta real «la luz de tus ojos» devuelve «La Luz En Tus Ojos». No se modificó su extracción ni reproducción de HLS.
- La caché de búsquedas cambia de versión para no reutilizar resultados anteriores a las correcciones.
- La prioridad de audio usa palabras completas de la etiqueta de audio. Buscar simplemente `es` en todo el nombre clasificaba incorrectamente servidores como españoles.
- La función de ordenado experimental ya no elimina Google Drive/Vidhide. No tenía llamadas actuales: era un defecto latente, no una causa demostrada del fallo visible.
- Se corrigió la importación `curlcffi` a `curl_cffi` y se ejecuta el cargador de plataforma de la dependencia Kodi cuando es necesario. Los errores de carga ya no se silencian.
- Las peticiones curl reconocen los alias presentes de Filemoon y Dood, respetan el presupuesto del sondeo, no modifican los headers del llamador y descartan respuestas HTTP de error o páginas de desafío. Se registran host, estado y tipo de error, sin cuerpos ni tokens.

## Dependencia reparada

En `../script.module.curlcffi/lib/windows_x64` faltaba `curl_cffi.libs/libcurl-impersonate-1172405423dc93b7aeed557f2a2ca325.dll`.

Se restauró únicamente esa DLL desde el wheel oficial de PyPI de la misma versión 0.16.3. Su SHA-256 coincide con el RECORD ya instalado y con el wheel descargado. Después, la importación nativa funcionó en Python 3.13 de terminal. No se verificó la carga dentro del intérprete de Kodi ni en Android.

La API e importación se contrastaron con la [documentación oficial de curl_cffi](https://github.com/lexiforest/curl_cffi/blob/main/docs/quick_start.rst).

## Pendiente: acceso a SoloLatino

La petición real a `/peliculas` devuelve HTTP 403 tanto con urllib como con curl_cffi y perfil chrome; este último recibe una página de desafío. Reparar la dependencia no resolvió el bloqueo externo. No se da por funcional un cambio de perfil sin evidencia.

El resumen recibido afirmaba que el índice estaba vacío, pero `sololatino_catalog.sqlite` contiene 19.612 títulos. La búsqueda local «la luz» devuelve 24 resultados. Se conservó la base: borrarla eliminaría el catálogo utilizable mientras la web continúa bloqueada. Las categorías consultan la web directamente, no este índice; por eso pueden fallar aunque la búsqueda local funcione.

Tubi contiene 82.259 títulos. La comprobación de búsqueda real se hizo desactivando la actualización de red durante esa lectura.

## Verificación y respaldo

- Antes: 19 pruebas, un fallo y un error.
- Después: 25 pruebas correctas, incluidas seis nuevas pruebas de regresión.
- Compilación de main.py, catalog.py, servidores.py y tubi.py correcta.
- `git diff --check` correcto.
- No se inició reproducción ni se controló la interfaz de Kodi. Reiniciar Kodi permite cargar el código y la dependencia reparados; la reproducción debe comprobarse allí.
- Copias de los cuatro archivos antes de esta revisión y wheel utilizado: `C:\Users\Usuario\AppData\Local\Temp\vaquexflix-review-20261010-082607`.
