from contextlib import closing
import http.cookiejar
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.request import build_opener, HTTPCookieProcessor

import sessions


class BrowserSessionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.profile = Path(self.temp.name)
        (self.profile / 'compatibility.ini').write_text(
            '[Compatibility]\nLastVersion=157.0.1_build\nLastOSABI=WINNT_x86_64-msvc\n')
        with closing(sqlite3.connect(str(self.profile / 'cookies.sqlite'))) as db, db:
            db.execute('CREATE TABLE moz_cookies (host,path,isSecure,expiry,name,value,originAttributes,lastAccessed)')
            for host, name, value, attrs, stamp, expiry in [
                ('.doramaexpress.com', 'cf_clearance', 'old', '', 10, 4102444800),
                ('.doramaexpress.com', 'cf_clearance', 'fresh', '^partitionKey=%28https%2Cdoramaexpress.com%29', 10, 4102444800),
                ('.doramaexpress.com', 'login', 'secret', '', 100, 4102444800),
                ('.other.test', 'cf_clearance', 'other', '', 100, 4102444800),
                ('.doramaexpress.com', 'cf_clearance', 'container', '^userContextId=1', 100, 4102444800),
                ('.doramaexpress.com', '__cf_bm', 'expired', '', 100, 1),
            ]:
                db.execute('INSERT INTO moz_cookies VALUES (?,?,?,?,?,?,?,?)',
                           (host, '/', 1, expiry, name, value, attrs, stamp))
        handle = patch.object(sessions, '_firefox_profiles', return_value=[self.profile])
        handle.start()
        self.addCleanup(handle.stop)

    def test_first_party_partition_and_no_unrelated_cookies(self):
        cookies, agent = sessions.firefox_verification()
        self.assertEqual([(c.name, c.value) for c in cookies], [('cf_clearance', 'fresh')])
        self.assertIn('Firefox/157.0', agent)

    def test_cookie_change_is_read_on_next_request_without_export(self):
        for value in ('fresh', 'renewed'):
            jar = http.cookiejar.CookieJar()
            with patch.object(sessions, 'browser_settings', return_value=('missing.txt', 'old-agent')):
                agent = sessions.configure(build_opener(HTTPCookieProcessor(jar)), 'doramaexpress', ('doramaexpress.com',))
            self.assertEqual([c.value for c in jar], [value])
            self.assertIn('Firefox/157.0', agent)
            with closing(sqlite3.connect(str(self.profile / 'cookies.sqlite'))) as db, db:
                db.execute("UPDATE moz_cookies SET value='renewed' WHERE value='fresh'")

    def test_unavailable_database_falls_back(self):
        (self.profile / 'cookies.sqlite').unlink()
        self.assertIsNone(sessions.firefox_verification())
        self.assertFalse((self.profile / 'cookies.sqlite').exists())

    def test_spoofed_identity_is_not_guessed(self):
        (self.profile / 'prefs.js').write_text('user_pref("privacy.resistFingerprinting", true);')
        self.assertIsNone(sessions.firefox_verification())
