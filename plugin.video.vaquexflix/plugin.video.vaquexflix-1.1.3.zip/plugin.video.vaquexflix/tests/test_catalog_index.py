import network
import resolvers
import os
import tempfile
import unittest
from unittest.mock import patch

import servidores
import catalog
import catalog_index as index


def item(number):
    return {'url': 'https://sololatino.net/pelicula/amor-%d' % number,
            'title': 'Amór %d' % number, 'is_serie': False, 'source': 'sololatino'}


class SoloLatinoIndexTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        db = patch.object(index, 'database', return_value=os.path.join(self.temp.name, 'index.db'))
        db.start()
        self.addCleanup(db.stop)
        bg = patch.object(index, 'ensure_background')
        bg.start()
        self.addCleanup(bg.stop)

    def build(self, last=10):
        def page(section, number):
            numbers = range(1, 6) if number == 1 else range(6, last + 1)
            return [item(n) for n in numbers], 2
        with patch.object(index, 'SECTIONS', ('peliculas',)), patch.object(index, 'fetch_page', side_effect=page):
            self.assertTrue(index.refresh(force=True))

    def test_all_matches_without_six_result_limit(self):
        self.build()
        results = servidores.sololatino_buscar('amor')
        self.assertEqual(len(results), 10)
        self.assertEqual(index.search('amor 1')[0]['title'], 'Amór 1')
        with patch.object(servidores, '_sololatino_sugerencias') as suggest:
            self.assertEqual(servidores.sololatino_buscar('missing'), [])
            suggest.assert_not_called()

    def test_failed_refresh_preserves_catalog_then_success_removes_titles(self):
        self.build()
        revision = index.revision()
        def failed(section, number):
            if number == 2:
                raise RuntimeError('offline')
            return [item(1)], 2
        with patch.object(index, 'SECTIONS', ('peliculas',)), patch.object(index, 'fetch_page', side_effect=failed):
            with self.assertRaises(RuntimeError):
                index.refresh(force=True)
        self.assertEqual(len(index.search('amor')), 10)
        self.assertEqual(index.revision(), revision)
        self.build(last=8)
        self.assertEqual(len(index.search('amor')), 8)
        self.assertEqual(index.search('amor 10'), [])
        self.assertNotEqual(index.revision(), revision)

    def test_repeated_page_does_not_replace_index(self):
        self.build()
        with patch.object(index, 'SECTIONS', ('peliculas',)), patch.object(index, 'fetch_page', return_value=([item(1)], 2)):
            with self.assertRaises(ValueError):
                index.refresh(force=True)
        self.assertEqual(len(index.search('amor')), 10)

    def test_first_build_uses_live_suggestions(self):
        with patch.object(servidores, '_sololatino_sugerencias', return_value=[item(1)]) as suggest:
            self.assertEqual(servidores.sololatino_buscar('amor'), [item(1)])
            suggest.assert_called_once_with('amor')

    def test_browse_published_catalog_offline_with_pagination(self):
        self.build(last=65)
        with patch.object(network, 'fetch_html', return_value=('', [])):
            first, more = catalog.page('peliculas', 1, experimental=False)
            second, more2 = catalog.page('peliculas', 2, experimental=False)
            last, end = catalog.page('peliculas', 3, experimental=False)
            self.assertEqual((len(first), len(second), len(last)), (30, 30, 5))
            self.assertEqual((more, more2, end), (True, True, False))
            self.assertEqual(len({i['url'] for i in first + second + last}), 65)
            self.assertTrue(all(i['catalog_cached'] for i in first))
            self.assertEqual(catalog.page('peliculas', 4, False), ([], False))

    def test_live_catalog_is_preferred_and_paging_does_not_mix_sources(self):
        self.build()
        markup = '<div class="card"><a href="/pelicula/new"><img alt="New title"></a></div>'
        with patch.object(network, 'fetch_html', return_value=(markup, [])) as fetch:
            self.assertEqual(catalog.page('peliculas', 1, False)[0][0]['title'], 'New title')
            fetch.reset_mock()
            self.assertEqual(len(catalog.page('peliculas', 1, False, primary_source='cache')[0]), 10)
            fetch.assert_not_called()
        with patch.object(network, 'fetch_html', return_value=('', [])):
            with self.assertRaises(network.ServidorNoDisponible):
                catalog.page('peliculas', 2, False, primary_source='live')

    def test_browse_separates_series_and_movies(self):
        self.build()
        import json
        from contextlib import closing
        with closing(index.connect()) as db, db:
            for number, kind in enumerate(('serie', 'series', 'tv', 'anime')):
                entry = dict(item(number), url='https://sololatino.net/%s/example' % kind, is_serie=True)
                db.execute('INSERT INTO titles VALUES (?,?,?)', (entry['url'], index.normalize(entry['title']), json.dumps(entry)))
        self.assertEqual(len(index.page('series')[0]), 4)
        self.assertEqual(len(index.page('peliculas')[0]), 10)
        self.assertEqual(len(index.page('all')[0]), 14)
        with self.assertRaises(ValueError):
            index.page('peliculas', 0)

    def test_unpublished_catalog_falls_back_to_web_and_reports_failure(self):
        self.assertIsNone(index.page('peliculas'))
        with patch.object(network, 'fetch_html', return_value=('', [])):
            with self.assertRaisesRegex(network.ServidorNoDisponible, 'no hay catalogo guardado'):
                catalog.page('peliculas', 1, False)
        markup = '<div class="card"><a href="/pelicula/example"><img alt="Example"></a></div>'
        with patch.object(network, 'fetch_html', return_value=(markup, [])):
            entries, more = catalog.page('peliculas', 1, False)
            self.assertEqual(len(entries), 1)
            self.assertNotIn('catalog_cached', entries[0])


if __name__ == '__main__':
    unittest.main()
