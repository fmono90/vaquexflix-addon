import network
import resolvers
import unittest
from unittest.mock import patch

import catalog
import servidores as c
import servidores as s


def card(slug):
    return '<div class="home_post_cont"><a href="/pelicula/%s/"><img alt="%s (2025)" src="/poster.jpg"></a></div>' % (slug, slug)


class CinecalidadTests(unittest.TestCase):
    def test_search_follows_pages_and_deduplicates(self):
        first = c.cinecalidad_soup(card('Batman') + '<a href="/page/2/?s=Batman">Más películas</a>')
        second = c.cinecalidad_soup(card('Batman') + card('Batman Returns'))
        with patch.object(c, 'cinecalidad_fetch', side_effect=[first, second]) as fetch:
            found = c.cinecalidad_search('Batman')
        self.assertEqual(len(found), 2)
        self.assertEqual(fetch.call_args.args[0], c.cinecalidad_BASE + '/page/2/?s=Batman')
        self.assertEqual(found[0]['year'], '2025')
        self.assertFalse(found[0]['is_serie'])
        self.assertFalse(c.cinecalidad_owns('https://cinecalidad.my.evil.test/'))

    def test_online_players_exclude_trailers_and_downloads(self):
        markup = '<div id="panel_online"><a service="OnlineVoe" data="abc"></a><a service="Trailer" data="xyz"></a><a service="OnlineFilemoon" data="def"></a></div><a service="OnlineMega" data="download"></a>'
        with patch.object(c, 'cinecalidad_fetch', return_value=c.cinecalidad_soup(markup)):
            result = c.cinecalidad_servers({'url': c.cinecalidad_BASE + '/pelicula/test/'})
        self.assertEqual([x['url'] for x in result], ['https://voe.sx/e/abc', 'https://bysedikamoum.com/e/def'])
        with patch.object(resolvers, 'resolver_filemoon', return_value='stream') as resolve:
            self.assertEqual(resolvers.resolver_stream(result[1]['url']), 'stream')
            resolve.assert_called_once_with(result[1]['url'])

    def test_only_experimental_movies_and_global_search(self):
        item = {'title': 'Example', 'url': c.cinecalidad_BASE + '/pelicula/example/', 'is_serie': False}
        # Exercise dispatch without making requests to unrelated providers.
        with patch.object(c, 'cinecalidad_search', return_value=[item]) as search, patch.object(catalog, 'parallel', side_effect=lambda calls: [call() for call in calls if 'cinecalidad' in call.__code__.co_names]), patch.object(s, 'sololatino_buscar', return_value=[]):
            self.assertEqual(len(catalog.search('Example', True, 'peliculas')), 1)
            self.assertEqual(len(catalog.search('Example', True, 'all')), 1)
            self.assertEqual(catalog.search('Example', True, 'series'), [])
            self.assertEqual(catalog.search('Example', True, 'doramas'), [])
            self.assertEqual(catalog.search('Example', False, 'peliculas'), [])
            self.assertEqual(search.call_count, 2)
        with patch.object(catalog, 'expand', side_effect=lambda x: x), patch.object(c, 'cinecalidad_servers', return_value=[{'nombre': 'Voe', 'url': 'https://voe.sx/e/abc'}]) as servers:
            self.assertEqual(catalog.servers(item, True)[0]['url'], 'https://voe.sx/e/abc')
            servers.assert_called_once_with(item)


if __name__ == '__main__':
    unittest.main()
