import unittest
import urllib.error
import ssl
from unittest.mock import Mock, patch

import network
import resolvers


class PortableDoodTests(unittest.TestCase):
    def test_standard_tls_keeps_certificate_validation(self):
        context = ssl.create_default_context()
        with patch.object(network.ssl, 'create_default_context', return_value=context):
            network.nueva_sesion(standard_tls=True)
        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)
        if getattr(context, 'post_handshake_auth', None) is not None:
            self.assertTrue(context.post_handshake_auth)

    def test_all_platforms_resolve_mirror_without_native_libraries(self):
        for target in ('android-aarch64', 'android-armv7', 'linux-x86_64', 'windows-x86_64'):
            with self.subTest(target=target):
                opener = Mock(handlers=[])
                page = Mock()
                page.read.return_value = b"'/pass_md5/example'; '?token=abc&expiry='"
                page.geturl.return_value = 'https://playmogo.com/e/1'
                prefix = Mock()
                prefix.read.return_value = b'https://cdn.example/video/'
                page_context, prefix_context = Mock(), Mock()
                for context, value in ((page_context, page), (prefix_context, prefix)):
                    context.__enter__ = Mock(return_value=value)
                    context.__exit__ = Mock(return_value=False)
                opener.open.side_effect = [
                    urllib.error.HTTPError('https://do7go.com/e/1', 403, 'blocked', {}, None),
                    page_context, prefix_context]
                with patch.object(resolvers, '_fm_native_target', return_value=target), \
                     patch.object(resolvers.ctypes, 'CDLL', side_effect=AssertionError('Native library not allowed')) as native, \
                     patch.object(resolvers, '_dood_configure', return_value='agent'), \
                     patch.object(network, 'nueva_sesion', return_value=opener):
                    result = resolvers.resolver_dood('https://do7go.com/e/1')
                native.assert_not_called()
                self.assertTrue(result.startswith('https://cdn.example/video/'))
                self.assertEqual(opener.open.call_args_list[1].args[0].full_url,
                                 'https://playmogo.com/e/1')
                self.assertEqual(opener.open.call_args_list[2].args[0].get_header('Referer'),
                                 'https://playmogo.com/e/1')
