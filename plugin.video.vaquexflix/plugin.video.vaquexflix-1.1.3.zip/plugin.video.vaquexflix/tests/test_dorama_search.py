import io
import json
import unittest
from unittest.mock import Mock, patch
import doramas
import catalog

class SearchTests(unittest.TestCase):
    def test_flix_uses_variables_and_reports_partial_errors(self):
        payload = {'data': {'searchDorama': [{'slug': 'eyes', 'name_es': 'Ojos'}], 'searchMovie': []}}
        opener = Mock()
        opener.open.side_effect = lambda *a, **k: io.BytesIO(json.dumps(payload).encode())
        with patch.object(doramas.network, 'nueva_sesion', return_value=opener):
            result = doramas.DoramasFlix().search('ojos')
            self.assertEqual(result['items'][0]['title'], 'Ojos')
            sent = json.loads(opener.open.call_args.args[0].data)
            self.assertEqual(sent['variables']['input'], 'ojos')
            payload['errors'] = [{'message': 'unavailable'}]
            with self.assertRaises(doramas.SourceError):
                doramas.DoramasFlix().search('ojos')

    def test_failed_provider_is_named(self):
        with patch.object(catalog.s, 'tubi_is_available', return_value=False), patch.object(catalog, 'parallel', return_value=[None, [], [], [], [], [], []]):
            result = catalog.search('ojos', experimental=True)
        self.assertEqual(result.errors, ['SoloLatino'])


    def test_express_cookie_reload_is_bounded(self):
        from urllib.error import HTTPError
        from email.message import Message
        token = '1792913978.' + 'a' * 64
        body = ("document.cookie='ypg_chal=" + token + ";path=/';").encode()
        client = doramas._Client('https://yandispoiler.net')
        error = lambda: HTTPError(client.base, 503, 'Verification', Message(), io.BytesIO(body))
        client.opener = Mock()
        client.opener.open.side_effect = [error(), error()]
        with self.assertRaises(doramas.SourceError):
            client.request(client.base + '/')
        self.assertEqual(client.opener.open.call_count, 2)
        retry = client.opener.open.call_args.args[0]
        self.assertEqual(retry.get_header('Cookie'), 'ypg_chal=' + token)

    def test_retired_provider_removed_but_other_variant_kept(self):
        valid = {'title': 'Film', 'url': 'https://cinecalidad.my/film', 'is_serie': False}
        retired = dict(valid, url='https://www.fuegocine.com/film')
        item = dict(retired, variants=[retired, valid])
        result = catalog.in_section([item])
        self.assertEqual(result[0]['url'], valid['url'])
        self.assertEqual(result[0]['variants'], [valid])


    def test_failed_episode_source_is_not_reported_as_empty(self):
        item = {'title': 'Example', 'url': 'https://doramasflix.io/doramas/example', 'is_serie': True}
        with patch.object(catalog, 'parallel', return_value=[None]):
            with self.assertRaises(catalog.network.ServidorNoDisponible):
                catalog.episodes(item, experimental=True)
        with patch.object(catalog, 'parallel', return_value=[{}]):
            self.assertEqual(catalog.episodes(item, experimental=True), {})

    def test_complete_embedded_season_does_not_call_stale_action(self):
        c = doramas.DoramasFlix()
        data = {'serie_id': 'a'*24, 'seasons': [{'season_number': 1, 'number_of_episodes': 1}],
                'initialSeason': 1, 'initialEpisodes': [{'slug': 'test-1x1', 'episode_number': 1}]}
        with patch.object(c, '_page_data', return_value=(Mock(title='Test'), json.dumps(data, separators=(',', ':')))), patch.object(c.http, 'action') as action:
            self.assertEqual(c.detail(doramas.FLIX+'/doramas/test')['episode_count'], 1)
            action.assert_not_called()

    def test_fiche_fallback_preserves_canonical_domain(self):
        c = doramas.DoramasFlix()
        with patch.object(c.http, 'request', side_effect=doramas.SourceError('offline')), patch.object(doramas, '_Client') as alternate:
            alternate.return_value.request.return_value = '<title>Test</title>'
            c._page_data(doramas.FLIX+'/doramas/test')
            alternate.assert_called_once_with('https://doramasflix.in')
            alternate.return_value.request.assert_called_once_with('https://doramasflix.in/doramas/test')


    def test_links_use_current_api_for_episode_and_movie(self):
        for field in ('getEpisodeLinks', 'getMovieLinks'):
            payload = {'data': {field: {'links_online': [{'link': 'https://example.test/embed/1', 'server': '1', 'lang': '38'}]}}}
            opener = Mock()
            opener.open.side_effect = lambda *a, **k: io.BytesIO(json.dumps(payload).encode())
            with patch.object(doramas.network, 'nueva_sesion', return_value=opener):
                c = doramas.DoramasFlix()
                links = c._links(field, 'a'*24, doramas.FLIX + '/')
                self.assertEqual(len(links), 1)
                sent = json.loads(opener.open.call_args.args[0].data)
                self.assertIn('links_online', sent['query'])
                payload['errors'] = [{'message': 'upstream unavailable'}]
                with self.assertRaises(doramas.SourceError):
                    c._links(field, 'a'*24, doramas.FLIX + '/')
