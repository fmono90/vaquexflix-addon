import network
import resolvers
import unittest
from unittest.mock import patch

import doramas
import servidores


class ExpressIntegrationTests(unittest.TestCase):
    def test_alternate_public_catalog_after_primary_failure(self):
        markup = '''<div class="display-item"><a href="https://yandispoiler.net/series/light/" title="Light"></a></div>'''
        with patch.object(doramas._Client, 'request', side_effect=[doramas.SourceError('HTTP 403'), markup]) as fetch:
            result = doramas._express_search('light')
        self.assertEqual(result['items'][0]['url'], doramas.EXPRESS + '/serie/light/')
        self.assertEqual(fetch.call_args.args[0], doramas.EXPRESS_ALTERNATE + '/?s=light')

    def test_alternate_episodes_and_unlocked_servers(self):
        markup = '''<div id="yan-list-episodes"><div onclick="window.location.href='https://yandispoiler.net/episodios/light-1x1/'">1</div></div>
        <div id="yan-list-servers"><div id="yan-lang-grid-mx-a">
        <div data-locked="0" data-url="https://dingtezuni.com/embed/a" onclick="YanPlayerApp.loadSource(this)">Earnvid</div>
        <div data-locked="1" data-url="https://example.com/private" onclick="YanPlayerApp.loadSource(this)">VIP</div>
        </div></div>'''
        with patch.object(doramas._Client, 'request', side_effect=[doramas.SourceError('HTTP 403'), markup]) as fetch:
            result = doramas._express_detail(doramas.EXPRESS + '/serie/light/')
        self.assertEqual(fetch.call_args.args[0], doramas.EXPRESS_ALTERNATE + '/series/light/')
        self.assertEqual(result['episodes'][0]['url'], doramas.EXPRESS + '/episodio/light-1x1/')
        self.assertEqual([p['server'] for p in result['embeds']], ['Earnvid'])

    def test_alternate_failure_is_not_silenced(self):
        with patch.object(doramas._Client, 'request', side_effect=doramas.SourceError('HTTP 403')):
            with self.assertRaises(doramas.SourceError):
                doramas._express_search('light')

    def test_search_collects_later_pages_and_reports_partial_failure(self):
        first = {'items': [{'url': doramas.EXPRESS + '/serie/one/', 'title': 'One', 'type': 'serie'}], 'has_next': True}
        second = {'items': [{'url': doramas.EXPRESS + '/movies/two/', 'title': 'Two', 'type': 'pelicula'}], 'has_next': False}
        with patch.object(doramas, '_express_search', side_effect=[first, second]) as fetch:
            result = doramas.DoramaExpress().search('one')
            self.assertEqual(len(result['items']), 1)
            self.assertEqual(len(result['movies']), 1)
            fetch.assert_called_with('one', 2)
        with patch.object(doramas, '_express_search', side_effect=[first, doramas.SourceError('HTTP 403')]):
            result = doramas.DoramaExpress().search('one')
            self.assertEqual(result['errors'], ['DoramaExpress'])
            self.assertEqual(len(result['items']), 1)

    def test_failed_express_search_is_visible_in_global_and_drama_results(self):
        import catalog
        with patch.object(doramas.DoramasYT, 'search', return_value={'items': []}), \
             patch.object(doramas.DoramasFlix, 'search', return_value={'items': []}), \
             patch.object(doramas.DoramaExpress, 'search', side_effect=doramas.SourceError('HTTP 403')):
            result = catalog.search('example', True, 'doramas')
            self.assertEqual(result.errors, ['DoramaExpress'])
            self.assertEqual(list(result), [])
            # Preserve the failure metadata when the global catalog merges lists.
            with patch.object(catalog, 'parallel', return_value=[result]):
                self.assertEqual(catalog.search('example', True, 'all').errors, ['DoramaExpress'])

    def test_search_pagination_and_domain(self):
        url = doramas._express_url('/page/2/?s=love')
        self.assertEqual(url, 'https://doramaexpress.com/page/2/?s=love')
        with self.assertRaises(ValueError):
            doramas._express_url('https://example.com/serie/title/')
        self.assertIsInstance(doramas.client(url), doramas.DoramaExpress)
        self.assertTrue(doramas.is_dorama({'url': url}))
        self.assertIsInstance(doramas.client(doramas.YT), doramas.DoramasYT)
        self.assertIsInstance(doramas.client(doramas.FLIX), doramas.DoramasFlix)

    def test_episode_order_and_languages(self):
        markup = '''<div id="yan-list-episodes">
        <div onclick="location='https://doramaexpress.com/episodio/test-2x3/'">3</div>
        <div onclick="location='https://doramaexpress.com/episodio/test-1x2/'">2</div>
        </div><div id="yan-list-servers">
        <div id="yan-lang-grid-kr-1"><button data-url="https://ok.ru/videoembed/1" onclick="loadSource(this)">Ok.ru</button></div>
        <div id="yan-lang-grid-mx-1"><button data-url="https://ok.ru/videoembed/2" onclick="loadSource(this)">Ok.ru</button></div>
        <div id="yan-lang-grid-downloads"><button data-url="https://example.com/download" onclick="loadSource(this)">Download</button></div></div>'''
        with patch.object(doramas._Client, 'request', return_value=markup):
            item = {'url': doramas.EXPRESS + '/serie/test/', 'title': 'Test'}
            episodes = doramas.episodes(item)
            self.assertEqual(list(episodes), ['1', '2'])
            self.assertEqual(episodes['2'][0]['episode'], '3')
            servers = doramas.servers({'url': doramas.EXPRESS + '/episodio/test-1x2/'}, True)
            self.assertEqual([s['language'] for s in servers], ['Subtitulado', 'Latino'])
            self.assertTrue(all(not s['premium'] for s in servers))

    def test_new_host_aliases(self):
        for host, resolver in [('bysevepoin.com', 'resolver_filemoon'),
                               ('player.abyssplayer.com', 'resolver_hydrax'),
                               ('dsvplay.com', 'resolver_dood'),
                               ('luluvido.com', 'resolver_host_hls')]:
            with self.subTest(host=host), patch.object(resolvers, resolver, return_value='stream') as resolve:
                url = 'https://' + host + '/e/test'
                self.assertEqual(resolvers.resolver_stream(url), 'stream')
                resolve.assert_called_once_with(url)


if __name__ == '__main__':
    unittest.main()
