import network
import resolvers
# -*- coding: utf-8 -*-
import unittest
from unittest.mock import Mock, patch
import servidores


class EmbedResolversTests(unittest.TestCase):
    def test_extraer_fuentes_hls_sources_pattern(self):
        page = """
        var player = new Player({
            sources: [
                { file: "https://stream.vidhide.com/hls/test/index.m3u8", label: "1080p" },
                { src: "https://stream.vidhide.com/video.mp4", label: "720p" }
            ]
        });
        """
        sources = resolvers.extraer_fuentes_hls(page, 'https://vidhide.com/e/123')
        self.assertIn('https://stream.vidhide.com/hls/test/index.m3u8', sources)

    def test_extraer_fuentes_hls_json_hls_pattern(self):
        page = '{"status": 200, "hls": "https:\\/\\/delivery.voe.sx\\/hls\\/stream.m3u8"}'
        sources = resolvers.extraer_fuentes_hls(page, 'https://voe.sx/e/123')
        self.assertIn('https://delivery.voe.sx/hls/stream.m3u8', sources)

    def test_extraer_fuentes_hls_direct_m3u8_and_mp4(self):
        page_m3u8 = '<div><source src="https://cdn.example.com/live/playlist.m3u8?token=xyz"></div>'
        self.assertEqual(resolvers.extraer_fuentes_hls(page_m3u8, 'https://example.com/'),
                         ['https://cdn.example.com/live/playlist.m3u8?token=xyz'])

        page_mp4 = '<video src="https://cdn.example.com/video.mp4?sig=abc"></video>'
        self.assertEqual(resolvers.extraer_fuentes_hls(page_mp4, 'https://example.com/'),
                         ['https://cdn.example.com/video.mp4?sig=abc'])

    def test_unpack_js_and_host_hls(self):
        # Packed code containing JWPlayer sources
        packed = (
            "eval(function(p,a,c,k,e,u){while(c--)if(k[c])p=p.replace(new RegExp('\\\\b'+c.toString(a)+'\\\\b','g'),k[c]);return p}"
            "('0 1={2:[{3:\"4://5.6/7.8\"}]};',9,9,'var|player|sources|file|https|cdn|video|master|m3u8'.split('|')))"
        )
        session = Mock()
        page = Mock()
        page.read.return_value = packed.encode('utf-8')
        page.geturl.return_value = 'https://vidhide.com/e/abc'
        session.open.return_value.__enter__ = Mock(return_value=page)
        session.open.return_value.__exit__ = Mock(return_value=False)

        with patch.object(network, 'nueva_sesion', return_value=session), \
             patch.object(resolvers, 'procesar_hls_local', return_value='playable_stream'):
            res = resolvers.resolver_vidhide('https://vidhide.com/e/abc')
            self.assertEqual(res, 'playable_stream')

    def test_resolver_streamwish_mirror_fallback(self):
        def side_effect(url, **kwargs):
            if 'strwish.com' in url:
                return 'stream_from_strwish'
            return None

        with patch.object(resolvers, 'resolver_host_hls', side_effect=side_effect):
            res = resolvers.resolver_streamwish('https://streamwish.to/e/xyz123')
            self.assertEqual(res, 'stream_from_strwish')

    def test_resolver_voe_permanent_token_and_fallback(self):
        session = Mock()
        page1 = Mock()
        page1.read.return_value = b"window.location.href = 'https://voe.sx/delivery?token=abc'; permanentToken"
        page1.geturl.return_value = 'https://voe.sx/e/1'

        page2 = Mock()
        page2.read.return_value = b'{"hls": "https://delivery.voe.sx/stream.m3u8"}'
        page2.geturl.return_value = 'https://voe.sx/delivery?token=abc'

        session.open.return_value.__enter__ = Mock(side_effect=[page1, page2])
        session.open.return_value.__exit__ = Mock(return_value=False)

        with patch.object(network, 'nueva_sesion', return_value=session), \
             patch.object(resolvers, 'procesar_hls_local', return_value='voe_stream'):
            res = resolvers.resolver_voe('https://voe.sx/e/1')
            self.assertEqual(res, 'voe_stream')

    def test_resolver_enlace_directo_routing(self):
        with patch.object(resolvers, 'resolver_vidhide', return_value='stream_vidhide') as r_vh, \
             patch.object(resolvers, 'resolver_streamwish', return_value='stream_wish') as r_sw, \
             patch.object(resolvers, 'resolver_filemoon', return_value='stream_filemoon') as r_fm, \
             patch.object(resolvers, 'resolver_voe', return_value='stream_voe') as r_voe:

            self.assertEqual(resolvers.resolver_enlace_directo('https://minochinos.com/e/123'), 'stream_vidhide')
            r_vh.assert_called_once_with('https://minochinos.com/e/123')

            self.assertEqual(resolvers.resolver_enlace_directo('https://strwish.com/e/456'), 'stream_wish')
            r_sw.assert_called_once_with('https://strwish.com/e/456')

            self.assertEqual(resolvers.resolver_enlace_directo('https://filemoon.to/e/789'), 'stream_filemoon')
            r_fm.assert_called_once_with('https://filemoon.to/e/789')

            self.assertEqual(resolvers.resolver_enlace_directo('https://voex.top/e/999'), 'stream_voe')
            r_voe.assert_called_once_with('https://voex.top/e/999')

    def test_desenvolver_embed_shortener(self):
        # JWT wrapping a voe link
        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJlbWJlZCI6Imh0dHBzOi8vdm9lLnN4L2UvYWJjZGVmIn0.signature"
        url = f"https://embedshortener.co/e/{jwt}"
        unwrapped = resolvers.desenvolver_embed_shortener(url)
        self.assertEqual(unwrapped, 'https://voe.sx/e/abcdef')

        # Routing unwrap integration
        with patch.object(resolvers, 'resolver_voe', return_value='voe_stream') as r_voe:
            self.assertEqual(resolvers.resolver_enlace_directo(url), 'voe_stream')
            r_voe.assert_called_once_with('https://voe.sx/e/abcdef')

    def test_resolver_pixeldrain(self):
        url = 'https://pixeldrain.com/u/kH8y7z12'
        direct = resolvers.resolver_pixeldrain(url)
        self.assertTrue(direct.startswith('https://pixeldrain.com/api/file/kH8y7z12'))
        self.assertIn('User-Agent=', direct)

    def test_resolver_vidara(self):
        session = Mock()
        page = Mock()
        page.read.return_value = b'{"streaming_url": "https://cdn.vidara.so/hls/vid.m3u8"}'
        session.open.return_value.__enter__ = Mock(return_value=page)
        session.open.return_value.__exit__ = Mock(return_value=False)

        with patch.object(network, 'nueva_sesion', return_value=session), \
             patch.object(resolvers, 'procesar_hls_local', return_value='vidara_stream'):
            res = resolvers.resolver_vidara('https://vidara.so/e/test99')
            self.assertEqual(res, 'vidara_stream')


if __name__ == '__main__':
    unittest.main()
