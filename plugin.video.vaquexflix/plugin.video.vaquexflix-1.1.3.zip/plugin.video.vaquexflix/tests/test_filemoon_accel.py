import subprocess
import ctypes
import os
import unittest
from unittest.mock import patch

import resolvers as accel
import resolvers as portable
import network
import resolvers


class AcceleratorTests(unittest.TestCase):
    def test_process_bitness_selects_android_arm_abi(self):
        from types import SimpleNamespace
        with patch.dict(os.environ, {'ANDROID_ROOT':'/system'}), \
             patch.object(accel.sys, 'platform', 'linux'), \
             patch.object(os, 'uname', return_value=SimpleNamespace(machine='aarch64'), create=True):
            with patch.object(ctypes, 'sizeof', return_value=4):
                self.assertEqual(accel._fm_native_target(), 'android-armv7')
            with patch.object(ctypes, 'sizeof', return_value=8):
                self.assertEqual(accel._fm_native_target(), 'android-aarch64')

    def test_native_matches_python_and_solves_batch(self):
        try:
            lib = accel._fm_native_load()
        except OSError as exc:
            self.skipTest(str(exc))
        for text in ('a:0', 'nonce:123', 'nonce:4294967295'):
            encoded = text.encode()
            self.assertEqual(lib.fm_word(encoded,len(encoded)), portable._fm_py_proof_word(text))
        expected = next(n for n in range(256) if portable._fm_py_proof_word('a:'+str(n)) >> 28 == 0)
        self.assertEqual(accel._fm_native_batch(lib,b'a',4,0,256), str(expected))

    def test_native_resolution_does_not_execute_helpers(self):
        with patch.object(subprocess, 'run', side_effect=AssertionError('External process')):
            self.assertEqual(resolvers._filemoon_proof({'pow_nonce':'a','pow_difficulty':0}), '0')

    def test_invalid_parameters_rejected_before_native_call(self):
        with patch.object(accel, '_fm_native_load') as load:
            with self.assertRaises(network.ServidorNoDisponible):
                resolvers._filemoon_proof({'pow_nonce':'a','pow_difficulty':33})
            load.assert_not_called()
