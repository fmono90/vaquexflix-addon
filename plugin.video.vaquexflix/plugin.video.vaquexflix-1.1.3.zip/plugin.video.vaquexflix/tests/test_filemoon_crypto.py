import network
import resolvers
import json
import shutil
import subprocess
import unittest
from unittest.mock import patch

import servidores as fm


class FilemoonCryptoTests(unittest.TestCase):
    def test_attestation_uses_fresh_challenge_signature(self):
        calls = []
        def api(path, body):
            calls.append((path, body))
            return ({'nonce': 'fresh', 'challenge_id': 'challenge'} if path.endswith('/challenge')
                    else {'token': 'accepted', 'confidence': 1})
        with patch.object(resolvers, '_filemoon_crypto', return_value={'signature': 'signed', 'public_key': {}}) as sign:
            result = resolvers._filemoon_attest(api, 'agent')
        sign.assert_called_once_with('sign', nonce='fresh')
        self.assertEqual(calls[1][1]['signature'], 'signed')
        self.assertEqual(result['viewer_id'], calls[1][1]['viewer_id'])
        self.assertEqual(result['token'], 'accepted')

    def test_crypto_is_native_and_honors_expired_probe(self):
        with patch.object(subprocess, 'run', side_effect=AssertionError('External process')):
            signed = resolvers._filemoon_crypto('sign', nonce='test')
            self.assertEqual(signed['public_key']['crv'], 'P-256')
        with patch.object(network, 'tiempo_peticion', side_effect=TimeoutError):
            with self.assertRaises(TimeoutError):
                resolvers._filemoon_crypto('sign', nonce='test')

    @unittest.skipUnless(shutil.which('node'), 'Optional Node runtime unavailable')
    def test_gcm_authentication_and_versioned_key_selection(self):
        script = """const c=require('crypto');const key=c.randomBytes(32),iv=c.randomBytes(12);
        const e=c.createCipheriv('aes-256-gcm',key,iv);
        const data=Buffer.concat([e.update(JSON.stringify({sources:[]})),e.final(),e.getAuthTag()]);
        const parts=Array(30).fill(Buffer.alloc(16).toString('base64url'));
        parts[0]=key.subarray(0,16).toString('base64url');parts[29]=key.subarray(16).toString('base64url');
        console.log(JSON.stringify({version:1,key_parts:parts,iv:iv.toString('base64url'),payload:data.toString('base64url')}));"""
        envelope = json.loads(subprocess.check_output([shutil.which('node'), '-e', script], text=True))
        self.assertEqual(resolvers._filemoon_crypto('decrypt', playback=envelope), {'sources': []})
        import servidores
        envelope['iv'] = 'AAAAAAAAAAAAAAAA'
        with self.assertRaises(network.ServidorNoDisponible):
            resolvers._filemoon_crypto('decrypt', playback=envelope)
