import unittest
from unittest.mock import patch
import resolvers as p
import resolvers

VECTOR = {'key_parts': ['AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8'], 'iv': 'AAECAwQFBgcICQoL', 'payload': 'PCCldLCXoX7-Y63Q7JQbcNGvvTWP4G02Hf0oqMEb'}

class PortableTests(unittest.TestCase):
    def test_gcm_fixed_vector_and_tamper(self):
        self.assertEqual(p._fm_py_decrypt(VECTOR, resolvers.MiniAES), {'sources':[]})
        bad = dict(VECTOR)
        raw = bytearray(p._fm_py_decode(bad['payload']));raw[0] ^= 1
        bad['payload'] = p._fm_py_encode(bytes(raw))
        with self.assertRaises(ValueError):p._fm_py_decrypt(bad, resolvers.MiniAES)

    def test_p256_known_generator_and_order(self):
        self.assertEqual(p._fm_py_multiply(1), p._fm_py_G)
        self.assertIsNone(p._fm_py_multiply(p._fm_py_N))
        self.assertEqual(p._fm_py_multiply(p._fm_py_N-1), (p._fm_py_G[0], (-p._fm_py_G[1]) % p._fm_py_P))

    def test_signature_verifies_without_external_library(self):
        signed=p._fm_py_sign('nonce')
        raw=p._fm_py_decode(signed['signature']);r=int.from_bytes(raw[:32],'big');s=int.from_bytes(raw[32:],'big')
        j=signed['public_key'];pub=(int.from_bytes(p._fm_py_decode(j['x']),'big'),int.from_bytes(p._fm_py_decode(j['y']),'big'))
        def mul(k, point):
            result=None
            while k:
                if k & 1:result=p._fm_py_add(result,point)
                point=p._fm_py_add(point,point);k >>= 1
            return result
        z=int.from_bytes(p.hashlib.sha256(b'nonce').digest(),'big');w=pow(s,-1,p._fm_py_N)
        point=p._fm_py_add(p._fm_py_multiply(z*w % p._fm_py_N),mul(r*w % p._fm_py_N,pub))
        self.assertEqual(point[0] % p._fm_py_N,r)

    def test_optimized_proof_matches_reference(self):
        for text in ('a:0', 'test:123', 'nonce:65536'):
            self.assertEqual(p._fm_py_proof_word(text), resolvers._py_pow_hash(text)[0])
