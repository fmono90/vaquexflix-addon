import unittest
from unittest.mock import patch, MagicMock
from io import BytesIO
import json
import servidores as s

class HackstoreJuanitaTests(unittest.TestCase):
    def test_hackstore_parse_url(self):
        kind, post_id, season, ep = s.hackstore_parse_url('hack://movie/120836')
        self.assertEqual((kind, post_id, season, ep), ('movie', 120836, None, None))

        kind, post_id, season, ep = s.hackstore_parse_url('hack://tvshow/120774/temporada-1/episodio-5?ep_id=999')
        self.assertEqual((kind, post_id, season, ep), ('tvshow', 120774, 1, 5))

        with self.assertRaises(ValueError):
            s.hackstore_parse_url('hack://invalid/123')
        with self.assertRaises(ValueError):
            s.hackstore_parse_url('http://example.com')

    def test_pelisjuanita_parse_url(self):
        kind, item_id, season, ep = s.pelisjuanita_parse_url('juanita://movie/604360?slug=la-8%C2%AA-noche')
        self.assertEqual((kind, item_id, season, ep), ('movie', 604360, None, None))

        kind, item_id, season, ep = s.pelisjuanita_parse_url('juanita://tvshow/500/temporada-2/episodio-3')
        self.assertEqual((kind, item_id, season, ep), ('tvshow', 500, 2, 3))

        with self.assertRaises(ValueError):
            s.pelisjuanita_parse_url('juanita://unknown/123')

    def test_hackstore_item(self):
        obj = {
            '_id': 120836,
            'title': 'Velocidad y Deseo (2026)',
            'type': 'movies',
            'overview': 'Sinopsis de prueba',
            'release_date': '2026-02-15',
            'rating': '7.5',
            'images': {'poster': '/2026/02/poster.jpg'}
        }
        item = s.hackstore_item(obj)
        self.assertIsNotNone(item)
        self.assertEqual(item['title'], 'Velocidad y Deseo (2026)')
        self.assertEqual(item['url'], 'hack://movie/120836')
        self.assertFalse(item['is_serie'])
        self.assertEqual(item['year'], '2026')
        self.assertEqual(item['rating'], '7.5')
        self.assertIn('hackstore3.net/wp-content/uploads/2026/02/poster.jpg', item['cover'])

    def test_pelisjuanita_item(self):
        obj = {
            'catalog_item_id': 604360,
            'title': 'La 8ª Noche',
            'kind': 'movie',
            'slug': 'la-8ª-noche',
            'overview': 'Sinopsis',
            'year': 2021,
            'rating_avg': '6.8',
            'poster_path': '/poster.jpg'
        }
        item = s.pelisjuanita_item(obj)
        self.assertIsNotNone(item)
        self.assertEqual(item['title'], 'La 8ª Noche')
        self.assertIn('slug=la-8%C2%AA-noche', item['url'])
        self.assertFalse(item['is_serie'])
        self.assertEqual(item['year'], '2021')
        self.assertEqual(item['rating'], '6.8')
        self.assertEqual(item['cover'], 'https://image.tmdb.org/t/p/w500/poster.jpg')

    def test_hackstore_servers_filtering(self):
        fake_payload = {
            'data': {
                'embeds': [
                    {'serverName': 'Dummy', 'url': 'https://la.movie/embed.html?v=1', 'lang': 'Latino'},
                    {'serverName': 'Vimeos', 'url': 'https://vimeos.net/embed-abc.html', 'lang': 'Latino'},
                    {'serverName': 'GoodStream', 'url': 'https://goodstream.one/embed-xyz.html', 'lang': 'Sub'}
                ]
            }
        }
        with patch.object(s, 'hackstore_api', return_value=fake_payload):
            servers = s.hackstore_servers('hack://movie/120836')
            # la.movie should be filtered out
            self.assertEqual(len(servers), 2)
            # GoodStream prioritized over Vimeos
            self.assertEqual(servers[0]['url'], 'https://goodstream.one/embed-xyz.html')
            self.assertEqual(servers[1]['url'], 'https://vimeos.net/embed-abc.html')

    def test_pelisjuanita_servers_extraction(self):
        html_player = '<html><body><iframe src="https://vimeos.net/embed-test.html"></iframe></body></html>'
        mock_resp = MagicMock()
        mock_resp.read.return_value = html_player.encode('utf-8')
        mock_resp.__enter__.return_value = mock_resp

        with patch.object(s.network, 'abrir_url', return_value=mock_resp):
            url = 'juanita://movie/604360?slug=test&player_url=https%3A%2F%2Fvideoapp.mov%2Fe%2Fmovie%2F604360'
            servers = s.pelisjuanita_servers(url)
            self.assertEqual(len(servers), 1)
            self.assertEqual(servers[0]['url'], 'https://vimeos.net/embed-test.html')
            self.assertEqual(servers[0]['nombre'], 'Vimeos HLS (PelisJuanita)')

class HackstoreBackupTests(unittest.TestCase):
    def test_additional_hosts_preserve_api_and_deduplicate(self):
        payload = {'data': {'embeds': [{'url': 'https://vimeos.net/embed-one.html'}]}}
        backup = [{'url': 'https://vimeos.net/embed-one.html'}, {'url': 'https://doodstream.com/e/two'}]
        with patch.object(s, 'hackstore_api', return_value=payload), patch.object(s, 'hackstore_backup_servers', return_value=backup):
            links = s.hackstore_servers('hack://movie/9?slug=movie-2026')
        self.assertEqual([x['url'] for x in links], [x['url'] for x in backup])

    def test_backup_failure_preserves_api_links(self):
        with patch.object(s, 'hackstore_api', return_value={'data': {'embeds': [{'url': 'https://vimeos.net/e/one'}]}}), patch.object(s, 'hackstore_backup_servers', side_effect=TimeoutError):
            self.assertEqual(len(s.hackstore_servers('hack://movie/9?slug=movie-2026')), 1)

    def test_wrapper_extracts_player_and_ignores_external_ad(self):
        page = '<div class="player"><a class="playr" data-href="/play.php?u=x" data-lang="latino">Dood</a><a class="playr" data-href="https://ads.test/play.php">Ad</a></div>'
        wrapper = "<script>window.location.href = 'https://doodstream.com/e/test';</script>"
        replies = []
        for text in (page, wrapper):
            response = MagicMock()
            response.__enter__.return_value = response
            response.read.return_value = text.encode()
            replies.append(response)
        with patch.object(s.network, 'abrir_url', side_effect=replies) as request:
            links = s.hackstore_backup_servers('movie-2026')
        self.assertEqual(request.call_count, 2)
        self.assertEqual(links[0]['url'], 'https://doodstream.com/e/test')
        self.assertIn('latino', links[0]['nombre'])

    def test_invalid_slug_never_requests_arbitrary_path(self):
        with patch.object(s.network, 'abrir_url') as request:
            self.assertEqual(s.hackstore_backup_servers('../series/other'), [])
            request.assert_not_called()

if __name__ == '__main__':
    unittest.main()
