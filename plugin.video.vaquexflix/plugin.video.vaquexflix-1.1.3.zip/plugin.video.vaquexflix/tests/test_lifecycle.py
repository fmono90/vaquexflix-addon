import network
import resolvers
import ast
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import catalog
import doramas
import playback
import servidores as s
import stream_metadata


class LifecycleTests(unittest.TestCase):
    def test_playback_budget_preserves_normal_request_timeout(self):
        with network.presupuesto_resolucion(time.monotonic() + 40):
            self.assertEqual(network.tiempo_peticion(20), 20)
            self.assertEqual(catalog.parallel([lambda: network.tiempo_peticion(20)]), [20])
        with network.presupuesto_sondeo(time.monotonic() + 40):
            self.assertEqual(network.tiempo_peticion(20), 6)

    def test_request_timeout_releases_foreground(self):
        release, exited = threading.Event(), threading.Event()
        def fetch():
            release.wait(2)
            exited.set()
        try:
            with self.assertRaises(TimeoutError):
                playback.request_with_progress(fetch, network.presupuesto_resolucion, lambda: True, seconds=.02)
        finally:
            release.set()
            self.assertTrue(exited.wait(1))

    def test_cancel_returns_before_network_and_signals_worker(self):
        entered, release, exited = threading.Event(), threading.Event(), threading.Event()
        seen = {}
        def fetch():
            seen['cancel'] = network._sondeo.cancel
            entered.set()
            release.wait(2)
            exited.set()
            return 'late'
        def waiting():
            entered.wait(1)
            return False
        try:
            with self.assertRaises(playback.Cancelled):
                playback.request_with_progress(fetch, network.presupuesto_sondeo, waiting)
            self.assertTrue(seen['cancel'].is_set())
            self.assertFalse(exited.is_set())
        finally:
            release.set()
            self.assertTrue(exited.wait(1))

    def test_request_returns_value_and_propagates_error(self):
        self.assertEqual(playback.request_with_progress(lambda: 42, network.presupuesto_sondeo, lambda: True), 42)
        def fail():
            raise ValueError('source')
        with self.assertRaisesRegex(ValueError, 'source'):
            playback.request_with_progress(fail, network.presupuesto_sondeo, lambda: True)

    def test_parallel_workers_inherit_cancellation(self):
        cancel = threading.Event()
        deadline = time.monotonic() + 10
        for provider in (catalog, doramas):
            with network.presupuesto_sondeo(deadline, cancel):
                result = provider.parallel([lambda: (network._sondeo.deadline, network._sondeo.cancel)])
            self.assertEqual(result, [(deadline, cancel)])

    def test_scanner_close_cancels_active_resolver_and_rejects_late_result(self):
        entered, exited = threading.Event(), threading.Event()
        def resolve(url):
            entered.set()
            network._sondeo.cancel.wait(2)
            exited.set()
            return 'https://cdn.example/late.mp4'
        scanner = stream_metadata.Scanner(resolve, Mock(), Mock(), network.presupuesto_sondeo)
        thread = threading.Thread(target=lambda: scanner.scan([{'url': 'https://host.example/a'}]))
        thread.start()
        try:
            self.assertTrue(entered.wait(1))
            scanner.close()
            self.assertTrue(exited.wait(1))
            thread.join(1)
            self.assertFalse(thread.is_alive())
            self.assertIsNone(scanner.resolved('https://host.example/a'))
        finally:
            scanner.close()
            thread.join(2)

    def check_close(self, playing, active=True):
        tree = ast.parse((Path(__file__).resolve().parents[1] / 'main.py').read_text(encoding='utf-8'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'VaquexflixUI')
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '_comprobar_cierre_player')
        namespace = {'time': time, 'xbmc': Mock(), 'xbmcgui': Mock(), 'playback': Mock()}
        exec(compile(ast.Module(body=[method], type_ignores=[]), 'main.py', 'exec'), namespace)
        ui = SimpleNamespace(_closing_session=1, _closing_since=time.monotonic()-20,
            _closing_warned=False, _pending_stream=({'stream': 'new'}, 0), activa=active,
            player=Mock(), _iniciar_stream=Mock())
        ui.player.isPlaying.return_value = playing
        namespace['_comprobar_cierre_player'](ui)
        return ui

    def test_missing_stop_callback_recovers_only_after_player_stopped(self):
        ui = self.check_close(False)
        self.assertIsNone(ui._closing_session)
        ui._iniciar_stream.assert_called_once()
        busy = self.check_close(True)
        self.assertEqual(busy._closing_session, 1)
        self.assertIsNone(busy._pending_stream)
        busy._iniciar_stream.assert_not_called()
        closed = self.check_close(False, False)
        closed._iniciar_stream.assert_not_called()


class FocusCloseTests(unittest.TestCase):
    def test_focus_callback_defers_controls_until_close_is_complete(self):
        tree = ast.parse((Path(__file__).resolve().parents[1] / 'main.py').read_text(encoding='utf-8'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'VaquexflixUI')
        methods = [n for n in cls.body if isinstance(n, ast.FunctionDef)
                   and n.name in ('onFocus', '_procesar_foco_pendiente')]
        namespace = {}
        exec(compile(ast.Module(body=methods, type_ignores=[]), 'main.py', 'exec'), namespace)
        ui = SimpleNamespace(reproduciendo_video=False, _closing_session=3,
                             pos_anterior=0, items_actuales=[{'title': 'Movie'}],
                             _actualizar_sinopsis_de_elemento=Mock(), getControl=Mock())
        namespace['onFocus'](ui, 204)
        namespace['onFocus'](ui, 100)
        ui.getControl.assert_not_called()
        namespace['_procesar_foco_pendiente'](ui)
        ui._actualizar_sinopsis_de_elemento.assert_not_called()
        self.assertEqual(ui._pending_focus, 100)
        ui._closing_session = None
        namespace['_procesar_foco_pendiente'](ui)
        ui._actualizar_sinopsis_de_elemento.assert_called_once_with(ui.items_actuales[0])
        namespace['_procesar_foco_pendiente'](ui)
        self.assertEqual(ui._actualizar_sinopsis_de_elemento.call_count, 1)
