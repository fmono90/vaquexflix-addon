import io
import unittest
import urllib.request
import urllib.error
from unittest.mock import Mock, patch

import network
import resolvers


class MegaTests(unittest.TestCase):
    def tearDown(self):
        resolvers.cerrar_streams_locales()

    def test_public_link_and_invalid_domain(self):
        suffix = 'oPVyAbqJ#Hh2_H0u7ihByEFoVAlG1oYXRPN8bAjJMl6smRaodIeE'
        self.assertEqual(resolvers._mega_link('https://mega.nz/embed/' + suffix),
                         resolvers._mega_link('https://mega.nz/file/' + suffix))
        self.assertEqual(len(resolvers._mega_link('https://mega.nz/file/' + suffix)[1]), 16)
        with self.assertRaises(network.ServidorNoDisponible):
            resolvers._mega_link('https://mega.nz.evil.test/file/' + suffix)

    def test_ranges(self):
        for value, expected in [(None, (0, 99, False)), ('bytes=7-31', (7, 31, True)),
                                ('bytes=90-', (90, 99, True)), ('bytes=-8', (92, 99, True)),
                                ('bytes=90-120', (90, 99, True))]:
            self.assertEqual(resolvers._mega_range(value, 100), expected)
        for value in ('bytes=100-', 'bytes=10-2', 'bytes=-0', 'bytes=0-1,5-6', 'bytes=-'):
            with self.assertRaises(ValueError):
                resolvers._mega_range(value, 100)

    def test_blocked_file_reports_mega_error(self):
        response = Mock()
        response.read.return_value = b'[-16]'
        context = Mock()
        context.__enter__ = Mock(return_value=response)
        context.__exit__ = Mock(return_value=False)
        opener = Mock()
        opener.open.return_value = context
        with patch.object(resolvers, '_mega_aes'), patch.object(network, 'nueva_sesion', return_value=opener):
            with self.assertRaisesRegex(network.ServidorNoDisponible, 'bloqueado'):
                resolvers._mega_file('https://mega.nz/file/oPVyAbqJ#Hh2_H0u7ihByEFoVAlG1oYXRPN8bAjJMl6smRaodIeE')

    def test_http_head_seek_suffix_and_invalid_range(self):
        data = bytes(range(256)) * (32768 + 1)
        port = resolvers._mega_start_server()
        path = '/unit-test-token.mp4'
        resolvers._mega_resources[path] = {'size': len(data), 'extension': '.mp4', 'used': 0}
        url = 'http://127.0.0.1:%d%s' % (port, path)
        def read(resource, start, end):
            aligned = start - start % 16
            return io.BytesIO(data[aligned:end+1]), Mock(decrypt=lambda b: b), start - aligned
        with patch.object(resolvers, '_mega_open_range', side_effect=read) as fetch:
            with urllib.request.urlopen(urllib.request.Request(url, method='HEAD')) as r:
                self.assertEqual(int(r.headers['Content-Length']), len(data))
                self.assertEqual(r.read(), b'')
            fetch.assert_not_called()
            # Abandon a transfer as Kodi does on Stop, then immediately Stat it.
            with urllib.request.urlopen(url, timeout=2) as r:
                self.assertEqual(r.headers.get('Connection'), 'close')
                r.read(128)
            with urllib.request.urlopen(urllib.request.Request(url, method='HEAD'), timeout=2) as r:
                self.assertEqual(r.status, 200)
            with urllib.request.urlopen(url) as r:
                self.assertEqual(r.status, 200)
                self.assertEqual(r.read(), data)
            self.assertGreaterEqual(fetch.call_count, 3)
            for call in fetch.call_args_list:
                self.assertLessEqual(call.args[2] - call.args[1] + 1, 4 * 1024 * 1024)
            for span, expected in [('bytes=7-100', data[7:101]), ('bytes=-33', data[-33:])]:
                with urllib.request.urlopen(urllib.request.Request(url, headers={'Range': span})) as r:
                    self.assertEqual(r.status, 206)
                    self.assertEqual(r.read(), expected)
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(url, headers={'Range': 'bytes=99999999-'}))
            self.assertEqual(error.exception.code, 416)
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(url.replace('unit-test-token', 'wrong-token'))
            self.assertEqual(error.exception.code, 404)


    def test_local_stream_uses_default_reader_without_content_lookup(self):
        import playback
        item = Mock()
        playback.configure_stream(item, 'http://127.0.0.1:12345/token.mp4', 'test')
        item.setProperty.assert_not_called()
        item.setContentLookup.assert_called_with(False)
