import unittest
from unittest.mock import patch

import network
import resolvers
import servidores
import doramas


class ModuleBoundariesTests(unittest.TestCase):
    def test_host_resolvers_have_one_owner(self):
        for name in ('resolver_filemoon', 'resolver_dood', 'resolver_voe',
                     'resolver_streamtape', 'resolver_hydrax', 'resolver_tubi'):
            self.assertEqual(getattr(resolvers, name).__module__, 'resolvers')
            self.assertFalse(hasattr(servidores, name))

    def test_sources_have_expected_owner(self):
        for name in ('sololatino_buscar', 'cinecalidad_search', 'tubi_search',
                     'hackstore_search', 'fuegocine_buscar'):
            self.assertEqual(getattr(servidores, name).__module__, 'servidores')
        self.assertEqual(doramas.DoramaExpress.__module__, 'doramas')
        self.assertEqual(doramas.DoramasFlix.__module__, 'doramas')
        self.assertEqual(doramas.DoramasYT.__module__, 'doramas')

    def test_sources_and_resolvers_share_network_state(self):
        self.assertIs(servidores.network, network)
        self.assertIs(resolvers.network, network)
        self.assertIs(doramas.network, network)

    def test_dorama_player_routes_through_common_host_resolver(self):
        with patch.object(doramas, 'resolve', return_value='https://voe.sx/e/test') as source, \
                patch.object(resolvers, 'resolver_voe', return_value='video') as host:
            self.assertEqual(resolvers.resolver_stream('dorama://player?option=1'), 'video')
        source.assert_called_once()
        host.assert_called_once_with('https://voe.sx/e/test')

    def test_tubi_route_uses_central_resolver(self):
        with patch.object(resolvers, 'resolver_tubi', return_value='video') as host:
            self.assertEqual(resolvers.resolver_stream('tubi://play?url=test'), 'video')
        host.assert_called_once_with('tubi://play?url=test')
