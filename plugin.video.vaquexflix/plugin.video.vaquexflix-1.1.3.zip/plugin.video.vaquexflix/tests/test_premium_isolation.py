import ast
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import network

class PremiumIsolationTests(unittest.TestCase):
    def test_provider_failure_does_not_enable_experimental(self):
        tree = ast.parse(Path('main.py').read_text(encoding='utf-8'))
        method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == '_cargar_pagina_unificada')
        provider = Mock()
        provider.page.side_effect = network.ServidorNoDisponible('blocked')
        ui = Mock()
        class ImmediateThread:
            def __init__(self, target, **kwargs): self.target = target
            def start(self): self.target()
        scope = dict(catalog=provider, network=network, xbmc=Mock(), xbmcgui=ui,
                     threading=SimpleNamespace(Thread=ImmediateThread))
        exec(compile(ast.Module(body=[method], type_ignores=[]), 'main.py', 'exec'), scope)
        window = SimpleNamespace(_catalog_generation=1, experimental=False,
                                 categoria_actual_url='unified://series', activa=True,
                                 _primary_catalog_source=None)
        scope['_cargar_pagina_unificada'](window, 1)
        provider.page.assert_called_once_with('series', 1, experimental=False, primary_source=None)
        self.assertFalse(window.cargando_mas)
        ui.Dialog.return_value.notification.assert_called_once()

    def test_blocked_category_reports_access_error(self):
        import catalog
        from unittest.mock import patch
        with patch.object(network, 'fetch_html', return_value=('', '')):
            with self.assertRaises(network.ServidorNoDisponible):
                catalog.page('series?genre=drama', 1, experimental=False)
