import unittest
from unittest.mock import patch

import network
import servidores
import catalog


class ProviderFailoverTests(unittest.TestCase):
    def setUp(self):
        p = patch.object(network, '_solo_backup_until', 0)
        p.start()
        self.addCleanup(p.stop)

    def test_retry_preserves_path_query_and_strips_primary_cookie(self):
        headers = {'Cookie': 'session=primary', 'Referer': 'https://sololatino.net/series',
                   'Origin': 'https://sololatino.net'}
        with patch.object(network, '_fetch_html_once', side_effect=[('', []), ('page', [])]) as fetch:
            result = network.fetch_html('https://sololatino.net/series?page=2&genero=drama',
                                        cookies='session=primary', headers_dict=headers)
        self.assertEqual(result[0], 'page')
        args = fetch.call_args.args
        self.assertEqual(args[0], 'https://sololatino.co/series?page=2&genero=drama')
        self.assertEqual(args[1], '')
        self.assertNotIn('Cookie', args[5])
        self.assertEqual(args[5]['Origin'], 'https://sololatino.co')
        self.assertIn('Cookie', headers)
        self.assertEqual(network.solo_origins()[0], 'https://sololatino.co')

    def test_success_on_primary_never_calls_backup(self):
        with patch.object(network, '_fetch_html_once', return_value=('[]', [])) as fetch:
            network.fetch_html('https://sololatino.net/api/search/suggest?q=test')
        fetch.assert_called_once()

    def test_primary_rechecked_after_cooldown(self):
        with patch.object(network.time, 'monotonic', return_value=100):
            network.solo_origin_success(network._SOLO_FALLBACK)
        with patch.object(network.time, 'monotonic', return_value=161):
            self.assertEqual(network.solo_origins()[0], network.SOLOLATINO_BASE)

    def test_server_flow_restarts_csrf_and_does_not_replay_tokens(self):
        requests = []
        def fetch(url, cookies, referer, timeout, data, headers):
            requests.append((url, headers))
            backup = url.startswith(network._SOLO_FALLBACK)
            token = 'backup' if backup else 'primary'
            if url.endswith('/sanctum/csrf-cookie'):
                return '', ['XSRF-TOKEN=' + token, 'session=' + token]
            if url.endswith('/api/player-url'):
                self.assertEqual(headers['X-XSRF-TOKEN'], token)
                self.assertIn('session=' + token, headers['Cookie'])
                self.assertEqual(headers['Origin'], network._SOLO_FALLBACK if backup else network.SOLOLATINO_BASE)
                return ('{"url":"https://voe.sx/e/test"}', []) if backup else ('', [])
            return '<button data-player-token="abc">Voe</button>', []
        with patch.object(network, '_fetch_html_once', side_effect=fetch):
            result = servidores.sololatino_obtener_servidores('https://sololatino.net/pelicula/test')
        self.assertEqual(result[0]['url'], 'https://voe.sx/e/test')
        self.assertEqual(len(requests), 7)
        self.assertTrue(requests[4][0].endswith('/sanctum/csrf-cookie'))

    def test_cancellation_stops_failover(self):
        with patch.object(network, 'tiempo_peticion', side_effect=TimeoutError), \
             patch.object(network, '_fetch_html_once') as fetch:
            with self.assertRaises(TimeoutError):
                network.fetch_html('https://sololatino.net/series')
        fetch.assert_not_called()

    def test_backup_is_primary_source_and_canonicalized(self):
        self.assertTrue(catalog.is_primary({'url': 'https://sololatino.co/series/a'}))
        self.assertEqual(network.solo_url('https://sololatino.co/series/a?page=2'),
                         'https://sololatino.net/series/a?page=2')
        self.assertEqual(network.solo_url('https://sololatino.net.evil.test/a'),
                         'https://sololatino.net.evil.test/a')

    def test_sololatino_extraer_media_id_movie(self):
        html = '<a href="https://www.imdb.com/title/tt37522541/">IMDb</a>'
        mid = servidores._sololatino_extraer_media_id('https://sololatino.net/pelicula/test', html)
        self.assertEqual(mid, 'tt37522541')

    def test_sololatino_extraer_media_id_episode(self):
        html_ep = '<a href="https://sololatino.net/serie/tulsa-king">Volver</a>'
        html_serie = '<a href="https://www.imdb.com/title/tt16358384/">IMDb</a>'
        with patch.object(network, 'fetch_html', return_value=(html_serie, [])):
            mid = servidores._sololatino_extraer_media_id('https://sololatino.net/serie/tulsa-king/temporada-1/episodio-5', html_ep)
        self.assertEqual(mid, 'tt16358384-1x05')

    def test_sololatino_fallback_when_player_api_fails(self):
        import resolvers
        html = '<a href="https://www.imdb.com/title/tt12345678/">IMDb</a>'
        with patch.object(network, 'fetch_html', return_value=(html, [])), \
             patch.object(resolvers, 'resolver_embed69_hosts', return_value=[{'nombre': 'VOE', 'url': 'https://voe.sx/e/123'}]):
            result = servidores._sololatino_obtener_servidores('https://sololatino.net/pelicula/test', premium_only=False)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['nombre'], 'PREMIUM (Mediafire - Alta Velocidad)')
        self.assertEqual(result[0]['url'], 'https://player.pelisserieshoy.com/f/tt12345678')
        self.assertEqual(result[1]['nombre'], 'VOE')
