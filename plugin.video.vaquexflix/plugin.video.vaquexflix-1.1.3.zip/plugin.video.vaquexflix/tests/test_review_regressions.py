import network
import resolvers
import json
import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from unittest.mock import Mock, patch

import catalog
import servidores as s
import servidores as tubi
import sessions


class ReviewRegressions(unittest.TestCase):
    def test_pelisflix_uses_own_player_parser(self):
        item = {'url': s.PELISFLIX_BASE_URL + '/pelicula/example', 'title': 'Example'}
        with patch.object(catalog, 'expand', side_effect=lambda x: x), \
             patch.object(s, 'pelisflix_servers', return_value=[{'nombre': 'Voe', 'url': 'https://voe.sx/e/1'}]) as fetch, \
             patch.object(s, 'sololatino_obtener_servidores') as wrong:
            self.assertEqual(len(catalog.servers(item, True)), 1)
            fetch.assert_called_once_with(item['url'])
            wrong.assert_not_called()

    def test_tubi_tolerates_prepositions_but_requires_content_words(self):
        with tempfile.TemporaryDirectory() as root, \
             patch.object(tubi, 'tubi_database', return_value=os.path.join(root, 'index.db')), \
             patch.object(tubi, 'tubi_is_available', return_value=True), \
             patch.object(tubi, 'tubi_refresh'):
            with closing(sqlite3.connect(tubi.tubi_database())) as db, db:
                db.execute('CREATE TABLE titles (title TEXT, url TEXT, data TEXT)')
                for title in ('La luz en tus ojos', 'La luz del sol', 'El'):
                    db.execute('INSERT INTO titles VALUES (?,?,?)', (tubi.tubi_normalize(title), title, json.dumps({'title': title})))
            self.assertEqual(tubi.tubi_search('la luz de tus ojos'), [{'title': 'La luz en tus ojos'}])
            self.assertEqual(tubi.tubi_search('luz ojos inexistente'), [])
            self.assertEqual(tubi.tubi_search('el'), [{'title': 'La luz del sol'}, {'title': 'El'}][::-1])
            self.assertEqual(tubi.tubi_search(''), [])

    def test_urllib_rejects_challenge_and_does_not_mutate_headers(self):
        resp = Mock()
        resp.read.return_value = b'<title>Just a moment...</title>'
        resp.headers.get_all.return_value = []
        headers = {'Content-Type': 'application/json'}
        with patch.object(network, 'nueva_sesion') as session, patch('sessions.configure', return_value=''):
            session.return_value.handlers = []
            mock_open = session.return_value.open
            mock_open.return_value.__enter__ = Mock(return_value=resp)
            mock_open.return_value.__exit__ = Mock(return_value=False)
            self.assertEqual(network.fetch_html(network.SOLOLATINO_BASE, data=b'', cookies='a=b', headers_dict=headers), ('', []))
            mock_open.assert_called_once()
        self.assertEqual(headers, {'Content-Type': 'application/json'})
        self.assertFalse(network._challenge_page('<html>Uses Cloudflare CDN</html>'))
        self.assertFalse(network._challenge_page('<title>Peliculas</title><script src="/cdn-cgi/challenge-platform/scripts/jsd/main.js"></script>'))

    def test_filemoon_alias_uses_urllib_and_respects_probe_deadline(self):
        resp = Mock()
        resp.read.return_value = b'{}'
        resp.headers.get_all.return_value = []
        with patch.object(network, 'abrir_url') as mock_open, \
             patch.object(network, 'tiempo_peticion', return_value=2):
            mock_open.return_value.__enter__ = Mock(return_value=resp)
            mock_open.return_value.__exit__ = Mock(return_value=False)
            self.assertEqual(network.fetch_html('https://bysedikamoum.com/api/videos/1'), ('{}', []))
            mock_open.assert_called_once()
            self.assertEqual(mock_open.call_args.kwargs['timeout'], 2)

    def test_dood_keeps_session_and_final_redirect_origin(self):
        session = Mock()
        session.handlers = []
        page = Mock()
        page.read.return_value = b"'/pass_md5/example'; '?token=abc&expiry='"
        page.geturl.return_value = 'https://dsvplay.com/e/1'
        prefix = Mock()
        prefix.read.return_value = b'https://cdn.example/video/'
        session.open.return_value.__enter__ = Mock(side_effect=[page, prefix])
        session.open.return_value.__exit__ = Mock(return_value=False)
        with patch.object(network, 'nueva_sesion', return_value=session):
            media = resolvers.resolver_dood('https://dood.to/e/1')
        self.assertTrue(media.startswith('https://cdn.example/video/'))
        request = session.open.call_args_list[1].args[0]
        self.assertEqual(request.full_url, 'https://dsvplay.com/pass_md5/example')
        self.assertEqual(request.get_header('Referer'), page.geturl.return_value)

    def test_sorting_does_not_remove_servers(self):
        servers = [{'nombre': 'Google Drive', 'url': 'https://drive.google.com/file/1'},
                   {'nombre': 'Vidhide', 'url': 'https://morencius.com/e/1'}]
        self.assertEqual(len(s.ordenar_servidores_experimental(servers)), 2)
