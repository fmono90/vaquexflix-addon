import network
import resolvers
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError

import catalog
import servidores as cinecalidad
import doramas
import servidores
import servidores as tubi
class SearchRankingAndCategoriesTests(unittest.TestCase):
    def test_search_relevance_ranking(self):
        items = [
            {'title': 'Los pingüinos de Madagascar: El Pingüino Zombie', 'url': 'https://s1.test/p1'},
            {'title': 'Amor a la luz de la luna', 'url': 'https://s2.test/p2'},
            {'title': 'La Luz En Tus Ojos', 'url': 'https://s3.test/p3'},
            {'title': 'La sonrisa se ha ido de tus ojos', 'url': 'https://s4.test/p4'},
            {'title': 'La Luz en tus Ojos: Especial', 'url': 'https://s5.test/p5'},
        ]
        ranked = catalog.sort_by_relevance(items, 'la luz en tus ojos')
        # Exact match and prefix match must be at the very top
        self.assertEqual(ranked[0]['title'], 'La Luz En Tus Ojos')
        self.assertEqual(ranked[1]['title'], 'La Luz en tus Ojos: Especial')
        # Partial match next
        self.assertEqual(ranked[2]['title'], 'La sonrisa se ha ido de tus ojos')
        self.assertEqual(ranked[3]['title'], 'Amor a la luz de la luna')
        # Madagascar has zero matching words, so it should be filtered out
        self.assertEqual(len(ranked), 4)

    def test_categories_experimental_queries_all_providers_and_survives_sololatino_offline(self):
        with patch.object(network, 'fetch_html', side_effect=network.ServidorNoDisponible('SoloLatino offline')):
            with patch.object(cinecalidad, 'cinecalidad_page', return_value=([{'title': 'Peli Cinecalidad', 'url': 'https://cine.test/1', 'is_serie': False}], True)) as mock_cine:
                with patch.object(servidores, 'pelisflix_catalog', return_value=[{'title': 'Peli Pelisflix', 'url': 'https://flix.test/1', 'is_serie': False}]) as mock_flix:
                    with patch.object(servidores, 'fuegocine_catalogo_genero', return_value=[{'title': 'Peli Fuego', 'url': 'https://fuego.test/1', 'is_serie': False}]) as mock_fuego:
                        with patch.object(tubi, 'tubi_is_available', return_value=True), patch.object(tubi, 'tubi_page', return_value=([{'title': 'Peli Tubi', 'url': 'https://tubitv.com/movies/1/peli', 'source': 'tubi', 'is_serie': False}], False)) as mock_tubi:
                            items, more = catalog.page('peliculas?genre=accion', 1, experimental=True)
                            self.assertTrue(len(items) >= 3)
                            titles = [i['title'] for i in items]
                            self.assertIn('Peli Cinecalidad', titles)
                            self.assertIn('Peli Pelisflix', titles)
                            self.assertNotIn('Peli Fuego', titles)
                            self.assertIn('Peli Tubi', titles)
                            self.assertTrue(more)
                            mock_cine.assert_called_once_with(1, genre='accion')
                            mock_flix.assert_called_once_with('peliculas', 1, genre='accion')
                            mock_fuego.assert_not_called()
                            mock_tubi.assert_called_once_with('peliculas', 1, genre='accion')

    def test_categories_doramas_queries_multiple_sources_and_survives_yt_failure(self):
        with patch.object(doramas.DoramasYT, '_catalog', side_effect=RuntimeError('DoramasYT offline')):
            with patch.object(doramas.DoramasFlix, 'search', return_value={
                'items': [{'title': 'Dorama Romance', 'url': 'https://doramasflix.io/doramas/romance-1'}],
                'movies': []
            }):
                items, more = doramas.page(1, 'romance')
                self.assertEqual(len(items), 1)
                self.assertEqual(items[0]['title'], 'Dorama Romance')

    def test_doramaexpress_suppressed_from_search_notification(self):
        from provider_cache import SearchResults
        raw_results = SearchResults([{'title': 'Test', 'url': 'https://test'}], ['DoramaExpress'])
        visible_errors = [e for e in getattr(raw_results, 'errors', []) if e != 'DoramaExpress' and 'doramaexpress' not in e.lower()]
        self.assertEqual(visible_errors, [])


if __name__ == '__main__':
    unittest.main()
