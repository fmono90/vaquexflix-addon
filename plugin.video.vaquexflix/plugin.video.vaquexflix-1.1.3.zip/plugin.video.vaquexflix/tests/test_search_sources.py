import network
import resolvers
import unittest
from contextlib import ExitStack
from unittest.mock import patch

import catalog
import doramas
import servidores
import servidores as tubi
class SearchSourcesTests(unittest.TestCase):
    def test_sections_merge_all_matching_sources_and_survive_failure(self):
        providers = ['sololatino_buscar', 'hackstore_search', 'pelisjuanita_search',
                     'pelisflix_search']
        with ExitStack() as stack:
            stack.enter_context(patch.object(catalog.cinecalidad, 'cinecalidad_search', return_value=[]))
            stack.enter_context(patch.object(tubi, 'tubi_search', return_value=[]))
            for number, name in enumerate(providers):
                stack.enter_context(patch.object(servidores, name, return_value=[
                    {'title': 'Example', 'url': 'https://source%d.test/serie/example' % number,
                     'is_serie': True}]))
            for cls, host in [(doramas.DoramasYT, 'www.doramasyt.com'),
                              (doramas.DoramasFlix, 'doramasflix.io'),
                              (doramas.DoramaExpress, 'doramaexpress.com')]:
                stack.enter_context(patch.object(cls, 'search', return_value={
                    'items': [{'title': 'Example', 'url': 'https://' + host + '/serie/example'}]}))
            dramas = catalog.search('Example', True, 'doramas')
            self.assertEqual(len(dramas), 1)
            self.assertEqual(len(dramas[0]['variants']), 3)
            series = catalog.search('Example', True, 'series')
            self.assertEqual(len(series[0]['variants']), 4)
            all_items = catalog.search('Example', True, 'all')
            self.assertEqual(sum(len(i['variants']) for i in all_items), 7)
            with patch.object(doramas.DoramasYT, 'search', side_effect=RuntimeError('offline')):
                self.assertEqual(len(catalog.search('Example', True, 'doramas')[0]['variants']), 2)

    def test_pelisflix_search_parses_results(self):
        markup = '<article><a href="/serie/example"><img src="/poster.jpg"></a><h2>Example</h2></article>'
        with patch.object(network, 'fetch_html', return_value=(markup, '')):
            items = servidores.pelisflix_search('Example')
        self.assertEqual(len(items), 1)
        self.assertTrue(items[0]['is_serie'])
        self.assertEqual(items[0]['url'], servidores.PELISFLIX_BASE_URL + '/serie/example')

    def test_earnvid_alias_and_removed_ok_video(self):
        with patch.object(resolvers, 'resolver_host_hls', return_value='stream') as resolve:
            url = 'https://dingtezuni.com/embed/example'
            self.assertEqual(resolvers.resolver_stream(url), 'stream')
            resolve.assert_called_once_with(url)
        with patch.object(network, 'abrir_url') as request:
            request.return_value.__enter__.return_value.read.return_value = b'Video has not been found'
            with self.assertRaisesRegex(network.ServidorNoDisponible, 'ya no existe'):
                resolvers.resolver_ok_ru('https://ok.ru/videoembed/1')


if __name__ == '__main__':
    unittest.main()
