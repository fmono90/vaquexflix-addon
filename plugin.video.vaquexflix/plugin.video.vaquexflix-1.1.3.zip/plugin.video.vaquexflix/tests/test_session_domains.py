import http.cookiejar
import os
import tempfile
import unittest
from unittest.mock import Mock, patch
from urllib.request import build_opener, HTTPCookieProcessor

import sessions as session


class ExpressSessionTests(unittest.TestCase):
    def test_only_provider_verification_is_loaded(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, 'cookies.txt')
            with open(path, 'w') as output:
                output.write('# Netscape HTTP Cookie File\n')
                for domain, name in [('.doramaexpress.com', 'cf_clearance'),
                                     ('.doramaexpress.com', 'login'),
                                     ('.other.test', 'cf_clearance')]:
                    output.write('%s\tTRUE\t/\tTRUE\t4102444800\t%s\ttest\n' % (domain, name))
            addon = Mock()
            addon.Addon.return_value.getSetting.side_effect = lambda key: path if key.endswith('_cookies') else 'verified-agent'
            vfs = Mock()
            vfs.translatePath.side_effect = lambda value: value
            jar = http.cookiejar.CookieJar()
            opener = build_opener(HTTPCookieProcessor(jar))
            with patch.dict('sys.modules', xbmcaddon=addon, xbmcvfs=vfs), \
                 patch.object(session, 'firefox_verification', return_value=None):
                self.assertEqual(session.configure(opener, 'doramaexpress', ('doramaexpress.com', 'www.doramaexpress.com')), 'verified-agent')
            self.assertEqual([(c.domain, c.name) for c in jar], [('.doramaexpress.com', 'cf_clearance')])
