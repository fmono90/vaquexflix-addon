import network
import resolvers
import http.cookiejar
import os
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

import sessions as solo


class SoloLatinoSessionTests(unittest.TestCase):
    def setUp(self):
        for name, value in (('_ACCESS_UNTIL', 0), ('_ACCESS_ERROR', '')):
            handle = patch.object(solo, name, value)
            handle.start()
            self.addCleanup(handle.stop)

    def test_only_unexpired_verification_cookies_are_imported(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, 'cookies.txt')
            with open(path, 'w') as output:
                output.write('# Netscape HTTP Cookie File\n')
                for domain, name, expiry in [('#HttpOnly_.sololatino.net', 'cf_clearance', 4102444800),
                                              ('.sololatino.net', 'login', 4102444800),
                                              ('.other.test', 'cf_clearance', 4102444800),
                                              ('.sololatino.net', '__cf_bm', 1)]:
                    output.write('%s\tTRUE\t/\tTRUE\t%d\t%s\ttest-value\n' % (domain, expiry, name))
            cookies = solo.clearance_cookies(path)
            self.assertEqual([c.name for c in cookies], ['cf_clearance'])

    def test_zero_expiry_browser_cookie_is_a_session_cookie(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, 'cookies.txt')
            with open(path, 'w') as output:
                output.write('# Netscape HTTP Cookie File\n#HttpOnly_.sololatino.net\tTRUE\t/\tTRUE\t0\tcf_clearance\ttest-value\n')
            cookies = solo.clearance_cookies(path)
            self.assertEqual(len(cookies), 1)
            self.assertIsNone(cookies[0].expires)

    def test_requests_share_session_and_keep_user_agent_consistent(self):
        transport = Mock()
        transport.Session.return_value.request.return_value.status_code = 200
        transport.Session.return_value.cookies.jar = http.cookiejar.CookieJar()
        headers = {'Cookie': 'XSRF-TOKEN=token', 'User-Agent': 'old-agent'}
        with patch.object(solo, '_LOCAL', threading.local()), \
             patch.object(solo, 'browser_settings', return_value=('', 'verified-agent')):
            solo.request(transport, 'https://sololatino.net/sanctum/csrf-cookie', {}, None, 5)
            solo.request(transport, 'https://sololatino.net/api/player-url', headers, b'{}', 5)
            transport.Session.assert_called_once_with(impersonate='chrome')
            session = transport.Session.return_value
            self.assertEqual(session.request.call_args.args[0], 'POST')
            self.assertEqual(session.request.call_args.kwargs['headers'], {'User-Agent': 'verified-agent'})
            session.cookies.set.assert_called_once_with('XSRF-TOKEN', 'token', domain='sololatino.net', path='/')
        self.assertEqual(headers['User-Agent'], 'old-agent')
        self.assertIn('Cookie', headers)

    def test_other_hosts_cannot_use_the_verified_session(self):
        with patch.object(solo, 'client') as client:
            with self.assertRaises(ValueError):
                solo.request(Mock(), 'https://sololatino.net.evil.test/', {}, None, 5)
            client.assert_not_called()

    def test_ip_block_stops_retries_without_touching_other_providers(self):
        import servidores
        with patch.object(solo.time, 'monotonic', return_value=100):
            solo.record_response(Mock(status_code=403, text='The owner has banned your IP address.'))
            self.assertIn('1006', solo.access_error())
            with patch.object(network, 'nueva_sesion') as session, patch.object(solo, 'configure', return_value=''):
                session.return_value.handlers = []
                request_mock = session.return_value.open
                self.assertEqual(network.fetch_html('https://sololatino.net/series'), ('', []))
                request_mock.assert_called_once()
                self.assertEqual(request_mock.call_args.args[0].full_url, 'https://sololatino.co/series')
        with patch.object(solo.time, 'monotonic', return_value=1001):
            self.assertEqual(solo.access_error(), '')

    def test_record_http_error_sets_access_error(self):
        with patch.object(solo.time, 'monotonic', return_value=100):
            solo.record_http_error('sololatino.net', 403, 'Challenge turnstile')
            self.assertIn('rechazo el acceso', solo.access_error())
        with patch.object(solo.time, 'monotonic', return_value=1000):
            self.assertEqual(solo.access_error(), '')

    def test_parse_curl_or_headers(self):
        curl_sample = (
            "curl 'https://sololatino.net/' "
            "-H 'user-agent: Mozilla/5.0 TestBrowser/1.0' "
            "-H 'cookie: other=123; cf_clearance=test_clearance_abc; __cf_bm=test_bm_xyz' "
            "--compressed"
        )
        cf_clearance, cf_bm, ua = solo.parse_curl_or_headers(curl_sample)
        self.assertEqual(cf_clearance, 'test_clearance_abc')
        self.assertEqual(cf_bm, 'test_bm_xyz')
        self.assertEqual(ua, 'Mozilla/5.0 TestBrowser/1.0')

    def test_save_verification_creates_valid_netscape_file(self):
        with tempfile.TemporaryDirectory() as root:
            cookie_path = os.path.join(root, 'sololatino_cookies.txt')
            saved = solo.save_verification('cf_val_123', 'MyAgent/1.0', cf_bm='bm_val_456',
                                           domains=('sololatino.net', 'sololatino.co'),
                                           provider='sololatino', path=cookie_path)
            self.assertEqual(saved, cookie_path)
            self.assertTrue(os.path.isfile(cookie_path))
            cookies = solo.clearance_cookies(cookie_path, domains=('sololatino.net', 'sololatino.co'))
            names = {c.name for c in cookies}
            self.assertIn('cf_clearance', names)
            self.assertIn('__cf_bm', names)
