import network
import resolvers
import json
import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from unittest.mock import patch

import catalog
import doramas
import servidores
import servidores as tubi
class TubiTests(unittest.TestCase):
    def test_requested_episode_not_recommendation(self):
        payload = {'video': {'byId': {'1': {'id': '1', 'title': 'Other'},
                                     '2': {'id': '2', 'title': 'undefined'}}}}
        html = '<script>window.__data=' + json.dumps(payload)[:-1] + ',"missing":undefined};</script>'
        with patch.object(tubi, 'tubi_request', return_value=html):
            self.assertEqual(tubi.tubi_detail(tubi.tubi_BASE + '/tv-shows/2')['title'], 'undefined')
            with self.assertRaises(ValueError):
                tubi.tubi_detail(tubi.tubi_BASE + '/tv-shows/3')
            with self.assertRaises(ValueError):
                tubi.tubi_detail('https://example.com/tv-shows/2')

    def test_sitemap_metadata_and_foreign_urls(self):
        xml = '''<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
        <url><loc>https://tubitv.com/movies/1/example</loc><video:video>
        <video:title>Título</video:title><video:description>Plot</video:description>
        </video:video></url><url><loc>https://example.com/movies/2/no</loc></url></urlset>'''
        items = tubi.tubi_parse_sitemap(xml)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['title'], 'Título')
        self.assertFalse(items[0]['is_serie'])

    def test_index_search_pagination_and_failed_refresh(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(tubi, 'tubi_database', return_value=os.path.join(temp, 'index.db')), patch.object(tubi, 'tubi_is_available', return_value=True):
            index = '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><sitemap><loc>https://tubitv.com/sitemaps/movies-1.xml</loc></sitemap></sitemapindex>'
            items = [{'url': tubi.tubi_BASE + '/movies/%d/example' % n, 'title': 'Título %03d' % n,
                      'is_serie': False} for n in range(65)]
            with patch.object(tubi, 'tubi_request', return_value=index), patch.object(tubi, 'tubi_parse_sitemap', side_effect=[items, []]):
                tubi.tubi_refresh(force=True)
            a, more = tubi.tubi_page('peliculas', 1)
            b, last = tubi.tubi_page('peliculas', 3)
            self.assertEqual((len(a), more, len(b), last), (30, True, 5, False))
            self.assertEqual(len(tubi.tubi_search('titulo 031')), 1)
            with patch.object(tubi, 'tubi_request', side_effect=RuntimeError('offline')):
                tubi.tubi_refresh(force=True)
            self.assertEqual(len(tubi.tubi_search('titulo')), 65)

    def test_fresh_tokens_and_cdn_fallback(self):
        item = {'url': tubi.tubi_BASE + '/tv-shows/2'}
        with patch.object(tubi, 'tubi_is_available', return_value=True):
            server = tubi.tubi_servers(item)[0]
        self.assertEqual(server['nombre'], 'US_VPN')
        self.assertNotIn('token=', server['url'])
        data = {'video_resources': [
            {'type': 'dash', 'manifest': {'url': 'https://nc-cf.tubi.video/x.mpd'}},
            {'type': 'hlsv6', 'manifest': {'url': 'https://nc-cf.tubi.video/x.m3u8?token=fresh'}},
            {'type': 'hlsv6', 'manifest': {'url': 'https://nc-aka.tubi.video/x.m3u8?token=fresh'}}]}
        with patch.object(tubi, 'tubi_is_available', return_value=True), patch.object(tubi, 'tubi_detail', return_value=data) as fetch, patch.object(resolvers, 'procesar_hls_local', side_effect=[None, 'stream']):
            self.assertEqual(resolvers.resolver_stream(server['url']), 'stream')
            fetch.assert_called_once_with(item['url'])

    def test_tubi_stays_in_experimental_series(self):
        item = {'title': 'Example', 'url': tubi.tubi_BASE + '/series/123/example',
                'source': 'tubi', 'section': 'series', 'is_serie': True}
        other = dict(item, url='https://doramaexpress.com/serie/example/', source='express')
        with patch.object(tubi, 'tubi_is_available', return_value=True):
            self.assertFalse(doramas.is_dorama(item))
            self.assertEqual(len(catalog.merge([item, other])), 2)
            self.assertEqual(catalog.in_section([item], 'doramas'), [])
            self.assertEqual(catalog.in_section([item], 'series'), [item])
            self.assertEqual(catalog.display_title(item), 'Example [US VPN]')
            self.assertEqual(catalog.display_title(other), 'Example')
            self.assertEqual(catalog.display_title(item, 'Example (12:34)'), 'Example (12:34) [US VPN]')
            self.assertEqual(item['title'], 'Example')
            merged = catalog.merge([item, dict(item, url='https://sololatino.net/serie/example')])[0]
            self.assertEqual(catalog.display_title(merged), 'Example [US VPN]')
            self.assertEqual(catalog.servers(item, True)[0]['nombre'], 'US_VPN')
            with patch.object(tubi, 'tubi_detail', return_value={'seasons': [
                    {'number': '2', 'episodes': [{'id': '9', 'num': 3}]}]}):
                ep = servidores.obtener_episodios(item)['2'][0]
                self.assertFalse(doramas.is_dorama(ep))
                self.assertEqual(ep['episode'], '3')
                self.assertEqual(catalog.display_title(ep), 'T2:E3 - Example [US VPN]')

    def test_existing_drama_index_is_reclassified_offline(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(tubi, 'tubi_database', return_value=os.path.join(temp, 'index.db')), patch.object(tubi, 'tubi_is_available', return_value=True):
            item = {'title': 'La luz en tus ojos', 'url': tubi.tubi_BASE + '/series/123/example',
                    'source': 'tubi', 'section': 'doramas', 'is_serie': True}
            with closing(sqlite3.connect(tubi.tubi_database())) as db, db:
                db.execute('CREATE TABLE titles (url TEXT PRIMARY KEY, title TEXT, kind TEXT, drama INTEGER, data TEXT)')
                db.execute('CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)')
                db.execute('INSERT INTO titles VALUES (?,?,?,?,?)',
                           (item['url'], tubi.tubi_normalize(item['title']), 'series', 1, json.dumps(item)))
                db.execute("INSERT INTO meta VALUES ('updated', ?)", (str(__import__('time').time()),))
            tubi.tubi_refresh()
            self.assertEqual(tubi.tubi_page('doramas')[0], [])
            self.assertEqual(tubi.tubi_page('series')[0][0]['section'], 'series')

    def test_is_available_detection(self):
        class MockResp:
            def __init__(self, url):
                self._url = url
            def geturl(self):
                return self._url
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass

        class MockSession:
            def __init__(self, target_url):
                self._target_url = target_url
            def open(self, req, timeout=3):
                return MockResp(self._target_url)

        with patch.object(network, 'nueva_sesion', return_value=MockSession('https://gdpr.tubi.tv/')):
            self.assertFalse(tubi.tubi_is_available(force=True))

        with patch.object(network, 'nueva_sesion', return_value=MockSession('https://tubitv.com/home')):
            self.assertTrue(tubi.tubi_is_available(force=True))

    def test_tubi_hidden_when_vpn_inactive(self):
        tubi_item = {'title': 'Tubi Solo', 'url': tubi.tubi_BASE + '/movies/123/tubi', 'source': 'tubi', 'is_serie': False}
        hybrid_item = {'title': 'Hybrid', 'url': tubi.tubi_BASE + '/movies/456/hybrid', 'source': 'tubi', 'is_serie': False,
                       'variants': [dict(tubi_item, url=tubi.tubi_BASE + '/movies/456/hybrid'),
                                    {'title': 'Hybrid', 'url': 'https://sololatino.net/pelicula/hybrid', 'source': 'sololatino', 'is_serie': False}]}

        with patch.object(tubi, 'tubi_is_available', return_value=False):
            self.assertEqual(tubi.tubi_search('anything'), [])
            self.assertEqual(tubi.tubi_page('peliculas', 1), ([], False))
            self.assertEqual(tubi.tubi_servers(tubi_item), [])
            # In section: pure Tubi item is completely filtered out
            self.assertEqual(catalog.in_section([tubi_item], 'peliculas'), [])
            # Hybrid item has Tubi stripped and falls back to SoloLatino
            clean_hybrid = catalog.in_section([hybrid_item], 'peliculas')
            self.assertEqual(len(clean_hybrid), 1)
            self.assertEqual(clean_hybrid[0]['source'], 'sololatino')
            self.assertFalse(any(tubi.tubi_owns(v['url']) for v in clean_hybrid[0]['variants']))
            # Display title strips [US VPN]
            self.assertEqual(catalog.display_title(tubi_item, 'Tubi Solo [US VPN]'), 'Tubi Solo')


if __name__ == '__main__':
    unittest.main()
