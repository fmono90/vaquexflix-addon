import subprocess
import network
import resolvers
import json
import time
import unittest
from contextlib import ExitStack
from unittest.mock import Mock, patch
from urllib.error import HTTPError

import catalog
import servidores as cinecalidad
import servidores as fm
import servidores as s
import servidores as tubi
class VersionReviewTests(unittest.TestCase):
    def test_optional_resolver_failure_uses_native(self):
        optional = Mock()
        optional.relevant_resolvers.side_effect = RuntimeError('broken optional plugin')
        with patch.object(resolvers, 'resolveurl', optional), patch.object(resolvers, 'resolver_filemoon', return_value='native'):
            self.assertEqual(resolvers.resolver_stream('https://filemoon.sx/e/abc'), 'native')

    def test_catalog_restores_experimental_providers(self):
        film = {'url': cinecalidad.cinecalidad_BASE + '/pelicula/example/', 'title': 'Example', 'is_serie': False}
        with ExitStack() as stack:
            stack.enter_context(patch.object(network, 'fetch_html', return_value=('<html></html>', [])))
            for name in ('hackstore_catalog', 'pelisjuanita_catalog'):
                stack.enter_context(patch.object(s, name, return_value=([], False)))
            stack.enter_context(patch.object(s, 'pelisflix_catalog', return_value=[]))
            tubi_page = stack.enter_context(patch.object(tubi, 'tubi_page', return_value=([], False)))
            cinema_page = stack.enter_context(patch.object(cinecalidad, 'cinecalidad_page', return_value=([film], True)))
            items, more = catalog.page('peliculas', 2, True)
            self.assertEqual(items[0]['url'], film['url'])
            self.assertTrue(more)
            tubi_page.assert_called_once_with('peliculas', 2)
            cinema_page.assert_called_once_with(2)
            catalog.page('series', 1, True)
            cinema_page.assert_called_once()

    def test_provider_metadata_and_vpn_label(self):
        old = {'title': 'Example', 'url': 'https://tubitv.com/movies/123/example'}
        self.assertEqual(catalog.display_title(old), 'Example [US VPN]')
        self.assertEqual(catalog.display_title(old, 'Example [US VPN]'), 'Example [US VPN]')
        with patch.object(tubi, 'tubi_metadata', return_value={'plot': 'complete'}) as fetch:
            self.assertEqual(catalog.metadata(old), {'plot': 'complete'})
            fetch.assert_called_once_with(old)
        with patch.object(cinecalidad, 'cinecalidad_metadata', return_value={'plot': 'complete'}):
            self.assertEqual(catalog.metadata({'url': cinecalidad.cinecalidad_BASE + '/pelicula/1/'}), {'plot': 'complete'})

    def session(self, bodies):
        opener = Mock()
        responses = []
        for body in bodies:
            if isinstance(body, Exception):
                responses.append(body)
                continue
            response = Mock()
            response.read.return_value = json.dumps(body).encode()
            cm = Mock()
            cm.__enter__ = Mock(return_value=response)
            cm.__exit__ = Mock(return_value=False)
            responses.append(cm)
        opener.open.side_effect = responses
        return opener

    def test_filemoon_follows_dynamic_frame_and_keeps_token_session(self):
        opener = self.session([
            {'embed_frame_url': 'https://player.example/new12/abc'},
            {'captcha_required': True},
            {'pow_nonce': 'nonce', 'pow_difficulty': 16, 'pow_token': 'proof'},
            {'status': 'ok', 'token': 'accepted'},
            {'sources': [{'url': 'https://cdn.example/video.m3u8'}]},
        ])
        with network.presupuesto_sondeo(time.monotonic() + 15), patch.object(network, 'nueva_sesion', return_value=opener), patch.object(resolvers, '_filemoon_attest', return_value={'token': 'session'}), patch.object(resolvers, '_filemoon_proof', return_value='42'), patch.object(resolvers, 'procesar_hls_local', return_value='playable'):
            self.assertEqual(resolvers._filemoon_resolve('https://bysedikamoum.com/e/abc'), 'playable')
        requests = [call.args[0] for call in opener.open.call_args_list]
        self.assertEqual(requests[1].full_url, 'https://player.example/api/videos/abc/embed/settings')
        self.assertEqual(requests[-1].get_header('X-captcha-token'), 'accepted')
        self.assertEqual(json.loads(requests[3].data)['solution'], '42')

    def test_filemoon_verified_but_playback_rejected_is_not_success(self):
        error = HTTPError('https://example.test', 405, 'Method', {}, None)
        opener = self.session([{}, {}, error, error])
        with patch.object(network, 'nueva_sesion', return_value=opener):
            with self.assertRaisesRegex(network.ServidorNoDisponible, 'HTTP 405'):
                resolvers._filemoon_resolve('https://bysedikamoum.com/e/abc')

    def test_filemoon_expired_probes_do_not_launch_helper(self):
        opener = self.session([{}, {'captcha_required': True}])
        with patch.object(network, 'nueva_sesion', return_value=opener), patch.object(resolvers, '_filemoon_proof') as helper, patch.object(network._sondeo, 'deadline', 1, create=True):
            with self.assertRaises(TimeoutError):
                resolvers._filemoon_resolve('https://bysedikamoum.com/e/abc')
            helper.assert_not_called()

    def test_filemoon_proof_does_not_require_node(self):
        with patch.object(resolvers.shutil, 'which', return_value=None), patch.object(subprocess, 'run', side_effect=AssertionError('External process')):
            self.assertEqual(resolvers._filemoon_proof({'pow_nonce':'a', 'pow_difficulty':0}), '0')

    def test_filemoon_proof_timeout_is_explicit(self):
        with patch.object(resolvers.shutil, 'which', return_value=None), self.assertRaisesRegex(network.ServidorNoDisponible, 'tiempo'):
            resolvers._filemoon_proof({'pow_nonce':'a', 'pow_difficulty':16}, timeout=0)


if __name__ == '__main__':
    unittest.main()
