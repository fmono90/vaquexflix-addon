# Run an isolated diagnostic with Kodi's actual Python DLL, without touching Kodi's process.
param([string]$Script, [string]$TestStandardLibrary)
$ErrorActionPreference = 'Stop'
if (-not $Script) { throw 'Pass the absolute path of a Python diagnostic script.' }
$scriptPath = (Resolve-Path -LiteralPath $Script).Path
$addonRoot = Split-Path -Parent $PSScriptRoot
$kodiRoot = 'C:\Program Files\Kodi'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class KodiPythonDiagnostic {
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    public static extern IntPtr LoadLibraryW(string path);
    [DllImport("C:\\Program Files\\Kodi\\python3.8.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void Py_SetPath(IntPtr path);
    [DllImport("C:\\Program Files\\Kodi\\python3.8.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void Py_Initialize();
    [DllImport("C:\\Program Files\\Kodi\\python3.8.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern int PyRun_SimpleString([MarshalAs(UnmanagedType.LPStr)] string code);
    [DllImport("C:\\Program Files\\Kodi\\python3.8.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern int Py_FinalizeEx();
}
'@
$null = [KodiPythonDiagnostic]::LoadLibraryW((Join-Path $kodiRoot 'python3.8.dll'))
$null = [KodiPythonDiagnostic]::LoadLibraryW((Join-Path $kodiRoot 'python3.dll'))
$modulePaths = @(
    (Join-Path $kodiRoot 'system\Python\Lib'),
    (Join-Path $kodiRoot 'system\Python\DLLs'),
    $addonRoot,
    (Join-Path $addonRoot 'lib')
)
# Kodi omits unittest; an optional official Python 3.8 stdlib supplies tests only.
if ($TestStandardLibrary) {
    $modulePaths += (Resolve-Path -LiteralPath $TestStandardLibrary).Path
}
$modulePaths = $modulePaths -join ';'
$pathPointer = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($modulePaths)
try {
    [KodiPythonDiagnostic]::Py_SetPath($pathPointer)
    [KodiPythonDiagnostic]::Py_Initialize()
    $encodedPath = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($scriptPath))
    $result = [KodiPythonDiagnostic]::PyRun_SimpleString("import base64,runpy; runpy.run_path(base64.b64decode('$encodedPath').decode('utf-8'), run_name='__main__')")
    $null = [KodiPythonDiagnostic]::Py_FinalizeEx()
    if ($result -ne 0) { throw 'Kodi Python diagnostic failed.' }
} finally {
    [Runtime.InteropServices.Marshal]::FreeHGlobal($pathPointer)
}
