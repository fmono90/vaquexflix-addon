"""Build a small installer from current tracked files and export-ignore rules."""
import argparse
import subprocess
import zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent

def build(output):
    manifest = ET.parse(str(ROOT / 'addon.xml')).getroot()
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=str(ROOT)).decode().split('\0')
    names = [n for n in names if n]
    attrs = subprocess.check_output(['git', 'check-attr', '-z', '--stdin', 'export-ignore'],
                                    input=('\0'.join(names)+'\0').encode(), cwd=str(ROOT)).decode().split('\0')
    excluded = {attrs[i] for i in range(0, len(attrs)-2, 3) if attrs[i+2] == 'set'}
    output = Path(output)
    with zipfile.ZipFile(str(output), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in names:
            path = ROOT / name
            if name in excluded or not path.is_file(): continue
            if path.suffix in ('.zip', '.pyc', '.pyo') or path.name.endswith('_cookies.txt'): continue
            archive.write(str(path), manifest.attrib['id'] + '/' + name)
    if output.stat().st_size > 9_000_000:
        raise RuntimeError('Installer exceeds 9 MB')
    with zipfile.ZipFile(str(output)) as archive:
        if archive.testzip(): raise RuntimeError('Corrupt installer')
    print(str(output), output.stat().st_size)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('output')
    build(parser.parse_args().output)
