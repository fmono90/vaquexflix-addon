"""
Herramienta de Renovacion de Acceso a SoloLatino para Vaquexflix (Kodi).
Soporta:
1. --solve: Abre Chrome para resolver interactivamente el desafio Cloudflare Turnstile
           y extrae automaticamente cf_clearance y User-Agent via CDP.
2. --curl "<texto>": Importa la sesion desde una peticion cURL copiada desde DevTools.
3. --paste: Solicita pegar el comando cURL o cabeceras interactivamente.
4. --test: Verifica el acceso actual desde el motor de red del addon.
"""
import os
import sys
import json
import time
import socket
import base64
import struct
import argparse
import subprocess
import urllib.request
from pathlib import Path

# Agregar directorio raiz del addon a sys.path
ADDON_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ADDON_DIR))

import sessions
import network


def _cdp_call(ws_url, method, params=None, msg_id=1, timeout=8):
    """Llama a un metodo del Chrome DevTools Protocol sobre WebSocket sin librerias externas."""
    parts = ws_url.replace('ws://', '').split('/', 1)
    host, port = parts[0].split(':')
    path = '/' + parts[1]

    s = socket.create_connection((host, int(port)), timeout=timeout)
    key = base64.b64encode(os.urandom(16)).decode('utf-8')
    handshake = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}:{port}\r\n"
        f"Upgrade: websocket\r\n"
        f"Connection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\n"
        f"Sec-WebSocket-Version: 13\r\n\r\n"
    )
    s.sendall(handshake.encode('utf-8'))
    resp = s.recv(4096)
    if len(resp.split(b'\r\n', 1)[0].split()) < 2 or resp.split(b'\r\n', 1)[0].split()[1] != b'101':
        s.close()
        raise RuntimeError("Fallo el handshake de WebSocket con Chrome")

    msg = json.dumps({"id": msg_id, "method": method, "params": params or {}}).encode('utf-8')
    header = bytearray([0x81])
    length = len(msg)
    mask = os.urandom(4)
    if length < 126:
        header.append(0x80 | length)
    elif length <= 0xFFFF:
        header.append(0x80 | 126)
        header.extend(struct.pack('>H', length))
    else:
        header.append(0x80 | 127)
        header.extend(struct.pack('>Q', length))
    header.extend(mask)
    masked = bytearray(b ^ mask[i % 4] for i, b in enumerate(msg))
    s.sendall(header + masked)

    raw = bytearray()
    while True:
        chunk = s.recv(65536)
        if not chunk:
            break
        raw.extend(chunk)
        if len(raw) >= 2:
            payload_len = raw[1] & 0x7F
            idx = 2
            if payload_len == 126:
                if len(raw) < 4:
                    continue
                payload_len = struct.unpack('>H', raw[2:4])[0]
                idx = 4
            elif payload_len == 127:
                if len(raw) < 10:
                    continue
                payload_len = struct.unpack('>Q', raw[2:10])[0]
                idx = 10
            if len(raw) >= idx + payload_len:
                data = raw[idx:idx + payload_len].decode('utf-8', errors='ignore')
                s.close()
                return json.loads(data)
    s.close()
    return {}


def find_chrome():
    """Localiza el ejecutable de Google Chrome en Windows."""
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def solve_interactive():
    """Abre Chrome con un perfil temporal para superar Cloudflare y capturar la verificacion."""
    chrome_path = find_chrome()
    if not chrome_path:
        print("ERROR: No se encontro Google Chrome en las rutas estandar.")
        print("Usa la opcion --curl o --paste para importar la sesion manualmente.")
        return False

    temp_profile = Path(os.environ.get('TEMP', '.')) / 'vaquexflix_chrome_solve'
    temp_profile.mkdir(parents=True, exist_ok=True)
    port = 9244

    url_target = "https://sololatino.net/"
    args = [
        chrome_path,
        f"--user-data-dir={temp_profile}",
        f"--remote-debugging-port={port}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-blink-features=AutomationControlled",
        url_target
    ]

    print(f"\n[1/3] Lanzando Chrome en puerto {port}...")
    print("      Navegando a https://sololatino.net/")
    print("      (Si aparece la casilla de Cloudflare Turnstile, marcala en la ventana abierta)")
    proc = subprocess.Popen(args)

    cf_clearance = ''
    cf_bm = ''
    user_agent = ''

    try:
        # Esperar a que Chrome inicie y responda en el puerto de depuracion
        ws_url = None
        for _ in range(15):
            time.sleep(1)
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2) as r:
                    tabs = json.loads(r.read().decode('utf-8'))
                    if tabs:
                        ws_url = tabs[0].get('webSocketDebuggerUrl')
                        if ws_url:
                            break
            except Exception:
                pass

        if not ws_url:
            print("ERROR: No se pudo conectar a la sesion de depuracion de Chrome.")
            return False

        print("\n[2/3] Monitoreando la resolucion del desafio Cloudflare...")
        start_time = time.time()
        timeout_seconds = 90

        while time.time() - start_time < timeout_seconds:
            try:
                # Consultar cookies de sololatino.net y sololatino.co
                res_cookies = _cdp_call(ws_url, "Network.getCookies", {
                    "urls": ["https://sololatino.net", "https://sololatino.co"]
                })
                cookie_list = res_cookies.get('result', {}).get('cookies', [])
                for ck in cookie_list:
                    if ck.get('name') == 'cf_clearance':
                        cf_clearance = ck.get('value')
                    elif ck.get('name') == '__cf_bm':
                        cf_bm = ck.get('value')

                if cf_clearance:
                    # Obtener el User-Agent real
                    res_ua = _cdp_call(ws_url, "Runtime.evaluate", {
                        "expression": "navigator.userAgent"
                    })
                    user_agent = res_ua.get('result', {}).get('result', {}).get('value', '')
                    print(">>> Exito! Desafio Turnstile superado y cookies generadas.")
                    break
            except Exception as e:
                pass

            time.sleep(2)

        if not cf_clearance:
            print("\nTIEMPO AGOTADO: No se detecto cookie 'cf_clearance' dentro de los 90 segundos.")
            return False

    finally:
        try:
            proc.terminate()
            proc.wait(timeout=3)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    print("\n[3/3] Guardando sesion en Kodi...")
    saved_path = sessions.save_verification(
        cf_clearance=cf_clearance,
        user_agent=user_agent,
        cf_bm=cf_bm,
        domains=('sololatino.net', 'sololatino.co')
    )
    print(f"      Archivo guardado: {saved_path}")
    print(f"      User-Agent: {user_agent}")

    print("\nProbando conexion con Kodi...")
    return test_connection()


def import_curl(curl_text):
    """Importa cURL o texto de cabeceras pegado."""
    cf_clearance, cf_bm, user_agent = sessions.parse_curl_or_headers(curl_text)
    if not cf_clearance:
        print("ERROR: No se encontro el token 'cf_clearance' en el texto proporcionado.")
        print("Asegurate de copiar la solicitud despues de completar la verificacion en el navegador.")
        return False

    if not user_agent:
        user_agent = network.UA
        print(f"AVISO: No se detecto User-Agent en el texto. Usando por defecto: {user_agent}")

    saved_path = sessions.save_verification(
        cf_clearance=cf_clearance,
        user_agent=user_agent,
        cf_bm=cf_bm,
        domains=('sololatino.net', 'sololatino.co')
    )
    print(f"\nExito! Sesion importada correctamente:")
    print(f"Archivo guardado: {saved_path}")
    print(f"User-Agent: {user_agent}")

    print("\nProbando conexion con Kodi...")
    return test_connection()


def test_connection():
    """Prueba el acceso a SoloLatino con la sesion actual de Kodi."""
    print("=" * 60)
    print("Comprobando conexion con SoloLatino desde network.fetch_html()...")
    
    url = f"{network.SOLOLATINO_BASE}/peliculas"
    html, cookies = network.fetch_html(url, timeout=12)
    
    if html and len(html) > 1000:
        import servidores
        items = servidores.sololatino_parsear_tarjetas(html, "peliculas")
        print(f"CONEXION EXITOSA!")
        print(f"Dominio: {network.SOLOLATINO_BASE}")
        print(f"Respuesta HTML: {len(html)} bytes")
        print(f"Titulos extraidos de /peliculas: {len(items)}")
        if items:
            print(f"Primer titulo de muestra: {items[0].get('title', '')}")
        print("=" * 60)
        return True
    else:
        print("FALLO LA CONEXION:")
        print("SoloLatino sigue devolviendo respuesta vacia o bloqueo 403.")
        err = sessions.access_error()
        if err:
            print(f"Detalle del bloqueo: {err}")
        print("Es necesario renovar la verificacion en el navegador.")
        print("=" * 60)
        return False


def main():
    parser = argparse.ArgumentParser(description="Renovador de sesion SoloLatino para Vaquexflix.")
    parser.add_argument("--solve", action="store_true", help="Abrir Chrome para resolver Cloudflare Turnstile automaticamente.")
    parser.add_argument("--curl", type=str, help="Importar solicitud cURL o cabeceras.")
    parser.add_argument("--paste", action="store_true", help="Pegar cURL interactivamente en la terminal.")
    parser.add_argument("--test", action="store_true", help="Comprobar conexion actual sin modificar nada.")

    args = parser.parse_args()

    if args.solve:
        solve_interactive()
    elif args.curl:
        import_curl(args.curl)
    elif args.paste:
        print("Pega aqui tu comando cURL (o cabeceras) y presiona Enter:")
        lines = []
        try:
            while True:
                line = input()
                if not line and lines:
                    break
                lines.append(line)
        except EOFError:
            pass
        import_curl("\n".join(lines))
    elif args.test:
        test_connection()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
