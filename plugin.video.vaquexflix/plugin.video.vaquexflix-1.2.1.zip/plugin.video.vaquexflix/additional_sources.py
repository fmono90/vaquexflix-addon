"""Fuentes verificadas: Dondever, Ver Películas Online, HomeCine y AresHD.

Los enlaces de servidor se resuelven al seleccionarlos: sus URLs caducan y
una opción anunciada no equivale a un vídeo comprobado.
"""

import html
import json
import re
import unicodedata
from urllib.parse import urlencode, urljoin, urlsplit, parse_qs, quote

import network
import source_switches

DONDEVER = 'https://dondever.net'
VERPEL = 'https://ver-peliculas-online.net'
HOMECINE = 'https://www3.homecine.to'
ARESHD = 'https://areshd.com'
PELISGO = 'https://pelisgo.online'


def pelisgo_media_headers():
    """El CDN de KeKi exige el mismo agente e idioma usados al pedir la firma."""
    return {'User-Agent': network.UA,
            'Accept-Language': _headers(PELISGO + '/', api=True)['Accept-Language'],
            'Origin': PELISGO, 'Referer': PELISGO + '/'}


def _headers(referer, api=False):
    return {
        'User-Agent': network.UA, 'Referer': referer,
        'Accept': 'application/json, text/plain, */*' if api else
                  'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
        'Sec-Fetch-Dest': 'empty' if api else 'document',
        'Sec-Fetch-Mode': 'cors' if api else 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        **({'X-Requested-With': 'XMLHttpRequest'} if api else {}),
    }


def _get(url, referer=None, api=False, data=None):
    page, _ = network.fetch_html(url, referer=referer or url, timeout=10,
                                 data=data, headers_dict=_headers(referer or url, api))
    if not page:
        raise network.ServidorNoDisponible('La fuente no respondió: ' + (urlsplit(url).hostname or 'desconocida'))
    return page


def _text(fragment):
    return html.unescape(re.sub(r'<[^>]+>', '', fragment or '')).strip()


def owns(url):
    import servidores
    if servidores.owns(url):
        return True
    return urlsplit(url).hostname in ('dondever.net', 'www.dondever.net',
                                     'ver-peliculas-online.net', 'www.ver-peliculas-online.net',
                                     'homecine.to', 'www.homecine.to', 'www3.homecine.to',
                                     'areshd.com', 'www.areshd.com', 'pelisgo.online', 'www.pelisgo.online')


def _pelisgo_id(page):
    match = re.search(r'\\"contentId\\":\\"([a-z0-9]+)\\"', page)
    if not match:
        raise network.ServidorNoDisponible('PelisGO no publicó el identificador de la ficha.')
    return match.group(1)


def _pelisgo_links(content_id, referer, episode=False):
    headers = _headers(referer, api=True)
    headers['Origin'] = PELISGO
    headers['Content-Type'] = 'application/json'
    sync, _ = network.fetch_html(PELISGO + '/api/session/sync', referer=referer,
                                 timeout=10, data=b'', headers_dict=headers)
    try:
        sid = json.loads(sync).get('sid')
    except (TypeError, ValueError):
        sid = None
    if not isinstance(sid, str) or not sid:
        raise network.ServidorNoDisponible('PelisGO no entregó una sesión válida.')
    headers.pop('Content-Type')
    headers['x-session-id'] = sid
    path = '/api/series/episode/' if episode else '/api/movies/'
    payload, _ = network.fetch_html(PELISGO + path + content_id + '/stream',
                                    referer=referer, timeout=10, headers_dict=headers)
    try:
        data = json.loads(payload)
    except (TypeError, ValueError):
        raise network.ServidorNoDisponible('PelisGO devolvió una respuesta de servidores inválida.')
    if not isinstance(data, dict) or not isinstance(data.get('links'), list):
        raise network.ServidorNoDisponible('PelisGO no publicó servidores para esta ficha.')
    return [link for link in data['links'] if isinstance(link, dict)]


def _pelisgo_cards(page):
    found = {}
    for match in re.finditer(r'<a\b[^>]*href=["\'](/(?:movies|series)/[^"\']+)["\'][^>]*>(.*?)</a>',
                             page, re.I | re.S):
        path, body = match.groups()
        image = re.search(r'<img\b[^>]*\balt=["\']([^"\']+)', body, re.I)
        title = _text(image.group(1)) if image else ''
        if not title:
            continue
        # El año está en el texto de la tarjeta, después del título. Sin él,
        # dos películas homónimas pueden compartir servidores por error.
        card_text = html.unescape(re.sub(r'<[^>]+>', ' ', body))
        year_match = re.search(r'\b(?:19|20)\d{2}\b', card_text)
        year = year_match.group(0) if year_match else ''
        cover = ''
        if image:
            tag = image.group(0) + body[image.end():body.find('>', image.end()) + 1]
            src = re.search(r'\bsrc=["\']([^"\']+)', tag, re.I)
            if src:
                image_url = html.unescape(src.group(1))
                if image_url.startswith('/_next/image'):
                    cover = parse_qs(urlsplit(image_url).query).get('url', [''])[0]
                elif image_url.startswith(('https://', 'http://')):
                    cover = image_url
        url = urljoin(PELISGO, path)
        found[url] = {'title': title, 'url': url, 'cover': cover, 'year': year,
                      'source': 'PelisGO', 'is_serie': path.startswith('/series/'),
                      'section': 'series' if path.startswith('/series/') else 'peliculas'}
    return list(found.values())


def search_pelisgo(query):
    return _pelisgo_cards(_get(PELISGO + '/search?' + urlencode({'q': query}), PELISGO + '/'))


def _cards(page, source):
    if source == 'Dondever':
        cards = re.findall(r'<article\b[^>]*\bnt-card\b[^>]*>(.*?)</article>', page, re.I | re.S)
        path_pattern = r'/(?:movies|tvshows)/[^"\'<> ]+'
    else:
        cards = re.findall(r'<div\b[^>]*class=["\']result-item["\'][^>]*>\s*<article>(.*?)</article>',
                           page, re.I | re.S)
        cards.extend(re.findall(r'<article\b[^>]*class=["\'][^"\']*\bitem\s+movies\b[^"\']*["\'][^>]*>(.*?)</article>',
                                page, re.I | re.S))
        path_pattern = r'/pelicula/[^"\'<> ]+'
    found = {}
    for card in cards:
        link = re.search(r'href=["\'](https?://[^"\']+' + path_pattern + r')["\']', card, re.I)
        if not link:
            continue
        url = html.unescape(link.group(1))
        if source == 'Dondever':
            title_match = re.search(r'<h3\b[^>]*>\s*<a[^>]*>(.*?)</a>', card, re.I | re.S)
        else:
            title_match = re.search(r'<div\b[^>]*class=["\']title["\'][^>]*>\s*<a[^>]*>(.*?)</a>', card, re.I | re.S)
            if not title_match:
                title_match = re.search(r'<h3\b[^>]*>\s*<a[^>]*>(.*?)</a>', card, re.I | re.S)
        title = _text(title_match.group(1)) if title_match else ''
        if not title:
            continue
        image = re.search(r'<img\b[^>]*(?:data-src|src)=["\'](https?://[^"\']+)', card, re.I)
        year = re.search(r'\b(?:19|20)\d{2}\b', card)
        found[url] = {'title': title, 'url': url, 'cover': html.unescape(image.group(1)) if image else '',
                      'year': year.group(0) if year else '', 'source': source,
                      'is_serie': '/tvshows/' in url, 'section': 'series' if '/tvshows/' in url else 'peliculas'}
    return list(found.values())


def search_dondever(query):
    page = _get(DONDEVER + '/?' + urlencode({'s': query}), DONDEVER + '/')
    return _cards(page, 'Dondever')


def search_verpel(query):
    page = _get(VERPEL + '/?' + urlencode({'s': query}), VERPEL + '/')
    return _cards(page, 'VerPeliculasOnline')


def _homecine_cards(page):
    found = {}
    blocks = re.split(r'(?=<div\b[^>]*\bdata-movie-id=["\']\d+)', page, flags=re.I)
    for block in blocks:
        match = re.search(r'<a\b[^>]*href=["\'](https?://[^"\']+)["\'][^>]*\boldtitle=["\']([^"\']+)',
                          block, re.I)
        if not match:
            continue
        url = html.unescape(match.group(1))
        parsed = urlsplit(url)
        if parsed.hostname not in ('homecine.to', 'www.homecine.to', 'www3.homecine.to'):
            continue
        if parsed.path.startswith(('/episode/', '/search/', '/genre/', '/release-year/')):
            continue
        title = _text(match.group(2))
        if not title:
            continue
        image = re.search(r'<img\b[^>]*(?:data-original|data-src|src)=["\']([^"\']+)', block, re.I)
        year = re.search(r'/release-year/((?:19|20)\d{2})', block)
        is_series = parsed.path.startswith('/series/')
        found[url] = {'title': title, 'url': url,
                      'cover': html.unescape(image.group(1)) if image else '',
                      'year': year.group(1) if year else '', 'source': 'HomeCine',
                      'is_serie': is_series,
                      'section': 'series' if is_series else 'peliculas'}
    return list(found.values())


def search_homecine(query):
    page = _get(HOMECINE + '/?' + urlencode({'s': query}), HOMECINE + '/')
    return _homecine_cards(page)


def _areshd_cards(page):
    found = {}
    for match in re.finditer(r'<a\b[^>]*class=["\']Posters-link["\'][^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                             page, re.I | re.S):
        url = urljoin(ARESHD, html.unescape(match.group(1)))
        path = urlsplit(url).path
        if urlsplit(url).hostname not in ('areshd.com', 'www.areshd.com') or not path.startswith(('/pelicula/', '/serie/')):
            continue
        body = match.group(2)
        image = re.search(r'<img\b[^>]*\balt=["\']([^"\']+)["\'][^>]*\bsrc=["\']([^"\']+)', body, re.I)
        label = re.search(r'<div\b[^>]*class=["\']listing-content["\'][^>]*>\s*<p>(.*?)</p>', body, re.I | re.S)
        title = _text(label.group(1) if label else (image.group(1) if image else ''))
        if not title:
            continue
        cover = ''
        if image:
            image_url = html.unescape(image.group(2))
            if image_url.startswith('data:'):
                srcset = re.search(r'\bsrcSet=["\']([^"\']+)', body, re.I)
                if srcset:
                    image_url = html.unescape(srcset.group(1).split(' 1x', 1)[0])
            if image_url.startswith('/_next/image'):
                cover = parse_qs(urlsplit(image_url).query).get('url', [''])[0]
            elif image_url.startswith(('http://', 'https://')):
                cover = image_url
        found[url] = {'title': title, 'url': url, 'cover': cover, 'year': '',
                      'source': 'AresHD', 'is_serie': path.startswith('/serie/'),
                      'section': 'series' if path.startswith('/serie/') else 'peliculas'}
    return list(found.values())


def search_areshd(query):
    plain = ''.join(c for c in unicodedata.normalize('NFD', _text(query).lower())
                    if unicodedata.category(c) != 'Mn')
    slug = re.sub(r'[^a-z0-9]+', '-', plain).strip('-')
    if not slug:
        return []
    return _areshd_cards(_get(ARESHD + '/search/' + quote(slug), ARESHD + '/'))


def search(query):
    results = []
    for key, getter in (('dondever', search_dondever), ('verpel', search_verpel),
                        ('homecine', search_homecine), ('areshd', search_areshd),
                        ('pelisgo', search_pelisgo)):
        if not source_switches.enabled(key):
            continue
        try:
            results.extend(getter(query))
        except Exception as exc:
            network.log_resolver('Fuente adicional: ' + str(exc))
    import servidores
    results.extend(servidores.search(query))
    return results


def page(source, number, section='peliculas'):
    """Catálogos propios para que las fichas verificadas sean navegables."""
    if source in ('pelispanda', 'megadedeoficial'):
        import servidores
        return servidores.page(source, number, section)
    if number < 1 or source not in ('dondever', 'verpel', 'homecine', 'areshd', 'pelisgo') or not source_switches.enabled(source):
        return [], False
    if source == 'pelisgo':
        path = '/series' if section == 'series' else '/movies'
        url = PELISGO + path + (f'?page={number}' if number > 1 else '')
        page_html = _get(url, PELISGO + '/')
        total = re.search(r'\\"totalPages\\":(\d+)', page_html)
        more = number < int(total.group(1)) if total else False
        return _pelisgo_cards(page_html), more
    if source == 'areshd':
        # The site's visible /page/2 links currently return 404. Do not repeat page 1.
        if number != 1:
            return [], False
        path = '/series' if section == 'series' else '/peliculas'
        return _areshd_cards(_get(ARESHD + path, ARESHD + '/')), False
    if source == 'homecine':
        base = HOMECINE + ('/series' if section == 'series' else '/peliculas-nuevas')
        url = base if number == 1 else base + f'/page/{number}'
        page_html = _get(url, HOMECINE + '/')
        return _homecine_cards(page_html), f'/page/{number + 1}' in page_html
    if source == 'dondever':
        kind = 'tvshows' if section == 'series' else 'movies'
        base = DONDEVER + '/' + kind + '/'
        url = base if number == 1 else base + f'page/{number}/'
        page_html = _get(url, DONDEVER + '/')
        items = _cards(page_html, 'Dondever')
        return items, f'/{kind}/page/{number + 1}/' in page_html
    if section != 'peliculas':
        return [], False
    base = VERPEL + '/pelicula/'
    url = base if number == 1 else base + f'page/{number}/'
    page_html = _get(url, VERPEL + '/')
    items = _cards(page_html, 'VerPeliculasOnline')
    return items, f'/pelicula/page/{number + 1}/' in page_html


def episodes(series):
    if not source_switches.allowed(series):
        return {}
    url = series.get('url', '')
    import servidores
    if servidores.owns(url):
        return servidores.episodes(series)
    if urlsplit(url).hostname in ('pelisgo.online', 'www.pelisgo.online'):
        if not urlsplit(url).path.startswith('/series/'):
            return {}
        page_html = _get(url, PELISGO + '/')
        marker = r'\"seasons\":'
        start = page_html.find(marker)
        if start < 0:
            raise network.ServidorNoDisponible('PelisGO no publicó la lista de episodios.')
        decoded = page_html[start + len(marker):].replace(r'\"', '"').replace(r'\\', '\\')
        try:
            seasons, _ = json.JSONDecoder().raw_decode(decoded)
        except ValueError as exc:
            raise network.ServidorNoDisponible('PelisGO publicó episodios inválidos.') from exc
        grouped = {}
        for season in seasons:
            if not isinstance(season, dict) or not isinstance(season.get('episodes'), list):
                continue
            season_num = season.get('number')
            for episode in season['episodes']:
                if not isinstance(episode, dict) or not isinstance(episode.get('id'), str):
                    continue
                number = episode.get('number')
                if not isinstance(season_num, int) or not isinstance(number, int):
                    continue
                grouped.setdefault(str(season_num), []).append({
                    'title': f'T{season_num}:E{number} - {episode.get("title") or series.get("title", "Episodio")}',
                    'url': PELISGO + '/episode/' + episode['id'], 'season': str(season_num),
                    'episode': str(number), 'cover': episode.get('poster') or series.get('cover', ''),
                    'is_serie': True, 'section': 'series', 'source': 'PelisGO'})
        return grouped
    if urlsplit(url).hostname in ('areshd.com', 'www.areshd.com'):
        if not urlsplit(url).path.startswith('/serie/'):
            return {}
        slug = urlsplit(url).path.rstrip('/').rsplit('/', 1)[-1]
        page_html = _get(url, ARESHD + '/')
        found = {}
        for name, season, number in re.findall(
                r'"slug":\{"name":"([^"]+)","season":"(\d+)","episode":"(\d+)"\}',
                page_html):
            if name != slug:
                continue
            key = (int(season), int(number))
            found[key] = {'title': f'T{key[0]}:E{key[1]} - {series.get("title", "Episodio")}',
                          'url': f'{ARESHD}/episodio/{slug}-temporada-{key[0]}-episodio-{key[1]}',
                          'season': str(key[0]), 'episode': str(key[1]),
                          'cover': series.get('cover', ''), 'is_serie': True,
                          'section': 'series', 'source': 'AresHD'}
        grouped = {}
        for (season, _), entry in sorted(found.items()):
            grouped.setdefault(str(season), []).append(entry)
        return grouped
    if urlsplit(url).hostname in ('homecine.to', 'www.homecine.to', 'www3.homecine.to'):
        if not urlsplit(url).path.startswith('/series/'):
            return {}
        page_html = _get(url, HOMECINE + '/')
        found = {}
        for episode_url, season, number in re.findall(
                r'href=["\'](https?://[^"\']+/episode/[^"\']*-temporada-(\d+)-capitulo-(\d+))',
                page_html, re.I):
            if not owns(episode_url):
                continue
            key = (int(season), int(number))
            found[key] = {'title': f'T{key[0]}:E{key[1]} - {series.get("title", "Episodio")}',
                          'url': episode_url, 'season': str(key[0]), 'episode': str(key[1]),
                          'cover': series.get('cover', ''), 'is_serie': True,
                          'section': 'series', 'source': 'HomeCine'}
        grouped = {}
        for (season, _), entry in sorted(found.items()):
            grouped.setdefault(str(season), []).append(entry)
        return grouped
    if urlsplit(url).hostname not in ('dondever.net', 'www.dondever.net') or '/tvshows/' not in url:
        return {}
    page = _get(url, DONDEVER + '/')
    found = {}
    for episode_url, season, number in re.findall(
            r'href=["\'](https://dondever\.net/episodes/[^"\']+?-(\d+)x(\d+)/)["\']', page, re.I):
        key = (int(season), int(number))
        found[key] = {'title': f'T{season}:E{number} - {series.get("title", "Episodio")}',
                      'url': episode_url, 'season': str(int(season)), 'episode': str(int(number)),
                      'cover': series.get('cover', ''), 'is_serie': True, 'section': 'series',
                      'source': 'Dondever'}
    result = {}
    for (season, _), item in sorted(found.items()):
        result.setdefault(str(season), []).append(item)
    return result


def servers(item):
    if not source_switches.allowed(item):
        return []
    url = item.get('url', '')
    import servidores
    if servidores.owns(url):
        return servidores.servers(item)
    host = urlsplit(url).hostname or ''
    if host in ('pelisgo.online', 'www.pelisgo.online'):
        path = urlsplit(url).path
        episode = path.startswith('/episode/')
        if not episode and not path.startswith('/movies/'):
            raise network.ServidorNoDisponible('PelisGO: ficha inválida.')
        content_id = path.rsplit('/', 1)[-1] if episode else _pelisgo_id(_get(url, PELISGO + '/'))
        result = []
        for link in _pelisgo_links(content_id, url, episode=episode):
            link_id = link.get('id')
            target = link.get('url')
            if not isinstance(link_id, str) or not isinstance(target, str) or \
                    urlsplit(target).scheme not in ('http', 'https') or not urlsplit(target).hostname:
                continue
            language = link.get('language') or 'Sin indicar'
            name = link.get('server') or link.get('name') or urlsplit(target).hostname
            token = urlencode({'id': content_id, 'link': link_id,
                               'referer': url, 'episode': '1' if episode else '0'})
            result.append({'nombre': f'{name} [PelisGO] | Audio: {language}',
                           'url': 'vaquexsrc://pelisgo?' + token, 'calidad': 'Sin verificar',
                           'idioma': language, 'source': 'pelisgo'})
        if not result:
            raise network.ServidorNoDisponible('PelisGO no publicó servidores reproducibles.')
        return result
    if host in ('areshd.com', 'www.areshd.com'):
        if not urlsplit(url).path.startswith(('/pelicula/', '/episodio/')):
            raise network.ServidorNoDisponible('AresHD: ficha inválida.')
        page_html = _get(url, ARESHD + '/')
        languages = [_text(value) for value in re.findall(
            r'<li\b[^>]*class=["\']pres["\'][^>]*>\s*<a\b[^>]*class=["\']playr["\'][^>]*>(.*?)</a>',
            page_html, re.I | re.S)]
        blocks = re.findall(r'<ul\b[^>]*class=["\']TbVideoNv nav nav-tabs hide["\'][^>]*>(.*?)</ul>',
                            page_html, re.I | re.S)
        result = []
        for index, block in enumerate(blocks):
            language = languages[index] if index < len(languages) else 'Audio sin indicar'
            for player, label in re.findall(
                    r'<li\b[^>]*class=["\']pres["\'][^>]*data-tr=["\']([^"\']+)["\'][^>]*>\s*'
                    r'<a\b[^>]*class=["\']playr["\'][^>]*>(.*?)</a>', block, re.I | re.S):
                player = html.unescape(player)
                if urlsplit(player).hostname != 'player.areshd.com':
                    continue
                token = urlencode({'player': player, 'referer': url})
                result.append({'nombre': f'{_text(label)} [AresHD] | Audio: {language}',
                               'url': 'vaquexsrc://areshd?' + token,
                               'calidad': 'Sin verificar', 'idioma': language,
                               'source': 'areshd'})
        if not result:
            raise network.ServidorNoDisponible('AresHD no publicó servidores para esta ficha.')
        return result
    if host in ('homecine.to', 'www.homecine.to', 'www3.homecine.to'):
        if not (urlsplit(url).path.startswith(('/series/', '/episode/')) or
                urlsplit(url).path.count('/') == 1):
            raise network.ServidorNoDisponible('HomeCine: ficha inválida.')
        page_html = _get(url, HOMECINE + '/')
        labels = {key: _text(label) for key, label in re.findall(
            r'href=["\']#tab(\d+)["\'][^>]*>(.*?)</a>', page_html, re.I | re.S)}
        sections = list(re.finditer(r'<div\b[^>]*\bid=["\']tab(\d+)["\'][^>]*>', page_html, re.I))
        result = []
        for index, section in enumerate(sections):
            end = sections[index + 1].start() if index + 1 < len(sections) else len(page_html)
            fragment = page_html[section.end():end]
            iframe = re.search(r'<iframe\b[^>]*\bsrc=["\']([^"\']+)', fragment, re.I)
            if not iframe:
                continue
            target = html.unescape(urljoin(url, iframe.group(1)))
            if urlsplit(target).scheme not in ('http', 'https') or not urlsplit(target).hostname:
                continue
            if 'youtube' in (urlsplit(target).hostname or ''):
                continue
            label = labels.get(section.group(1), 'Audio sin indicar')
            result.append({'nombre': f'{urlsplit(target).hostname} [HomeCine] | Audio: {label}',
                           'url': target, 'calidad': 'Sin verificar', 'idioma': label,
                           'source': 'homecine'})
        if not result:
            raise network.ServidorNoDisponible('HomeCine no publicó servidores para esta ficha.')
        return result
    referer = DONDEVER + '/' if 'dondever' in host else VERPEL + '/'
    if 'dondever' in host and '/episodes/' in url:
        match_series = re.search(r'/episodes/(.+?)-\d+x\d+/', url)
        if match_series:
            referer = DONDEVER + '/tvshows/' + match_series.group(1) + '/'
    page = _get(url, referer)
    if 'dondever.net' in host:
        match = re.search(r'<script\b[^>]*data-nt-sources[^>]*>(.*?)</script>', page, re.I | re.S)
        if not match:
            raise network.ServidorNoDisponible('Dondever no publicó opciones para esta ficha.')
        try:
            data = json.loads(html.unescape(match.group(1)))
        except ValueError as exc:
            raise network.ServidorNoDisponible('Dondever publicó opciones inválidas.') from exc
        post = data.get('post')
        if not isinstance(post, int) or post <= 0:
            raise network.ServidorNoDisponible('Dondever no publicó un ID de reproductor válido.')
        result = []
        for group in data.get('groups', []):
            if not isinstance(group, dict):
                continue
            language = group.get('label') or group.get('code') or ''
            for option in group.get('servers', []):
                if not isinstance(option, dict) or not isinstance(option.get('index'), int):
                    continue
                name = option.get('name') or 'Servidor'
                token = urlencode({'post': post, 'index': option['index'], 'referer': url})
                result.append({'nombre': f'{name} [Dondever] | Audio: {language}',
                               'url': 'vaquexsrc://dondever?' + token, 'calidad': 'Sin verificar',
                               'idioma': language})
        return result
    if 'ver-peliculas-online.net' in host:
        result = []
        for tag, body in re.findall(r'(<li\b[^>]*\bdooplay_player_option\b[^>]*>)(.*?)</li>', page, re.I | re.S):
            post = re.search(r'\bdata-post=["\'](\d+)', tag)
            nume = re.search(r'\bdata-nume=["\'](\d+)', tag)
            kind = re.search(r'\bdata-type=["\']([a-z]+)', tag)
            if not (post and nume and kind):
                continue
            label = _text((re.search(r'<span\b[^>]*class=["\']title["\'][^>]*>(.*?)</span>', body, re.I | re.S) or [None, ''])[1])
            host_label = _text((re.search(r'<span\b[^>]*class=["\']server["\'][^>]*>(.*?)</span>', body, re.I | re.S) or [None, ''])[1])
            token = urlencode({'post': post.group(1), 'nume': nume.group(1),
                               'type': kind.group(1), 'referer': url})
            result.append({'nombre': f'{host_label or "Servidor"} [Ver Películas Online] | Audio: {label or "Sin indicar"}',
                           'url': 'vaquexsrc://verpel?' + token, 'calidad': 'Sin verificar',
                           'idioma': label})
        return result
    return []


def resolve(url):
    parsed = urlsplit(url)
    if parsed.netloc == 'megadedeoficial':
        import resolvers
        return resolvers.resolver_megadedeoficial(url)
    params = parse_qs(parsed.query)
    referer = params.get('referer', [''])[0]
    if parsed.netloc == 'pelisgo':
        content_id = params.get('id', [''])[0]
        link_id = params.get('link', [''])[0]
        episode = params.get('episode', ['0'])[0] == '1'
        expected = '/episode/' if episode else '/movies/'
        if urlsplit(referer).hostname not in ('pelisgo.online', 'www.pelisgo.online') or \
                not urlsplit(referer).path.startswith(expected) or \
                not re.fullmatch(r'[a-z0-9]+', content_id) or not re.fullmatch(r'[a-z0-9]+', link_id):
            raise network.ServidorNoDisponible('PelisGO: servidor inválido.')
        links = _pelisgo_links(content_id, referer, episode=episode)
        match = next((link for link in links if link.get('id') == link_id), None)
        target = match.get('url') if match else None
        error = 'PelisGO ya no entregó el enlace de este servidor.'
    elif parsed.netloc == 'areshd':
        player = params.get('player', [''])[0]
        if urlsplit(referer).hostname not in ('areshd.com', 'www.areshd.com') or \
                urlsplit(player).hostname != 'player.areshd.com':
            raise network.ServidorNoDisponible('AresHD: reproductor inválido.')
        page = _get(player, referer)
        match = re.search(r'var\s+url\s*=\s*["\']([^"\']+)', page, re.I)
        target = html.unescape(match.group(1)) if match else None
        error = 'AresHD no entregó el enlace de este servidor.'
    elif parsed.netloc == 'dondever':
        if urlsplit(referer).hostname not in ('dondever.net', 'www.dondever.net'):
            raise network.ServidorNoDisponible('Dondever: ficha de origen inválida.')
        post = params.get('post', [''])[0]
        index = params.get('index', [''])[0]
        if not post.isdigit() or not index.isdigit():
            raise network.ServidorNoDisponible('Dondever: servidor inválido.')
        api = DONDEVER + '/wp-json/nt/v1/marco?' + urlencode({'post': post, 'index': index})
        data = json.loads(_get(api, referer, api=True))
        target = data.get('iframe') if data.get('ok') else None
        error = 'Dondever no entregó el iframe de este servidor.'
    elif parsed.netloc == 'verpel':
        if urlsplit(referer).hostname not in ('ver-peliculas-online.net', 'www.ver-peliculas-online.net'):
            raise network.ServidorNoDisponible('Ver Películas Online: ficha de origen inválida.')
        post, nume, kind = (params.get(key, [''])[0] for key in ('post', 'nume', 'type'))
        if not post.isdigit() or not nume.isdigit() or kind not in ('movie', 'tv'):
            raise network.ServidorNoDisponible('Ver Películas Online: servidor inválido.')
        payload = urlencode({'action': 'doo_player_ajax', 'post': post,
                             'nume': nume, 'type': kind}).encode()
        headers = _headers(referer, api=True)
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        page, _ = network.fetch_html(VERPEL + '/wp-admin/admin-ajax.php', referer=referer,
                                     timeout=10, data=payload, headers_dict=headers)
        if not page:
            raise network.ServidorNoDisponible('Ver Películas Online: la API no respondió.')
        data = json.loads(page)
        target = data.get('embed_url')
        error = 'Ver Películas Online no entregó el iframe de este servidor.'
    else:
        raise network.ServidorNoDisponible('Fuente adicional desconocida.')
    if not isinstance(target, str) or urlsplit(target).scheme not in ('https', 'http') or not urlsplit(target).hostname:
        raise network.ServidorNoDisponible(error)
    return target
