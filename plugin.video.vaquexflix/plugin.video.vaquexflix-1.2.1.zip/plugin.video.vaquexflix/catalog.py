"""Catalogo visible unico; las rutas originales se conservan como alternativas."""
import network
import re
import time
import threading
import unicodedata
from difflib import SequenceMatcher
from concurrent.futures import ThreadPoolExecutor, wait
from urllib.parse import urlsplit, parse_qs
import servidores as s
import doramas
import servidores as cinecalidad
from provider_cache import SearchResults
import source_switches


def title(value):
    value = re.sub(r'\s*-?\s*(?:todas?\s+las?\s+)?temporadas?\b.*$', '', value, flags=re.I)
    return re.sub(r'\s*\(\d{4}(?:\s*-\s*\d{4})?\)\s*$', '', value).strip()

def display_title(item, label=None):
    text = label if label is not None else item.get('title', '')
    if item.get('source') == 'nova' and text == item.get('title') and not item.get('episode'):
        year = str(item.get('franchise_year') or item.get('year') or '')[:4]
        if year.isdigit() and year not in text:
            text += ' ({})'.format(year)
        if (item.get('anime_season') or 1) > 1:
            text += ' [Temporada {}]'.format(item['anime_season'])
    import servidores as tubi
    if not tubi.tubi_is_available():
        return re.sub(r'\s*\[US VPN\]\s*', '', text).strip()
    if '[US VPN]' not in text and any(v.get('source') == 'tubi' or tubi.tubi_owns(v.get('url', '')) for v in variants(item)):
        return f"{text} [US VPN]"
    return text


def same(a, b):
    if doramas.is_dorama(a) != doramas.is_dorama(b):
        return False
    return same_title(a, b)


def same_title(a, b):
    if bool(a.get('is_serie')) != bool(b.get('is_serie')):
        return False
    if a.get('source') == b.get('source') == 'nova' and a.get('url') != b.get('url'):
        return False
    if a.get('tmdb_id') and b.get('tmdb_id'):
        return str(a['tmdb_id']) == str(b['tmdb_id'])
    ya, yb = str(a.get('year') or '')[:4], str(b.get('year') or '')[:4]
    if ya.isdigit() and yb.isdigit() and ya != yb:
        return False
    return s.titulo_coincide(title(a.get('title', '')), title(b.get('title', '')))


def _unique_tmdb_match(candidates, source):
    """Match the same TMDb poster, or a unique exact title/year."""
    import catalog_index
    poster = urlsplit(source.get('cover') or '').path.rsplit('/', 1)[-1]
    source_year = str(source.get('year') or '')[:4]
    if poster:
        poster_matches = [item for item in candidates
            if urlsplit(item.get('cover') or '').path.rsplit('/', 1)[-1] == poster
            and (not source_year.isdigit() or not str(item.get('year') or '')[:4].isdigit()
                 or abs(int(str(item['year'])[:4]) - int(source_year)) <= 1)
            and bool(item.get('is_serie')) == bool(source.get('is_serie'))]
        if len(poster_matches) == 1:
            return poster_matches[0]
    matched = [item for item in candidates if same_title(item, source)]
    exact_title = [item for item in matched if catalog_index.normalize(
        title(item.get('title', ''))) == catalog_index.normalize(title(source.get('title', '')))]
    if exact_title:
        matched = exact_title
    if source_year.isdigit():
        exact_year = [item for item in matched if str(item.get('year') or '')[:4] == source_year]
        if exact_year:
            matched = exact_year
    return matched[0] if len(matched) == 1 else None


def _sololatino_tmdb_candidates(source):
    """Search both the mixed and typed TMDb indexes for a blocked source."""
    import lolplus
    candidates = list(lolplus.lolplus_catalog_search(title(source.get('title', '')), section='all'))
    if _unique_tmdb_match(candidates, source) or not source.get('cover'):
        return candidates
    kind = 'tv' if source.get('is_serie') else 'movie'
    try:
        tmdb = lolplus.LolPlusCatalog()
        query = title(source.get('title', ''))
        year = str(source.get('year') or '')[:4]
        searches = ([{'query': query, ('first_air_date_year' if kind == 'tv' else 'year'): year}]
                    if year.isdigit() else []) + [{'query': query}]
        seen = {item.get('tmdb_id') for item in candidates}
        for params in searches:
            data = tmdb._query('/search/' + kind, params)
            for item in data.get('results', []):
                tmdb_id = item.get('id')
                if not tmdb_id or tmdb_id in seen:
                    continue
                seen.add(tmdb_id)
                poster = item.get('poster_path') or ''
                candidates.append({
                    'title': item.get('name') or item.get('title') or '',
                    'year': (item.get('first_air_date') or item.get('release_date') or '')[:4],
                    'is_serie': kind == 'tv', 'tmdb_id': tmdb_id,
                    'cover': 'https://image.tmdb.org/t/p/w500' + poster if poster else ''})
            if _unique_tmdb_match(candidates, source):
                break
    except Exception as exc:
        network.log_resolver('SoloLatino: busqueda TMDb por tipo no disponible ({})'.format(type(exc).__name__))
    return candidates


def _sololatino_alt_poster_match(candidates, source):
    """Accept only one matching TMDb alternate poster of the same type/year."""
    import lolplus
    poster = urlsplit(source.get('cover') or '').path.rsplit('/', 1)[-1]
    year = str(source.get('year') or '')[:4]
    if not poster or not year.isdigit():
        return None
    eligible = [item for item in candidates if item.get('tmdb_id')
                and bool(item.get('is_serie')) == bool(source.get('is_serie'))
                and str(item.get('year') or '')[:4].isdigit()
                and abs(int(str(item['year'])[:4]) - int(year)) <= 1]
    if len(eligible) > 8:
        return None
    tmdb = lolplus.LolPlusCatalog()
    kind = 'tv' if source.get('is_serie') else 'movie'
    matches = []
    for item in eligible:
        try:
            images = tmdb._query('/{}/{}/images'.format(kind, item['tmdb_id']),
                                 {'include_image_language': 'null,en,es'})
            if any(urlsplit(image.get('file_path') or '').path.rsplit('/', 1)[-1] == poster
                   for image in images.get('posters', [])):
                matches.append(item)
        except Exception:
            continue
    return matches[0] if len(matches) == 1 else None


def _sololatino_tmdb_match(candidates, source):
    return (_unique_tmdb_match(candidates, source)
            or _sololatino_alt_poster_match(candidates, source))


def _sololatino_series_identity(candidates, source):
    """Return a TV identity, plus a verified poster-matched IMDb alias if needed."""
    import catalog_index
    import lolplus
    match = _sololatino_tmdb_match(candidates, source)
    if match:
        return match, None
    name = catalog_index.normalize(title(source.get('title', '')))
    year = str(source.get('year') or '')[:4]
    poster = urlsplit(source.get('cover') or '').path.rsplit('/', 1)[-1]
    if not name or not year.isdigit() or not poster:
        return None, None
    tv = [item for item in candidates if item.get('is_serie')
          and catalog_index.normalize(title(item.get('title', ''))) == name
          and str(item.get('year') or '')[:4].isdigit()
          and abs(int(item['year'][:4]) - int(year)) <= 1]
    movies = [item for item in candidates if not item.get('is_serie')
              and catalog_index.normalize(title(item.get('title', ''))) == name
              and str(item.get('year') or '')[:4] == year
              and urlsplit(item.get('cover') or '').path.rsplit('/', 1)[-1] == poster]
    if len(tv) != 1 or len(movies) != 1:
        return None, None
    try:
        details = lolplus.LolPlusCatalog().get_movie_details(movies[0]['tmdb_id'])
        imdb_id = details.get('external_ids', {}).get('imdb_id') or details.get('imdb_id')
        if re.fullmatch(r'tt\d{7,10}', imdb_id or ''):
            return tv[0], imdb_id
    except Exception:
        pass
    return None, None


def variants(item):
    return item.get('variants') or [{k: v for k, v in item.items() if k not in ('variants', 'history_keys')}]


def active_item(item):
    """Usa la primera variante activa sin alterar el objeto guardado."""
    active = [v for v in variants(item) if source_switches.allowed(v)]
    if not active:
        return None
    if source_switches.allowed(item):
        return dict(item, variants=active)
    projected = dict(item)
    projected.update(active[0])
    projected['variants'] = active
    return projected


def merge(items):
    result = []
    for original in items:
        if not original.get('url'):
            continue
        matches = [x for x in result if x['url'] == original['url'] or same(x, original)]
        if len(matches) == 1:
            item = matches[0]
            seen = {v['url'] for v in item['variants']}
            item['variants'].extend(v for v in variants(original) if v['url'] not in seen)
            for field in ('cover', 'plot', 'year', 'rating', 'tmdb_id', 'mpaa', 'duration'):
                if not item.get(field) and original.get(field):
                    item[field] = original[field]
        else:
            item = dict(original, title=title(original['title']), variants=list(variants(original)))
            result.append(item)
    return result


def parallel(calls, partial=False):
    deadline = getattr(network._sondeo, 'deadline', None)
    cancel = getattr(network._sondeo, 'cancel', None)
    max_request = getattr(network._sondeo, 'max_request', 6)
    def safe(call):
        try:
            with network.presupuesto_sondeo(deadline, cancel, max_request):
                network.tiempo_peticion(15)
                return call()
        except Exception as exc:
            network.log_resolver('Consulta de catalogo no disponible ({})'.format(type(exc).__name__))
            return None
    if partial and deadline is not None:
        pool = ThreadPoolExecutor(max_workers=4)
        try:
            futures = [pool.submit(safe, call) for call in calls]
            done, pending = wait(futures, timeout=max(0, deadline - time.monotonic() - 1))
            for future in pending:
                future.cancel()
            return [future.result() for future in futures if future in done]
        finally:
            pool.shutdown(wait=False)
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(safe, calls))


def is_anime(item):
    if not item:
        return False
    if item.get('section') in ('animes', 'anime'):
        return True
    url = item.get('url', '').lower()
    if any(x in url for x in ('/anime/', 'animeflv', 'anime')):
        return True
    genres = [g.lower() if isinstance(g, str) else '' for g in item.get('genres', [])]
    if 'anime' in genres:
        return True
    if item.get('original_language') == 'ja' and any(g in genres for g in ('animacion', 'animación', 'animation')):
        return True
    return False


def in_section(items, section='all'):
    # Remove retired provider variants and explicitly excluded titles.
    import lolplus
    cleaned = []
    for item in items:
        if lolplus.catalog_item_excluded(item):
            continue
        item_variants = variants(item)
        if any(lolplus.catalog_item_excluded(v) for v in item_variants):
            continue
        kept = [v for v in item_variants if source_switches.allowed(v) and not s.es_url_fuegocine(v.get('url', ''))
                and 'gnula' not in (urlsplit(v.get('url', '')).hostname or '')]
        if kept:
            current = dict(item)
            if not source_switches.allowed(current) or s.es_url_fuegocine(current.get('url', '')):
                current.update(kept[0])
            if 'variants' in item:
                current['variants'] = kept
            cleaned.append(current)
    items = cleaned
    import servidores as tubi
    if not tubi.tubi_is_available():
        cleaned = []
        for i in items:
            v_list = variants(i)
            non_tubi = [v for v in v_list if v.get('source') != 'tubi' and not tubi.tubi_owns(v.get('url', ''))]
            if not non_tubi:
                continue
            if i.get('source') == 'tubi' or tubi.tubi_owns(i.get('url', '')):
                new_item = dict(non_tubi[0])
                new_item['variants'] = non_tubi
                for k in ('cover', 'plot', 'year', 'rating', 'tmdb_id'):
                    if not new_item.get(k) and i.get(k):
                        new_item[k] = i[k]
                cleaned.append(new_item)
            else:
                new_item = dict(i)
                new_item['variants'] = non_tubi
                cleaned.append(new_item)
        items = cleaned
    if section == 'all':
        return items
    if section == 'doramas':
        return [i for i in items if doramas.is_dorama(i)]
    if section == 'animes':
        return [i for i in items if is_anime(i)]
    return [i for i in items if not doramas.is_dorama(i) and not is_anime(i) and bool(i.get('is_serie')) == (section == 'series')]


CINECALIDAD_GENRE_MAP = {
    'accion': 'accion',
    'animacion': 'animacion',
    'anime': 'animacion',
    'aventura': 'aventura',
    'ciencia-ficcion': 'ciencia-ficcion',
    'comedia': 'comedia',
    'crimen': 'crimen',
    'drama': 'drama',
    'familia': 'familiar',
    'familiar': 'familiar',
    'fantasia': 'fantasia',
    'misterio': 'misterio',
    'romance': 'romance',
    'suspense': 'suspenso',
    'suspenso': 'suspenso',
    'terror': 'terror',
}

PELISFLIX_GENRE_MAP = {
    'accion': 'accion',
    'animacion': 'animacion',
    'anime': 'animacion',
    'aventura': 'aventura',
    'ciencia-ficcion': 'ciencia-ficcion',
    'comedia': 'comedia',
    'crimen': 'crimen',
    'documental': 'documental',
    'drama': 'drama',
    'familia': 'familia',
    'familiar': 'familia',
    'fantasia': 'fantasia',
    'romance': 'romance',
    'suspense': 'suspense',
    'suspenso': 'suspense',
    'terror': 'terror',
}

FUEGOCINE_GENRE_MAP = {
    'accion': 'Acción',
    'animacion': 'Animación',
    'anime': 'Animación',
    'aventura': 'Aventura',
    'belica': 'Acción',
    'ciencia-ficcion': 'Ciencia ficción',
    'comedia': 'Comedia',
    'crimen': 'Crimen',
    'drama': 'Drama',
    'familia': 'Familia',
    'familiar': 'Familia',
    'fantasia': 'Fantasía',
    'historia': 'Historia',
    'misterio': 'Misterio',
    'romance': 'Romance',
    'suspense': 'Suspenso',
    'suspenso': 'Suspenso',
    'terror': 'Terror',
}

STOPWORDS = {
    'el', 'la', 'lo', 'los', 'las', 'un', 'una', 'unos', 'unas',
    'de', 'del', 'al', 'a', 'en', 'con', 'por', 'para', 'y', 'o', 'u',
    'que', 'su', 'sus', 'se', 'the', 'an', 'in', 'on', 'at', 'of', 'and', 'or', 'to', 'for', 'is'
}


def normalize_search_text(text):
    text = ''.join(c for c in unicodedata.normalize('NFKD', str(text or '')) if not unicodedata.combining(c))
    text = re.sub(r'[^a-z0-9\s]', ' ', text.lower())
    text = re.sub(r'\bspiderman\b', 'spider man', text)
    return re.sub(r'\s+', ' ', text).strip()


def relevance_score(item, query):
    norm_q = normalize_search_text(query)
    if not norm_q:
        return 0.0
    q_words = norm_q.split()
    sig_q = [w for w in q_words if w not in STOPWORDS] or q_words

    norm_t = normalize_search_text(title(item.get('title', '')))
    if not norm_t:
        return 0.0
    t_words = norm_t.split()
    t_words_set = set(t_words)

    # 1. Exact match
    if norm_t == norm_q:
        return 1000.0

    # 2. Prefix match
    if norm_t.startswith(norm_q):
        penalty = min(100.0, len(norm_t) - len(norm_q))
        return 900.0 - penalty

    # 3. Substring match
    if norm_q in norm_t:
        penalty = min(150.0, len(norm_t) - len(norm_q))
        return 800.0 - penalty

    matched_sig = [w for w in sig_q if w in t_words_set]
    matched_all = [w for w in q_words if w in t_words_set]
    sig_ratio = len(matched_sig) / len(sig_q) if sig_q else 0.0
    all_ratio = len(matched_all) / len(q_words) if q_words else 0.0

    if not matched_sig:
        norm_plot = normalize_search_text(item.get('plot', ''))
        if norm_q in norm_plot or (sig_q and all(w in norm_plot for w in sig_q)):
            return 20.0
        return 0.0

    if sig_ratio == 1.0:
        indices = [t_words.index(w) for w in matched_sig]
        order_bonus = 50.0 if indices == sorted(indices) else 0.0
        seq_ratio = SequenceMatcher(None, norm_q, norm_t).ratio() * 100.0
        return 500.0 + order_bonus + (all_ratio * 100.0) + seq_ratio

    seq_ratio = SequenceMatcher(None, norm_q, norm_t).ratio() * 100.0
    return (sig_ratio * 300.0) + (all_ratio * 50.0) + seq_ratio


def sort_by_relevance(items, query):
    if not query or not items:
        return list(items)
    scored = [(relevance_score(it, query), it) for it in items]
    has_positive = any(score > 0 for score, _ in scored)
    if has_positive:
        scored = [pair for pair in scored if pair[0] > 0]
    only_arg = source_switches.only_enabled('argflix')
    scored.sort(
        key=lambda pair: (pair[0], 0 if (not only_arg and pair[1].get('source') == 'argflix') else 1),
        reverse=True,
    )
    return [it for _, it in scored]


def search(query, experimental=False, section='all'):
    import lolplus
    import additional_sources
    import argflix
    import frikiserie
    import archive_sources
    if source_switches.only_enabled('nova') and section in ('all', 'peliculas', 'series', 'animes', 'anime'):
        import nova_sources
        return SearchResults(sort_by_relevance(
            merge(in_section(nova_sources.search(query, section=section), section)), query))
    if source_switches.only_enabled('argflix') and section in ('all', 'peliculas', 'series'):
        return SearchResults(sort_by_relevance(
            merge(in_section(argflix.search(query, section=section), section)), query))
    if source_switches.disabled() and section not in ('animes', 'anime', 'doramas'):
        import internal_catalogs
        calls = []
        if source_switches.enabled('sololatino'):
            calls.append(s.sololatino_buscar)
        if experimental:
            if source_switches.enabled('nova'):
                import nova_sources
                calls.append(lambda q: nova_sources.search(q, section=section))
            if source_switches.enabled('lacartoons') and section in ('series', 'all'):
                calls.append(lolplus.lacartoons_search)
            if source_switches.enabled('seriesturcas') and section in ('series', 'all'):
                calls.append(lolplus.seriesturcas_search)
            for key in internal_catalogs._ROUTES:
                if source_switches.enabled(key):
                    calls.append(lambda query, key=key: internal_catalogs.search(key, query))
            for key, fn in (
                ('hackstore', s.hackstore_search), ('pelisjuanita', s.pelisjuanita_search),
                ('pelisflix', s.pelisflix_search), ('cinecalidad', s.cinecalidad_search),
                ('tubi', s.tubi_search)):
                if source_switches.enabled(key) and (key != 'cinecalidad' or section != 'series'):
                    if key == 'tubi' and not s.tubi_is_available():
                        continue
                    calls.append(fn)
            calls.append(additional_sources.search)
            if source_switches.enabled('frikiserie') and section in ('all', 'series', 'peliculas'):
                calls.append(frikiserie.search)
            if source_switches.enabled('archiveorg') and section in ('all', 'series'):
                calls.append(lambda q: archive_sources.search(q, section=section))
            if section == 'all':
                calls.extend((doramas.search, lambda q: __import__('anime').search(q)))
        if source_switches.enabled('argflix') and section in ('all', 'series', 'peliculas'):
            calls.append(lambda q: argflix.search(q, section=section))
        batches = parallel([lambda fn=fn: fn(query) for fn in calls]) if calls else []
        items = [item for batch in batches if batch for item in batch]
        if not items and source_switches.enabled('tioplus') and not any(
                source_switches.enabled(key) for key in ('sololatino', 'hackstore', 'pelisjuanita',
                    'pelisflix', 'cinecalidad', 'tubi', 'dondever', 'verpel', 'lacartoons',
                    'seriesturcas', 'argflix', *internal_catalogs._ROUTES)):
            return SearchResults([], ['TioPlus no publicó un catálogo accesible en esta sesión.'])
        return SearchResults(sort_by_relevance(merge(in_section(items, section)), query),
                             ['Fuente no disponible' for batch in batches if batch is None])
    if section in ('animes', 'anime'):
        import anime
        return SearchResults(anime.search(query))
    if experimental and section == 'doramas':
        results = doramas.search(query)
        return SearchResults(sort_by_relevance(merge(in_section(results, 'doramas')), query),
                             getattr(results, 'errors', []))
    if experimental and section == 'all':
        import anime
        batches = parallel([lambda: lolplus.lolplus_catalog_search(query, section=section),
                            lambda: doramas.search(query),
                            lambda: anime.search(query),
                            lambda: additional_sources.search(query),
                            lambda: frikiserie.search(query) if source_switches.enabled('frikiserie') else [],
                            lambda: archive_sources.search(query, section=section) if source_switches.enabled('archiveorg') else [],
                            lambda: argflix.search(query, section=section) if source_switches.enabled('argflix') else []])
        items = [item for batch in batches if batch for item in batch]
        errors = [name for batch in batches for name in getattr(batch, 'errors', [])]
        errors.extend(name for name, batch in zip(('TMDb', 'Doramas', 'Anime', 'Fuentes adicionales'), batches) if batch is None)
        return SearchResults(sort_by_relevance(merge(in_section(items)), query), errors)
    if experimental and section in ('peliculas', 'series'):
        batches = parallel([lambda: lolplus.lolplus_catalog_search(query, section=section),
                            lambda: additional_sources.search(query),
                            lambda: frikiserie.search(query) if source_switches.enabled('frikiserie') else [],
                            lambda: archive_sources.search(query, section=section) if source_switches.enabled('archiveorg') and section in ('all', 'series') else [],
                            lambda: argflix.search(query, section=section) if source_switches.enabled('argflix') else []])
        items = [item for batch in batches if batch for item in batch]
        return SearchResults(sort_by_relevance(merge(in_section(items, section)), query),
                             ['Fuentes adicionales' for batch in batches[1:] if batch is None])
    archive_call = [lambda: archive_sources.search(query, section=section)] if source_switches.enabled('archiveorg') and section in ('all', 'series') else []
    frikiserie_call = [lambda: frikiserie.search(query)] if source_switches.enabled('frikiserie') and section in ('all', 'series', 'peliculas') else []
    argflix_call = [lambda: argflix.search(query, section=section)] if source_switches.enabled('argflix') and section in ('all', 'series', 'peliculas') else []
    if archive_call or frikiserie_call or argflix_call:
        batches = parallel([lambda: lolplus.lolplus_catalog_search(query, section=section)] + archive_call + frikiserie_call + argflix_call)
        return SearchResults(sort_by_relevance(merge(in_section(
            [entry for batch in batches if batch for entry in batch], section)), query))
    return SearchResults(lolplus.lolplus_catalog_search(query, section=section))


_SOLO_CATEGORY_LOCK = threading.Lock()
_SOLO_CATEGORY_CACHE = {}
_SOLO_CATEGORY_SIZE = 12
SOLOLATINO_EMPTY_MENU_GENRES = frozenset(('talk', 'tmdb-10763'))


def _sololatino_category_page(section, genre, number, preview=False):
    """Browse TMDb categories intersected with the published SoloLatino index."""
    import catalog_index
    import lolplus
    revision = catalog_index.revision()
    if revision == 'pending':
        raise network.ServidorNoDisponible('SoloLatino no tiene un catalogo guardado para filtrar categorias.')
    key = (revision, section, genre)
    with _SOLO_CATEGORY_LOCK:
        state = _SOLO_CATEGORY_CACHE.get(key)
        if state is None or time.monotonic() - state['created'] > 21600:
            state = {'created': time.monotonic(), 'lock': threading.Lock(),
                     'items': [], 'seen': set(), 'next_page': 1, 'more': True,
                     'page_ends': {0: 0}}
            _SOLO_CATEGORY_CACHE[key] = state
            if len(_SOLO_CATEGORY_CACHE) > 64:
                oldest = next(iter(_SOLO_CATEGORY_CACHE))
                if oldest != key:
                    _SOLO_CATEGORY_CACHE.pop(oldest, None)
    limit = 3 if preview else 20
    with state['lock']:
        start = state['page_ends'].get(number - 1, (number - 1) * _SOLO_CATEGORY_SIZE)
        target = 1 if preview else start + _SOLO_CATEGORY_SIZE + 1
        scanned = 0
        while len(state['items']) < target and state['more'] and scanned < limit:
            tmdb_items, more = lolplus.lolplus_catalog_page(
                section, state['next_page'], genre=genre)
            if not tmdb_items:
                state['more'] = False
                break
            for entry in catalog_index.match_tmdb_items(tmdb_items, section):
                if entry['url'] not in state['seen']:
                    state['items'].append(entry)
                    state['seen'].add(entry['url'])
            state['next_page'] += 1
            state['more'] = more
            scanned += 1
        if preview:
            return state['items'][:3], False
        result = state['items'][start:start + _SOLO_CATEGORY_SIZE]
        state['page_ends'][number] = start + len(result)
        more = bool(result) and (len(state['items']) > start + _SOLO_CATEGORY_SIZE or state['more'])
        return result, more


def page(section, number, experimental=False, primary_source=None, preview=False):
    parsed_sec = urlsplit('unified://' + section)
    base_section = parsed_sec.netloc or section.split('?', 1)[0]
    genre = parse_qs(parsed_sec.query).get('genre', [None])[0]

    if source_switches.only_enabled('frikiserie') and base_section in ('series', 'peliculas'):
        import frikiserie
        return frikiserie.page(base_section, number)

    if source_switches.only_enabled('archiveorg') and base_section == 'series':
        import archive_sources
        return archive_sources.page(base_section, number, genre=genre)

    if source_switches.only_enabled('argflix') and base_section in ('series', 'peliculas'):
        import argflix
        return argflix.page(base_section, number, genre=genre)

    if base_section in ('animes', 'anime'):
        if source_switches.only_enabled('nova'):
            import nova_sources
            items, more = nova_sources.page('animes', number, genre=genre, preview=preview)
            return merge(in_section(items, 'animes')), more
        import anime
        items, more = anime.page(number, genre)
        return merge(in_section(items, 'animes')), more

    if base_section == 'doramas':
        if not experimental:
            return [], False
        items, more = doramas.page(number, genre)
        return merge(in_section(items, 'doramas')), more

    if experimental and genre in ('fuente-dondever', 'fuente-verpel', 'fuente-homecine',
                                  'fuente-areshd', 'fuente-pelisgo', 'fuente-pelispanda',
                                  'fuente-megadedeoficial'):
        import additional_sources
        provider = {'fuente-dondever': 'dondever', 'fuente-verpel': 'verpel',
                    'fuente-homecine': 'homecine', 'fuente-areshd': 'areshd',
                    'fuente-pelisgo': 'pelisgo', 'fuente-pelispanda': 'pelispanda',
                    'fuente-megadedeoficial': 'megadedeoficial'}[genre]
        if not source_switches.enabled(provider):
            return [], False
        items, more = additional_sources.page(provider, number, base_section)
        return merge(in_section(items, base_section)), more

    is_series = base_section == 'series'

    if source_switches.only_enabled('nova') and base_section in ('peliculas', 'series'):
        import nova_sources
        items, more = nova_sources.page(base_section, number, genre=genre, preview=preview)
        return merge(in_section(items, base_section)), more

    def primary():
        if primary_source != 'cache':
            if genre:
                url_prim = f"{network.SOLOLATINO_BASE}/{base_section}?genero={genre}" + (f"&page={number}" if number > 1 else "")
            else:
                url_prim = f"{network.SOLOLATINO_BASE}/{base_section}?page={number}" if number > 1 else f"{network.SOLOLATINO_BASE}/{base_section}"
            html, _ = network.fetch_html(url_prim)
            if html:
                items = s.sololatino_parsear_tarjetas(html, base_section)
                return items, bool(items)
            if primary_source == 'live':
                raise network.ServidorNoDisponible('SoloLatino no permite cargar la siguiente pagina. Renueva la verificacion del navegador.')
        if not genre and base_section in ('peliculas', 'series', 'all'):
            import catalog_index
            cached = catalog_index.page(base_section, number)
            if cached is not None:
                return cached
            raise network.ServidorNoDisponible('SoloLatino no permite acceder a la web y no hay catalogo guardado disponible.')
        raise network.ServidorNoDisponible('SoloLatino no permite acceder a esta categoria. Es necesario restablecer el acceso al sitio.')

    if source_switches.only_enabled('sololatino') and base_section in ('peliculas', 'series'):
        import catalog_index
        if genre:
            return _sololatino_category_page(base_section, genre, number, preview=preview)
        cached = catalog_index.page(base_section, number)
        if cached is not None and primary_source != 'live':
            items, more = cached
            return merge(in_section(items, base_section)), more
        items, more = primary()
        return merge(in_section(items, base_section)), more

    if source_switches.disabled():
        import argflix
        import lolplus
        import internal_catalogs
        calls = []
        if source_switches.enabled('sololatino'):
            if genre in ('argentinas', 'cortos', 'mexicanas', 'musica'):
                calls.append(lambda: _sololatino_category_page(base_section, genre, number, preview=preview))
            else:
                calls.append(primary)
        if not genre and source_switches.enabled('frikiserie') and base_section in ('series', 'peliculas'):
            import frikiserie
            calls.append(lambda: frikiserie.page(base_section, number))
        if base_section == 'series' and source_switches.enabled('archiveorg') and (
                not genre or genre in ('musica', 'recitales', 'documental')):
            import archive_sources
            pos = 0 if genre in ('musica', 'recitales') else len(calls)
            calls.insert(pos, lambda: archive_sources.page(base_section, number, genre=genre))
        if experimental:
            if source_switches.enabled('nova') and base_section in ('peliculas', 'series'):
                import nova_sources
                calls.append(lambda: nova_sources.page(base_section, number, genre=genre, preview=preview))
            if source_switches.enabled('cinecalidad') and not is_series:
                mapped = CINECALIDAD_GENRE_MAP.get(genre) if genre else None
                if not genre or mapped:
                    calls.append(lambda mapped=mapped: cinecalidad.cinecalidad_page(number, genre=mapped))
            if source_switches.enabled('pelisflix'):
                mapped = PELISFLIX_GENRE_MAP.get(genre) if genre else None
                if not genre or mapped:
                    calls.append(lambda mapped=mapped: (s.pelisflix_catalog(base_section, number, genre=mapped), True))
            if source_switches.enabled('tubi') and s.tubi_is_available():
                calls.append(lambda: s.tubi_page(base_section, number, genre=genre))
            if not genre:
                for key, fn in (('hackstore', s.hackstore_catalog),
                                ('pelisjuanita', s.pelisjuanita_catalog)):
                    if source_switches.enabled(key):
                        kind = 'tvshow' if is_series else 'movie'
                        calls.append(lambda fn=fn, kind=kind: fn(kind, number))
                if is_series and source_switches.enabled('lacartoons'):
                    calls.append(lambda: lolplus.lacartoons_catalog_page(number))
                if is_series and source_switches.enabled('seriesturcas'):
                    calls.append(lambda: lolplus.seriesturcas_catalog_page(number))
                for key in internal_catalogs._ROUTES:
                    if source_switches.enabled(key):
                        calls.append(lambda key=key: internal_catalogs.page(key, base_section, number))
                if source_switches.enabled('dondever'):
                    import additional_sources
                    calls.append(lambda: additional_sources.page('dondever', number, base_section))
                if not is_series and source_switches.enabled('verpel'):
                    import additional_sources
                    calls.append(lambda: additional_sources.page('verpel', number, base_section))
                if source_switches.enabled('homecine'):
                    import additional_sources
                    calls.append(lambda: additional_sources.page('homecine', number, base_section))
                if source_switches.enabled('areshd'):
                    import additional_sources
                    calls.append(lambda: additional_sources.page('areshd', number, base_section))
                if source_switches.enabled('pelisgo'):
                    import additional_sources
                    calls.append(lambda: additional_sources.page('pelisgo', number, base_section))
                for provider in ('pelispanda', 'megadedeoficial'):
                    if source_switches.enabled(provider):
                        import additional_sources
                        calls.append(lambda provider=provider: additional_sources.page(provider, number, base_section))
        if genre and base_section in ('series', 'peliculas') and source_switches.enabled('argflix') and argflix.supports_genre(base_section, genre):
            calls.append(lambda: argflix.page(base_section, number, genre=genre))
        if not calls and source_switches.enabled('tioplus'):
            raise network.ServidorNoDisponible('TioPlus no publicó un catálogo accesible en esta sesión.')
        pages = [result for result in parallel(calls) if result] if calls else []
        items = [item for entries, _ in pages for item in entries]
        return merge(in_section(items, base_section)), any(more for _, more in pages)

    # Fase de pruebas exclusiva de LolPlus
    import argflix
    import frikiserie
    import lolplus
    import archive_sources
    archive_applies = (base_section == 'series' and source_switches.enabled('archiveorg') and
                       (not genre or genre in ('musica', 'recitales', 'documental')))
    frikiserie_applies = (not genre and base_section in ('series', 'peliculas') and
                          source_switches.enabled('frikiserie'))
    argflix_applies = (bool(genre) and base_section in ('series', 'peliculas') and
                       source_switches.enabled('argflix') and argflix.supports_genre(base_section, genre))
    if archive_applies or frikiserie_applies or argflix_applies:
        calls = []
        if archive_applies and genre in ('musica', 'recitales'):
            calls.append(lambda: archive_sources.page(base_section, number, genre=genre))
        calls.append(lambda: lolplus.lolplus_catalog_page(base_section, number, genre=genre))
        if archive_applies and genre not in ('musica', 'recitales'):
            calls.append(lambda: archive_sources.page(base_section, number, genre=genre))
        if frikiserie_applies:
            calls.append(lambda: frikiserie.page(base_section, number))
        if argflix_applies:
            calls.append(lambda: argflix.page(base_section, number, genre=genre))
        pages = [result for result in parallel(calls) if result]
        items = [item for entries, _ in pages for item in entries]
        more = any(has_more for _, has_more in pages)
    else:
        items, more = lolplus.lolplus_catalog_page(base_section, number, genre=genre)
    return merge(in_section(items, base_section)), more

    import servidores as tubi
    calls = [primary]

    if genre:
        # Categorías en experimental: consultar todos los servidores disponibles adaptando el género
        if not is_series:
            c_genre = CINECALIDAD_GENRE_MAP.get(genre)
            if c_genre:
                calls.append(lambda c_genre=c_genre: cinecalidad.cinecalidad_page(number, genre=c_genre))

        pf_genre = PELISFLIX_GENRE_MAP.get(genre)
        if pf_genre:
            calls.append(lambda pf_genre=pf_genre: (s.pelisflix_catalog('series' if is_series else 'peliculas', number, genre=pf_genre), True))

        if tubi.tubi_is_available():
            calls.append(lambda: tubi.tubi_page(base_section, number, genre=genre))
    else:
        # Catálogo general (TODO)
        if tubi.tubi_is_available():
            calls.append(lambda: tubi.tubi_page(base_section, number))
        if not is_series:
            calls.append(lambda: cinecalidad.cinecalidad_page(number))
        for kind in (('tvshow', 'anime') if is_series else ('movie',)):
            calls.extend([lambda kind=kind: s.hackstore_catalog(kind, number),
                          lambda kind=kind: s.pelisjuanita_catalog(kind, number)])
        calls.append(lambda: (s.pelisflix_catalog('series' if is_series else 'peliculas', number), True))

    pages = [x for x in parallel(calls) if x]
    items_list = [i for items, _ in pages for i in items if bool(i.get('is_serie')) == is_series]
    return merge(in_section(items_list, base_section)), any(more for _, more in pages)


def expand(item, premium_only=False):
    if doramas.owns(item.get('url', '')):
        matches = [c for c in doramas.search(title(item['title'])) if same(c, item)]
        return merge([item, matches[0]])[0] if len(matches) == 1 else item
    candidates = s.sololatino_buscar(title(item['title'])) if premium_only else search(title(item['title']), experimental=True, section='series' if item.get('is_serie') else 'peliculas')
    matches = [c for c in candidates if same(c, item)]
    # No adivinar entre remakes cuando faltan fechas o identificadores.
    if len(matches) == 1:
        return merge([item, matches[0]])[0]
    return item


def episodes(series, experimental=False):
    series = active_item(series)
    if series is None:
        return {}
    if source_switches.key_for(series) == 'nova':
        import nova_sources
        return nova_sources.episodes(series)
    if source_switches.key_for(series) == 'seriesturcas':
        import lolplus
        return lolplus.seriesturcas_episodes(series)
    import internal_catalogs
    if source_switches.key_for(series) in internal_catalogs._ROUTES:
        import lolplus
        title_query = title(series.get('title', ''))
        matches = [entry for entry in lolplus.lolplus_catalog_search(title_query, section='series')
                   if same_title(entry, series) and entry.get('url', '').startswith('lolplus://tv/')]
        if len(matches) != 1:
            raise network.ServidorNoDisponible('No se pudo identificar una serie única en TMDb para consultar sus episodios.')
        return lolplus.lolplus_obtener_temporadas_episodios(matches[0])
    if source_switches.key_for(series) == 'lacartoons':
        import lolplus
        matches = [entry for entry in lolplus.lolplus_catalog_search(title(series.get('title', '')), section='series')
                   if same_title(entry, series) and entry.get('url', '').startswith('lolplus://tv/')]
        if len(matches) != 1:
            raise network.ServidorNoDisponible('LaCartoons: no se pudo identificar una serie única para obtener sus episodios.')
        return lolplus.lolplus_obtener_temporadas_episodios(matches[0])
    if series.get('url', '').startswith('lolplus://'):
        import lolplus
        return lolplus.lolplus_obtener_temporadas_episodios(series)
    import anime
    if anime.is_anime_url(series.get('url', '')) or anime.is_anime(series):
        return anime.obtener_temporadas_episodios(series)
    import additional_sources
    if additional_sources.owns(series.get('url', '')):
        return additional_sources.episodes(series)
    import frikiserie
    if frikiserie.owns(series.get('url', '')):
        return frikiserie.episodes(series)
    import archive_sources
    if archive_sources.owns(series.get('url', '')):
        return archive_sources.episodes(series)
    import argflix
    if argflix.owns(series.get('url', '')):
        return argflix.episodes(series)
    roots = [v for v in variants(series) if source_switches.allowed(v) and (experimental or is_primary(v))]
    results = parallel([lambda item=item: s.obtener_episodios(item) for item in roots])
    grouped = {}
    for seasons in results:
        for season, entries in (seasons or {}).items():
            for ep in entries:
                number = str(ep.get('episode', ''))
                if not str(season).isdigit() or not number.isdigit():
                    continue
                key = (str(int(season)), str(int(number)))
                if key in grouped:
                    grouped[key]['variants'].extend(variants(ep))
                else:
                    grouped[key] = dict(ep, variants=list(variants(ep)), season=key[0], episode=key[1])
    if not grouped and source_switches.key_for(series) == 'sololatino':
        fallback = _sololatino_tmdb_episodes(series)
        if fallback:
            return fallback
        raise network.ServidorNoDisponible(
            'SoloLatino no entrego episodios y no se pudo obtener una lista alternativa verificada en TMDb.')
    if not grouped and any(r is None for r in results):
        failed = [urlsplit(v.get('url', '')).hostname or 'fuente' for v, r in zip(roots, results) if r is None]
        raise network.ServidorNoDisponible('No se pudieron cargar los episodios de: ' + ', '.join(dict.fromkeys(failed)) + '. No se pudo confirmar si hay episodios.')
    result = {}
    for (season, _), ep in sorted(grouped.items(), key=lambda pair: tuple(map(int, pair[0]))):
        result.setdefault(season, []).append(ep)
    if result and source_switches.key_for(series) == 'sololatino':
        try:
            import lolplus
            match, premium_imdb_id = _sololatino_series_identity(
                _sololatino_tmdb_candidates(series), series)
            if match:
                for episodes_list in result.values():
                    for ep in episodes_list:
                        ep.setdefault('tmdb_id', match['tmdb_id'])
                        if premium_imdb_id:
                            ep.setdefault('premium_imdb_id', premium_imdb_id)
        except Exception as exc:
            network.log_resolver('SoloLatino: ID de sinopsis no disponible ({})'.format(type(exc).__name__))
    return result


def fast_season_summaries(series):
    """Return counts only for TMDb cards; other sources retain their own episode route."""
    series = active_item(series)
    if series and source_switches.key_for(series) == 'lolplus' and \
            str(series.get('url', '')).startswith('lolplus://tv/'):
        import lolplus
        return lolplus.lolplus_temporadas_resumen(series)
    return None


def season_episodes(series, season):
    import lolplus
    return lolplus.lolplus_obtener_temporadas_episodios(series, season_number=season).get(str(season), [])


def _sololatino_tmdb_episodes(series):
    """Use an exact TMDb identity when Cloudflare blocks SoloLatino episode pages."""
    import lolplus
    try:
        match, premium_imdb_id = _sololatino_series_identity(
            _sololatino_tmdb_candidates(series), series)
        if not match:
            return {}
        tmdb_id = match['tmdb_id']
        seasons = lolplus.lolplus_obtener_temporadas_episodios(match)
        base_url = series.get('url', '').rstrip('/')
        return {season: [dict(ep, source='sololatino', tmdb_id=tmdb_id,
                    **({'premium_imdb_id': premium_imdb_id} if premium_imdb_id else {}),
                    url='{}/temporada-{}/episodio-{}'.format(
                        base_url, ep['season'], ep['episode'])) for ep in entries]
                for season, entries in seasons.items()}
    except Exception as exc:
        network.log_resolver('SoloLatino: episodios TMDb no disponibles ({})'.format(type(exc).__name__))
        return {}


def is_primary(item):
    u = item.get('url', '')
    if item.get('source') == 'lolplus' or u.startswith('lolplus://'):
        return True
    if source_switches.key_for(item) in ('frikiserie', 'archiveorg', 'argflix') or item.get('source') in ('archiveorg', 'argflix'):
        return True
    import anime
    if anime.is_anime(item) or anime.is_anime_url(u):
        return True
    host = urlsplit(u).hostname or ''
    return host in network._SOLO_HOSTS


def visible(items, experimental=False):
    """Project saved entries into the active catalog without changing user data."""
    if experimental or source_switches.only_enabled('nova'):
        return in_section(items)
    result = []
    for item in items:
        roots = [dict(v) for v in variants(item) if source_switches.allowed(v) and is_primary(v)]
        if roots:
            projected = dict(item)
            projected.update(roots[0])
            projected['variants'] = roots
            result.append(projected)
    return result


def visible_server(server):
    name = re.sub(r'(?i)\b(?:fuegocine|hackstore2?|pelisjuanita|sololatino|pelisflix)\b(?:\.[a-z]+)?', '', server.get('nombre', ''))
    return dict(server, nombre=re.sub(r'\s+', ' ', name).strip(' -') or 'Servidor')


def _sololatino_premium_tmdb(item, series=None, premium_only=False):
    """Resolve a catalog-matched SoloLatino title when its detail page is blocked."""
    import lolplus
    import resolvers
    root = series or item
    tmdb_id = root.get('tmdb_id') or item.get('tmdb_id')
    season, episode = item.get('season'), item.get('episode')
    if not tmdb_id or (series and (season is None or episode is None)):
        return []
    try:
        catalog = lolplus.LolPlusCatalog()
        details = (catalog.get_tv_details(tmdb_id) if series
                   else catalog.get_movie_details(tmdb_id))
        imdb_id = details.get('external_ids', {}).get('imdb_id') or details.get('imdb_id')
        imdb_id = item.get('premium_imdb_id') or imdb_id
        if not re.fullmatch(r'tt\d{7,10}', imdb_id or ''):
            return []
        media_id = imdb_id
        if series:
            media_id += '-{}x{:02d}'.format(int(season), int(episode))
        # La pagina SoloLatino abrio tt22084616-1 para Principal y Servidor 2.
        # tt22084616 sigue disponible como respaldo historico, pero el usuario
        # comprobo que su video era CAM.
        current_id = 'tt22084616-1' if not series and media_id == 'tt22084616' else media_id
        player_url = 'https://player.pelisserieshoy.com/f/' + current_id
        video_url = resolvers.resolver_pelisserieshoy(player_url)
        found = []
        if video_url:
            found.append({'nombre': 'SoloLatino Premium', 'url': video_url,
                          'calidad': 'Sin verificar', 'source': 'sololatino'})
        elif not premium_only:
            # Keep the original Player+ choice visible when its probe fails.
            found.append({'nombre': 'SoloLatino Player+ (sin verificar)',
                          'url': player_url, 'calidad': 'Sin verificar',
                          'source': 'sololatino'})
        if premium_only:
            return found
        embed_ids = [current_id]
        if current_id != media_id:
            embed_ids.append(media_id)
        for embed_id in embed_ids:
            for alternate in resolvers.resolver_embed69_hosts('https://embed69.org/f/' + embed_id):
                suffix = (' (Servidor 2)' if embed_id == current_id and current_id != media_id
                          else ' (respaldo IMDb; CAM reportada)' if embed_id != current_id else '')
                found.append(dict(alternate,
                                  nombre='Embed69 ' + alternate.get('nombre', 'Servidor') + suffix,
                                  calidad='Sin verificar', source='sololatino'))
        found.extend(resolvers.pelisserieshoy_opciones(player_url))
        return found
    except Exception as exc:
        network.log_resolver('SoloLatino Premium por IMDb no disponible ({})'.format(type(exc).__name__))
    return []


def _sololatino_premium_by_title(item, series=None, premium_only=False):
    """Find one exact TMDb identity for a SoloLatino catalog entry."""
    import lolplus
    root = series or item
    try:
        match = _sololatino_tmdb_match(_sololatino_tmdb_candidates(root), root)
        if not match:
            return []
        tmdb_item = dict(item, tmdb_id=match['tmdb_id'])
        tmdb_series = dict(series, tmdb_id=match['tmdb_id']) if series else None
        return [dict(server, source='sololatino') for server in
                _sololatino_premium_tmdb(tmdb_item, tmdb_series, premium_only=premium_only)]
    except Exception as exc:
        network.log_resolver('SoloLatino: identificacion TMDb no disponible ({})'.format(type(exc).__name__))
        return []


def normal_premium(item, series=None):
    """Consult only SoloLatino Premium for the first automatic attempt."""
    if not source_switches.enabled('sololatino'):
        return []
    item = active_item(item)
    series = active_item(series) if series is not None else None
    if item is None or (series is None and item.get('episode') is not None):
        return []
    root = series or item
    direct_entries = [v for v in variants(root)
                      if urlsplit(v.get('url', '')).hostname in network._SOLO_HOSTS]
    if not direct_entries:
        if not root.get('tmdb_id'):
            return []
        import catalog_index
        section = 'series' if series or root.get('is_serie') else 'peliculas'
        direct_entries = catalog_index.match_tmdb_items([root], section)
        if not direct_entries:
            return []
    target_url = item.get('url', '') if series else direct_entries[0].get('url', '')
    if urlsplit(target_url).hostname in network._SOLO_HOSTS:
        try:
            direct_premium = s.sololatino_obtener_servidores(target_url, premium_only=True)
            if direct_premium:
                premium = [dict(server, source='sololatino') for server in direct_premium
                           if 'premium' in server.get('nombre', '').lower()]
                if premium:
                    return premium
        except Exception as exc:
            network.log_resolver('SoloLatino: Premium directo no disponible ({})'.format(type(exc).__name__))
    if item.get('tmdb_id') or root.get('tmdb_id'):
        return _sololatino_premium_tmdb(item, series, premium_only=True)
    if direct_entries:
        return _sololatino_premium_by_title(item, series, premium_only=True)
    return []


def servers(item, experimental=False, series=None):
    import anime
    import additional_sources
    import frikiserie
    item = active_item(item)
    if item is None:
        return []
    if series is not None:
        series = active_item(series)
        if series is None:
            return []
    if frikiserie.owns((series or item).get('url', '')):
        return frikiserie.servers(item, series=series)
    import archive_sources
    if archive_sources.owns((series or item).get('url', '')):
        return archive_sources.servers(item, series=series)
    import argflix
    if argflix.owns((series or item).get('url', '')):
        return s.ordenar_servidores_por_calidad([visible_server(srv) for srv in argflix.servers(item, series=series)])
    if series and source_switches.key_for(series) == 'seriesturcas':
        import lolplus
        found = lolplus.LolPlusScrapers.scrape_seriesturcas(
            title(series.get('title', '')), season=item.get('season'), episode=item.get('episode'))
        return s.ordenar_servidores_por_calidad(
            [visible_server(dict(server, calidad='Sin verificar')) for server in found if server.get('url')])
    import internal_catalogs
    direct_source = source_switches.key_for(series or item)
    if direct_source in internal_catalogs._ROUTES:
        import lolplus
        scraper = getattr(lolplus.LolPlusScrapers, 'scrape_' + direct_source)
        root = series or item
        kwargs = {'year': root.get('year'), 'tmdb_id': item.get('tmdb_id') or root.get('tmdb_id')}
        if series:
            kwargs.update(season=item.get('season'), episode=item.get('episode'))
        found = scraper(title(root.get('title', '')), **kwargs)
        if source_switches.enabled('nova') and (experimental or source_switches.only_enabled('nova')):
            import nova_sources
            found = list(found or []) + nova_sources.servers(item, series=series)
        return s.ordenar_servidores_por_calidad(
            [visible_server(dict(server, calidad='Sin verificar')) for server in found if server.get('url')])
    u = item.get('url', '')
    if anime.is_anime_url(u):
        srvs = anime.obtener_servidores(u)
        if srvs:
            unique = {}
            for srv in srvs:
                if srv.get('url'):
                    unique.setdefault(srv['url'], visible_server(srv))
            return s.ordenar_servidores_por_calidad(list(unique.values()))
    if series and anime.is_anime_url(series.get('url', '')):
        s_u = series.get('url', '')
        srvs = anime.obtener_servidores(s_u)
        if srvs:
            unique = {}
            for srv in srvs:
                if srv.get('url'):
                    unique.setdefault(srv['url'], visible_server(srv))
            return s.ordenar_servidores_por_calidad(list(unique.values()))

    import lolplus
    root = series or item
    calls = []
    tmdb = any(v.get('url', '').startswith('lolplus://') for v in (root, item))
    if tmdb and not source_switches.only_enabled('nova'):
        calls.append(lambda: lolplus.lolplus_obtener_servidores(item, series=series))
    if source_switches.enabled('nova') and (experimental or source_switches.only_enabled('nova')):
        import nova_sources
        calls.append(lambda: nova_sources.servers(item, series=series))

    is_anime_content = (
        anime.is_anime(item) or
        anime.is_anime(root) or
        root.get('section') == 'animes' or
        item.get('section') == 'animes'
    )
    if is_anime_content and any(source_switches.enabled(key) for key in (
            'tioanime', 'animeflv', 'animeav1', 'jkanime', 'monoschinos', 'latanime')):
        calls.append(lambda: anime.obtener_servidores_para_tmdb(item, series=series))

    providers = []
    if source_switches.enabled('frikiserie'):
        providers.append((frikiserie.owns, frikiserie.search,
                          frikiserie.servers))
    if source_switches.enabled('archiveorg'):
        providers.append((archive_sources.owns, archive_sources.search,
                          archive_sources.servers))
    if source_switches.enabled('sololatino'):
        providers.append((lambda url: urlsplit(url).hostname in network._SOLO_HOSTS,
                          s.sololatino_buscar, lambda v: s.sololatino_obtener_servidores(v['url'], premium_only=False)))
    if experimental:
        if source_switches.enabled('hackstore'):
            providers.append((s.es_url_hackstore, s.hackstore_search, lambda v: s.hackstore_servers(v['url'])))
        if source_switches.enabled('pelisjuanita'):
            providers.append((s.es_url_pelisjuanita, s.pelisjuanita_search, lambda v: s.pelisjuanita_servers(v['url'])))
        if source_switches.enabled('pelisflix'):
            providers.append((s.es_url_pelisflix, s.pelisflix_search, lambda v: s.pelisflix_servers(v['url'])))
        if any(source_switches.enabled(key) for key in ('doramasyt', 'doramasflix', 'doramaexpress')):
            providers.append((doramas.owns, doramas.search, lambda v: doramas.servers(v, True)))
        if any(source_switches.enabled(key) for key in ('dondever', 'verpel', 'homecine',
                                                        'areshd', 'pelisgo', 'pelispanda',
                                                        'megadedeoficial')):
            providers.append((additional_sources.owns, additional_sources.search, additional_sources.servers))
        if source_switches.enabled('cinecalidad') and not root.get('is_serie') and not series:
            providers.append((s.cinecalidad_owns, s.cinecalidad_search, s.cinecalidad_servers))
        if source_switches.enabled('tubi') and s.tubi_is_available():
            providers.append((s.tubi_owns, s.tubi_search, s.tubi_servers))
    if source_switches.enabled('argflix'):
        providers.append((argflix.owns, argflix.search, argflix.servers))

    def lookup(owns, search_provider, get_servers):
        direct = [v for v in variants(item) if source_switches.allowed(v) and owns(v.get('url', ''))]
        if direct:
            found_direct = [server for v in direct for server in (get_servers(v) or [])]
            if any(urlsplit(v.get('url', '')).hostname in network._SOLO_HOSTS for v in direct):
                found_direct = [dict(server, source='sololatino') for server in found_direct]
                import resolvers
                for server in list(found_direct):
                    if urlsplit(server.get('url', '')).hostname == 'player.pelisserieshoy.com':
                        media_id = server['url'].rstrip('/').rsplit('/', 1)[-1].split('?', 1)[0]
                        found_direct.extend(dict(alt, nombre='Embed69 ' + alt.get('nombre', 'Servidor'),
                            calidad='Sin verificar', source='sololatino')
                            for alt in resolvers.resolver_embed69_hosts(
                                'https://embed69.org/f/' + media_id))
                        found_direct.extend(resolvers.pelisserieshoy_opciones(server['url']))
            if not found_direct and any(urlsplit(v.get('url', '')).hostname in network._SOLO_HOSTS for v in direct):
                found_direct = (_sololatino_premium_tmdb(item, series)
                                if series and (series.get('tmdb_id') or item.get('tmdb_id')) else
                                _sololatino_premium_by_title(item, series))
                found_direct = [dict(server, source='sololatino') for server in found_direct]
            return found_direct
        if not tmdb or (item.get('episode') is not None and not series):
            return []
        by_host = {}
        for entry in search_provider(title(root.get('title', ''))) or []:
            url = entry.get('url', '')
            if source_switches.allowed(entry) and owns(url) and same_title(entry, root):
                by_host.setdefault(urlsplit(url).hostname, {})[url] = entry
        found = []
        for matches in by_host.values():
            if len(matches) != 1:
                continue
            target = next(iter(matches.values()))
            is_sololatino = urlsplit(target.get('url', '')).hostname in network._SOLO_HOSTS
            if series:
                season, number = str(item.get('season')), str(item.get('episode'))
                if frikiserie.owns(target.get('url', '')):
                    entries = (frikiserie.episodes(target) or {}).get(season, [])
                elif archive_sources.owns(target.get('url', '')):
                    entries = (archive_sources.episodes(target) or {}).get(season, [])
                elif argflix.owns(target.get('url', '')):
                    entries = (argflix.episodes(target) or {}).get(season, [])
                elif additional_sources.owns(target.get('url', '')):
                    entries = (additional_sources.episodes(target) or {}).get(season, [])
                else:
                    entries = (s.obtener_episodios(target) or {}).get(season, [])
                episodes_found = [ep for ep in entries if str(ep.get('episode')) == number]
                if len(episodes_found) != 1:
                    if is_sololatino:
                        found.extend(dict(server, source='sololatino') for server in
                                     _sololatino_premium_tmdb(item, series))
                    continue
                target = episodes_found[0]
            servers_found = get_servers(target) or []
            if not servers_found and is_sololatino:
                servers_found = _sololatino_premium_tmdb(item, series)
            if is_sololatino:
                servers_found = [dict(server, source='sololatino') for server in servers_found]
            found.extend(servers_found)
        return found

    for provider in providers:
        calls.append(lambda provider=provider: lookup(*provider))
    unique = {}
    for batch in parallel(calls, partial=True):
        for server in batch or []:
            url = server.get('url')
            if not url:
                continue
            cleaned = visible_server(server)
            existing = unique.get(url)
            if existing is None:
                unique[url] = cleaned
            elif not (existing.get('idioma') or existing.get('language')) and (
                    cleaned.get('idioma') or cleaned.get('language')):
                unique[url] = cleaned
    return s.ordenar_servidores_por_calidad(list(unique.values()))


def metadata(item):
    """Enrich only from the selected title/episode, without title-based guessing."""
    if item.get('url', '').startswith('lolplus://'):
        import lolplus
        return lolplus.lolplus_metadata(item)
    import frikiserie
    if frikiserie.owns(item.get('url', '')):
        enriched = frikiserie._enrich(item)
        result = {key: enriched[key] for key in ('cover', 'plot', 'rating', 'tmdb_id', 'plot_language')
                  if enriched.get(key)}
        if enriched.get('tmdb_id'):
            localized = _sololatino_tmdb_metadata(enriched)
            result.update(localized)
        return result
    import archive_sources
    if archive_sources.owns(item.get('url', '')):
        return {key: item[key] for key in ('cover', 'plot', 'rating', 'plot_language') if item.get(key)}
    import argflix
    if argflix.owns(item.get('url', '')):
        return argflix.metadata(item)
    import content_metadata
    import servidores as tubi
    if tubi.tubi_owns(item.get('url', '')):
        if not tubi.tubi_is_available():
            return {}
        return tubi.tubi_metadata(item)
    if cinecalidad.cinecalidad_owns(item.get('url', '')):
        return cinecalidad.cinecalidad_metadata(item)
    if doramas.is_dorama(item):
        return doramas.metadata(item)
    if source_switches.key_for(item) == 'sololatino':
        localized = _sololatino_tmdb_metadata(item)
        if localized:
            return localized
    url = item.get('url', '')
    if not url.startswith(('https://', 'http://')):
        return {k: v for k, v in content_metadata.fields(item).items() if v}
    page, _ = network.fetch_html(url, referer=url, timeout=5)
    result = content_metadata.from_page(page, episode=bool(item.get('episode')))
    plot = result.get('plot', '')
    if not plot or plot.endswith('...') or plot.endswith('…'):
        full_plot = network.extraer_sinopsis(page)
        if full_plot and len(full_plot) > len(plot):
            result['plot'] = full_plot
    curr_plot = item.get('plot', '')
    res_plot = result.get('plot', '')
    if curr_plot and (res_plot.endswith('...') or res_plot.endswith('…') or len(curr_plot) > len(res_plot)):
        result['plot'] = curr_plot
    return result


def _sololatino_tmdb_metadata(item):
    """Spanish plot for an exact SoloLatino/TMDb identity, with no guessed text."""
    import lolplus
    tmdb_id = item.get('tmdb_id')
    if not tmdb_id and item.get('episode') is None:
        try:
            match = _sololatino_tmdb_match(_sololatino_tmdb_candidates(item), item)
            if match:
                tmdb_id = match['tmdb_id']
        except Exception:
            return {}
    if not tmdb_id:
        return {}
    endpoint = ('/tv/{}/season/{}/episode/{}'.format(
        tmdb_id, item['season'], item['episode']) if item.get('episode') is not None
        else '/{}/{}'.format('tv' if item.get('is_serie') else 'movie', tmdb_id))
    try:
        tmdb = lolplus.LolPlusCatalog()
        for language in ('es-MX', 'es-ES'):
            plot = tmdb._query(endpoint, {'language': language}).get('overview')
            if plot:
                return {'plot': plot, 'plot_language': 'es'}
        plot = tmdb._query(endpoint, {'language': 'en-US'}).get('overview')
        if plot:
            return {'plot': plot, 'plot_language': 'en'}
    except Exception as exc:
        network.log_resolver('SoloLatino: sinopsis TMDb no disponible ({})'.format(type(exc).__name__))
    return {}
