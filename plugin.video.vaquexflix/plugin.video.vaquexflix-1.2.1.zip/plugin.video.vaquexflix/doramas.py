# -*- coding: utf-8 -*-
"""Proveedores DoramasYT, DoramasFlix y DoramaExpress para Kodi.

Catalogos, busquedas, metadatos, episodios y reproductores publicados.
Las acciones internas de DoramasFlix pueden cambiar con cada despliegue.
"""

from __future__ import annotations
import network

import json
import re
import sys
import time
import content_metadata
from provider_cache import PageCache, SearchResults

_PAGE_CACHE = PageCache()
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urljoin, urlparse, parse_qs
from urllib.request import HTTPCookieProcessor, Request


USER_AGENT = "Mozilla/5.0"
YT = "https://www.doramasyt.com"
FLIX = "https://doramasflix.io"
FLIX_GRAPHQL = "https://user-api.fluxcedene.net/graphql"
FLIX_ACTIONS = {
    "search": "40f2b52de618b2460ce1d8676868e64a6774f2429c",
    "episodes": "4053123812c621a321f75a5d312ba2ca9a45d65e3f",
    "links": "40aea86e91b4fa6a9ea1d62d82adfde4fb4ec48d33",
    "movie_links": "40fc0c7365f478577476ba6c619b652aaa46d9e2d8",
}


class SourceError(Exception):
    pass


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

def _prepare_poster(poster_url: str) -> str:
    if not poster_url:
        return ""
    if "doramasyt.com" in poster_url and "|" not in poster_url:
        return poster_url + "|Referer=" + quote(YT + "/") + "&User-Agent=" + quote(BROWSER_UA)
    return poster_url


class _HTML(HTMLParser):
    """Extrae los elementos necesarios sin dependencias externas."""

    def __init__(self, base: str):
        super().__init__(convert_charrefs=True)
        self.base = base
        self.links = []
        self.players = []
        self.scripts = []
        self.csrf = ""
        self.ajax = ""
        self.player_key = ""
        self.title = ""
        self._link = None
        self._player = None
        self._h1 = 0
        self._h3 = 0
        self._script = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = set((attrs.get("class") or "").split())
        if tag == "a" and attrs.get("href"):
            self._link = {"url": urljoin(self.base, attrs["href"]),
                          "title": "", "heading": "", "poster": ""}
        elif tag == "img" and self._link:
            image = attrs.get("data-src") or attrs.get("src") or ""
            if image:
                self._link["poster"] = urljoin(self.base, image)
            self._link["alt"] = attrs.get("alt") or ""
        elif tag == "meta" and attrs.get("name") == "csrf-token":
            self.csrf = attrs.get("content") or ""
        elif tag == "section" and "caplist" in classes:
            self.ajax = attrs.get("data-ajax") or ""
        elif tag == "div" and "player" in classes:
            self.player_key = attrs.get("data-key") or ""
        elif tag == "button" and "play-video" in classes:
            self._player = {"name": "", "token": attrs.get("data-player") or "",
                            "uses_api": attrs.get("data-usa-api") == "1"}
        elif tag == "script":
            self._script = True
        if tag == "h1":
            self._h1 += 1
        if tag == "h3" and self._link:
            self._h3 += 1

    def handle_endtag(self, tag):
        if tag == "a" and self._link:
            self._link["title"] = _clean(self._link["title"])
            self._link["heading"] = _clean(self._link["heading"])
            self.links.append(self._link)
            self._link = None
        elif tag == "button" and self._player:
            self._player["name"] = _clean(self._player["name"])
            self.players.append(self._player)
            self._player = None
        elif tag == "script":
            self._script = False
        if tag == "h1" and self._h1:
            self._h1 -= 1
        if tag == "h3" and self._h3:
            self._h3 -= 1

    def handle_data(self, data):
        if self._link:
            self._link["title"] += data
            if self._h3:
                self._link["heading"] += data
        if self._player:
            self._player["name"] += data
        if self._h1:
            self.title += data
        if self._script and "self.__next_f.push([1," in data:
            self.scripts.append(data)


def _parse(html: str, url: str) -> _HTML:
    parser = _HTML(url)
    parser.feed(html)
    parser.title = _clean(parser.title)
    return parser


def _flight(parser: _HTML) -> str:
    chunks = []
    for script in parser.scripts:
        match = re.search(r"self\.__next_f\.push\(\[1,(\"(?:\\.|[^\"\\])*\")\]\)", script, re.S)
        if match:
            try:
                chunks.append(json.loads(match.group(1)))
            except ValueError:
                pass
    return "".join(chunks)


def _json_after(source: str, marker: str):
    position = source.find(marker)
    if position < 0:
        return None
    try:
        return json.JSONDecoder().raw_decode(source[position + len(marker):].lstrip())[0]
    except ValueError:
        return None


class _Client:
    def __init__(self, base: str):
        self.base = base
        self.host = urlparse(base).hostname
        from network import nueva_sesion
        self.opener = nueva_sesion()
        self.user_agent = USER_AGENT
        if self.host == 'doramaexpress.com':
            from sessions import configure
            try:
                self.user_agent = configure(self.opener, 'doramaexpress', ('doramaexpress.com', 'www.doramaexpress.com')) or BROWSER_UA
            except (OSError, ValueError) as exc:
                raise SourceError('No se pudieron leer las cookies configuradas de DoramaExpress') from exc
        # YT embeds CSRF/player tokens bound to this client's cookie session.
        self.page_cache = PageCache() if self.host == urlparse(YT).hostname else _PAGE_CACHE

    def _safe_url(self, url: str) -> str:
        result = urljoin(self.base, url)
        if urlparse(result).hostname != self.host or urlparse(result).scheme != "https":
            raise SourceError("La consulta debe permanecer en %s" % self.host)
        return result

    def request(self, url: str, data: bytes | None = None, headers: dict | None = None) -> str:
        url = self._safe_url(url)
        path = urlparse(url).path
        if data is None and path.startswith(('/dorama/', '/doramas/', '/peliculas/', '/ver/', '/capitulos/', '/serie/', '/movies/', '/episodio/')):
            from network import tiempo_peticion
            key = (url, tuple(sorted((headers or {}).items())))
            return self.page_cache.get(key, lambda: self._request(url, data, headers), lambda: tiempo_peticion(20))
        return self._request(url, data, headers)

    def _request(self, url, data=None, headers=None, verified=False):
        url = self._safe_url(url)
        request = Request(url, data=data, headers={"User-Agent": self.user_agent,
                                                  **(headers or {})})
        try:
            with self.opener.open(request, timeout=20) as response:
                if urlparse(response.url).hostname != self.host:
                    raise SourceError("La consulta salió del dominio esperado")
                return response.read(5_000_000).decode(
                    response.headers.get_content_charset() or "utf-8", errors="replace")
        except HTTPError as exc:
            if self.host in ('doramaexpress.com', 'yandispoiler.net') and exc.code == 503 and not verified and data is None:
                # The site's own JS sets this cookie and reloads. Parse only the
                # literal token; never execute scripts or forward it to another host.
                body = exc.read(65536).decode('utf-8', errors='replace')
                exc.close()
                token = re.search(r"document\.cookie\s*=\s*['\"]ypg_chal=([0-9]{9,12}\.[a-f0-9]{64});", body)
                if token:
                    retry_headers = dict(headers or {})
                    existing = retry_headers.get('Cookie', '')
                    retry_headers['Cookie'] = (existing + '; ' if existing else '') + 'ypg_chal=' + token.group(1)
                    return self._request(url, data, retry_headers, verified=True)
            if self.host == 'doramaexpress.com' and exc.code == 403:
                raise SourceError('DoramaExpress requiere renovar la verificacion. En Windows, abre el sitio en Firefox y vuelve a buscar; en otros equipos se necesita una sesion valida propia.') from exc
            raise SourceError("HTTP %s en %s" % (exc.code, url)) from exc
        except URLError as exc:
            raise SourceError("No se pudo conectar a %s: %s" % (self.host, exc.reason)) from exc

    def post_form(self, url: str, fields: dict, referer: str) -> dict:
        payload = urlencode(fields).encode("utf-8")
        text = self.request(url, payload, {"Referer": self._safe_url(referer),
                                           "X-Requested-With": "XMLHttpRequest",
                                           "Content-Type": "application/x-www-form-urlencoded"})
        try:
            result = json.loads(text)
        except ValueError as exc:
            raise SourceError("La respuesta de capítulos no es JSON") from exc
        if not isinstance(result, dict):
            raise SourceError("La respuesta de capítulos tiene un formato inesperado")
        return result

    def action(self, page_url: str, action_id: str, argument: dict):
        text = self.request(page_url, json.dumps([argument]).encode("utf-8"), {
            "Next-Action": action_id, "Accept": "text/x-component",
            "Content-Type": "text/plain;charset=UTF-8", "Origin": self.base,
            "Referer": self._safe_url(page_url),
        })
        for line in text.splitlines():
            if line.startswith("1:"):
                try:
                    result = json.loads(line[2:])
                except ValueError as exc:
                    raise SourceError("La acción devolvió datos inválidos") from exc
                if result is None:
                    raise SourceError("La acción ya no responde; puede haber cambiado la versión del sitio")
                return result
        raise SourceError("No se encontró el resultado de la acción")


class DoramasYT:
    name = "DoramasYT"

    def __init__(self):
        self.http = _Client(YT)

    @staticmethod
    def _items(parser: _HTML) -> list[dict]:
        found = {}
        for link in parser.links:
            if re.fullmatch(r"/dorama/[^/]+/?", urlparse(link["url"]).path):
                found.setdefault(link["url"], {"title": link["heading"] or link["title"],
                                                 "url": link["url"], "poster": _prepare_poster(link["poster"])})
        return list(found.values())

    def _catalog(self, page: int, path: str) -> dict:
        if page < 1:
            raise SourceError("La página debe ser mayor que cero")
        url = YT + path + ("?p=%d" % page if page > 1 else "")
        parser = _parse(self.http.request(url), url)
        last_page = max((int(parse_qs(urlparse(link["url"]).query)["p"][0])
                         for link in parser.links if urlparse(link["url"]).path == path
                         and parse_qs(urlparse(link["url"]).query).get("p")), default=page)
        return {"source": self.name, "page": page, "last_page": last_page,
                "items": self._items(parser)}

    def catalog(self, page: int = 1) -> dict:
        return self._catalog(page, "/doramas")

    def movies(self, page: int = 1) -> dict:
        return self._catalog(page, "/peliculas")

    def catalog_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay)

    def movies_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay, "movies")

    def search(self, query: str) -> dict:
        url = YT + "/buscar?" + urlencode({"q": query})
        return {"source": self.name, "query": query,
                "items": self._items(_parse(self.http.request(url), url))}

    def detail(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser = _parse(self.http.request(url), url)
        if not parser.ajax or not parser.csrf:
            raise SourceError("No se encontró la lista de capítulos en la ficha")
        meta = self.http.post_form(parser.ajax, {"_token": parser.csrf}, url)
        total = len(meta.get("eps") or [])
        per_page = int(meta.get("perpage") or 50)
        if per_page < 1 or not meta.get("paginate_url"):
            raise SourceError("Paginación de capítulos inválida")
        episodes = []
        for page in range(1, (total + per_page - 1) // per_page + 1):
            data = self.http.post_form(meta["paginate_url"],
                                       {"_token": parser.csrf, "p": page}, url)
            for item in data.get("caps") or []:
                episode_url = self.http._safe_url(item.get("url") or "")
                episodes.append({"number": item.get("episodio"), "url": episode_url,
                                 "poster": _prepare_poster(item.get("thumb") or "")})
        return {"source": self.name, "title": parser.title, "url": url,
                "episodes": episodes, "episode_count": len(episodes)}

    def episode(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser = _parse(self.http.request(url), url)
        if not parser.player_key or not parser.players:
            raise SourceError("No se encontraron opciones de reproducción")
        return {"source": self.name, "title": parser.title, "url": url,
                "player_key": parser.player_key, "players": parser.players}

    def embed(self, episode_url: str, option: int = 1) -> dict:
        episode = self.episode(episode_url)
        if not 1 <= option <= len(episode["players"]):
            raise SourceError("Número de opción fuera de rango")
        player = episode["players"][option - 1]
        if not player["uses_api"]:
            target = player["token"]
        else:
            target = episode["player_key"] + player["token"]
            target += "&player=" + quote(player["name"])
        target = self.http._safe_url(target)
        html = self.http.request(target, headers={"Referer": episode["url"]})
        match = re.search(r'<iframe\b[^>]*\bsrc=["\']([^"\']+)', html, re.I)
        if not match:
            raise SourceError("El reproductor no publicó un iframe")
        embed = urljoin(target, match.group(1))
        if urlparse(embed).scheme not in ("https", "http"):
            raise SourceError("El iframe no contiene una URL válida")
        return {"source": self.name, "server": player["name"], "embed": embed}


class DoramasFlix:
    name = "DoramasFlix"

    def __init__(self):
        self.http = _Client(FLIX)

    @staticmethod
    def _item(item: dict, kind: str = "doramas") -> dict:
        poster = item.get("poster") or item.get("poster_path") or ""
        if poster.startswith("/"):
            poster = "https://image.tmdb.org/t/p/w342" + poster
        return {"title": item.get("name_es") or item.get("name") or "",
                "original_title": item.get("name") or "",
                "url": FLIX + "/" + kind + "/" + item.get("slug", ""), "poster": poster}

    @staticmethod
    def _graphql(field: str, page: int) -> dict:
        if page < 1:
            raise SourceError("La página debe ser mayor que cero")
        if field not in ("paginationDorama", "paginationMovie"):
            raise SourceError("Tipo de catálogo inválido")
        query = ("query Catalog($page:Int,$limit:Int){" + field +
                 "(page:$page,limit:$limit){count pageInfo{pageCount hasNextPage} "
                 "items{_id slug name name_es poster_path poster}}}")
        payload = json.dumps({"query": query, "variables": {"page": page, "limit": 24}}).encode()
        request = Request(FLIX_GRAPHQL, data=payload, headers={
            "User-Agent": USER_AGENT, "Content-Type": "application/json",
            "Origin": FLIX, "Referer": FLIX + "/" +
            ("doramas" if field == "paginationDorama" else "peliculas"),
            "x-brand-host": "doramasflix.io", "x-forwarded-host": "doramasflix.io"})
        try:
            from network import nueva_sesion
            with nueva_sesion().open(request, timeout=20) as response:
                result = json.load(response)
        except (HTTPError, URLError, ValueError) as exc:
            raise SourceError("No se pudo consultar el catálogo GraphQL: %s" % exc) from exc
        data = (result.get("data") or {}).get(field) if isinstance(result, dict) else None
        if not isinstance(data, dict) or "items" not in data:
            raise SourceError("El catálogo GraphQL devolvió un formato inesperado")
        return data

    def catalog(self, page: int = 1) -> dict:
        data = self._graphql("paginationDorama", page)
        info = data.get("pageInfo") or {}
        return {"source": self.name, "page": page, "last_page": info.get("pageCount"),
                "total": data.get("count"), "items": [self._item(x) for x in data["items"]]}

    def movies(self, page: int = 1) -> dict:
        data = self._graphql("paginationMovie", page)
        info = data.get("pageInfo") or {}
        return {"source": self.name, "page": page, "last_page": info.get("pageCount"),
                "total": data.get("count"),
                "items": [self._item(x, "peliculas") for x in data["items"]]}

    def catalog_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay)

    def movies_all(self, max_pages: int = 200, delay: float = 0.3) -> dict:
        return _catalog_all(self, max_pages, delay, "movies")

    def search(self, query: str, limit: int = 20) -> dict:
        # Public catalog API: unlike Next actions, this does not depend on a build ID.
        gql = ("query Search($input:String,$limit:Int){"
               "searchDorama(input:$input,limit:$limit){slug name name_es poster_path poster} "
               "searchMovie(input:$input,limit:$limit){slug name name_es poster_path poster}}")
        request = Request(FLIX_GRAPHQL,
            data=json.dumps({'query': gql, 'variables': {'input': query, 'limit': limit}}).encode(),
            headers={'User-Agent': USER_AGENT, 'Content-Type': 'application/json',
                     'Origin': FLIX, 'Referer': FLIX + '/doramas',
                     'x-brand-host': 'doramasflix.io', 'x-forwarded-host': 'doramasflix.io'})
        try:
            with network.nueva_sesion().open(request, timeout=20) as response:
                result = json.load(response)
        except (HTTPError, URLError, ValueError) as exc:
            raise SourceError('DoramasFlix: no se pudo consultar la busqueda') from exc
        data = result.get('data') if isinstance(result, dict) else None
        if (not isinstance(data, dict) or result.get('errors') or
                not isinstance(data.get('searchDorama'), list) or
                not isinstance(data.get('searchMovie'), list)):
            raise SourceError('DoramasFlix: respuesta de busqueda incompleta')
        return {'source': self.name, 'query': query,
                'items': [self._item(x) for x in data['searchDorama']],
                'movies': [self._item(x, 'peliculas') for x in data['searchMovie']]}

    def _page_data(self, url: str) -> tuple[_HTML, str]:
        url = self.http._safe_url(url)
        try:
            markup = self.http.request(url)
        except SourceError:
            alternate = 'https://doramasflix.in' + urlparse(url).path
            if urlparse(url).query:
                alternate += '?' + urlparse(url).query
            markup = _Client('https://doramasflix.in').request(alternate)
        parser = _parse(markup, url)
        return parser, _flight(parser)

    def detail(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser, flight = self._page_data(url)
        # The first matching object should contain seasons; other references can
        # contain only the numeric ID, so search for that explicit shape.
        match = re.search(r'\{"serie_id":"([0-9a-f]{24})","seasons":', flight)
        if not match:
            raise SourceError("No se encontraron las temporadas en la ficha")
        series_id = match.group(1)
        season_data = _json_after(flight[match.start():], "")
        seasons = season_data.get("seasons") or [] if isinstance(season_data, dict) else []
        episodes = []
        for season in seasons:
            number = int(season["season_number"])
            initial = season_data.get('initialEpisodes')
            expected = season.get('number_of_episodes')
            if (isinstance(initial, list) and isinstance(expected, int) and
                    season_data.get('initialSeason') == number and len(initial) == expected and
                    all(isinstance(e, dict) and e.get('slug') and e.get('episode_number') is not None for e in initial)):
                for item in initial:
                    episodes.append({'season': number, 'number': item['episode_number'],
                                     'title': item.get('title') or item.get('name') or '',
                                     'url': FLIX + '/capitulos/' + item['slug'],
                                     'poster': item.get('stillUrl') or '', 'plot': '', 'year': ''})
                continue
            page = 1
            while True:
                gql = ('{paginationEpisode(filter:{serie_id:%s,season_number:%d},page:%d,limit:100)'
                       '{items{slug episode_number name name_es still_path backdrop overview} pageInfo{hasNextPage}}}'
                       % (json.dumps(series_id), number, page))
                request = Request(FLIX_GRAPHQL, data=json.dumps({'query': gql}).encode(),
                    headers={'User-Agent': USER_AGENT, 'Content-Type': 'application/json',
                             'Origin': FLIX, 'Referer': url, 'x-brand-host': 'doramasflix.io',
                             'x-forwarded-host': 'doramasflix.io'})
                try:
                    with network.nueva_sesion().open(request, timeout=20) as response:
                        result = json.load(response)
                except (HTTPError, URLError, ValueError) as exc:
                    raise SourceError('DoramasFlix: no se pudo cargar la temporada %s' % number) from exc
                data = (result.get('data') or {}).get('paginationEpisode') if isinstance(result, dict) else None
                if (not isinstance(data, dict) or result.get('errors') or
                        not isinstance(data.get('items'), list) or not isinstance(data.get('pageInfo'), dict)):
                    raise SourceError('La temporada devolvio un formato inesperado')
                for item in data.get("items") or []:
                    still = item.get("still_path") or item.get("backdrop") or ""
                    if still.startswith("/"):
                        still = "https://image.tmdb.org/t/p/w300" + still
                    episodes.append({
                        "season": number,
                        "number": item.get("episode_number"),
                        "title": item.get("name_es") or item.get("name") or "",
                        "url": FLIX + "/capitulos/" + item.get("slug", ""),
                        "poster": still,
                        "plot": item.get("overview") or "",
                        "year": content_metadata.fields(item)["year"],
                    })
                if not (data.get("pageInfo") or {}).get("hasNextPage"):
                    break
                page += 1
        episodes.sort(key=lambda item: (item["season"], item["number"] or 0))
        return {"source": self.name, "title": parser.title, "url": url,
                "series_id": series_id, "seasons": seasons, "episodes": episodes,
                "episode_count": len(episodes)}

    def episode(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser, flight = self._page_data(url)
        match = re.search(r'\{"episode":\{"_id":"([0-9a-f]{24})"', flight)
        if not match:
            raise SourceError("No se encontró el ID del episodio")
        episode_id = match.group(1)
        links = self._links("getEpisodeLinks", episode_id, url)
        if not isinstance(links, list):
            raise SourceError("Los servidores devolvieron un formato inesperado")
        players = self._players(links, flight)
        return {"source": self.name, "title": parser.title, "url": url,
                "episode_id": episode_id, "players": players}

    def _links(self, field, item_id, referer):
        if field not in ('getEpisodeLinks', 'getMovieLinks'):
            raise ValueError('Tipo de reproductor no valido')
        query = '{%s(id:%s){links_online{link server lang}}}' % (field, json.dumps(item_id))
        request = Request(FLIX_GRAPHQL, data=json.dumps({'query': query}).encode(),
            headers={'User-Agent': USER_AGENT, 'Content-Type': 'application/json',
                     'Origin': FLIX, 'Referer': referer, 'x-brand-host': 'doramasflix.io',
                     'x-forwarded-host': 'doramasflix.io'})
        try:
            with network.nueva_sesion().open(request, timeout=20) as response:
                result = json.load(response)
        except (HTTPError, URLError, ValueError) as exc:
            raise SourceError('DoramasFlix: no se pudieron cargar los servidores') from exc
        data = (result.get('data') or {}).get(field) if isinstance(result, dict) else None
        if not isinstance(data, dict) or result.get('errors') or not isinstance(data.get('links_online'), list):
            raise SourceError('DoramasFlix: respuesta de servidores incompleta')
        return data['links_online']

    @staticmethod
    def _players(links: list, flight: str) -> list[dict]:
        def _code_map(key, typename):
            entries = _json_after(flight, f'"{key}":')
            mapping = {
                str(x.get("code_flix")): x.get("name")
                for x in (entries if isinstance(entries, list) else [])
                if isinstance(x, dict) and x.get("code_flix") and x.get("name")
            }
            if mapping or not typename:
                return mapping
            for raw in re.findall(r'\{[^{}]*"__typename":"' + typename + r'"[^{}]*\}', flight):
                try:
                    entry = json.loads(raw)
                except ValueError:
                    continue
                if isinstance(entry, dict) and entry.get("code_flix") and entry.get("name"):
                    mapping[str(entry["code_flix"])] = entry["name"]
            return mapping

        server_names = _code_map("listServers", "Server")
        language_names = _code_map("listLanguages", "") or _code_map("langs", "Language")
        return [{"server": server_names.get(str(x.get("server")), str(x.get("server"))),
                 "language": language_names.get(str(x.get("lang")), x.get("lang")), "embed": x.get("link"),
                 "recommended": bool(x.get("is_recommended"))}
                for x in links if isinstance(x, dict) and
                urlparse(str(x.get("link") or "")).scheme in ("http", "https")]

    def movie(self, url: str) -> dict:
        url = self.http._safe_url(url)
        parser, flight = self._page_data(url)
        match = re.search(r'\{"movie":\{"_id":"([0-9a-f]{24})"', flight)
        if not match:
            raise SourceError("No se encontró el ID de la película")
        movie_id = match.group(1)
        links = self._links("getMovieLinks", movie_id, url)
        if not isinstance(links, list):
            raise SourceError("Los servidores devolvieron un formato inesperado")
        return {"source": self.name, "title": parser.title, "url": url,
                "movie_id": movie_id, "players": self._players(links, flight)}

    def movie_embed(self, movie_url: str, option: int = 1) -> dict:
        movie = self.movie(movie_url)
        if not 1 <= option <= len(movie["players"]):
            raise SourceError("Número de opción fuera de rango")
        return {"source": self.name, **movie["players"][option - 1]}

    def embed(self, episode_url: str, option: int = 1) -> dict:
        episode = self.episode(episode_url)
        if not 1 <= option <= len(episode["players"]):
            raise SourceError("Número de opción fuera de rango")
        return {"source": self.name, **episode["players"][option - 1]}


EXPRESS = "https://doramaexpress.com"
EXPRESS_ALTERNATE = "https://yandispoiler.net"


def _express_url(url):
    url = urljoin(EXPRESS + "/", url)
    parsed = urlparse(url)
    if parsed.scheme == 'https' and parsed.hostname == 'yandispoiler.net':
        path = parsed.path
        for alternate, canonical in (('/series/', '/serie/'), ('/episodios/', '/episodio/')):
            if path.startswith(alternate):
                path = canonical + path[len(alternate):]
                break
        url = urljoin(EXPRESS, path) + ('?' + parsed.query if parsed.query else '')
        parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ("doramaexpress.com", "www.doramaexpress.com"):
        raise ValueError("La URL de pagina debe pertenecer a doramaexpress.com")
    if not (parsed.path.startswith(("/serie/", "/movies/", "/episodio/", "/page/")) or parsed.path == "/"):
        raise ValueError("Ruta de pagina no reconocida")
    return url.replace("https://www.doramaexpress.com", EXPRESS)


def _express_soup(url):
    # Kodi ships the parser with this addon; no pip dependency at runtime.
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        import os
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))
        from bs4 import BeautifulSoup
    url = _express_url(url)
    try:
        page = _Client(EXPRESS).request(url)
    except SourceError:
        # Related public catalog: verified search, episodes and identical embeds.
        # Only translate page routes; never send the primary site's cookies.
        parsed = urlparse(url)
        path = parsed.path
        for canonical, alternate in (('/serie/', '/series/'), ('/episodio/', '/episodios/')):
            if path.startswith(canonical):
                path = alternate + path[len(canonical):]
                break
        alternate_url = EXPRESS_ALTERNATE + path + ('?' + parsed.query if parsed.query else '')
        page = _Client(EXPRESS_ALTERNATE).request(alternate_url)
    return BeautifulSoup(page, 'html.parser')


def _express_meta(soup, key):
    tag = soup.select_one('meta[property="%s"]' % key)
    return tag.get("content", "").strip() if tag else ""


def _express_kind(url):
    path = urlparse(url).path
    if path.startswith("/serie/"):
        return "serie"
    if path.startswith("/movies/"):
        return "pelicula"
    if path.startswith("/episodio/"):
        return "episodio"
    return "desconocido"


def _express_cards(soup):
    result, seen = [], set()
    for card in soup.select(".display-item"):
        anchor = card.select_one('a[href][data-ptype]') or card.select_one('a[href]')
        if not anchor:
            continue
        url = anchor.get("href", "")
        try:
            url = _express_url(url)
        except ValueError:
            continue
        if url in seen or _express_kind(url) not in ("serie", "pelicula"):
            continue
        seen.add(url)
        image = card.select_one("img")
        title = anchor.get("title") or (image.get("alt") if image else None) or anchor.get_text(" ", strip=True)
        result.append({"title": title.strip(), "url": url, "type": _express_kind(url),
                       "poster": (image.get("data-src") or image.get("src") or "") if image else ""})
    return result


def _express_pagination(soup, page):
    total = soup.select_one(".pagination .total")
    match = re.search(r"Page\s+\d+\s+of\s+(\d+)", total.get_text(" ", strip=True), re.I) if total else None
    pages = int(match.group(1)) if match else page
    return {"page": page, "total_pages": pages, "has_next": page < pages}


def _express_catalog(kind="series", page=1):
    if kind not in ("series", "movies") or page < 1:
        raise ValueError("kind debe ser series o movies; page >= 1")
    path = "serie" if kind == "series" else "movies"
    url = "%s/%s/" % (EXPRESS, path)
    if page > 1:
        url += "page/%d/" % page
    soup = _express_soup(url)
    return {"url": url, "items": _express_cards(soup), **_express_pagination(soup, page)}


def _express_search(query, page=1):
    if not query.strip() or page < 1:
        raise ValueError("Se necesita una busqueda y page >= 1")
    url = "%s/?s=%s" % (EXPRESS, quote(query.strip()))
    if page > 1:
        url = "%s/page/%d/?s=%s" % (EXPRESS, page, quote(query.strip()))
    soup = _express_soup(url)
    return {"query": query, "url": url, "items": _express_cards(soup), **_express_pagination(soup, page)}


def _express_episodes(soup):
    result, seen = [], set()
    root = soup.select_one("#yan-list-episodes")
    if not root:
        return result
    for element in root.select('[onclick*="/episodio/"], [onclick*="/episodios/"]'):
        onclick = element.get("onclick", "")
        match = re.search(r"https?://[^'\"\s]+/episodios?/[^'\"\s]+", onclick)
        if not match:
            continue
        try:
            url = _express_url(match.group(0))
        except ValueError:
            continue
        if url in seen:
            continue
        seen.add(url)
        slug = urlparse(url).path.rstrip("/").split("/")[-1]
        numbers = re.search(r"-(\d+)x(\d+)$", slug)
        result.append({"title": element.get_text(" ", strip=True), "url": url,
                       "season": int(numbers.group(1)) if numbers else None,
                       "episode": int(numbers.group(2)) if numbers else None})
    return result


def _express_embeds(soup):
    result, seen = [], set()
    root = soup.select_one("#yan-list-servers")
    if not root:
        return result
    for grid in root.select('[id^="yan-lang-grid-"]'):
        grid_id = grid.get("id", "")
        if grid_id == "yan-lang-grid-downloads":
            continue
        language = "Subtitulado" if grid_id.startswith("yan-lang-grid-kr-") else "Latino" if grid_id.startswith("yan-lang-grid-mx-") else grid_id
        for server in grid.select('[data-url][onclick*="loadSource"]'):
            if server.get('data-locked', '0') not in ('0', 'false', ''):
                continue
            url = server.get("data-url", "").strip()
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https") or not parsed.netloc or url in seen:
                continue
            seen.add(url)
            result.append({"language": language, "server": server.get_text(" ", strip=True).lstrip("▶ ").strip(),
                           "embed_url": url})
    return result


def _express_detail(url):
    url = _express_url(url)
    if _express_kind(url) == "desconocido":
        raise ValueError("Use una ficha de serie, pelicula o episodio")
    soup = _express_soup(url)
    title = _express_meta(soup, "og:title") or (soup.title.get_text(" ", strip=True) if soup.title else "")
    return {"url": url, "type": _express_kind(url), "title": title,
            "description": _express_meta(soup, "og:description"), "poster": _express_meta(soup, "og:image"),
            "episodes": _express_episodes(soup), "embeds": _express_embeds(soup)}


class DoramaExpress:
    name = 'DoramaExpress'

    def __init__(self):
        self.http = _Client(EXPRESS)

    def catalog(self, page=1):
        data = _express_catalog('series', page)
        return dict(data, last_page=data['total_pages'])

    def movies(self, page=1):
        data = _express_catalog('movies', page)
        return dict(data, last_page=data['total_pages'])

    def search(self, query, page=1):
        data = _express_search(query, page)
        found = {i['url']: i for i in data['items']}
        errors = []
        while data.get('has_next'):
            page += 1
            try:
                data = _express_search(query, page)
            except Exception:
                errors.append(self.name)
                break
            fresh = [i for i in data['items'] if i['url'] not in found]
            if not fresh:
                if data['items'] or data.get('has_next'):
                    errors.append(self.name)
                break
            found.update((i['url'], i) for i in fresh)
        return dict(data, items=[i for i in found.values() if i['type'] == 'serie'],
                    movies=[i for i in found.values() if i['type'] == 'pelicula'], errors=errors)

    def detail(self, url):
        data = _express_detail(url)
        for ep in data['episodes']:
            ep['number'] = ep['episode']
        data['episodes'].sort(key=lambda ep: (ep['season'] or 1, ep['number'] or 0))
        return data

    def episode(self, url):
        data = self.detail(url)
        return dict(data, players=[dict(p, embed=p['embed_url']) for p in data['embeds']])

    def embed(self, url, option=1):
        players = self.episode(url)['players']
        if not 1 <= option <= len(players):
            raise SourceError('Numero de opcion fuera de rango')
        return players[option - 1]


def _catalog_all(source, max_pages: int, delay: float, method: str = "catalog") -> dict:
    if max_pages < 1:
        raise SourceError("max_pages debe ser mayor que cero")
    found = {}
    last_page = None
    scanned = 0
    for page in range(1, max_pages + 1):
        result = getattr(source, method)(page)
        scanned += 1
        last_page = result.get("last_page") or last_page
        if not result["items"]:
            break
        for item in result["items"]:
            found.setdefault(item["url"], item)
        if last_page is not None and page >= last_page:
            break
        if page < max_pages:
            time.sleep(max(0, delay))
    return {"source": source.name, "items": list(found.values()), "count": len(found),
            "pages_scanned": scanned, "last_page": last_page,
            "complete": last_page is not None and scanned >= last_page}




"""Adaptadores de proveedores para el catalogo de Kodi."""
import base64
import random
from urllib.parse import urlsplit, urlencode, parse_qs
from concurrent.futures import ThreadPoolExecutor


_DORAMA_HOSTS = (
    'www.doramasyt.com', 'doramasyt.com',
    'doramasflix.io', 'doramasflix.in',
    'doramaexpress.com', 'www.doramaexpress.com', 'yandispoiler.net',
)


def owns(url):
    return urlsplit(url or '').hostname in _DORAMA_HOSTS


def is_dorama(item):
    if item.get('source') == 'tubi':
        return False
    if owns(item.get('url', '')):
        return True
    return item.get('section') == 'doramas'


def client(url):
    host = urlsplit(url).hostname
    if host in ('doramaexpress.com', 'www.doramaexpress.com', 'yandispoiler.net'):
        return DoramaExpress()
    return DoramasFlix() if host in ('doramasflix.io', 'doramasflix.in') else DoramasYT()


def convert(item, movie=False):
    return dict(title=item['title'], url=item['url'], cover=_prepare_poster(item.get('poster', '')),
                is_serie=not movie, section='doramas', plot=item.get('plot', ''),
                year=item.get('year', ''), genres=item.get('genres', []),
                media_type='movie' if movie else '')


def parallel(calls):
    pass
    deadline = getattr(network._sondeo, 'deadline', None)
    cancel = getattr(network._sondeo, 'cancel', None)
    max_request = getattr(network._sondeo, 'max_request', 6)
    def safe(call):
        try:
            with network.presupuesto_sondeo(deadline, cancel, max_request):
                network.tiempo_peticion(15)
                return call()
        except Exception as exc:
            network.log_resolver('Doramas: ' + str(exc))
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(safe, calls))


DEFAULT_DORAMAS_GENRES = {
    'k-drama': {'nom': 'K-Drama', 'posters': []},
    'c-drama': {'nom': 'C-Drama', 'posters': []},
    'j-drama': {'nom': 'J-Drama', 'posters': []},
    'thai-drama': {'nom': 'Thai-Drama', 'posters': []},
    'romance': {'nom': 'Romance', 'posters': []},
    'comedia': {'nom': 'Comedia', 'posters': []},
    'accion': {'nom': 'Acción', 'posters': []},
    'escolar': {'nom': 'Escolar', 'posters': []},
    'drama': {'nom': 'Drama', 'posters': []},
    'fantasia': {'nom': 'Fantasía', 'posters': []},
    'historico': {'nom': 'Histórico', 'posters': []},
    'misterio': {'nom': 'Misterio', 'posters': []},
}

REGIONAL_DORAMAS = {
    'k-drama': (('KR',), 'ko'),
    'c-drama': (('CN', 'TW', 'HK'), 'zh'),
    'j-drama': (('JP',), 'ja'),
    'thai-drama': (('TH',), 'th'),
}

# Géneros de TV y palabras clave de TMDb. La búsqueda textual de un proveedor
# devuelve títulos que contienen el término, pero no acredita su categoría.
THEMATIC_DORAMAS = {
    'romance': {'with_keywords': '9840'},
    'comedia': {'with_genres': '18,35'},
    'accion': {'with_genres': '18,10759'},
    'escolar': {'with_keywords': '10873|6270|190116'},
    'drama': {'with_genres': '18'},
    'fantasia': {'with_genres': '18,10765'},
    'historico': {'with_keywords': '15126|15060'},
    'misterio': {'with_genres': '18,9648'},
}

ASIAN_DORAMA_COUNTRIES = {'KR', 'CN', 'TW', 'HK', 'JP', 'TH'}
SCHOOL_CONTEXT = re.compile(r'\b(?:escuel[ao]s?|colegios?|institutos?|estudiant(?:e|es)|alumnos?|'
                            r'secundaria|profesores?|school|college|high school|students?|'
                            r'classmates?|classroom|campus)\b', re.I)


def thematic_page(number, genre):
    """Clasifica series asiáticas por metadatos de TMDb, sin búsqueda textual."""
    import lolplus
    filters = THEMATIC_DORAMAS[genre]
    data = lolplus.LolPlusCatalog()._query('/discover/tv', {
        'page': number, **filters,
        'with_origin_country': '|'.join(sorted(ASIAN_DORAMA_COUNTRIES)),
        'without_genres': '16,99,10762,10764,10767', 'sort_by': 'popularity.desc',
        'with_genres': filters.get('with_genres', '18'),
        'include_adult': 'false',
    })
    items = []
    for show in data.get('results', []):
        genre_ids = show.get('genre_ids', [])
        if (18 not in genre_ids or
                set(genre_ids).intersection({16, 99, 10762, 10764, 10767}) or
                not set(show.get('origin_country', [])).intersection(ASIAN_DORAMA_COUNTRIES)):
            continue
        if not all(int(value) in genre_ids for value in filters.get('with_genres', '18').split(',')):
            continue
        if genre == 'escolar' and not SCHOOL_CONTEXT.search(show.get('overview') or ''):
            continue
        title = show.get('name') or show.get('original_name') or 'Sin título'
        poster = show.get('poster_path')
        items.append({
            'title': title, 'original_title': show.get('original_name') or title,
            'url': 'lolplus://tv/' + str(show['id']),
            'cover': 'https://image.tmdb.org/t/p/w500' + poster if poster else '',
            'plot': show.get('overview', ''), 'year': (show.get('first_air_date') or '')[:4],
            'rating': str(round(show.get('vote_average', 0), 1)) if show.get('vote_average') else '',
            'is_serie': True, 'section': 'doramas', 'source': 'lolplus',
            'tmdb_id': show['id'], 'genres': [genre],
        })
    return items, number < data.get('total_pages', 1)


def regional_page(number, genre):
    """Catálogo regional verificado por país e idioma de origen de TMDb."""
    import lolplus
    countries, language = REGIONAL_DORAMAS[genre]
    data = lolplus.LolPlusCatalog()._query('/discover/tv', {
        'page': number, 'with_genres': '18', 'without_genres': '16',
        'with_origin_country': '|'.join(countries),
        'with_original_language': language, 'sort_by': 'popularity.desc',
        'include_adult': 'false',
    })
    items = []
    for show in data.get('results', []):
        if (show.get('original_language') != language or
                not set(show.get('origin_country', [])).intersection(countries) or
                18 not in show.get('genre_ids', []) or 16 in show.get('genre_ids', [])):
            continue
        title = show.get('name') or show.get('original_name') or 'Sin título'
        poster = show.get('poster_path')
        items.append({
            'title': title, 'original_title': show.get('original_name') or title,
            'url': 'lolplus://tv/' + str(show['id']),
            'cover': 'https://image.tmdb.org/t/p/w500' + poster if poster else '',
            'plot': show.get('overview', ''), 'year': (show.get('first_air_date') or '')[:4],
            'rating': str(round(show.get('vote_average', 0), 1)) if show.get('vote_average') else '',
            'is_serie': True, 'section': 'doramas', 'source': 'lolplus',
            'tmdb_id': show['id'], 'genres': [genre],
        })
    return items, number < data.get('total_pages', 1)


def menu():
    import source_switches
    try:
        if not source_switches.enabled('doramasyt'):
            raise SourceError('DoramasYT apagada')
        source = DoramasYT()
        url = source.http.base + '/doramas'
        parser = _parse(source.http.request(url), url)
        items = source._items(parser)
        covers = [_prepare_poster(x['poster']) for x in items if x.get('poster')]
        genres = {}
        for link in parser.links:
            parsed = urlsplit(link['url'])
            if parsed.hostname == urlsplit(url).hostname and parsed.path.startswith('/genero/'):
                slug = parsed.path[len('/genero/'):].rstrip('/')
                if slug and '/' not in slug:
                    genres[slug] = {'nom': link['title'].strip(), 'posters': []}
        slugs = list(genres)
        def posters(slug):
            result = DoramasYT()._catalog(1, '/genero/' + slug)
            return list(dict.fromkeys(_prepare_poster(x['poster']) for x in result['items'] if x.get('poster')))
        for slug, pool in zip(slugs, parallel([lambda slug=slug: posters(slug) for slug in slugs])):
            genres[slug]['posters'] = pool or []
    except Exception as exc:
        network.log_resolver('Doramas menu fallback: ' + str(exc))
        covers, genres = [], {}
    genres = genres or DEFAULT_DORAMAS_GENRES
    if not covers or any(not data['posters'] for data in genres.values()):
        fallback_calls = []
        if source_switches.enabled('doramasflix'):
            fallback_calls.append(lambda: DoramasFlix().catalog(1))
        if source_switches.enabled('doramaexpress'):
            fallback_calls.append(lambda: DoramaExpress().catalog(1))
        catalogs = parallel(fallback_calls) if fallback_calls else []
        covers = list(dict.fromkeys(covers + [
            _prepare_poster(item['poster']) for catalog in catalogs if catalog
            for item in catalog.get('items', []) if item.get('poster')
        ]))
    return {'cover': covers[0] if covers else '', 'covers': covers, 'genres': genres}


def category_covers(menu, excluded=()):
    pools = {'todo': menu.get('covers', [])}
    pools.update({key: data['posters'] or menu.get('covers', [])
                  for key, data in menu.get('genres', {}).items()})
    candidates = {key: list(dict.fromkeys(p for p in pool if p not in excluded)) for key, pool in pools.items()}
    for pool in candidates.values():
        random.shuffle(pool)
    owners = {}
    def assign(key, visited):
        for poster in candidates[key]:
            if poster in visited:
                continue
            visited.add(poster)
            if poster not in owners or assign(owners[poster], visited):
                owners[poster] = key
                return True
        return False
    for key in sorted(candidates, key=lambda key: len(candidates[key])):
        assign(key, set())
    return {key: poster for poster, key in owners.items()}


def page(number, genre=None):
    import source_switches
    if not any(source_switches.enabled(key) for key in ('doramasyt', 'doramasflix', 'doramaexpress')):
        return [], False
    if genre in REGIONAL_DORAMAS:
        return regional_page(number, genre)
    if genre in THEMATIC_DORAMAS:
        return thematic_page(number, genre)
    if genre:
        if not all(c.isalnum() or c == '-' for c in genre):
            raise ValueError('Categoria de doramas no valida')
        calls = []
        def fetch_yt():
            result = DoramasYT()._catalog(number, '/genero/' + genre)
            items = [convert(i) for i in result.get('items', [])]
            return items, bool(items) and number < (result.get('last_page') or number)
        if source_switches.enabled('doramasyt'):
            calls.append(fetch_yt)

        if number == 1 and source_switches.enabled('doramasflix'):
            genre_query = genre.replace('-', ' ')
            def fetch_flix():
                res = DoramasFlix().search(genre_query)
                items = [convert(i) for i in res.get('items', [])] + [convert(i, movie=True) for i in res.get('movies', [])]
                return items, False
            calls.append(fetch_flix)

        results = [r for r in parallel(calls) if r]
        return [i for items, _ in results for i in items], any(more for _, more in results)

    calls = []
    for cls in (DoramasYT, DoramasFlix, DoramaExpress):
        if not source_switches.enabled(cls.__name__.lower()):
            continue
        for method in ('catalog', 'movies'):
            def fetch(cls=cls, method=method):
                result = getattr(cls(), method)(number)
                # YT film entries share the series page/episode flow.
                movie = method == 'movies'
                items = [convert(i, movie) for i in result['items']]
                return items, bool(items) and number < (result.get('last_page') or number)
            calls.append(fetch)
    results = [r for r in parallel(calls) if r]
    return [i for items, _ in results for i in items], any(more for _, more in results)


def search(query):
    import source_switches
    sources = tuple(cls for cls in (DoramasYT, DoramasFlix, DoramaExpress)
                    if source_switches.enabled(cls.__name__.lower()))
    if not sources:
        return SearchResults([])
    results = parallel([lambda cls=cls: cls().search(query) for cls in sources])
    items = [convert(i, key == 'movies') for result in results if result for key in ('items', 'movies') for i in result.get(key, [])]
    errors = [cls.name for cls, result in zip(sources, results) if result is None]
    errors.extend(name for result in results if result for name in result.get('errors', []))
    return SearchResults(items, errors)


def episodes(item):
    import source_switches
    if not source_switches.allowed(item):
        return {}
    result = {}
    for ep in client(item['url']).detail(item['url'])['episodes']:
        season, number = str(ep.get('season') or 1), str(ep.get('number') or '')
        if not number:
            continue
        entry = convert({'title': 'T%s:E%s - %s' % (season, number, ep.get('title') or item['title']),
                         'url': ep['url'], 'poster': ep.get('poster') or item.get('cover', ''),
                         'plot': ep.get('plot') or '', 'year': ep.get('year', ''),
                         'genres': item.get('genres', [])})
        entry.update(season=season, episode=number)
        result.setdefault(season, []).append(entry)
    return result


def unwrap_player(url):
    # The provider returns public embed URLs inside its redirect payload.
    if urlsplit(url).hostname != 'embedshortener.co':
        return url
    try:
        token = urlsplit(url).path.rsplit('/', 1)[-1].split('.')[1]
        payload = json.loads(base64.urlsafe_b64decode(token + '=' * (-len(token) % 4)))
        encoded = payload['link']
        target = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8')
        if urlsplit(target).scheme in ('http', 'https') and urlsplit(target).hostname:
            return target
    except (ValueError, KeyError, IndexError, TypeError):
        pass
    return url


def servers(item, experimental=False):
    import source_switches
    if not source_switches.allowed(item):
        return []
    source = client(item['url'])
    player_url = item['url']
    if isinstance(source, DoramasYT) and '/dorama/' in player_url:
        entries = source.detail(player_url)['episodes']
        if len(entries) != 1:
            raise SourceError('La ficha no contiene un unico video de pelicula')
        player_url = entries[0]['url']
    movie = isinstance(source, DoramasFlix) and '/peliculas/' in item['url']
    data = source.movie(player_url) if movie else source.episode(player_url)
    found = []
    for index, option in enumerate(data['players'], 1):
        name = option.get('server') or option.get('name') or 'Servidor'
        language = option.get('language') or ('Latino' if 'latino' in item['url'].lower() else '')
        label = name + (' | ' + str(language) if language else '')
        url = unwrap_player(option.get('embed') or '')
        if not url:
            url = 'dorama://player?' + urlencode({'url': player_url, 'option': index})
        # Only the known primary player is equivalent to SoloLatino Premium.
        premium = urlsplit(url).hostname == 'player.pelisserieshoy.com'
        found.append({'nombre': label, 'url': url, 'premium': premium, 'language': language})
    premium = [x for x in found if x['premium']]
    return premium if premium and not experimental else found


def resolve(url):
    params = parse_qs(urlsplit(url).query)
    page = params['url'][0]
    if not owns(page):
        raise SourceError('Fuente de doramas no valida')
    return client(page).embed(page, int(params['option'][0]))['embed']


def metadata(item):
    url = item['url']
    if not owns(url):
        is_serie = bool(item.get('is_serie', True))
        return {'is_serie': is_serie, 'media_type': 'series' if is_serie else 'movie'}
    page = client(url).http.request(url)
    episode = bool(item.get('episode')) or '/ver/' in url or '/capitulos/' in url or '/episodio/' in url
    result = content_metadata.from_page(page, episode=episode)
    if isinstance(client(url), DoramaExpress) and not episode:
        movie = '/movies/' in url
        result.update(is_serie=not movie, media_type='movie' if movie else 'series')
    if not episode:
        parser = content_metadata.StructuredParser()
        parser.feed(page)
        for node in parser.documents:
            if not isinstance(node, dict) or node.get('@type') not in ('Movie', 'TVSeries'):
                continue
            movie = node.get('@type') == 'Movie' or any(
                g.lower() in ('pelicula', 'película', 'movie')
                for g in content_metadata.genres(node.get('genre', [])))
            result.update(is_serie=not movie, media_type='movie' if movie else 'series')
            break
    return result
