"""Configuracion de streams compartida por el reproductor y las pruebas.

Sin dependencias de Kodi al importar: funciona tambien en Python de Batocera.
"""
from urllib.parse import parse_qsl, urlencode, urlsplit, quote
import math
import threading
import time
import re


def server_priority(server, metadata=None):
    """Prefer SoloLatino, then Latino audio and Full HD for automatic fallback."""
    import source_switches
    import stream_metadata
    metadata = metadata or {}
    audio = stream_metadata.audio_label(metadata, server).lower()
    language = 0 if re.search(r'\b(?:lat|latino|es-419|es-mx)\b', audio) else 1
    quality = stream_metadata.quality_label(metadata) or ' '.join(str(server.get(k) or '') for k in ('calidad', 'quality', 'nombre'))
    heights = [int(h) for h in re.findall(r'(\d{3,4})p\b', quality.lower())]
    height = max(heights or ([2160] if '4k' in quality.lower() else [0]))
    name = server.get('nombre', '').lower()
    player_url = urlsplit(server.get('url', ''))
    host = 0 if 'earnvids' in name else (1 if 'streamwish' in name or
        'hglink' in (player_url.hostname or '') else 2)
    player_host = player_url.hostname == 'player.pelisserieshoy.com'
    solo = server.get('source') == 'sololatino' or player_host
    failed_player_probe = player_host and 'sin verificar' in name
    premium = solo and not failed_player_probe and (
        (player_host and 'vxopt=' not in player_url.query) or 'premium' in name)
    full_hd = 1080 in heights or 'full hd' in quality.lower() or 'fhd' in quality.lower()
    argflix_deprio = server.get('source') == 'argflix' and not source_switches.only_enabled('argflix')
    return not premium, argflix_deprio, language, not full_hd, -height, not solo, host


class Cancelled(Exception):
    pass


def request_with_progress(call, budget_context, keep_waiting, seconds=45):
    """Bound foreground waiting; late workers only write their local result."""
    done, cancel = threading.Event(), threading.Event()
    result = {}
    deadline = time.monotonic() + seconds

    def run():
        try:
            with budget_context(deadline, cancel):
                result['value'] = call()
        except Exception as exc:
            result['error'] = exc
        finally:
            done.set()

    threading.Thread(target=run, name='VaquexflixResolver', daemon=True).start()
    try:
        while True:
            if not keep_waiting():
                raise Cancelled()
            if done.is_set():
                if 'error' in result:
                    raise result['error']
                return result.get('value')
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('El servidor excedio el tiempo de espera')
            done.wait(min(.1, remaining))
    finally:
        cancel.set()


def progress_waiter(progress, keep_waiting, message, start=5, end=92, span=6.0):
    """Return a keep_waiting predicate that advances DialogProgress smoothly."""
    started = time.monotonic()
    last_pct = [-1]
    start = max(0, min(99, int(start)))
    end = max(start, min(99, int(end)))
    span = max(0.5, float(span))

    def _emit(pct):
        if pct <= last_pct[0]:
            return
        last_pct[0] = pct
        update = getattr(progress, 'update', None)
        if callable(update):
            try:
                update(pct, message)
            except Exception:
                pass

    _emit(start)

    def _check():
        if callable(keep_waiting) and not keep_waiting():
            return False
        if progress is not None and progress.iscanceled():
            return False
        elapsed = max(0.0, time.monotonic() - started)
        frac = 1.0 - math.exp(-elapsed / span)
        pct = min(end, max(start, int(start + (end - start) * frac)))
        _emit(pct)
        return True

    return _check


STREAM_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'


def split_stream(stream, user_agent):
    url, _, options = stream.partition('|')
    headers = dict(parse_qsl(options, keep_blank_values=True))
    host = (urlsplit(url).hostname or '').lower()
    cdn_hosts = ('acek-cdn.com', 'premilkyway.com', 'dramiyos-cdn.com', 'tiktokcdn.com', 'embedwish.com', 'streamwish')
    effective_ua = STREAM_UA if any(c in host for c in cdn_hosts) else user_agent
    if urlsplit(url).scheme in ('http', 'https'):
        if any(c in host for c in cdn_hosts) or not any(k.lower() == 'user-agent' for k in headers):
            headers['User-Agent'] = effective_ua
    return url, headers


def _encode_headers(headers):
    return '&'.join(f"{quote(str(k), safe='')}={quote(str(v), safe='')}" for k, v in headers.items())


def _configure_inputstream_adaptive(item, url, headers, user_agent, manifest_type, ask_quality=False, hls_quality=None):
    """Configura inputstream.adaptive para manifiestos HLS o DASH MPD."""
    item.setProperty('inputstream', 'inputstream.adaptive')
    item.setProperty('inputstream.adaptive.manifest_type', manifest_type)
    if str(hls_quality) == '1' or ask_quality:
        item.setProperty('inputstream.adaptive.stream_selection_type', 'ask-quality')
    elif str(hls_quality) == '2':
        item.setProperty('inputstream.adaptive.stream_selection_type', 'fixed-res')
        item.setProperty('inputstream.adaptive.chooser_resolution_max', '1080p')
    else:
        # 'manual-osd' expone todas las pistas y resoluciones en los Ajustes de Video
        # del OSD de Kodi, permitiendo cambiar de calidad en tiempo real sin reiniciar.
        # chooser_resolution_max y chooser_bandwidth_max fuerzan la seleccion optima
        # (1080p si esta disponible) desde la primera reproduccion.
        item.setProperty('inputstream.adaptive.stream_selection_type', 'manual-osd')
        item.setProperty('inputstream.adaptive.chooser_resolution_max', '1080p')
        item.setProperty('inputstream.adaptive.chooser_bandwidth_max', '25000000')
    ua_val = headers.get('User-Agent') or headers.get('user-agent') or user_agent
    header_map = {'User-Agent': ua_val}
    for key in ('Accept-Language', 'Origin', 'Referer', 'Cookie'):
        if key in headers:
            header_map[key] = headers[key]
    header_str = _encode_headers(header_map)
    item.setProperty('inputstream.adaptive.manifest_headers', header_str)
    item.setProperty('inputstream.adaptive.stream_headers', header_str)
    if any(key in header_map for key in ('Accept-Language', 'Origin', 'Referer', 'Cookie')):
        # AES-128 keys (e.g. KeKi/tnmr.org, paretocdn/vidora) use a separate request path.
        item.setProperty('inputstream.adaptive.license_key', '|' + header_str)
    item.setPath(url)
    return url


def configure_stream(item, stream, user_agent, adaptive=False, kodi_major=20, ask_quality=False, hls_quality=None, is_tv=False):
    url, headers = split_stream(stream, user_agent)
    path = urlsplit(url).path.lower()
    if path.endswith('.bin'):
        headers.setdefault('ext', '.mp4')
    extension = headers.get('ext', '').lower()
    host = (urlsplit(url).hostname or '').lower()
    is_yt = 'googlevideo.com' in host
    is_dash = path.endswith('.mpd') or extension == '.mpd'
    is_hls = (path.endswith('.m3u8') or extension == '.m3u8'
              or 'manifest.googlevideo.com' in host
              or '/hls_variant/' in path
              or '/hls_playlist/' in path)
    if path.endswith(('.mp4', '.bin')) or extension == '.mp4':
        item.setMimeType('video/mp4')
        item.setContentLookup(False)
    elif path.endswith('.mkv') or extension == '.mkv':
        item.setMimeType('video/x-matroska')
        item.setContentLookup(False)
    if is_dash:
        item.setMimeType('application/dash+xml')
        item.setContentLookup(False)
        if not is_tv:
            return _configure_inputstream_adaptive(
                item, url, headers, user_agent, 'mpd',
                ask_quality=ask_quality, hls_quality=hls_quality)
    if is_hls:
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setContentLookup(False)
        # Los canales de TV en vivo (mono.m3u8 / IPTV) son reproducidos de forma mucho más estable
        # por el reproductor nativo de Kodi (FFmpeg), ya que inputstream.adaptive en Windows
        # genera fallos de memoria en ucrtbase.dll con streams TS en directo.
        if not is_tv and 'mono.m3u8' not in path and 'playmudos.com' not in host and (is_yt or adaptive):
            return _configure_inputstream_adaptive(
                item, url, headers, user_agent, 'hls',
                ask_quality=ask_quality, hls_quality=hls_quality)
        # Si es un master multivariante remoto, optimizar para el reproductor nativo
        # evitando que FFmpeg demuxe todas las variantes a la vez y cause timeout/buffer.
        elif ('.m3u8' in path or extension == '.m3u8') and not url.startswith('http://127.0.0.1'):
            try:
                import resolvers
                opt_stream = resolvers.seleccionar_variante_optima(stream, conservar_master=False)
                if opt_stream:
                    url, headers = split_stream(opt_stream, user_agent)
            except Exception:
                pass
    direct_file = path.endswith(('.mp4', '.mkv')) or extension in ('.mp4', '.mkv')
    remote_http = urlsplit(url).scheme in ('http', 'https') and host not in ('127.0.0.1', 'localhost')
    insecure_tls = str(headers.get('verifypeer', '')).lower() == 'false'
    if not is_hls and not is_dash and direct_file and remote_http and not insecure_tls:
        # El lector HTTP de FFmpeg maneja sus propios seeks y su callback de
        # interrupcion (Aborted()), conservando cabeceras sin pasar por
        # CurlFile/FileCache/HTTP2 que bloquea seeks y cuelga el cierre.
        item.setProperty('inputstream', 'inputstream.ffmpeg')
        item.setContentLookup(False)
    headers.pop('ext', None)
    if url.startswith('http://127.0.0.1'):
        result = url
    else:
        result = url + ('|' + _encode_headers(headers) if headers else '')
    item.setPath(result)
    return result


_close_trace_file = None


def stop_close_diagnostic():
    """Cancel only the watchdog installed by this module."""
    global _close_trace_file
    if _close_trace_file is not None:
        import faulthandler
        faulthandler.cancel_dump_traceback_later()
        _close_trace_file.close()
        _close_trace_file = None


def start_close_diagnostic(path, seconds=8):
    """Capture Python stacks even if the GIL is stuck inside a Kodi call.

    Temporary diagnostic: no frame locals, URLs, keys or cookies are written.
    The native watchdog does not depend on a Python worker being scheduled.
    """
    global _close_trace_file
    stop_close_diagnostic()
    try:
        import faulthandler
        _close_trace_file = open(path, 'w', encoding='utf-8')
        faulthandler.dump_traceback_later(seconds, repeat=True, file=_close_trace_file)
        return True
    except (ImportError, OSError, RuntimeError):
        if _close_trace_file is not None:
            _close_trace_file.close()
            _close_trace_file = None
        return False
