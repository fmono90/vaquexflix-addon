"""Interruptores locales de proveedores; los accesos y cookies no se modifican."""
import json
import os
import threading
from urllib.parse import urlsplit

SOURCES = (
    ('sololatino', 'SoloLatino'), ('cinecalidad', 'CineCalidad'),
    ('hackstore', 'HackStore'), ('pelisjuanita', 'PelisJuanita'),
    ('pelisflix', 'Pelisflix'), ('tubi', 'Tubi'),
    ('dondever', 'Dondever'), ('verpel', 'Ver Películas Online'),
    ('homecine', 'HomeCine'), ('areshd', 'AresHD'), ('pelisgo', 'PelisGO'),
    ('pelispanda', 'PelisPanda'), ('megadedeoficial', 'MegaDedeOficial'),
    ('tioanime', 'TioAnime'), ('animeflv', 'AnimeFLV'),
    ('animeav1', 'AnimeAV1'), ('jkanime', 'JKAnime'),
    ('monoschinos', 'MonosChinos'), ('latanime', 'Latanime'),
    ('doramasyt', 'DoramasYT'), ('doramasflix', 'DoramasFlix'),
    ('doramaexpress', 'DoramaExpress'),
    ('cuevana', 'Cuevana'), ('tioplus', 'TioPlus'),
    ('poseidon', 'Poseidon'), ('seriesmetro', 'SeriesMetro'),
    ('serieskao', 'SeriesKao'), ('seriesflix', 'SeriesFlix'),
    ('seriesturcas', 'SeriesTurcas'), ('lacartoons', 'LaCartoons'),
    ('pelisplus', 'PelisPlus'), ('pelisflixhd', 'PelisflixHD'),
    ('nova', 'NOVA (experimental)'),
    ('frikiserie', 'FrikiSeries'),
    ('archiveorg', 'Internet Archive'),
    ('argflix', 'Argflix'),
)
LABELS = dict(SOURCES)
_lock = threading.RLock()
_path = None
_disabled = set()


def configure(path):
    global _path, _disabled
    with _lock:
        _path = path
        try:
            with open(path, encoding='utf-8') as handle:
                data = json.load(handle)
            _disabled = set(data.get('disabled', [])) & LABELS.keys()
        except (OSError, ValueError, TypeError, AttributeError):
            _disabled = set()


def enabled(key):
    with _lock:
        return key not in _disabled


def only_enabled(key):
    with _lock:
        return key in LABELS and key not in _disabled and len(_disabled) == len(LABELS) - 1


def disabled():
    with _lock:
        return frozenset(_disabled)


def revision():
    return ','.join(sorted(disabled())) or 'all'


def _persist_locked():
    if not _path:
        return
    tmp = _path + '.tmp'
    os.makedirs(os.path.dirname(_path), exist_ok=True)
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump({'disabled': sorted(_disabled)}, handle)
    os.replace(tmp, _path)


def set_enabled(key, value):
    if key not in LABELS:
        raise KeyError(key)
    with _lock:
        previous = set(_disabled)
        if value:
            _disabled.discard(key)
        else:
            _disabled.add(key)
        try:
            _persist_locked()
        except OSError:
            _disabled.clear()
            _disabled.update(previous)
            raise


def set_all_enabled(value):
    """Guarda todos los interruptores en una sola operación reversible."""
    with _lock:
        previous = set(_disabled)
        _disabled.clear()
        if not value:
            _disabled.update(LABELS)
        try:
            _persist_locked()
        except OSError:
            _disabled.clear()
            _disabled.update(previous)
            raise


def key_for(item):
    source = str(item.get('source') or '').lower().replace(' ', '')
    aliases = {'verpeliculasonline': 'verpel', 'lolplus': None,
               'hackstore2': 'hackstore',
               'pelisflixhd': 'pelisflixhd', 'cinecalidad': 'cinecalidad'}
    if source in LABELS:
        return source
    if source in aliases:
        return aliases[source]
    url = item.get('url', '')
    if url.startswith('lolplus://'):
        return None
    host = (urlsplit(url).hostname or '').lower()
    for needle, key in (
        ('sololatino', 'sololatino'), ('cinecalidad', 'cinecalidad'),
        ('hackstore', 'hackstore'), ('pelisjuanita', 'pelisjuanita'),
        ('pelisflixhd', 'pelisflixhd'), ('pelisflix', 'pelisflix'),
        ('dondever', 'dondever'), ('ver-peliculas-online', 'verpel'),
        ('homecine', 'homecine'), ('areshd', 'areshd'), ('pelisgo', 'pelisgo'),
        ('pelispanda', 'pelispanda'), ('megadede.mobi', 'megadedeoficial'),
        ('tioanime', 'tioanime'), ('animeflv', 'animeflv'),
        ('animeav1', 'animeav1'), ('jkanime', 'jkanime'),
        ('monoschinos', 'monoschinos'), ('latanime', 'latanime'),
        ('doramasyt', 'doramasyt'), ('doramasflix', 'doramasflix'),
        ('doramaexpress', 'doramaexpress'), ('tubitv', 'tubi'),
        ('frikiserie', 'frikiserie'), ('archive.org', 'archiveorg'),
        ('argflix.com', 'argflix'),
    ):
        if needle in host:
            return key
    return None


def allowed(item):
    key = key_for(item)
    return key is None or enabled(key)
