# -*- coding: utf-8 -*-
"""
tube_engine.py - Motor autónomo de streaming y búsqueda de YouTube para Vaquexflix.
Conecta de forma nativa con la interfaz móvil de InnerTube para buscar,
explorar tendencias y resolver streams directos en HLS (1080p/720p/480p) y MP4
sin necesidad de claves API de Google Cloud ni dependencias externas.
"""

import json
import re
import urllib.request
import urllib.parse
import urllib.error
import gzip
from xml.sax.saxutils import escape as _xml_escape, quoteattr as _xml_attr

UA_MOBILE = "com.google.ios.youtube/20.20.7 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X)"
UA_ANDROID = "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip"
UA_VISION = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
UA_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

# Categorías canónicas de YouTube para Vaquexflix (Portadas panorámicas 16:9 para la vista en lista)
TUBE_CATEGORIAS = [
    {
        'key': 'search',
        'title': 'BUSCADOR DE YOUTUBE',
        'url': 'tube://search',
        'cover': 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&h=450&fit=crop&q=80',
        'plot': 'Busca cualquier vídeo, música, canales, streamers, tutoriales o emisiones en directo de YouTube.'
    },
    {
        'key': 'trending',
        'title': 'TENDENCIAS DEL MOMENTO',
        'url': 'tube://trending',
        'cover': 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=450&fit=crop&q=80',
        'plot': 'Los vídeos más populares, virales y con mayor audiencia en español y a nivel global.'
    },
    {
        'key': 'favorites',
        'title': 'FAVORITOS (YOUTUBE)',
        'url': 'tube://favorites',
        'cover': 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=450&fit=crop&q=80',
        'plot': 'Tus vídeos guardados como favoritos en YouTube para reproducir en cualquier momento.'
    },
    {
        'key': 'playlists',
        'title': 'LISTAS DE REPRODUCCIÓN',
        'url': 'tube://playlists',
        'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
        'plot': 'Explora y reproduce listas de reproducción temáticas, recopilaciones y colecciones de YouTube.'
    },
    {
        'key': 'trailers',
        'title': 'TRÁILERS Y CINE',
        'url': 'tube://trailers',
        'cover': 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&h=450&fit=crop&q=80',
        'plot': 'Avances oficiales, primeros vistazos y tráilers de próximos estrenos de cine y series en alta definición.'
    },
    {
        'key': 'music',
        'title': 'MÚSICA Y VIDEOCLIPS',
        'url': 'tube://music',
        'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
        'plot': 'Éxitos mundiales, listas de reproducción, videoclips en 4K/1080p y directos de tus artistas favoritos.'
    },
    {
        'key': 'gaming',
        'title': 'GAMING Y DIRECTOS',
        'url': 'tube://gaming',
        'cover': 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&h=450&fit=crop&q=80',
        'plot': 'Transmisiones en vivo de videojuegos, resúmenes de torneos, gameplays y creadores de contenido.'
    },
    {
        'key': 'podcasts',
        'title': 'PODCASTS Y ENTREVISTAS',
        'url': 'tube://podcasts',
        'cover': 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&h=450&fit=crop&q=80',
        'plot': 'Grandes conversaciones, entrevistas en profundidad, divulgación y los podcasts más escuchados.'
    },
    {
        'key': 'docs',
        'title': 'DOCUMENTALES Y CIENCIA',
        'url': 'tube://docs',
        'cover': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop&q=80',
        'plot': 'Reportajes sobre el universo, historia, tecnología, arqueología y maravillas de la naturaleza.'
    },
    {
        'key': 'history',
        'title': 'RECIÉN VISTOS (YOUTUBE)',
        'url': 'tube://history',
        'cover': 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&h=450&fit=crop&q=80',
        'plot': 'Historial de vídeos reproducidos recientemente en la sección YouTube de Vaquexflix.'
    }
]


def extract_video_id(url_or_id):
    """Extrae el identificador de 11 caracteres de un enlace o ID de YouTube."""
    if not url_or_id:
        return ""
    url_or_id = str(url_or_id).strip()
    if len(url_or_id) == 11 and re.match(r'^[a-zA-Z0-9_-]{11}$', url_or_id):
        return url_or_id

    patterns = [
        r'(?:v=|\/v\/|youtu\.be\/|\/embed\/|\/live\/|\/shorts\/)([a-zA-Z0-9_-]{11})',
        r'tube://([a-zA-Z0-9_-]{11})'
    ]
    for p in patterns:
        m = re.search(p, url_or_id)
        if m:
            return m.group(1)
    return ""


def _parse_range(fmt, field):
    rng = fmt.get(field)
    if not isinstance(rng, dict):
        return None
    try:
        start = int(rng.get('start'))
        end = int(rng.get('end'))
    except (TypeError, ValueError):
        return None
    if start < 0 or end < start:
        return None
    return f"{start}-{end}"


def _extract_codecs(mime_type):
    m = re.search(r'codecs="([^"]+)"', str(mime_type or ''))
    return m.group(1).strip() if m else ''


def build_dash_mpd(video_details, streaming):
    """Construye un manifiesto DASH estático fMP4 para VOD de YouTube."""
    if not isinstance(streaming, dict):
        return None
    vd = video_details if isinstance(video_details, dict) else {}
    if vd.get('isLiveContent') or vd.get('isLive'):
        return None

    adaptive = streaming.get('adaptiveFormats') or []
    videos_by_key = {}
    audios_by_track = {}
    max_ms = 0

    for fmt in adaptive:
        url = fmt.get('url')
        init_range = _parse_range(fmt, 'initRange')
        index_range = _parse_range(fmt, 'indexRange')
        if not url or not init_range or not index_range:
            continue
        mime = str(fmt.get('mimeType') or '').lower()
        codecs = _extract_codecs(fmt.get('mimeType'))
        bitrate = int(fmt.get('bitrate') or fmt.get('averageBitrate') or 0)
        if bitrate <= 0 or not codecs:
            continue
        try:
            max_ms = max(max_ms, int(fmt.get('approxDurationMs') or 0))
        except (TypeError, ValueError):
            pass

        entry = {
            'id': str(fmt.get('itag') or len(videos_by_key) + len(audios_by_track)),
            'url': url,
            'codecs': codecs,
            'bitrate': bitrate,
            'init': init_range,
            'index': index_range,
        }
        if mime.startswith('video/mp4') and 'avc1' in codecs.lower():
            w = int(fmt.get('width') or 0)
            h = int(fmt.get('height') or 0)
            fps = int(fmt.get('fps') or 0)
            if w <= 0 or h <= 0:
                continue
            entry.update({'width': w, 'height': h, 'fps': fps})
            key = (w, h, fps)
            prev = videos_by_key.get(key)
            if prev is None or bitrate > prev['bitrate']:
                videos_by_key[key] = entry
        elif mime.startswith('audio/mp4') and 'mp4a.40.2' in codecs.lower():
            track = fmt.get('audioTrack') if isinstance(fmt.get('audioTrack'), dict) else {}
            track_id = str(track.get('id') or 'und')
            lang_raw = re.split(r'[._-]', track_id)[0] if track_id != 'und' else 'und'
            lang = re.sub(r'[^a-zA-Z0-9-]', '', lang_raw) or 'und'
            sr = int(fmt.get('audioSampleRate') or 44100)
            ch = int(fmt.get('audioChannels') or 2)
            is_def = bool(track.get('audioIsDefault', False))
            entry.update({'sample_rate': sr, 'channels': ch, 'lang': lang, 'default': is_def})
            prev = audios_by_track.get((track_id, lang))
            score = (sr, bitrate)
            if prev is None or score > (prev['sample_rate'], prev['bitrate']):
                audios_by_track[(track_id, lang)] = entry

    if not videos_by_key or not audios_by_track:
        return None
    tagged_audios = {k: v for k, v in audios_by_track.items() if k[0] != 'und'}
    if tagged_audios:
        audios_by_track = tagged_audios
    try:
        len_sec = float(vd.get('lengthSeconds') or 0)
    except (TypeError, ValueError):
        len_sec = 0.0
    duration_sec = max(max_ms / 1000.0 if max_ms > 0 else 0.0, len_sec)
    if duration_sec <= 0:
        return None

    videos = sorted(videos_by_key.values(), key=lambda x: (x['height'], x['fps'], x['bitrate']), reverse=True)
    audios = sorted(audios_by_track.values(), key=lambda x: (x['default'], x['sample_rate'], x['bitrate']), reverse=True)
    # Garantizar al menos un audio marcado como principal para Kodi inputstream.adaptive
    if not any(a['default'] for a in audios):
        audios[0]['default'] = True

    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        f'<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" '
        f'type="static" minBufferTime="PT1.5S" mediaPresentationDuration="PT{duration_sec:.3f}S">',
        '  <Period id="0" start="PT0S">',
        '    <AdaptationSet id="0" contentType="video" mimeType="video/mp4" subsegmentAlignment="true">',
    ]
    for v in videos:
        fps_attr = f' frameRate="{v["fps"]}"' if v['fps'] > 0 else ''
        lines.extend([
            f'      <Representation id={_xml_attr(v["id"])} codecs={_xml_attr(v["codecs"])} '
            f'width="{v["width"]}" height="{v["height"]}"{fps_attr} bandwidth="{v["bitrate"]}">',
            f'        <BaseURL>{_xml_escape(v["url"])}</BaseURL>',
            f'        <SegmentBase indexRange="{v["index"]}" indexRangeExact="true">',
            f'          <Initialization range="{v["init"]}"/>',
            '        </SegmentBase>',
            '      </Representation>',
        ])
    lines.append('    </AdaptationSet>')

    for idx, a in enumerate(audios, start=1):
        lines.append(
            f'    <AdaptationSet id="{idx}" contentType="audio" mimeType="audio/mp4" '
            f'lang={_xml_attr(a["lang"])} subsegmentAlignment="true">'
        )
        if a['default']:
            lines.append('      <Role schemeIdUri="urn:mpeg:dash:role:2011" value="main"/>')
        lines.extend([
            f'      <Representation id={_xml_attr(a["id"])} codecs={_xml_attr(a["codecs"])} '
            f'audioSamplingRate="{a["sample_rate"]}" bandwidth="{a["bitrate"]}">',
            f'        <AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="{a["channels"]}"/>',
            f'        <BaseURL>{_xml_escape(a["url"])}</BaseURL>',
            f'        <SegmentBase indexRange="{a["index"]}" indexRangeExact="true">',
            f'          <Initialization range="{a["init"]}"/>',
            '        </SegmentBase>',
            '      </Representation>',
            '    </AdaptationSet>',
        ])

    lines.extend(['  </Period>', '</MPD>'])
    return '\n'.join(lines)


def _client_specs():
    return [
        (
            "5", "20.20.7", UA_MOBILE, "2AMB",
            {"clientName": "IOS", "clientVersion": "20.20.7", "deviceMake": "Apple",
             "deviceModel": "iPhone16,2", "osName": "iOS", "osVersion": "17.5.1.21F90",
             "hl": "es", "gl": "ES"},
            True,
        ),
        (
            "5", "20.20.7", UA_MOBILE, None,
            {"clientName": "IOS", "clientVersion": "20.20.7", "deviceMake": "Apple",
             "deviceModel": "iPhone16,2", "osName": "iOS", "osVersion": "17.5.1.21F90",
             "hl": "es", "gl": "ES"},
            True,
        ),
        (
            "3", "20.10.38", UA_ANDROID, "2AMB",
            {"clientName": "ANDROID", "clientVersion": "20.10.38", "androidSdkVersion": 34,
             "osName": "Android", "osVersion": "14", "hl": "es", "gl": "ES"},
            True,
        ),
        (
            "101", "0.1", UA_VISION, "2AMB",
            {"clientName": "VISIONOS", "clientVersion": "0.1", "deviceMake": "Apple",
             "deviceModel": "RealityDevice14,1", "osName": "visionOS",
             "osVersion": "1.3.21O771", "hl": "es", "gl": "ES"},
            False,
        ),
    ]


def _pick_url_stream(streaming, ua):
    hls_url = streaming.get('hlsManifestUrl')
    if hls_url:
        return f"{hls_url}|User-Agent={urllib.parse.quote(ua)}&ext=.m3u8"
    fmts = [f for f in streaming.get('formats', []) if f.get('url')]
    if fmts:
        fmts.sort(key=lambda x: (int(x.get('height') or 0), int(x.get('bitrate') or 0)), reverse=True)
        return f"{fmts[0]['url']}|User-Agent={urllib.parse.quote(ua)}"
    return None


def _resolve_with_clients(vid, prefer_dash=False, is_live=False):
    visitor_data = None
    hls_fallback = None
    for cid, cver, ua, params_val, client_obj, check_status in _client_specs():
        payload = {"videoId": vid, "context": {"client": dict(client_obj)}}
        if params_val:
            payload["params"] = params_val
        if visitor_data and cid != "5":
            payload["context"]["client"]["visitorData"] = visitor_data
        headers = {
            "User-Agent": ua,
            "X-YouTube-Client-Name": cid,
            "X-YouTube-Client-Version": cver,
            "Content-Type": "application/json",
        }
        try:
            req = urllib.request.Request(
                "https://www.youtube.com/youtubei/v1/player?prettyPrint=false",
                data=json.dumps(payload).encode('utf-8'),
                headers=headers,
            )
            with urllib.request.urlopen(req, timeout=7) as resp:
                data = json.loads(resp.read().decode('utf-8'))
            if not visitor_data:
                visitor_data = data.get("responseContext", {}).get("visitorData")
            if check_status and data.get('playabilityStatus', {}).get('status', '') != 'OK':
                continue
            vd = data.get('videoDetails', {})
            live_flag = bool(is_live or vd.get('isLiveContent') or vd.get('isLive'))
            streaming = data.get('streamingData', {})
            url_stream = _pick_url_stream(streaming, ua)
            if prefer_dash and not live_flag:
                mpd_xml = build_dash_mpd(vd, streaming)
                if mpd_xml:
                    return {
                        'kind': 'mpd',
                        'mpd': mpd_xml,
                        'headers': {'User-Agent': ua},
                        'fallback_url': url_stream,
                        'is_live': False,
                    }
                if url_stream and hls_fallback is None:
                    hls_fallback = {'kind': 'url', 'url': url_stream, 'is_live': live_flag}
                continue
            if url_stream:
                return {'kind': 'url', 'url': url_stream, 'is_live': live_flag}
        except Exception:
            continue

    if hls_fallback is not None:
        return hls_fallback

    # Nivel 4: Puente a plugin.video.youtube si estuviera habilitado en Kodi
    try:
        import xbmc
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
            return {'kind': 'url', 'url': f"plugin://plugin.video.youtube/play/?video_id={vid}", 'is_live': bool(is_live)}
    except Exception:
        pass
    return None


def resolve_playback(video_id_or_url, is_live=False):
    """
    Resuelve un vídeo de YouTube para reproducción estable en Kodi:
    - VOD: DASH estático fMP4 (vídeo H.264 + audio AAC) cuando está disponible, con fallback HLS.
    - Directos: HLS adaptativo.
    """
    vid = extract_video_id(video_id_or_url)
    if not vid:
        return None
    return _resolve_with_clients(vid, prefer_dash=not is_live, is_live=is_live)


def resolve(video_id_or_url):
    """
    Resuelve cualquier vídeo de YouTube a su enlace de reproducción nativo en Kodi
    (HLS adaptativo 1080p/720p o MP4 progresivo) con resolución escalonada multinivel.
    """
    vid = extract_video_id(video_id_or_url)
    if not vid:
        return None
    res = _resolve_with_clients(vid, prefer_dash=False, is_live=False)
    return res.get('url') if res else None


def suggest_queries(prefix):
    """Obtiene predicciones y sugerencias de búsqueda en tiempo real de YouTube."""
    if not prefix:
        return []
    encoded = urllib.parse.quote_plus(prefix.strip())
    url = f"https://suggestqueries-clients6.youtube.com/complete/search?client=youtube&hl=es&gl=ES&ds=yt&q={encoded}"
    req = urllib.request.Request(url, headers={"User-Agent": UA_DESKTOP})
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            m = re.search(r"\((\[.*\])\)", raw)
            if m:
                arr = json.loads(m.group(1))
                if len(arr) > 1 and isinstance(arr[1], list):
                    return [item[0] for item in arr[1] if isinstance(item, list) and item and isinstance(item[0], str)]
    except Exception:
        pass
    return []


def _normalize_thumb_url(url):
    """Asegura que las URLs relativas de avatares y carátulas incluyan protocolo https."""
    if not url:
        return ""
    u = str(url).strip()
    if u.startswith('//'):
        return f"https:{u}"
    return u


def _extraer_continuation_token(data):
    """Extrae el token de continuación (paginación) del árbol JSON de InnerTube."""
    token = ""
    def walk_token(o):
        nonlocal token
        if token:
            return
        if isinstance(o, dict):
            if 'continuationCommand' in o:
                t = o['continuationCommand'].get('token')
                if t:
                    token = t
                    return
            for v in o.values():
                walk_token(v)
                if token: return
        elif isinstance(o, list):
            for i in o:
                walk_token(i)
                if token: return
    walk_token(data)
    return token


def search(query="", sp="", continuation="", limit=35, with_token=False):
    """Busca vídeos y playlists en YouTube devolviendo lista limpia y diferenciada."""
    if not query and not continuation:
        return ([], "") if with_token else []

    url = "https://www.youtube.com/youtubei/v1/search?prettyPrint=false"
    headers = {
        "User-Agent": UA_DESKTOP,
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "Accept-Encoding": "gzip"
    }
    payload = {
        "context": {
            "client": {
                "clientName": "WEB",
                "clientVersion": "2.20260115.01.00",
                "hl": "es",
                "gl": "ES"
            }
        }
    }
    if continuation:
        payload["continuation"] = continuation
    else:
        payload["query"] = query
        if sp:
            payload["params"] = sp

    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip' or raw[:2] == b'\x1f\x8b':
                raw = gzip.decompress(raw)
            data = json.loads(raw.decode('utf-8'))
            items = _extraer_videos_innertube(data, limit=limit)
            token = _extraer_continuation_token(data)
            return (items, token) if with_token else items
    except Exception:
        return ([], "") if with_token else []


def _extraer_videos_innertube(data, limit=35):
    """Recorre el árbol JSON de InnerTube y extrae vídeos y playlists distinguidos para la UI."""
    items = []
    vistos = set()

    def walk(o):
        if isinstance(o, dict):
            # 1. Vídeos clásicos (videoRenderer)
            if 'videoRenderer' in o:
                vr = o['videoRenderer']
                vid = vr.get('videoId', '')
                if vid and vid not in vistos and len(vid) == 11:
                    vistos.add(vid)
                    title_runs = vr.get('title', {}).get('runs', [])
                    title = title_runs[0].get('text', '') if title_runs else vr.get('title', {}).get('simpleText', '')
                    thumbs = vr.get('thumbnail', {}).get('thumbnails', [])
                    thumb = _normalize_thumb_url(thumbs[-1].get('url', '')) if thumbs else f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
                    duration = vr.get('lengthText', {}).get('simpleText', '')
                    channel = vr.get('ownerText', {}).get('runs', [{}])[0].get('text', '')
                    views = vr.get('viewCountText', {}).get('simpleText', '')
                    desc_runs = vr.get('detailedMetadataSnippets', [{}])[0].get('snippetText', {}).get('runs', [])
                    desc = desc_runs[0].get('text', '') if desc_runs else ''

                    is_live = False
                    for b in vr.get('badges', []):
                        lbl = b.get('metadataBadgeRenderer', {}).get('label', '').upper()
                        if 'EN DIRECTO' in lbl or 'LIVE' in lbl:
                            is_live = True

                    plot_str = f"Canal: {channel}" if channel else ""
                    if duration:
                        plot_str += f"\nDuración: {duration}"
                    if views:
                        plot_str += f" • {views}"
                    if desc:
                        plot_str += f"\n\n{desc}"

                    disp_title = f"[EN VIVO] {title}" if is_live else title
                    disp_rating = "DIRECTO" if is_live else (duration or "VÍDEO")

                    items.append({
                        'id': vid,
                        'title': disp_title,
                        'url': f"https://www.youtube.com/watch?v={vid}",
                        'cover': thumb,
                        'rating': disp_rating,
                        'plot': plot_str.strip(),
                        'channel': channel,
                        'is_live': is_live
                    })
                    if len(items) >= limit:
                        return

            # 2. Listas de reproducción clásicas (playlistRenderer)
            elif 'playlistRenderer' in o:
                pr = o['playlistRenderer']
                pid = pr.get('playlistId', '')
                if pid and pid not in vistos:
                    vistos.add(pid)
                    title = pr.get('title', {}).get('simpleText', '') or pr.get('title', {}).get('runs', [{}])[0].get('text', '')
                    count = pr.get('videoCountText', {}).get('runs', [{}])[0].get('text', '') or pr.get('videoCountText', {}).get('simpleText', '')
                    thumbs = pr.get('thumbnails', [{}])[0].get('thumbnails', []) if isinstance(pr.get('thumbnails'), list) and pr.get('thumbnails') else []
                    thumb = _normalize_thumb_url(thumbs[-1].get('url', '')) if thumbs else "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80"
                    channel = pr.get('longBylineText', {}).get('runs', [{}])[0].get('text', '')

                    items.append({
                        'id': pid,
                        'title': f"[PLAYLIST] {title}",
                        'url': f"tube://playlist/{pid}",
                        'cover': thumb,
                        'rating': count or "PLAYLIST",
                        'plot': f"Lista de reproducción de YouTube: {title}\nCanal: {channel}\n{count}\n\nPulsa para abrir y ver los vídeos incluidos.",
                        'channel': channel,
                        'is_playlist': True
                    })
                    if len(items) >= limit:
                        return

            # 3. Formato moderno de YouTube (lockupViewModel: vídeos, directos, playlists y canales)
            elif 'lockupViewModel' in o:
                lvm = o['lockupViewModel']
                ct = lvm.get('contentType', '')
                cid = lvm.get('contentId', '')
                meta = lvm.get('metadata', {}).get('lockupMetadataViewModel', {})
                title = meta.get('title', {}).get('content', '')

                img_sources = (
                    lvm.get('contentImage', {}).get('thumbnailViewModel', {}).get('image', {}).get('sources', [])
                    or lvm.get('contentImage', {}).get('collectionThumbnailViewModel', {}).get('primaryThumbnail', {}).get('thumbnailViewModel', {}).get('image', {}).get('sources', [])
                )
                raw_thumb = img_sources[-1].get('url', '') if img_sources else ""
                thumb = _normalize_thumb_url(raw_thumb)

                channel = ""
                rows = lvm.get('metadata', {}).get('contentMetadataViewModel', {}).get('metadataRows', [])
                if rows:
                    parts = rows[0].get('metadataParts', [])
                    if parts:
                        channel = parts[0].get('text', {}).get('content', '')

                # Es una Playlist en lockupViewModel
                if ct == 'LOCKUP_CONTENT_TYPE_PLAYLIST' or cid.startswith('PL') or cid.startswith('VL') or cid.startswith('RD') or cid.startswith('OLAK5uy_'):
                    if cid and cid not in vistos:
                        vistos.add(cid)
                        count_txt = "PLAYLIST"
                        if len(rows) > 1:
                            c_parts = rows[1].get('metadataParts', [])
                            if c_parts:
                                count_txt = c_parts[0].get('text', {}).get('content', 'PLAYLIST')

                        items.append({
                            'id': cid,
                            'title': f"[PLAYLIST] {title}",
                            'url': f"tube://playlist/{cid}",
                            'cover': thumb or "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80",
                            'rating': count_txt,
                            'plot': f"Lista de reproducción de YouTube: {title}\nCanal: {channel}\n\nPulsa para abrir y ver los vídeos incluidos.",
                            'channel': channel,
                            'is_playlist': True
                        })
                        if len(items) >= limit:
                            return

                # Es un Canal en lockupViewModel
                elif ct == 'LOCKUP_CONTENT_TYPE_CHANNEL' or (cid.startswith('UC') and len(cid) == 24):
                    if cid and cid not in vistos:
                        vistos.add(cid)
                        items.append({
                            'id': cid,
                            'title': f"[CANAL] {title}",
                            'url': f"tube://channel/{cid}",
                            'cover': thumb or "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&h=450&fit=crop&q=80",
                            'rating': "CANAL",
                            'plot': f"Canal de YouTube: {title}\nPulsa para ver sus vídeos más recientes.",
                            'channel': title,
                            'is_channel': True
                        })
                        if len(items) >= limit:
                            return

                # Es un Vídeo individual en lockupViewModel
                elif len(cid) == 11:
                    if cid not in vistos:
                        vistos.add(cid)
                        dur = 'VÍDEO'
                        is_live = False
                        try:
                            for ov in lvm.get('contentImage', {}).get('thumbnailViewModel', {}).get('overlays', []):
                                for b in ov.get('thumbnailBottomOverlayViewModel', {}).get('badges', []) or []:
                                    badge_txt = b.get('thumbnailBadgeViewModel', {}).get('text', '')
                                    b_style = b.get('thumbnailBadgeViewModel', {}).get('badgeStyle', '')
                                    if 'LIVE' in b_style or badge_txt in ('DIRECTO', 'EN DIRECTO', 'LIVE'):
                                        is_live = True
                                        dur = 'DIRECTO'
                                    elif badge_txt:
                                        dur = badge_txt
                        except Exception:
                            pass

                        disp_title = f"[EN VIVO] {title}" if is_live else title
                        disp_rating = "DIRECTO" if is_live else dur

                        plot_lines = []
                        if channel:
                            plot_lines.append(f"Canal: {channel}")
                        if dur:
                            plot_lines.append(f"Duración: {dur}")
                        plot_str = '\n'.join(plot_lines)

                        items.append({
                            'id': cid,
                            'title': disp_title,
                            'url': f"https://www.youtube.com/watch?v={cid}",
                            'cover': thumb or f"https://i.ytimg.com/vi/{cid}/hqdefault.jpg",
                            'rating': disp_rating,
                            'plot': plot_str,
                            'channel': channel,
                            'is_live': is_live
                        })
                        if len(items) >= limit:
                            return

            # 4. Canales clásicos (channelRenderer)
            elif 'channelRenderer' in o:
                cr = o['channelRenderer']
                cid = cr.get('channelId', '')
                if cid and cid not in vistos:
                    vistos.add(cid)
                    title = cr.get('title', {}).get('simpleText', '') or cr.get('title', {}).get('runs', [{}])[0].get('text', '')
                    subs = cr.get('subscriberCountText', {}).get('simpleText', '')
                    desc = cr.get('descriptionSnippet', {}).get('runs', [{}])[0].get('text', '')
                    thumbs = cr.get('thumbnail', {}).get('thumbnails', []) or cr.get('avatar', {}).get('thumbnails', [])
                    raw_thumb = thumbs[-1].get('url', '') if thumbs else "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&h=450&fit=crop&q=80"
                    thumb = _normalize_thumb_url(raw_thumb)

                    items.append({
                        'id': cid,
                        'title': f"[CANAL] {title}",
                        'url': f"tube://channel/{cid}",
                        'cover': thumb,
                        'rating': subs or "CANAL",
                        'plot': f"Canal de YouTube: {title}\n{subs}\n\n{desc}\n\nPulsa para ver sus vídeos más recientes.",
                        'channel': title,
                        'is_channel': True
                    })
                    if len(items) >= limit:
                        return

            for v in o.values():
                walk(v)
                if len(items) >= limit:
                    return
        elif isinstance(o, list):
            for i in o:
                walk(i)
                if len(items) >= limit:
                    return

    walk(data)
    return items


def get_channel_videos(channel_id, limit=35):
    """Obtiene los vídeos más recientes de un canal de YouTube vía InnerTube browse."""
    if not channel_id:
        return "", []

    cid = str(channel_id).strip()
    if cid.startswith('tube://channel/'):
        cid = cid.split('tube://channel/')[-1].strip()

    url = "https://www.youtube.com/youtubei/v1/browse?prettyPrint=false"
    headers = {
        "User-Agent": UA_DESKTOP,
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "Accept-Encoding": "gzip"
    }
    payload = {
        "context": {
            "client": {
                "clientName": "WEB",
                "clientVersion": "2.20260115.01.00",
                "hl": "es",
                "gl": "ES"
            }
        },
        "browseId": cid,
        "params": "EgZ2aWRlb3PyBgQKAjoA"
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip' or raw[:2] == b'\x1f\x8b':
                raw = gzip.decompress(raw)
            data = json.loads(raw.decode('utf-8'))
    except Exception:
        return "", []

    ch_name = data.get('header', {}).get('pageHeaderRenderer', {}).get('pageTitle', '')
    if not ch_name:
        ch_name = data.get('metadata', {}).get('channelMetadataRenderer', {}).get('title', '')
    if not ch_name:
        ch_name = data.get('header', {}).get('c4TabbedHeaderRenderer', {}).get('title', '')

    videos = _extraer_videos_innertube(data, limit=limit)
    if not videos:
        try:
            payload.pop('params', None)
            req2 = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
            with urllib.request.urlopen(req2, timeout=8) as resp2:
                raw2 = resp2.read()
                if resp2.headers.get('Content-Encoding') == 'gzip' or raw2[:2] == b'\x1f\x8b':
                    raw2 = gzip.decompress(raw2)
                data2 = json.loads(raw2.decode('utf-8'))
                videos = _extraer_videos_innertube(data2, limit=limit)
                if not ch_name:
                    ch_name = data2.get('header', {}).get('pageHeaderRenderer', {}).get('pageTitle', '') or data2.get('metadata', {}).get('channelMetadataRenderer', {}).get('title', '')
        except Exception:
            pass

    return ch_name, videos


def get_category_videos(cat_key, continuation="", limit=35, with_token=False):
    """Devuelve vídeos destacados para una categoría temática de YouTube."""
    queries = {
        'trending': 'tendencias videos populares espana latinoamerica',
        'trailers': 'trailers oficiales peliculas estrenos cine 2026',
        'music': 'top canciones musica oficial videoclips',
        'gaming': 'gameplay videojuegos resumen',
        'podcasts': 'podcast entrevistas completo en espanol',
        'docs': 'documentales completos en espanol ciencia historia',
    }
    q = queries.get(cat_key, cat_key)
    return search(q, continuation=continuation, limit=limit, with_token=with_token)


POPULAR_PLAYLISTS = [
    {
        'id': 'PLc6y_bIejLFGLonpdNAsbL4ZDUE6GFBPR',
        'title': 'Grand Prix del Verano - Programas Completos',
        'cover': 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=450&fit=crop&q=80',
        'plot': 'Colección oficial de programas, juegos y mejores momentos del Grand Prix del Verano.'
    },
    {
        'id': 'PLFgquLnL59alW3xmYiWRaoz0oM3H17L-x',
        'title': 'Éxitos España y Latino América',
        'cover': 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=450&fit=crop&q=80',
        'plot': 'Lista de reproducción con las canciones y videoclips más escuchados de la actualidad.'
    },
    {
        'id': 'PLDIoUOhQQPlXr337SZtDc8n4W-tR9g17l',
        'title': 'Tráilers de Cine y Estrenos 2026',
        'cover': 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&h=450&fit=crop&q=80',
        'plot': 'Los últimos avances oficiales y tráilers cinematográficos en resolución HD/4K.'
    },
    {
        'id': 'PLwAXiRCBg3hL0PGFc5IULbxzvwzsgAh9h',
        'title': 'Grandes Documentales en Español',
        'cover': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop&q=80',
        'plot': 'Selección de documentales completos sobre historia, ciencia, universo y naturaleza.'
    }
]


def extract_playlist_id(url_or_id):
    """Extrae el identificador de una lista de reproducción de YouTube."""
    if not url_or_id:
        return ""
    s = str(url_or_id).strip()
    if s.startswith('tube://playlist/'):
        s = s.split('tube://playlist/')[-1].strip()
    m = re.search(r'[?&]list=([A-Za-z0-9_-]+)', s)
    if m:
        return m.group(1)
    if re.match(r'^(PL|VLPL|UU|FL|RD|OLAK5uy_)[A-Za-z0-9_-]+$', s, re.IGNORECASE):
        return s
    if len(s) >= 8 and not any(c in s for c in ('/', '?', '&', ' ', '=')):
        return s
    return s


def get_playlist_videos(list_id_or_url, limit=50):
    """Obtiene los vídeos y metadatos de una lista de reproducción de YouTube vía InnerTube."""
    list_id = extract_playlist_id(list_id_or_url)
    if not list_id:
        return "", []

    url = "https://www.youtube.com/youtubei/v1/browse?prettyPrint=false"
    headers = {
        "User-Agent": UA_DESKTOP,
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "Accept-Encoding": "gzip"
    }
    bid = list_id if list_id.startswith("VL") else f"VL{list_id}"
    payload = {
        "context": {
            "client": {
                "clientName": "WEB",
                "clientVersion": "2.20260115.01.00",
                "hl": "es",
                "gl": "ES"
            }
        },
        "browseId": bid
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
    data = None
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip' or raw[:2] == b'\x1f\x8b':
                raw = gzip.decompress(raw)
            data = json.loads(raw.decode('utf-8'))
    except Exception:
        pass

    if not data or not data.get('contents'):
        try:
            payload["browseId"] = list_id
            req2 = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
            with urllib.request.urlopen(req2, timeout=8) as resp2:
                raw2 = resp2.read()
                if resp2.headers.get('Content-Encoding') == 'gzip' or raw2[:2] == b'\x1f\x8b':
                    raw2 = gzip.decompress(raw2)
                data = json.loads(raw2.decode('utf-8'))
        except Exception:
            if not data:
                return "", []

    if not data:
        return "", []

    pl_title = data.get('metadata', {}).get('playlistMetadataRenderer', {}).get('title', '')
    if not pl_title:
        header = data.get('header', {})
        pl_h = header.get('pageHeaderRenderer') or header.get('playlistHeaderRenderer')
        if pl_h:
            pl_title = pl_h.get('pageTitle') or pl_h.get('title', {}).get('simpleText', '')

    videos = []
    vistos = set()

    def parse_lockup(lv):
        vid = lv.get('contentId', '')
        if not vid or vid in vistos or len(vid) != 11:
            return None
        vistos.add(vid)
        title = lv.get('metadata', {}).get('lockupMetadataViewModel', {}).get('title', {}).get('content', '')
        thumbs = lv.get('contentImage', {}).get('thumbnailViewModel', {}).get('image', {}).get('sources', [])
        thumb = thumbs[-1].get('url', '') if thumbs else f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
        dur = 'VÍDEO'
        try:
            for ov in lv.get('contentImage', {}).get('thumbnailViewModel', {}).get('overlays', []):
                for b in ov.get('thumbnailBottomOverlayViewModel', {}).get('badges', []) or []:
                    badge_txt = b.get('thumbnailBadgeViewModel', {}).get('text')
                    if badge_txt:
                        dur = badge_txt
        except Exception:
            pass
        rows = lv.get('metadata', {}).get('contentMetadataViewModel', {}).get('metadataRows', [])
        channel = ''
        if rows:
            channel = rows[0].get('metadataParts', [{}])[0].get('text', {}).get('content', '')
        return {
            'id': vid,
            'title': title or f"Vídeo {vid}",
            'url': f"https://www.youtube.com/watch?v={vid}",
            'cover': thumb,
            'rating': dur,
            'plot': f"Canal: {channel}\nDuración: {dur}" if channel else f"Duración: {dur}",
            'channel': channel
        }

    def walk(o):
        if isinstance(o, dict):
            if 'lockupViewModel' in o:
                v = parse_lockup(o['lockupViewModel'])
                if v:
                    videos.append(v)
                    if len(videos) >= limit:
                        return
            elif 'playlistVideoRenderer' in o:
                vr = o['playlistVideoRenderer']
                vid = vr.get('videoId', '')
                if vid and vid not in vistos and len(vid) == 11:
                    vistos.add(vid)
                    title = vr.get('title', {}).get('runs', [{}])[0].get('text', '') or vr.get('title', {}).get('simpleText', '')
                    dur = vr.get('lengthText', {}).get('simpleText', 'VÍDEO')
                    channel = vr.get('shortBylineText', {}).get('runs', [{}])[0].get('text', '')
                    videos.append({
                        'id': vid,
                        'title': title or f"Vídeo {vid}",
                        'url': f"https://www.youtube.com/watch?v={vid}",
                        'cover': f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                        'rating': dur,
                        'plot': f"Canal: {channel}\nDuración: {dur}" if channel else f"Duración: {dur}",
                        'channel': channel
                    })
                    if len(videos) >= limit:
                        return
            for v in o.values():
                walk(v)
                if len(videos) >= limit:
                    return
        elif isinstance(o, list):
            for i in o:
                walk(i)
                if len(videos) >= limit:
                    return

    walk(data)
    return pl_title, videos
