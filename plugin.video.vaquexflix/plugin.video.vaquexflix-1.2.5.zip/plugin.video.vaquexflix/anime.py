# -*- coding: utf-8 -*-
"""Motor especializado de Anime para Vaquexflix.

Integra catalogos, busquedas, simulcasts (ultimos episodios) y resolucion
multi-fuente de anime en espanol a partir de las 5 fuentes identificadas en Neko Player PC:
1. TioAnime (https://tioanime.com)
2. AnimeFLV Mirror (https://animeflv.or.at)
3. AnimeAV1 (https://animeav1.com)
4. JKAnime (https://jkanime.net)
5. MonosChinos (https://vww.monoschinos2.net)
"""

from __future__ import annotations
import base64
import html
import http.cookiejar
import json
import re
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import network
import resolvers

# Cabeceras y constantes base
ANIME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
TIOANIME_BASE = 'https://tioanime.com'
ANIMEFLV_BASE = 'https://animeflv.or.at'
ANIMEAV1_BASE = 'https://animeav1.com'
JKANIME_BASE = 'https://jkanime.net'
MONOSCHINOS_BASE = 'https://vww.monoschinos2.net'
LATANIME_BASE = 'https://latanime.org'


def latanime_listado(path: str) -> list[dict]:
    """Lee fichas publicadas sin atribuir calidad a sus servidores."""
    page = _hacer_peticion(urllib.parse.urljoin(LATANIME_BASE, path), referer=LATANIME_BASE)
    items = []
    seen = set()
    for url, card in re.findall(
            r'<a\b[^>]*href=["\'](https://latanime\.org/anime/[^"\']+)["\'][^>]*>(.*?)</a>',
            page, re.I | re.S):
        if url in seen:
            continue
        title = re.search(r'<h3\b[^>]*>(.*?)</h3>', card, re.I | re.S)
        if not title:
            continue
        image = re.search(r'<img\b[^>]*(?:data-src|src)=["\']([^"\']+)', card, re.I)
        clean_title = html.unescape(re.sub(r'<[^>]+>', '', title.group(1))).strip()
        if not clean_title:
            continue
        seen.add(url)
        items.append({'title': clean_title, 'url': url,
                      'cover': urllib.parse.urljoin(LATANIME_BASE, image.group(1)) if image else '',
                      'source': 'Latanime', 'section': 'animes', 'is_serie': True})
    return items


def latanime_buscar(query: str) -> list[dict]:
    return latanime_listado('/buscar?' + urllib.parse.urlencode({'q': query}))


def latanime_directorio(number: int = 1) -> list[dict]:
    return latanime_listado('/animes?' + urllib.parse.urlencode({'page': number}))


def latanime_episodios(anime_url: str) -> list[dict]:
    page = _hacer_peticion(anime_url, referer=LATANIME_BASE)
    if not page:
        return []
    cover_match = re.search(r'<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+)', page)
    title_match = re.search(r'<meta\s+property=["\']og:title["\']\s+content=["\']([^"\']+)', page)
    title = html.unescape(title_match.group(1)).split(' — ')[0] if title_match else 'Anime'
    cover = cover_match.group(1) if cover_match else ''
    found = {}
    for url, number in re.findall(
            r'href=["\'](https://latanime\.org/ver/[^"\']+-episodio-(\d+))["\']', page, re.I):
        found.setdefault(int(number), {'title': f'{title} - Episodio {number}',
                                       'url': url, 'episode_num': number, 'episode': int(number),
                                       'season': 1, 'cover': cover, 'thumb': cover,
                                       'source': 'Latanime', 'section': 'animes',
                                       'is_serie': True, 'is_episode': True})
    return [found[key] for key in sorted(found)]


def latanime_servidores(episode_url: str) -> list[dict]:
    page = _hacer_peticion(episode_url, referer=LATANIME_BASE)
    if not page:
        raise network.ServidorNoDisponible('Latanime no respondió al consultar este episodio.')
    servers = []
    seen = set()
    for encoded, name in re.findall(r'<a\b[^>]*class=["\'][^"\']*\bplay-video\b[^"\']*["\'][^>]*data-player=["\']([^"\']+)["\'][^>]*>(.*?)</a>', page, re.I | re.S):
        try:
            url = base64.b64decode(encoded + '=' * (-len(encoded) % 4), validate=True).decode('utf-8').strip()
        except (ValueError, UnicodeError):
            continue
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ('https', 'http') or not parsed.hostname or url in seen:
            continue
        seen.add(url)
        label = html.unescape(re.sub(r'<[^>]+>', '', name)).strip() or parsed.hostname
        servers.append({'nombre': f'{label} [Latanime]', 'url': url,
                        'calidad': 'Sin verificar', 'servidor': label.lower()})
    return servers

# Cookie jar compartido para sesiones que lo requieran (ej. JKAnime Laravel CSRF)
_jk_cookie_jar = http.cookiejar.CookieJar()
_jk_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jk_cookie_jar))


def _hacer_peticion(url: str, referer: str = '', data: bytes | None = None,
                    headers_extra: dict | None = None, timeout: int = 10,
                    use_jk_session: bool = False) -> str:
    """Realiza una peticion HTTP con cabeceras de navegador y timeout estricto."""
    headers = {
        'User-Agent': ANIME_UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
    }
    if referer:
        headers['Referer'] = referer
    if headers_extra:
        headers.update(headers_extra)
    try:
        req = urllib.request.Request(url, data=data, headers=headers)
        opener = _jk_opener if use_jk_session else urllib.request.build_opener()
        with opener.open(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', 'replace')
    except Exception as exc:
        network.log_resolver(f'anime.py: error al consultar {url} -> {exc}')
        return ''


def normalizar_titulo(titulo: str) -> str:
    """Normaliza el titulo para agrupacion y comparacion eliminando caracteres especiales."""
    t = titulo.lower()
    t = re.sub(r'[\(\[\{].*?[\)\]\}]', '', t)
    t = re.sub(r'[^a-z0-9\s]', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


# ============================================================================
# 1. SCRAPER TIOANIME (https://tioanime.com)
# ============================================================================

def tioanime_ultimos_episodios() -> list[dict]:
    """Obtiene los ultimos episodios en emision (simulcasts) de la portada de TioAnime."""
    page = _hacer_peticion(TIOANIME_BASE, referer=TIOANIME_BASE)
    if not page:
        return []

    articulos = re.findall(r'<article class="episode">[\s\S]*?</article>', page)
    episodios = []
    for art in articulos:
        m_link = re.search(r'<a href="(/ver/[^"]+)"', art)
        m_thumb = re.search(r'<img src="([^"]+)"', art)
        m_title = re.search(r'<h3 class="title">([^<]+)</h3>', art)

        if not (m_link and m_title):
            continue

        raw_title = html.unescape(m_title.group(1).strip())
        link = urllib.parse.urljoin(TIOANIME_BASE, m_link.group(1))
        thumb = urllib.parse.urljoin(TIOANIME_BASE, m_thumb.group(1)) if m_thumb else ''

        m_num = re.search(r'^(.*?)\s+(\d+(?:\.\d+)?)$', raw_title)
        if m_num:
            anime_nombre = m_num.group(1).strip()
            ep_num = m_num.group(2)
        else:
            anime_nombre = raw_title
            ep_num = '1'

        episodios.append({
            'title': f'{anime_nombre} - Episodio {ep_num}',
            'anime_title': anime_nombre,
            'episode_num': ep_num,
            'episode': int(float(ep_num)) if ep_num.replace('.', '', 1).isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'TioAnime',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    return episodios


def tioanime_buscar(query: str) -> list[dict]:
    """Busca animes en TioAnime por nombre."""
    q_enc = urllib.parse.quote_plus(query)
    url = f'{TIOANIME_BASE}/directorio?q={q_enc}'
    page = _hacer_peticion(url, referer=TIOANIME_BASE)
    if not page:
        return []

    articulos = re.findall(r'<article class="anime">[\s\S]*?</article>', page)
    resultados = []
    for art in articulos:
        m_link = re.search(r'<a href="(/anime/[^"]+)"', art)
        m_thumb = re.search(r'<img src="([^"]+)"', art)
        m_title = re.search(r'<h3 class="title">([^<]+)</h3>', art)
        m_badge = re.search(r'<span class="badge[^"]*">([^<]+)</span>', art)

        if not (m_link and m_title):
            continue

        titulo = html.unescape(m_title.group(1).strip())
        link = urllib.parse.urljoin(TIOANIME_BASE, m_link.group(1))
        thumb = urllib.parse.urljoin(TIOANIME_BASE, m_thumb.group(1)) if m_thumb else ''
        badge = m_badge.group(1).strip() if m_badge else 'Anime'

        resultados.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'badge': badge,
            'source': 'TioAnime',
            'is_serie': True,
            'section': 'animes'
        })
    return resultados


def tioanime_directorio(pagina: int = 1) -> list[dict]:
    """Obtiene el catalogo general paginado de TioAnime."""
    url = f'{TIOANIME_BASE}/directorio?p={pagina}'
    page = _hacer_peticion(url, referer=TIOANIME_BASE)
    if not page:
        return []

    articulos = re.findall(r'<article class="anime">[\s\S]*?</article>', page)
    items = []
    for art in articulos:
        m_link = re.search(r'<a href="(/anime/[^"]+)"', art)
        m_thumb = re.search(r'<img src="([^"]+)"', art)
        m_title = re.search(r'<h3 class="title">([^<]+)</h3>', art)
        m_badge = re.search(r'<span class="badge[^"]*">([^<]+)</span>', art)

        if not (m_link and m_title):
            continue

        titulo = html.unescape(m_title.group(1).strip())
        link = urllib.parse.urljoin(TIOANIME_BASE, m_link.group(1))
        thumb = urllib.parse.urljoin(TIOANIME_BASE, m_thumb.group(1)) if m_thumb else ''
        badge = m_badge.group(1).strip() if m_badge else 'Anime'

        items.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'badge': badge,
            'source': 'TioAnime',
            'is_serie': True,
            'section': 'animes'
        })
    return items


def tioanime_episodios(anime_url: str) -> list[dict]:
    """Extrae la lista de episodios de una serie en TioAnime."""
    page = _hacer_peticion(anime_url, referer=TIOANIME_BASE)
    if not page:
        return []

    m_title = re.search(r'<h1 class="title">([^<]+)</h1>', page)
    anime_title = html.unescape(m_title.group(1).strip()) if m_title else 'Anime'

    m_cover = re.search(r'<div class="thumb">\s*<img src="([^"]+)"', page)
    cover_base = urllib.parse.urljoin(TIOANIME_BASE, m_cover.group(1)) if m_cover else ''

    m_plot = re.search(r'<p class="sinopsis">([\s\S]*?)</p>', page)
    plot = html.unescape(re.sub(r'<[^>]+>', ' ', m_plot.group(1)).strip()) if m_plot else ''

    slug_match = re.search(r'/anime/([^/?#]+)', anime_url)
    slug = slug_match.group(1) if slug_match else ''

    m_eps = re.search(r'var\s+episodes\s*=\s*(\[[\s\S]*?\]);', page)
    episodios = []
    if m_eps:
        try:
            raw_eps = json.loads(m_eps.group(1))
            raw_eps.sort(key=lambda x: float(x) if str(x).replace('.', '', 1).isdigit() else 0)
            for ep_num in raw_eps:
                ep_str = str(ep_num)
                ep_url = f'{TIOANIME_BASE}/ver/{slug}-{ep_str}'
                thumb_ep = f'{TIOANIME_BASE}/uploads/thumbs/{slug}-{ep_str}.jpg'
                episodios.append({
                    'title': f'{anime_title} - Episodio {ep_str}',
                    'anime_title': anime_title,
                    'episode_num': ep_str,
                    'episode': int(float(ep_str)) if ep_str.replace('.', '', 1).isdigit() else 1,
                    'season': 1,
                    'url': ep_url,
                    'thumb': thumb_ep,
                    'cover': thumb_ep or cover_base,
                    'plot': plot,
                    'source': 'TioAnime',
                    'is_serie': True,
                    'is_episode': True,
                    'section': 'animes'
                })
        except Exception:
            pass
    return episodios


def tioanime_servidores(episodio_url: str) -> list[dict]:
    """Extrae los enlaces a servidores de video de un episodio en TioAnime."""
    page = _hacer_peticion(episodio_url, referer=TIOANIME_BASE)
    if not page:
        return []

    m = re.search(r'var\s+videos\s*=\s*(\[[\s\S]*?\]);', page)
    servidores = []
    if m:
        try:
            videos = json.loads(m.group(1))
            for v in videos:
                if isinstance(v, list) and len(v) >= 2:
                    srv_name = str(v[0]).strip()
                    srv_url = str(v[1]).strip()
                    if srv_url.startswith('//'):
                        srv_url = 'https:' + srv_url

                    servidores.append({
                        'nombre': f'{srv_name} [TioAnime]',
                        'url': srv_url,
                        'calidad': 'Sin verificar',
                        'servidor': srv_name.lower()
                    })
        except Exception:
            pass
    return servidores


# ============================================================================
# 2. SCRAPER ANIMEFLV MIRROR (https://animeflv.or.at)
# ============================================================================

def animeflv_ultimos_episodios() -> list[dict]:
    """Obtiene los ultimos episodios en emision de AnimeFLV Mirror con caratulas."""
    page = _hacer_peticion(ANIMEFLV_BASE, referer=ANIMEFLV_BASE)
    if not page:
        return []

    ep_blocks = re.findall(r'<div class="Episode">[\s\S]*?</h2>', page)
    vistos = set()
    episodios = []
    for block in ep_blocks:
        m_link = re.search(r'href="(https?://animeflv\.or\.at/\d{4}/\d{2}/\d{2}/([^"/]+)-episodio-(\d+)/?)"', block)
        m_thumb = re.search(r'src="(https?://animeflv\.or\.at/wp-content/uploads/[^"]+)"', block)
        m_title = re.search(r'<h2 class="Title">([^<]+)</h2>', block)

        if not m_link:
            continue

        link = m_link.group(1)
        if link in vistos:
            continue
        vistos.add(link)

        raw_slug = m_link.group(2)
        ep_num = m_link.group(3)
        anime_title = m_title.group(1).replace(f'Episodio {ep_num}', '').strip(' :-') if m_title else raw_slug.replace('-', ' ').title()
        thumb = m_thumb.group(1) if m_thumb else ''

        episodios.append({
            'title': f'{anime_title} - Episodio {ep_num}',
            'anime_title': anime_title,
            'episode_num': ep_num,
            'episode': int(ep_num) if ep_num.isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'AnimeFLV',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    return episodios


def animeflv_buscar(query: str) -> list[dict]:
    """Busca animes en AnimeFLV Mirror."""
    q_enc = urllib.parse.quote_plus(query)
    url = f'{ANIMEFLV_BASE}/?s={q_enc}'
    page = _hacer_peticion(url, referer=ANIMEFLV_BASE)
    if not page:
        return []

    cards = re.findall(r'<article[^>]*class="[^"]*Anime[^"]*"[^>]*>[\s\S]*?</article>', page)
    resultados = []
    vistos = set()
    for card in cards:
        m_link = re.search(r'<a[^>]+href="(https?://animeflv\.or\.at/anime/[^"/]+/?)"', card)
        m_title = re.search(r'<h3[^>]*class="Title"[^>]*>([^<]+)</h3>', card)
        m_img = re.search(r'<img[^>]+src="([^"]+)"', card)

        if not (m_link and m_title):
            continue

        link = m_link.group(1)
        if link in vistos:
            continue
        vistos.add(link)

        titulo = html.unescape(m_title.group(1).strip())
        thumb = m_img.group(1) if m_img else ''

        resultados.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'AnimeFLV',
            'is_serie': True,
            'section': 'animes'
        })
    return resultados


def animeflv_directorio(pagina: int = 1) -> list[dict]:
    """Obtiene el catalogo general paginado de AnimeFLV Mirror."""
    url = f'{ANIMEFLV_BASE}/anime/page/{pagina}/' if pagina > 1 else f'{ANIMEFLV_BASE}/anime/'
    page = _hacer_peticion(url, referer=ANIMEFLV_BASE)
    if not page:
        return []

    cards = re.findall(r'<article[^>]*class="[^"]*Anime[^"]*"[^>]*>[\s\S]*?</article>', page)
    items = []
    vistos = set()
    for card in cards:
        m_link = re.search(r'<a[^>]+href="(https?://animeflv\.or\.at/anime/[^"/]+/?)"', card)
        m_title = re.search(r'<h3[^>]*class="Title"[^>]*>([^<]+)</h3>', card)
        m_img = re.search(r'<img[^>]+src="([^"]+)"', card)

        if not (m_link and m_title):
            continue

        link = m_link.group(1)
        if link in vistos:
            continue
        vistos.add(link)

        titulo = html.unescape(m_title.group(1).strip())
        thumb = m_img.group(1) if m_img else ''

        items.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'AnimeFLV',
            'is_serie': True,
            'section': 'animes'
        })
    return items


def animeflv_episodios(anime_url: str) -> list[dict]:
    """Extrae la lista de episodios de una serie en AnimeFLV Mirror."""
    page = _hacer_peticion(anime_url, referer=ANIMEFLV_BASE)
    if not page:
        return []

    m_title = re.search(r'<h1 class="Title">([^<]+)</h1>', page)
    anime_title = html.unescape(m_title.group(1).strip()) if m_title else 'Anime'

    m_cover = re.search(r'<figure class="Image">\s*<img[^>]+src="([^"]+)"', page)
    cover_base = m_cover.group(1) if m_cover else ''

    m_plot = re.search(r'<div class="Description">\s*<p>([\s\S]*?)</p>', page)
    plot = html.unescape(m_plot.group(1).strip()) if m_plot else ''

    m_data = re.search(r'var\s+anime_episodes\s*=\s*(\[[\s\S]*?\]);', page)
    episodios = []
    if m_data:
        try:
            eps_info = json.loads(m_data.group(1))
            eps_info.sort(key=lambda x: int(x[0]) if isinstance(x, list) and str(x[0]).isdigit() else 0)
            for ep_item in eps_info:
                if isinstance(ep_item, list) and len(ep_item) >= 2:
                    ep_num = str(ep_item[0])
                    ep_link = ep_item[1]
                    episodios.append({
                        'title': f'{anime_title} - Episodio {ep_num}',
                        'anime_title': anime_title,
                        'episode_num': ep_num,
                        'episode': int(ep_num) if ep_num.isdigit() else 1,
                        'season': 1,
                        'url': ep_link,
                        'thumb': cover_base,
                        'cover': cover_base,
                        'plot': plot,
                        'source': 'AnimeFLV',
                        'is_serie': True,
                        'is_episode': True,
                        'section': 'animes'
                    })
        except Exception:
            pass
    return episodios


def animeflv_servidores(episodio_url: str) -> list[dict]:
    """Extrae los enlaces a servidores de video de AnimeFLV Mirror decodificando Base64."""
    page = _hacer_peticion(episodio_url, referer=ANIMEFLV_BASE)
    if not page:
        return []

    # Extraer data-src codificados en Base64 de botones server_btn
    raw_b64s = re.findall(r'<button[^>]*data-src="([A-Za-z0-9+/=]{10,})"', page)
    servidores = []
    vistos = set()
    for b64_str in raw_b64s:
        try:
            raw_url = base64.b64decode(b64_str).decode('utf-8').strip()
            if not raw_url.startswith(('http://', 'https://')) or raw_url in vistos:
                continue
            vistos.add(raw_url)

            host = urllib.parse.urlsplit(raw_url).netloc.lower()
            if 'zilla-networks' in host:
                srv_tag = 'Zilla Networks (HLS)'
                calidad = '1080p'
            elif 'voe' in host:
                srv_tag = 'VOE'
                calidad = '1080p'
            elif 'mp4upload' in host:
                srv_tag = 'MP4Upload'
                calidad = '720p'
            elif 'byselapuix' in host or 'vidhide' in host:
                srv_tag = 'VidHide'
                calidad = '720p'
            else:
                srv_tag = host.replace('www.', '').capitalize()
                calidad = 'HD'

            servidores.append({
                'nombre': f'{srv_tag} [AnimeFLV]',
                'url': raw_url,
                'calidad': calidad,
                'servidor': srv_tag.lower()
            })
        except Exception:
            continue
    return servidores


# ============================================================================
# 3. SCRAPER ANIMEAV1 (https://animeav1.com)
# ============================================================================

def animeav1_ultimos_episodios() -> list[dict]:
    """Obtiene los ultimos episodios emitidos de la portada de AnimeAV1."""
    page = _hacer_peticion(ANIMEAV1_BASE, referer=ANIMEAV1_BASE)
    if not page:
        return []

    # Enlaces tipo href="(/media/slug/ep_num)"
    m_eps = re.findall(r'href="(/media/([^"/]+)/(\d+))"', page)
    vistos = set()
    episodios = []
    for rel_url, raw_slug, ep_num in m_eps:
        link = f'{ANIMEAV1_BASE}{rel_url}'
        if link in vistos:
            continue
        vistos.add(link)

        anime_title = raw_slug.replace('-', ' ').title()
        # Captura de cover o backdrop generico de AnimeAV1
        thumb = f'https://cdn.animeav1.com/covers/{raw_slug}.jpg'

        episodios.append({
            'title': f'{anime_title} - Episodio {ep_num}',
            'anime_title': anime_title,
            'episode_num': ep_num,
            'episode': int(ep_num) if ep_num.isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'AnimeAV1',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    return episodios


def animeav1_buscar(query: str) -> list[dict]:
    """Busca animes en el catalogo de AnimeAV1."""
    q_enc = urllib.parse.quote_plus(query)
    url = f'{ANIMEAV1_BASE}/catalogo?search={q_enc}'
    page = _hacer_peticion(url, referer=f'{ANIMEAV1_BASE}/catalogo')
    if not page:
        return []

    articles = re.findall(r'<article[^>]*>[\s\S]*?</article>', page)
    resultados = []
    vistos = set()
    for art in articles:
        m_link = re.search(r'href="(/media/([^"/?#]+))"', art)
        m_img = re.search(r'<img[^>]+src="([^"]+)"', art)
        m_title = re.search(r'<h3[^>]*>([^<]+)</h3>', art)
        m_plot = re.search(r'<p[^>]*class="[^"]*line-clamp[^"]*"[^>]*>([^<]+)</p>', art)

        if not (m_link and m_title):
            continue

        rel_link = m_link.group(1)
        link = f'{ANIMEAV1_BASE}{rel_link}'
        if link in vistos:
            continue
        vistos.add(link)

        titulo = html.unescape(m_title.group(1).strip())
        thumb = m_img.group(1) if m_img else ''
        plot = html.unescape(m_plot.group(1).strip()) if m_plot else ''

        resultados.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'plot': plot,
            'source': 'AnimeAV1',
            'is_serie': True,
            'section': 'animes'
        })
    return resultados


def animeav1_directorio(pagina: int = 1) -> list[dict]:
    """Obtiene el catalogo general paginado de AnimeAV1."""
    url = f'{ANIMEAV1_BASE}/catalogo?page={pagina}' if pagina > 1 else f'{ANIMEAV1_BASE}/catalogo'
    page = _hacer_peticion(url, referer=ANIMEAV1_BASE)
    if not page:
        return []

    articles = re.findall(r'<article[^>]*>[\s\S]*?</article>', page)
    items = []
    vistos = set()
    for art in articles:
        m_link = re.search(r'href="(/media/([^"/?#]+))"', art)
        m_img = re.search(r'<img[^>]+src="([^"]+)"', art)
        m_title = re.search(r'<h3[^>]*>([^<]+)</h3>', art)
        m_plot = re.search(r'<p[^>]*class="[^"]*line-clamp[^"]*"[^>]*>([^<]+)</p>', art)

        if not (m_link and m_title):
            continue

        rel_link = m_link.group(1)
        link = f'{ANIMEAV1_BASE}{rel_link}'
        if link in vistos:
            continue
        vistos.add(link)

        titulo = html.unescape(m_title.group(1).strip())
        thumb = m_img.group(1) if m_img else ''
        plot = html.unescape(m_plot.group(1).strip()) if m_plot else ''

        items.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'plot': plot,
            'source': 'AnimeAV1',
            'is_serie': True,
            'section': 'animes'
        })
    return items


def animeav1_episodios(anime_url: str) -> list[dict]:
    """Extrae la lista de episodios de una serie en AnimeAV1."""
    page = _hacer_peticion(anime_url, referer=f'{ANIMEAV1_BASE}/catalogo')
    if not page:
        return []

    m_title = re.search(r'<h1[^>]*>([^<]+)</h1>', page)
    raw_slug = anime_url.rstrip('/').rsplit('/', 1)[-1]
    anime_title = html.unescape(m_title.group(1).strip()) if m_title else raw_slug.replace('-', ' ').title()

    m_cover = re.search(r'<img[^>]+src="(https://cdn\.animeav1\.com/covers/[^"]+)"', page)
    cover_base = m_cover.group(1) if m_cover else ''

    # Buscar enlaces a episodios: /media/{slug}/{num}
    m_eps = re.findall(r'href="(/media/[^"/]+/(\d+))"', page)
    episodios = []
    vistos = set()
    for rel_link, ep_num in m_eps:
        link = f'{ANIMEAV1_BASE}{rel_link}'
        if link in vistos:
            continue
        vistos.add(link)

        episodios.append({
            'title': f'{anime_title} - Episodio {ep_num}',
            'anime_title': anime_title,
            'episode_num': ep_num,
            'episode': int(ep_num) if ep_num.isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': cover_base,
            'cover': cover_base,
            'source': 'AnimeAV1',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    episodios.sort(key=lambda x: int(x['episode']))
    return episodios


def animeav1_servidores(episodio_url: str) -> list[dict]:
    """Extrae el servidor Zilla Networks HLS de AnimeAV1."""
    page = _hacer_peticion(episodio_url, referer=ANIMEAV1_BASE)
    if not page:
        return []

    m_if = re.search(r'<iframe[^>]+src="([^"]+)"', page)
    servidores = []
    if m_if:
        z_url = m_if.group(1)
        if 'zilla' in z_url:
            m3u8_url = z_url.replace('/play/', '/m3u8/')
            servidores.append({
                'nombre': 'Zilla Networks (HLS Directo) [AnimeAV1]',
                'url': m3u8_url,
                'calidad': 'Sin verificar',
                'servidor': 'zilla'
            })
    return servidores


# ============================================================================
# 4. SCRAPER JKANIME (https://jkanime.net)
# ============================================================================

def jkanime_ultimos_episodios() -> list[dict]:
    """Obtiene los ultimos episodios emitidos de JKAnime con sus miniaturas CDN."""
    page = _hacer_peticion(JKANIME_BASE, referer=JKANIME_BASE, use_jk_session=True)
    if not page:
        return []

    # Enlaces tipo <a href="https://jkanime.net/{slug}/{ep_num}/"> ... <img src="...">
    cards = re.findall(r'<a[^>]+href="(https://jkanime\.net/([^/]+)/(\d+)/)"[^>]*>([\s\S]*?)</a>', page)
    episodios = []
    vistos = set()
    for link, raw_slug, ep_num, inner in cards:
        if link in vistos:
            continue
        vistos.add(link)

        m_img = re.search(r'<img[^>]+src="([^"]+)"', inner)
        thumb = m_img.group(1) if m_img else ''
        anime_title = raw_slug.replace('-', ' ').title()

        episodios.append({
            'title': f'{anime_title} - Episodio {ep_num}',
            'anime_title': anime_title,
            'episode_num': ep_num,
            'episode': int(ep_num) if ep_num.isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'JKAnime',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    return episodios


def jkanime_buscar(query: str) -> list[dict]:
    """Busca animes en JKAnime por nombre."""
    q_enc = urllib.parse.quote_plus(query)
    url = f'{JKANIME_BASE}/buscar/{q_enc}/'
    page = _hacer_peticion(url, referer=JKANIME_BASE, use_jk_session=True)
    if not page:
        return []

    cards = re.findall(r'<div class="anime__item">[\s\S]*?</div>\s*</div>', page)
    resultados = []
    vistos = set()
    for card in cards:
        m_link = re.search(r'<a\s+href="(https://jkanime\.net/[^/]+/?)"', card)
        m_title = re.search(r'<h5><a[^>]*>([^<]+)</a></h5>', card)
        m_img = re.search(r'data-setbg="([^"]+)"', card)

        if not (m_link and m_title):
            continue

        link = m_link.group(1)
        if link in vistos:
            continue
        vistos.add(link)

        titulo = html.unescape(m_title.group(1).strip())
        thumb = m_img.group(1) if m_img else ''

        resultados.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'JKAnime',
            'is_serie': True,
            'section': 'animes'
        })
    return resultados


def jkanime_directorio(pagina: int = 1) -> list[dict]:
    """Obtiene el catalogo general paginado de JKAnime."""
    url = f'{JKANIME_BASE}/directorio/{pagina}/' if pagina > 1 else f'{JKANIME_BASE}/directorio/'
    page = _hacer_peticion(url, referer=JKANIME_BASE, use_jk_session=True)
    if not page:
        return []

    cards = re.findall(r'<div class="anime__item">[\s\S]*?</div>\s*</div>', page)
    items = []
    vistos = set()
    for card in cards:
        m_link = re.search(r'<a\s+href="(https://jkanime\.net/[^/]+/?)"', card)
        m_title = re.search(r'<h5><a[^>]*>([^<]+)</a></h5>', card)
        m_img = re.search(r'data-setbg="([^"]+)"', card)

        if not (m_link and m_title):
            continue

        link = m_link.group(1)
        if link in vistos:
            continue
        vistos.add(link)

        titulo = html.unescape(m_title.group(1).strip())
        thumb = m_img.group(1) if m_img else ''

        items.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'JKAnime',
            'is_serie': True,
            'section': 'animes'
        })
    return items


def jkanime_episodios(anime_url: str) -> list[dict]:
    """Extrae los episodios de una serie en JKAnime mediante llamada AJAX Laravel autenticada por token."""
    page = _hacer_peticion(anime_url, referer=JKANIME_BASE, use_jk_session=True)
    if not page:
        return []

    m_title = re.search(r'<h1[^>]*>([^<]+)</h1>', page) or re.search(r'<title>([^<]+)</title>', page)
    raw_slug = anime_url.rstrip('/').rsplit('/', 1)[-1]
    anime_title = html.unescape(m_title.group(1).replace('— Anime en HD — JKAnime', '').strip()) if m_title else raw_slug.replace('-', ' ').title()

    m_cover = re.search(r'data-setbg="([^"]+)"', page) or re.search(r'<meta property="og:image" content="([^"]+)"', page)
    cover_base = m_cover.group(1) if m_cover else ''

    m_plot = re.search(r'<p[^>]*class="[^"]*sinopsis[^"]*"[^>]*>([\s\S]*?)</p>', page) or re.search(r'<meta property="og:description" content="([^"]+)"', page)
    plot = html.unescape(re.sub(r'<[^>]+>', ' ', m_plot.group(1)).strip()) if m_plot else ''

    # Obtener anime ID y token CSRF
    m_id = re.search(r'ajax/episodes/(\d+)/', page) or re.search(r'data-anime="(\d+)"', page)
    m_token = re.search(r'<meta[^>]+name="csrf-token"[^>]+content="([^"]+)"', page)
    if not (m_id and m_token):
        return []

    aid = m_id.group(1)
    token = m_token.group(1)

    ajax_url = f'{JKANIME_BASE}/ajax/episodes/{aid}/1'
    post_data = urllib.parse.urlencode({'_token': token}).encode('utf-8')
    headers_ajax = {
        'Referer': anime_url,
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': token
    }
    ajax_resp = _hacer_peticion(ajax_url, referer=anime_url, data=post_data,
                                headers_extra=headers_ajax, use_jk_session=True)
    if not ajax_resp:
        return []

    episodios = []
    try:
        data_json = json.loads(ajax_resp)
        eps_list = data_json.get('data', [])
        for ep_data in eps_list:
            ep_num = str(ep_data.get('number', 1))
            ep_img = ep_data.get('image', '')
            thumb = f'https://cdn.jkdesa.com/assets/images/animes/video/image/{ep_img}' if ep_img else cover_base
            ep_link = f'{JKANIME_BASE}/{raw_slug}/{ep_num}/'

            episodios.append({
                'title': f'{anime_title} - Episodio {ep_num}',
                'anime_title': anime_title,
                'episode_num': ep_num,
                'episode': int(ep_num) if ep_num.isdigit() else 1,
                'season': 1,
                'url': ep_link,
                'thumb': thumb,
                'cover': thumb,
                'plot': plot,
                'source': 'JKAnime',
                'is_serie': True,
                'is_episode': True,
                'section': 'animes'
            })
    except Exception:
        pass
    episodios.sort(key=lambda x: int(x['episode']))
    return episodios


def jkanime_servidores(episodio_url: str) -> list[dict]:
    """Extrae los servidores de reproduccion en JKAnime decodificando array JS y reproductores HLS."""
    page = _hacer_peticion(episodio_url, referer=JKANIME_BASE, use_jk_session=True)
    if not page:
        return []

    servidores = []
    vistos = set()

    # 1. Reproductores JKPlayer nativos con direct HLS m3u8
    m_vids = re.findall(r'video\[\d+\]\s*=\s*[\'"]<iframe[^>]+src=[\'"]([^\'"]+)[\'"]', page)
    for p_url in m_vids:
        if 'jkplayer' in p_url:
            p_html = _hacer_peticion(p_url, referer=episodio_url)
            m_m3u8 = re.search(r'[\'"](https?://[^\'"]+\.m3u8[^\'"]*)[\'"]', p_html)
            if m_m3u8:
                stream_url = m_m3u8.group(1)
                if stream_url not in vistos:
                    vistos.add(stream_url)
                    servidores.append({
                        'nombre': 'JKPlayer (HLS Directo) [JKAnime]',
                        # El token HLS caduca: obtener uno nuevo al reproducir.
                        'url': 'jkanime://jkplayer?episode=' + urllib.parse.quote(episodio_url, safe=''),
                        'calidad': 'HD',
                        'servidor': 'jkplayer'
                    })

    # 2. Servidores externos desde array servers = [...]
    m_servers = re.search(r'servers\s*=\s*(\[[\s\S]*?\]);', page)
    if m_servers:
        try:
            raw_s = json.loads(m_servers.group(1))
            for s in raw_s:
                b64_remote = s.get('remote', '')
                srv_name = s.get('server', 'Servidor')
                try:
                    dec_url = base64.b64decode(b64_remote).decode('utf-8').strip()
                    if dec_url.startswith(('http://', 'https://')) and dec_url not in vistos:
                        vistos.add(dec_url)
                        calidad = 'Sin verificar'
                        servidores.append({
                            'nombre': f'{srv_name} [JKAnime]',
                            'url': dec_url,
                            'calidad': calidad,
                            'servidor': srv_name.lower()
                        })
                except Exception:
                    pass
        except Exception:
            pass

    return servidores


# ============================================================================
# 5. SCRAPER MONOSCHINOS (https://vww.monoschinos2.net)
# ============================================================================

def monoschinos_ultimos_episodios() -> list[dict]:
    """Obtiene los ultimos episodios en emision de MonosChinos."""
    page = _hacer_peticion(MONOSCHINOS_BASE, referer=MONOSCHINOS_BASE)
    if not page:
        return []

    # Enlaces tipo <a href="https://vww.monoschinos2.net/ver/{slug}-episodio-{num}">
    cards = re.findall(r'<a[^>]+href="(https://vww\.monoschinos2\.net/ver/([^"-]+(?:-[^"-]+)*)-episodio-(\d+))"[^>]*>([\s\S]*?)</a>', page)
    episodios = []
    vistos = set()
    for link, raw_slug, ep_num, inner in cards:
        if link in vistos:
            continue
        vistos.add(link)

        m_img = re.search(r'data-src="([^"]+)"', inner)
        thumb = m_img.group(1) if m_img else ''
        anime_title = raw_slug.replace('-', ' ').title()

        episodios.append({
            'title': f'{anime_title} - Episodio {ep_num}',
            'anime_title': anime_title,
            'episode_num': ep_num,
            'episode': int(ep_num) if ep_num.isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'MonosChinos',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    return episodios


def monoschinos_buscar(query: str) -> list[dict]:
    """Busca animes en el directorio de MonosChinos."""
    q_enc = urllib.parse.quote_plus(query)
    url = f'{MONOSCHINOS_BASE}/animes?buscar={q_enc}'
    page = _hacer_peticion(url, referer=f'{MONOSCHINOS_BASE}/animes')
    if not page:
        return []

    cards = re.findall(r'<a[^>]+href="(\./anime/([^"]+)|https://vww\.monoschinos2\.net/anime/([^"]+))"[^>]*>([\s\S]*?)</a>', page)
    resultados = []
    vistos = set()
    for full_match, slug1, slug2, inner in cards:
        slug = slug1 or slug2
        link = f'{MONOSCHINOS_BASE}/anime/{slug}'
        if link in vistos:
            continue
        vistos.add(link)

        m_img = re.search(r'data-src="([^"]+)"', inner)
        thumb = m_img.group(1) if m_img else ''
        titulo = slug.replace('-', ' ').title()

        resultados.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'MonosChinos',
            'is_serie': True,
            'section': 'animes'
        })
    return resultados


def monoschinos_directorio(pagina: int = 1) -> list[dict]:
    """Obtiene el catalogo general paginado de MonosChinos."""
    url = f'{MONOSCHINOS_BASE}/animes?p={pagina}' if pagina > 1 else f'{MONOSCHINOS_BASE}/animes'
    page = _hacer_peticion(url, referer=MONOSCHINOS_BASE)
    if not page:
        return []

    cards = re.findall(r'<a[^>]+href="(\./anime/([^"]+)|https://vww\.monoschinos2\.net/anime/([^"]+))"[^>]*>([\s\S]*?)</a>', page)
    items = []
    vistos = set()
    for full_match, slug1, slug2, inner in cards:
        slug = slug1 or slug2
        link = f'{MONOSCHINOS_BASE}/anime/{slug}'
        if link in vistos:
            continue
        vistos.add(link)

        m_img = re.search(r'data-src="([^"]+)"', inner)
        thumb = m_img.group(1) if m_img else ''
        titulo = slug.replace('-', ' ').title()

        items.append({
            'title': titulo,
            'url': link,
            'thumb': thumb,
            'cover': thumb,
            'source': 'MonosChinos',
            'is_serie': True,
            'section': 'animes'
        })
    return items


def monoschinos_episodios(anime_url: str) -> list[dict]:
    """Extrae los episodios de una serie en MonosChinos a traves del endpoint AJAX pagination."""
    page = _hacer_peticion(anime_url, referer=MONOSCHINOS_BASE)
    if not page:
        return []

    m_title = re.search(r'<h1[^>]*>([^<]+)</h1>', page)
    raw_slug = anime_url.rstrip('/').rsplit('/', 1)[-1]
    anime_title = html.unescape(m_title.group(1).strip()) if m_title else raw_slug.replace('-', ' ').title()

    m_cover = re.search(r'data-src="(https://vww\.monoschinos2\.net/cdn/img/portada/[^"]+)"', page)
    cover_base = m_cover.group(1) if m_cover else ''

    m_i = re.search(r'data-i="(\d+)"', page)
    m_u = re.search(r'data-u="([^"]+)"', page)
    if not (m_i and m_u):
        return []

    mc_i = m_i.group(1)
    mc_u = m_u.group(1)

    post_data = urllib.parse.urlencode({'acc': 'episodes', 'i': mc_i, 'u': mc_u, 'p': 1}).encode('utf-8')
    headers_ajax = {
        'Referer': anime_url,
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
    ajax_resp = _hacer_peticion(f'{MONOSCHINOS_BASE}/ajax_pagination', referer=anime_url,
                                data=post_data, headers_extra=headers_ajax)
    if not ajax_resp:
        return []

    # Extraer enlaces tipo href="(https://vww.monoschinos2.net/ver/{slug}-episodio-{ep})"
    matches = re.findall(r'<a[^>]+href="(https://vww\.monoschinos2\.net/ver/([^"-]+(?:-[^"-]+)*)-episodio-(\d+))"[^>]*>', ajax_resp)
    episodios = []
    vistos = set()
    for link, _, ep_num in matches:
        if link in vistos:
            continue
        vistos.add(link)

        episodios.append({
            'title': f'{anime_title} - Episodio {ep_num}',
            'anime_title': anime_title,
            'episode_num': ep_num,
            'episode': int(ep_num) if ep_num.isdigit() else 1,
            'season': 1,
            'url': link,
            'thumb': cover_base,
            'cover': cover_base,
            'source': 'MonosChinos',
            'is_serie': True,
            'is_episode': True,
            'section': 'animes'
        })
    episodios.sort(key=lambda x: int(x['episode']))
    return episodios


def monoschinos_servidores(episodio_url: str) -> list[dict]:
    """Extrae los servidores de reproduccion en MonosChinos via AJAX y decodificacion Base64."""
    page = _hacer_peticion(episodio_url, referer=MONOSCHINOS_BASE)
    if not page:
        return []

    m_enc = re.search(r'data-encrypt="([^"]+)"', page)
    if not m_enc:
        return []

    enc_val = m_enc.group(1)
    post_data = urllib.parse.urlencode({'acc': 'opt', 'i': enc_val}).encode('utf-8')
    headers_ajax = {
        'Referer': episodio_url,
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
    opt_resp = _hacer_peticion(f'{MONOSCHINOS_BASE}/ajax_pagination', referer=episodio_url,
                               data=post_data, headers_extra=headers_ajax)
    if not opt_resp:
        return []

    btns = re.findall(r'<button[^>]+data-player="([^"]+)"[^>]*>([^<]+)</button>', opt_resp)
    servidores = []
    vistos = set()
    for b64, lbl in btns:
        try:
            d_url = base64.b64decode(b64).decode('utf-8').strip()
            if not d_url.startswith(('http://', 'https://')) or d_url in vistos:
                continue
            vistos.add(d_url)

            srv_label = lbl.strip().title()
            calidad = '1080p' if 'voe' in srv_label.lower() else 'HD'
            servidores.append({
                'nombre': f'{srv_label} [MonosChinos]',
                'url': d_url,
                'calidad': calidad,
                'servidor': srv_label.lower()
            })
        except Exception:
            pass

    return servidores


# ============================================================================
# 6. MOTOR UNIFICADO MULTI-FUENTE (5 PROVEEDORES)
# ============================================================================

def ultimos_episodios() -> list[dict]:
    """Obtiene y unifica los ultimos episodios emitidos de las 5 fuentes en paralelo."""
    import source_switches
    scrapers = [fn for key, fn in (
        ('tioanime', tioanime_ultimos_episodios), ('animeflv', animeflv_ultimos_episodios),
        ('animeav1', animeav1_ultimos_episodios), ('jkanime', jkanime_ultimos_episodios),
        ('monoschinos', monoschinos_ultimos_episodios)) if source_switches.enabled(key)]
    if not scrapers:
        return []

    resultados_batches = []
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(sc) for sc in scrapers]
        for f in futures:
            try:
                res = f.result(timeout=10)
                if res:
                    resultados_batches.append(res)
            except Exception:
                pass

    if not resultados_batches:
        return []

    # Combinar alternando equitativamente para maxima diversidad y frescura
    unificados = []
    claves_vistas = set()

    max_len = max(len(b) for b in resultados_batches)
    for i in range(max_len):
        for batch in resultados_batches:
            if i < len(batch):
                ep = batch[i]
                norm_title = normalizar_titulo(ep.get('anime_title', ''))
                ep_num = str(ep.get('episode_num', '1'))
                k = (norm_title, ep_num)
                if k not in claves_vistas:
                    claves_vistas.add(k)
                    unificados.append(ep)

    return unificados


def buscar_anime(query: str) -> list[dict]:
    """Busca proveedores de anime, deduplicando y agrupando fuentes."""
    import source_switches
    scrapers = [fn for key, fn in (
        ('tioanime', tioanime_buscar), ('animeflv', animeflv_buscar),
        ('animeav1', animeav1_buscar), ('jkanime', jkanime_buscar),
        ('monoschinos', monoschinos_buscar), ('latanime', latanime_buscar))
        if source_switches.enabled(key)]
    if not scrapers:
        return []

    todos_resultados = []
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = [executor.submit(sc, query) for sc in scrapers]
        for f in futures:
            try:
                res = f.result(timeout=10)
                if res:
                    todos_resultados.extend(res)
            except Exception:
                pass

    agrupados: dict[str, dict] = {}
    for item in todos_resultados:
        norm = normalizar_titulo(item.get('title', ''))
        if not norm:
            continue

        thumb = item.get('thumb') or item.get('cover', '')
        if norm not in agrupados:
            agrupados[norm] = {
                'title': item['title'],
                'url': item['url'],
                'thumb': thumb,
                'cover': thumb,
                'badge': item.get('badge', 'Anime'),
                'plot': item.get('plot', ''),
                'sources': {item['source']: item['url']},
                'source': item['source'],
                'is_serie': True,
                'section': 'animes'
            }
        else:
            # Enriquecer fuentes e imagenes faltantes
            agrupados[norm]['sources'][item['source']] = item['url']
            if not agrupados[norm]['thumb'] and thumb:
                agrupados[norm]['thumb'] = thumb
                agrupados[norm]['cover'] = thumb
            if not agrupados[norm]['plot'] and item.get('plot'):
                agrupados[norm]['plot'] = item['plot']

    resultado_final = []
    for item in agrupados.values():
        fuentes = list(item['sources'].keys())
        if len(fuentes) > 1:
            item['source_label'] = ' + '.join(fuentes)
        else:
            item['source_label'] = fuentes[0]
        resultado_final.append(item)

    return resultado_final


def obtener_episodios(anime_item_o_url: dict | str) -> list[dict]:
    """Obtiene la lista completa de episodios para un anime dado su item o URL."""
    if isinstance(anime_item_o_url, str):
        url = anime_item_o_url
        import source_switches
        if not source_switches.allowed({'url': url}):
            return []
        if 'tioanime.com' in url:
            return tioanime_episodios(url)
        elif 'animeflv.or.at' in url:
            return animeflv_episodios(url)
        elif 'animeav1.com' in url:
            return animeav1_episodios(url)
        elif 'jkanime.net' in url:
            return jkanime_episodios(url)
        elif 'monoschinos2.net' in url:
            return monoschinos_episodios(url)
        elif 'latanime.org' in url:
            return latanime_episodios(url)
        return tioanime_episodios(url)

    # Si es un item con multiples fuentes agrupadas, probar por orden de confiabilidad
    sources = anime_item_o_url.get('sources', {})
    import source_switches
    for src, scraper in [
        ('TioAnime', tioanime_episodios),
        ('AnimeFLV', animeflv_episodios),
        ('AnimeAV1', animeav1_episodios),
        ('JKAnime', jkanime_episodios),
        ('MonosChinos', monoschinos_episodios),
        ('Latanime', latanime_episodios)
    ]:
        if src in sources and source_switches.enabled(src.lower()):
            eps = scraper(sources[src])
            if eps:
                return eps

    # Fallback a URL principal del item
    main_url = anime_item_o_url.get('url', '')
    return obtener_episodios(main_url)


def obtener_servidores(episodio_url: str) -> list[dict]:
    """Obtiene y prioriza todos los servidores de reproduccion para un enlace de episodio."""
    servidores = []
    import source_switches
    if not source_switches.allowed({'url': episodio_url}):
        return []
    if 'tioanime.com' in episodio_url:
        servidores = tioanime_servidores(episodio_url)
    elif 'animeflv.or.at' in episodio_url:
        servidores = animeflv_servidores(episodio_url)
    elif 'animeav1.com' in episodio_url:
        servidores = animeav1_servidores(episodio_url)
    elif 'jkanime.net' in episodio_url:
        servidores = jkanime_servidores(episodio_url)
    elif 'monoschinos2.net' in episodio_url:
        servidores = monoschinos_servidores(episodio_url)
    elif 'latanime.org' in episodio_url:
        servidores = latanime_servidores(episodio_url)

    # Priorizar servidores por estabilidad y resolucion:
    # 1. HLS Directo (Zilla Networks, JKPlayer)
    # 2. Voe (HLS)
    # 3. MP4Upload / YourUpload (MP4 Directo)
    # 4. VidHide / Filemoon / Streamwish
    # 5. Mega / Mediafire / Otros
    def peso_servidor(s: dict) -> int:
        u = s.get('url', '').lower()
        nom = s.get('nombre', '').lower()
        if 'zilla' in u or 'zilla' in nom:
            return 100
        if 'jkplayer' in nom or 'playmudos' in u:
            return 95
        if 'voe' in u or 'voe' in nom:
            return 90
        if 'mp4upload' in u or 'mp4upload' in nom:
            return 85
        if 'yourupload' in u or 'yourupload' in nom:
            return 80
        if 'streamwish' in u or 'streamwish' in nom:
            return 75
        if 'vidhide' in u or 'bysela' in u or 'bysesu' in u:
            return 70
        if 'mediafire' in u or 'mediafire' in nom:
            return 65
        if 'mega' in u or 'mega' in nom:
            return 60
        if 'filemoon' in u or 'filemoon' in nom:
            return 55
        return 50

    return sorted(servidores, key=peso_servidor, reverse=True)


def resolver_enlace_anime(servidor_url: str) -> str:
    """Resuelve la URL final reproducible para Kodi utilizando resolvers.py."""
    return resolvers.resolver_stream(servidor_url)


def is_anime(item: dict) -> bool:
    """Determina si un objeto pertenece al ecosistema de anime."""
    if not isinstance(item, dict):
        return False
    if item.get('section') == 'animes' or item.get('source') in ('TioAnime', 'AnimeFLV', 'AnimeAV1', 'JKAnime', 'MonosChinos', 'Latanime'):
        return True
    return is_anime_url(item.get('url', ''))


def is_anime_url(url: str) -> bool:
    """Verifica si una URL pertenece a un portal de anime."""
    if not isinstance(url, str):
        return False
    return any(d in url for d in (
        'tioanime.com',
        'animeflv.or.at',
        'animeav1.com',
        'jkanime.net',
        'monoschinos2.net',
        'latanime.org',
        'anime://'
    ))


def obtener_temporadas_episodios(serie_obj: dict) -> dict[str, list[dict]]:
    """Devuelve la estructura de temporadas y episodios compatible con Kodi (clave '1')."""
    eps = obtener_episodios(serie_obj)
    temporadas: dict[str, list[dict]] = {}
    cover = serie_obj.get('cover') or serie_obj.get('thumb', '')
    plot = serie_obj.get('plot', '')

    for ep in eps:
        ep_thumb = ep.get('thumb') or ep.get('cover') or cover
        ep_entry = {
            'title': ep['title'],
            'url': ep['url'],
            'cover': ep_thumb,
            'thumb': ep_thumb,
            'plot': ep.get('plot') or plot,
            'is_serie': True,
            'is_episode': True,
            'season': 1,
            'episode': int(ep.get('episode_num', 1)) if str(ep.get('episode_num', '')).isdigit() else 1,
            'number': str(ep.get('episode_num', '1'))
        }
        # La clave DEBE ser '1' (digito string) para que Kodi la muestre en main.py
        temporadas.setdefault('1', []).append(ep_entry)
    return temporadas


def obtener_servidores_para_tmdb(item: dict, series: dict = None) -> list[dict]:
    """
    Resuelve y extrae servidores de video desde los 5 proveedores de anime
    (TioAnime, AnimeFLV, AnimeAV1, JKAnime, MonosChinos) para una ficha o episodio de TMDb.
    """
    root = series or item
    title = root.get('title') or root.get('name') or ''
    orig_title = root.get('original_title') or root.get('original_name') or ''
    is_serie = root.get('is_serie', True)
    if 'season' in item and 'episode' in item:
        try:
            season_num = int(item.get('season') or 1)
        except Exception:
            season_num = 1
        try:
            episode_num = int(item.get('episode') or 1)
        except Exception:
            episode_num = 1
    else:
        season_num = 1
        episode_num = 1

    roman_map = {2: 'II', 3: 'III', 4: 'IV', 5: 'V', 6: 'VI', 7: 'VII', 8: 'VIII'}
    if is_serie and season_num > 1:
        roman = roman_map.get(season_num, str(season_num))
        queries = [
            f"{title} Season {season_num}",
            f"{title} {roman}",
            f"{title} {season_num}",
            f"{title} Temporada {season_num}",
            title
        ]
    else:
        queries = [title]

    all_candidates = []
    seen_urls = set()
    for q in queries:
        found = buscar_anime(q)
        for c in found:
            u = c.get('url')
            if u and u not in seen_urls:
                seen_urls.add(u)
                all_candidates.append(c)
        if all_candidates:
            break

    if not all_candidates and orig_title and orig_title != title:
        found = buscar_anime(orig_title)
        for c in found:
            u = c.get('url')
            if u and u not in seen_urls:
                seen_urls.add(u)
                all_candidates.append(c)

    matched_candidates = []
    s_str = str(season_num)
    roman_s = roman_map.get(season_num, s_str).lower() if is_serie else ''

    if is_serie and season_num > 1:
        season_regex = re.compile(rf'\b(?:season\s*{s_str}|{s_str}(?:nd|rd|th)?\s*season|temporada\s*{s_str}|{roman_s})\b', re.I)
        for c in all_candidates:
            if season_regex.search(c.get('title', '')):
                matched_candidates.append(c)
    elif is_serie and season_num == 1:
        other_season_regex = re.compile(r'\b(?:season\s*([0-9]+)|([0-9]+)(?:nd|rd|th)?\s*season|temporada\s*([0-9]+)|(ii|iii|iv|v|vi))\b', re.I)
        for c in all_candidates:
            m = other_season_regex.search(c.get('title', ''))
            if m:
                val = next((g for g in m.groups() if g), '').lower()
                if val in ('1', 'i', '1st'):
                    matched_candidates.append(c)
            else:
                matched_candidates.append(c)
    else:
        matched_candidates = all_candidates

    if not matched_candidates:
        return []

    # El buscador devuelve variantes de una franquicia. Solo la ficha exacta
    # (mas su sufijo de temporada) puede aportar enlaces al episodio solicitado.
    base_titles = {normalizar_titulo(t) for t in (title, orig_title) if t}
    matched_candidates = [c for c in matched_candidates if any(
        normalizar_titulo(c.get('title', '')) == base or
        (is_serie and season_num > 1 and normalizar_titulo(c.get('title', '')) in {
            f'{base} season {season_num}', f'{base} temporada {season_num}',
            f'{base} {season_num}', f'{base} {roman_map.get(season_num, season_num)}'.lower()
        }) for base in base_titles)]

    selected = matched_candidates[:2]
    all_sources = {}
    for c in selected:
        for s_name, s_url in c.get('sources', {}).items():
            if s_name not in all_sources:
                all_sources[s_name] = s_url

    def _fetch_servers_for_source(s_name, s_url):
        try:
            if not is_serie:
                eps = obtener_episodios(s_url)
                if eps:
                    return obtener_servidores(eps[0]['url'])
                else:
                    return obtener_servidores(s_url)
            eps = obtener_episodios(s_url)
            target = next((e for e in eps if str(e.get('episode_num')) == str(episode_num) or e.get('episode') == episode_num), None)
            if target and target.get('url'):
                return obtener_servidores(target['url'])
        except Exception:
            pass
        return []

    servers = []
    with ThreadPoolExecutor(max_workers=5) as ex:
        futures = [ex.submit(_fetch_servers_for_source, name, url) for name, url in all_sources.items()]
        for f in futures:
            try:
                srvs = f.result(timeout=12)
                if srvs:
                    servers.extend(srvs)
            except Exception:
                pass

    return servers


def menu_categorias() -> dict[str, str]:
    """Categorias disponibles para la navegacion en la seccion de Animes."""
    return {
        'ÚLTIMOS EPISODIOS (SIMULCASTS)': 'anime://ultimos',
        'TIOANIME (CATÁLOGO)': 'anime://tioanime',
        'ANIMEFLV (CATÁLOGO)': 'anime://animeflv',
        'ANIMEAV1 (CATÁLOGO)': 'anime://animeav1',
        'JKANIME (CATÁLOGO)': 'anime://jkanime',
        'MONOSCHINOS (CATÁLOGO)': 'anime://monoschinos',
        'CATÁLOGO GENERAL': 'unified://animes',
        'BUSCAR ANIME': 'search://?section=animes'
    }


def page(number: int = 1, genre: str = None) -> tuple[list[dict], bool]:
    """Paginacion de catalogo para catalog.py."""
    import source_switches
    if genre in ('tioanime', 'animeflv', 'animeav1', 'jkanime', 'monoschinos', 'latanime') and not source_switches.enabled(genre):
        return [], False
    if genre in ('ultimos', 'simulcast'):
        items = ultimos_episodios()
        return items, False
    elif genre == 'tioanime':
        items = tioanime_directorio(number)
        return items, len(items) >= 20
    elif genre == 'animeflv':
        items = animeflv_directorio(number)
        return items, len(items) >= 20
    elif genre == 'animeav1':
        items = animeav1_directorio(number)
        return items, len(items) >= 20
    elif genre == 'jkanime':
        items = jkanime_directorio(number)
        return items, len(items) >= 20
    elif genre == 'monoschinos':
        items = monoschinos_directorio(number)
        return items, len(items) >= 20
    elif genre == 'latanime':
        items = latanime_directorio(number)
        return items, len(items) >= 20

    if any(not source_switches.enabled(key) for key in
           ('tioanime', 'animeflv', 'animeav1', 'jkanime', 'monoschinos', 'latanime')):
        if genre:
            # Las categorías temáticas de TMDb no prueban que una fuente
            # concreta publique el título.
            return [], False
        catalogs = [fn for key, fn in (
            ('tioanime', tioanime_directorio), ('animeflv', animeflv_directorio),
            ('animeav1', animeav1_directorio), ('jkanime', jkanime_directorio),
            ('monoschinos', monoschinos_directorio), ('latanime', latanime_directorio))
            if source_switches.enabled(key)]
        if not catalogs:
            return [], False
        with ThreadPoolExecutor(max_workers=min(6, len(catalogs))) as executor:
            batches = list(executor.map(lambda fn: fn(number), catalogs))
        items = [item for batch in batches for item in batch]
        return items, any(len(batch) >= 20 for batch in batches)

    # Catalogo unificado de TMDb (LolPlus) para TODO y generos especificos
    import lolplus
    return lolplus.lolplus_catalog_page("animes", number, genre=genre)


def search(query: str) -> list[dict]:
    """Interfaz de busqueda para catalog.py."""
    return buscar_anime(query)
