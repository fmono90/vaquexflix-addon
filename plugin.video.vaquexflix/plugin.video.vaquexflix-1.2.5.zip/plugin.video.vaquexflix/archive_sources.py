"""Fuente para Internet Archive: Lollapalooza Argentina 2025 - Presentaciones [1080p]."""
import unicodedata
from urllib.parse import quote, urlsplit
import source_switches

BASE_DETAILS = "https://archive.org/details/lollapalooza-argentina-2025-presentaciones-1080p"
BASE_DOWNLOAD = "https://archive.org/download/lollapalooza-argentina-2025-presentaciones-1080p/"
COVER_URL = "https://archive.org/services/img/lollapalooza-argentina-2025-presentaciones-1080p"

# (day, ep, artist, is_kidz, length_seconds, filename, thumb_filename)
DATA = (
    (1, 1, 'Milk Shake', False, 2376.62, 'D1-01. Milk Shake - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-01. Milk Shake - Lollapalooza 2025 [1080p]_001853.jpg'),
    (1, 2, 'La Cintia', False, 2826.07, 'D1-02. La Cintia - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-02. La Cintia - Lollapalooza 2025 [1080p]_002206.jpg'),
    (1, 3, 'Cuentos Fabulantásticos', True, 2402.99, 'D1-03. Cuentos Fabulantásticos - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-03. Cuentos Fabulantásticos - Kidzapalooza 2025 [1080p]_001875.jpg'),
    (1, 4, 'Queralt Lahoz', False, 2550.74, 'D1-04. Queralt Lahoz - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-04. Queralt Lahoz - Lollapalooza 2025 [1080p]_001990.jpg'),
    (1, 5, 'Vinocio', False, 2678.61, 'D1-05. Vinocio - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-05. Vinocio - Lollapalooza 2025 [1080p]_002090.jpg'),
    (1, 6, 'Pablopablo', False, 2742.91, 'D1-06. Pablopablo - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-06. Pablopablo - Lollapalooza 2025 [1080p]_002140.jpg'),
    (1, 7, 'Planta', False, 3483.56, 'D1-07. Planta - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-07. Planta - Lollapalooza 2025 [1080p]_002718.jpg'),
    (1, 8, 'Arjaus Crew (Reni Chemello)', True, 2468.05, 'D1-08. Arjaus Crew (Reni Chemello) - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-08. Arjaus Crew (Reni Chemello) - Kidzapalooza 2025 [1080p]_001925.jpg'),
    (1, 9, 'Ana Mena', False, 3263.45, 'D1-09. Ana Mena - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-09. Ana Mena - Lollapalooza 2025 [1080p]_002546.jpg'),
    (1, 10, 'Darumas', False, 3492.57, 'D1-10. Darumas - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-10. Darumas - Lollapalooza 2025 [1080p]_002724.jpg'),
    (1, 11, 'Dúo un Pie', True, 2107.9, 'D1-11. Dúo un Pie - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-11. Dúo un Pie - Kidzapalooza 2025 [1080p]_001645.jpg'),
    (1, 12, 'Spreen x Matute', False, 3404.2, 'D1-12. Spreen x Matute - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-12. Spreen x Matute - Lollapalooza 2025 [1080p]_002656.jpg'),
    (1, 13, 'Parcels', False, 3663.83, 'D1-13. Parcels - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-13. Parcels - Lollapalooza 2025 [1080p]_002858.jpg'),
    (1, 14, 'School of Rock', True, 2513.24, 'D1-14. School of Rock - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-14. School of Rock - Kidzapalooza 2025 [1080p]_001962.jpg'),
    (1, 15, 'Los Ángeles Azules', False, 3655.81, 'D1-15. Los Ángeles Azules - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-15. Los Ángeles Azules - Lollapalooza 2025 [1080p]_002852.jpg'),
    (1, 16, 'Nessa Barrett', False, 3513.22, 'D1-16. Nessa Barrett - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-16. Nessa Barrett - Lollapalooza 2025 [1080p]_002740.jpg'),
    (1, 17, 'Micro TDH', False, 3326.0, 'D1-17. Micro TDH - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-17. Micro TDH - Lollapalooza 2025 [1080p]_002594.jpg'),
    (1, 18, 'Sin Cordones', True, 2629.68, 'D1-18. Sin Cordones - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-18. Sin Cordones - Kidzapalooza 2025 [1080p]_002052.jpg'),
    (1, 19, 'CA7RIEL & Paco Amoroso', False, 3428.86, 'D1-19. CA7RIEL & Paco Amoroso - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-19. CA7RIEL & Paco Amoroso - Lollapalooza 2025 [1080p]_002674.jpg'),
    (1, 20, 'DobleP', False, 2849.49, 'D1-20. DobleP - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-20. DobleP - Lollapalooza 2025 [1080p]_002224.jpg'),
    (1, 21, 'Soy Solcito', True, 2757.89, 'D1-21. Soy Solcito - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-21. Soy Solcito - Kidzapalooza 2025 [1080p]_002152.jpg'),
    (1, 22, 'Foster the People', False, 3679.83, 'D1-22. Foster the People - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-22. Foster the People - Lollapalooza 2025 [1080p]_002870.jpg'),
    (1, 23, 'Lasso', False, 3458.69, 'D1-23. Lasso - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-23. Lasso - Lollapalooza 2025 [1080p]_002698.jpg'),
    (1, 24, 'Zoom, acercate más', True, 1982.89, 'D1-24. Zoom, acercate más - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-24. Zoom, acercate más - Kidzapalooza 2025 [1080p]_001547.jpg'),
    (1, 25, 'Barry Can’t Swim', False, 3283.5, 'D1-25. Barry Can’t Swim - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-25. Barry Can’t Swim - Lollapalooza 2025 [1080p]_002562.jpg'),
    (1, 26, 'Alanis Morissette', False, 5716.57, 'D1-26. Alanis Morissette - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-26. Alanis Morissette - Lollapalooza 2025 [1080p]_004460.jpg'),
    (1, 27, 'BLONDISH', False, 3526.14, 'D1-27. BLONDISH - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-27. BLONDISH - Lollapalooza 2025 [1080p]_002750.jpg'),
    (1, 28, 'Mon Laferte', False, 3637.8, 'D1-28. Mon Laferte - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-28. Mon Laferte - Lollapalooza 2025 [1080p]_002838.jpg'),
    (1, 29, 'Charlotte de Witte', False, 3459.63, 'D1-29. Charlotte de Witte - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D1-29. Charlotte de Witte - Lollapalooza 2025 [1080p]_002698.jpg'),
    (2, 1, 'Juana Aguirre', False, 2362.54, 'D2-01. Juana Aguirre - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-01. Juana Aguirre - Lollapalooza 2025 [1080p]_001843.jpg'),
    (2, 2, 'Juan Lopez', False, 2794.88, 'D2-02. Juan Lopez - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-02. Juan Lopez - Lollapalooza 2025 [1080p]_002180.jpg'),
    (2, 3, 'Samuraï', False, 2589.44, 'D2-03. Samuraï - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-03. Samuraï - Lollapalooza 2025 [1080p]_002020.jpg'),
    (2, 4, 'Dum Chica', False, 2309.93, 'D2-04. Dum Chica - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-04. Dum Chica - Lollapalooza 2025 [1080p]_001801.jpg'),
    (2, 5, 'Soulfía', False, 2364.08, 'D2-05. Soulfía - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-05. Soulfía - Lollapalooza 2025 [1080p]_001845.jpg'),
    (2, 6, 'Luz Gaggi', False, 2761.86, 'D2-06. Luz Gaggi - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-06. Luz Gaggi - Lollapalooza 2025 [1080p]_002156.jpg'),
    (2, 7, 'Balthvs', False, 2432.77, 'D2-07. Balthvs - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-07. Balthvs - Lollapalooza 2025 [1080p]_001897.jpg'),
    (2, 8, 'Arjaus Crew (Mateo Trogolo)', True, 2610.3, 'D2-08. Arjaus Crew (Mateo Trogolo) - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-08. Arjaus Crew (Mateo Trogolo) - Kidzapalooza 2025 [1080p]_002036.jpg'),
    (2, 9, 'Elena Rose', False, 2591.57, 'D2-09. Elena Rose - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-09. Elena Rose - Lollapalooza 2025 [1080p]_002022.jpg'),
    (2, 10, 'Arde Bogotá', False, 3181.36, 'D2-10. Arde Bogotá - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-10. Arde Bogotá - Lollapalooza 2025 [1080p]_002482.jpg'),
    (2, 11, 'Artemas', False, 2823.68, 'D2-11. Artemas - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-11. Artemas - Lollapalooza 2025 [1080p]_002204.jpg'),
    (2, 12, 'Los Secretos del Hombre Extraordinariamente Fuerte', True, 2502.27, 'D2-12. Los Secretos del Hombre Extraordinariamente Fuerte - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-12. Los Secretos del Hombre Extraordinariamente Fuerte - Kidzapalooza 2025 [1080p]_001952.jpg'),
    (2, 13, 'Doly Flackko', False, 2077.4, 'D2-13. Doly Flackko - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-13. Doly Flackko - Lollapalooza 2025 [1080p]_001621.jpg'),
    (2, 14, 'Inhaler', False, 3357.53, 'D2-14. Inhaler - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-14. Inhaler - Lollapalooza 2025 [1080p]_002620.jpg'),
    (2, 15, 'Panceta y Los Papafritas', True, 2854.78, 'D2-15. Panceta y Los Papafritas - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-15. Panceta y Los Papafritas - Kidzapalooza 2025 [1080p]_002228.jpg'),
    (2, 16, 'Ponte Perro', False, 2270.64, 'D2-16. Ponte Perro - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-16. Ponte Perro - Lollapalooza 2025 [1080p]_001771.jpg'),
    (2, 17, 'The Marías', False, 3455.62, 'D2-17. The Marías - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-17. The Marías - Lollapalooza 2025 [1080p]_002696.jpg'),
    (2, 18, 'Wave to Earth', False, 3515.99, 'D2-18. Wave to Earth - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-18. Wave to Earth - Lollapalooza 2025 [1080p]_002742.jpg'),
    (2, 19, 'Salastkbron', False, 2607.92, 'D2-19. Salastkbron - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-19. Salastkbron - Lollapalooza 2025 [1080p]_002036.jpg'),
    (2, 20, 'WOS', False, 3463.64, 'D2-20. WOS - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-20. WOS - Lollapalooza 2025 [1080p]_002702.jpg'),
    (2, 21, 'Cantando con Adriana y Bailando con Julieta', True, 2877.1, 'D2-21. Cantando con Adriana y Bailando con Julieta - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-21. Cantando con Adriana y Bailando con Julieta - Kidzapalooza 2025 [1080p]_002244.jpg'),
    (2, 22, 'Kasablanca', False, 3597.57, 'D2-22. Kasablanca - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-22. Kasablanca - Lollapalooza 2025 [1080p]_002806.jpg'),
    (2, 23, 'Tate McRae', False, 3707.86, 'D2-23. Tate McRae - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-23. Tate McRae - Lollapalooza 2025 [1080p]_002892.jpg'),
    (2, 24, 'Sepultura', False, 3470.64, 'D2-24. Sepultura - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-24. Sepultura - Lollapalooza 2025 [1080p]_002708.jpg'),
    (2, 25, 'Panam y Circo', True, 3530.67, 'D2-25. Panam y Circo - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-25. Panam y Circo - Kidzapalooza 2025 [1080p]_002754.jpg'),
    (2, 26, 'Tool', False, 5555.71, 'D2-26. Tool - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-26. Tool - Lollapalooza 2025 [1080p]_004334.jpg'),
    (2, 27, 'La K’onga', False, 3962.2, 'D2-27. La K’onga - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-27. La K’onga - Lollapalooza 2025 [1080p]_003091.jpg'),
    (2, 28, 'Shawn Mendes', False, 5475.63, 'D2-28. Shawn Mendes - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-28. Shawn Mendes - Lollapalooza 2025 [1080p]_004272.jpg'),
    (2, 29, 'Teddy Swims', False, 3537.15, 'D2-29. Teddy Swims - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-29. Teddy Swims - Lollapalooza 2025 [1080p]_003419.jpg'),
    (2, 30, 'San Holo', False, 3672.24, 'D2-30. San Holo - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D2-30. San Holo - Lollapalooza 2025 [1080p]_003551.jpg'),
    (3, 1, 'Estratosfera', False, 2702.89, 'D3-01. Estratosfera - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-01. Estratosfera - Lollapalooza 2025 [1080p]_002614.jpg'),
    (3, 2, 'Lichi', False, 2538.92, 'D3-02. Lichi - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-02. Lichi - Lollapalooza 2025 [1080p]_002454.jpg'),
    (3, 3, 'Deyco', False, 2505.81, 'D3-03. Deyco - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-03. Deyco - Lollapalooza 2025 [1080p]_002422.jpg'),
    (3, 4, 'Francisco Victoria', False, 2312.49, 'D3-04. Francisco Victoria - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-04. Francisco Victoria - Lollapalooza 2025 [1080p]_002236.jpg'),
    (3, 5, 'Arjaus Crew (Franco y Mateo Trocca)', True, 1727.36, 'D3-05. Arjaus Crew (Franco y Mateo Trocca) - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-05. Arjaus Crew (Franco y Mateo Trocca) - Kidzapalooza 2025 [1080p]_001671.jpg'),
    (3, 6, 'Lara Project', False, 2474.67, 'D3-06. Lara Project - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-06. Lara Project - Lollapalooza 2025 [1080p]_002392.jpg'),
    (3, 7, 'BB Asul', False, 3566.25, 'D3-07. BB Asul - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-07. BB Asul - Lollapalooza 2025 [1080p]_003447.jpg'),
    (3, 8, 'Arjaus Crew (Angie Salghi)', True, 2648.45, 'D3-08. Arjaus Crew (Angie Salghi) - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-08. Arjaus Crew (Angie Salghi) - Kidzapalooza 2025 [1080p]_002560.jpg'),
    (3, 9, 'Marina Reche', False, 3303.47, 'D3-09. Marina Reche - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-09. Marina Reche - Lollapalooza 2025 [1080p]_003195.jpg'),
    (3, 10, 'Central Norte Crew - Brychitta, Metal DJ Crew Etta!', False, 5362.52, 'D3-10. Central Norte Crew - Brychitta, Metal DJ Crew Etta! - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-10. Central Norte Crew - Brychitta, Metal DJ Crew Etta! - Lollapalooza 2025 [1080p]_005185.jpg'),
    (3, 11, 'Chita', False, 3563.73, 'D3-11. Chita - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-11. Chita - Lollapalooza 2025 [1080p]_003445.jpg'),
    (3, 12, 'Little Jesus', False, 3427.8, 'D3-12. Little Jesus - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-12. Little Jesus - Lollapalooza 2025 [1080p]_003315.jpg'),
    (3, 13, 'Había Otra Vez, de Cuentos en Pijamas', True, 1980.67, 'D3-13. Había Otra Vez, de Cuentos en Pijamas - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-13. Había Otra Vez, de Cuentos en Pijamas - Kidzapalooza 2025 [1080p]_001915.jpg'),
    (3, 14, 'Aron', False, 3021.61, 'D3-14. Aron - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-14. Aron - Lollapalooza 2025 [1080p]_002920.jpg'),
    (3, 15, 'Girl in Red', False, 2782.93, 'D3-15. Girl in Red - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-15. Girl in Red - Lollapalooza 2025 [1080p]_002690.jpg'),
    (3, 16, 'Los Mellis', True, 2196.91, 'D3-16. Los Mellis - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-16. Los Mellis - Kidzapalooza 2025 [1080p]_002124.jpg'),
    (3, 17, 'El Malilla', False, 2344.79, 'D3-17. El Malilla - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-17. El Malilla - Lollapalooza 2025 [1080p]_002268.jpg'),
    (3, 18, 'Nathy Peluso', False, 3529.69, 'D3-18. Nathy Peluso - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-18. Nathy Peluso - Lollapalooza 2025 [1080p]_003413.jpg'),
    (3, 19, 'Nilocos', True, 2505.6, 'D3-19. Nilocos - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-19. Nilocos - Kidzapalooza 2025 [1080p]_002422.jpg'),
    (3, 20, 'Benson Boone', False, 3689.86, 'D3-20. Benson Boone - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-20. Benson Boone - Lollapalooza 2025 [1080p]_003567.jpg'),
    (3, 21, 'Rawayana', False, 3404.33, 'D3-21. Rawayana - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-21. Rawayana - Lollapalooza 2025 [1080p]_003291.jpg'),
    (3, 22, 'Disco Lines', False, 3553.15, 'D3-22. Disco Lines - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-22. Disco Lines - Lollapalooza 2025 [1080p]_003435.jpg'),
    (3, 23, 'Topa', True, 3237.89, 'D3-23. Topa - Kidzapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-23. Topa - Kidzapalooza 2025 [1080p]_003131.jpg'),
    (3, 24, 'Tan Biónica', False, 5123.29, 'D3-24. Tan Biónica - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-24. Tan Biónica - Lollapalooza 2025 [1080p]_004953.jpg'),
    (3, 25, 'JPEGMafia', False, 3373.14, 'D3-25. JPEGMafia - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-25. JPEGMafia - Lollapalooza 2025 [1080p]_003261.jpg'),
    (3, 26, 'Olivia Rodrigo', False, 5681.11, 'D3-26. Olivia Rodrigo - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-26. Olivia Rodrigo - Lollapalooza 2025 [1080p]_005493.jpg'),
    (3, 27, 'Caribou', False, 3513.43, 'D3-27. Caribou - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-27. Caribou - Lollapalooza 2025 [1080p]_003397.jpg'),
    (3, 28, 'James Hype', False, 4148.4, 'D3-28. James Hype - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-28. James Hype - Lollapalooza 2025 [1080p]_004012.jpg'),
    (3, 29, 'Rüfüs Du Sol', False, 4470.61, 'D3-29. Rüfüs Du Sol - Lollapalooza 2025 [1080p].mp4', 'lollapalooza-argentina-2025-presentaciones-1080p.thumbs/D3-29. Rüfüs Du Sol - Lollapalooza 2025 [1080p]_004322.jpg'),
)


def owns(url):
    if not isinstance(url, str):
        return False
    if 'lollapalooza-argentina-2025-presentaciones-1080p' in url:
        return True
    parsed = urlsplit(url)
    return parsed.hostname in ('archive.org', 'www.archive.org') and 'lollapalooza' in parsed.path.lower()


def get_series():
    return {
        'title': 'Lollapalooza Argentina 2025 - Presentaciones',
        'original_title': 'Lollapalooza Argentina 2025',
        'url': BASE_DETAILS,
        'cover': COVER_URL,
        'is_serie': True,
        'section': 'series',
        'year': '2025',
        'rating': '9.5',
        'plot': (
            'Lollapalooza Argentina 2025 - Presentaciones completas en vivo [1080p]. '
            'Edición décimo aniversario en el Hipódromo de San Isidro, Buenos Aires (21, 22 y 23 de Marzo 2025). '
            '88 conciertos completos organizados por día. Incluye shows de Olivia Rodrigo, Tool, Justin Timberlake, '
            'Shawn Mendes, Alanis Morissette, Rüfüs Du Sol, WOS, Tan Biónica, Nathy Peluso, The Marías, '
            'Foster the People, CA7RIEL & Paco Amoroso, Los Ángeles Azules, Mon Laferte, Charlotte de Witte, '
            'Sepultura, San Holo, Teddy Swims, Tate McRae, Inhaler, Arde Bogotá, Benson Boone, Rawayana, Caribou y más.'
        ),
        'source': 'archiveorg',
    }


def _normalize(text):
    text = unicodedata.normalize('NFKD', str(text or '').lower())
    return ''.join(c for c in text if not unicodedata.combining(c))


def _build_episode(entry):
    day, ep_num, artist, is_kidz, length, fname, thumb = entry
    video_url = BASE_DOWNLOAD + quote(fname)
    thumb_url = BASE_DOWNLOAD + quote(thumb) if thumb else COVER_URL
    day_dates = {1: 'Viernes 21 de Marzo', 2: 'Sábado 22 de Marzo', 3: 'Domingo 23 de Marzo'}
    date_str = day_dates.get(day, f'Día {day}')
    kidz_tag = ' [Kidzapalooza]' if is_kidz else ''
    mins = int(length // 60) if length else 0
    ep_title = f'{ep_num:02d}. {artist}{kidz_tag}'
    plot = f'{artist} en vivo en Lollapalooza Argentina 2025 [1080p]. Día {day} ({date_str}). Duración: {mins} min.'
    return {
        'title': ep_title,
        'url': video_url,
        'cover': thumb_url,
        'season': str(day),
        'episode': str(ep_num),
        'plot': plot,
        'year': '2025',
        'rating': '9.5',
        'duration': int(length),
        'series_title': 'Lollapalooza Argentina 2025 - Presentaciones',
        'is_serie': True,
        'is_episode': True,
        'section': 'series',
        'source': 'archiveorg',
    }


def search(query, section='series'):
    if not source_switches.enabled('archiveorg'):
        return []
    if section not in ('all', 'series'):
        return []
    norm_q = _normalize(query).strip()
    if not norm_q:
        return []
    series = get_series()
    keywords = ['lolla', 'lollapalooza', 'argentina', 'presentaciones', 'recital', 'festival', 'concierto', 'musica']
    q_words = norm_q.split()
    matched_series = any(k in norm_q for k in keywords) or any(
        w in _normalize(series['title']) or w in _normalize(series['plot']) for w in q_words if len(w) >= 3
    )

    results = []
    if matched_series:
        results.append(series)

    for entry in DATA:
        day, ep_num, artist, is_kidz, length, fname, thumb = entry
        norm_art = _normalize(artist)
        if norm_q in norm_art or all(w in norm_art for w in q_words if len(w) >= 3):
            ep_item = _build_episode(entry)
            if not any(r.get('url') == ep_item['url'] for r in results):
                results.append(ep_item)
                if not any(r.get('url') == series['url'] for r in results):
                    results.insert(0, series)
    return results


def page(section, number, genre=None):
    if not source_switches.enabled('archiveorg'):
        return [], False
    if section != 'series' or number != 1:
        return [], False
    if genre and genre not in ('musica', 'recitales', 'documental'):
        return [], False
    return [get_series()], False


def episodes(series=None):
    grouped = {}
    for entry in DATA:
        day = str(entry[0])
        grouped.setdefault(day, []).append(_build_episode(entry))
    return grouped


def servers(item, series=None):
    url = item.get('url', '')
    if not url:
        return []
    return [
        {
            'nombre': 'Internet Archive [1080p]',
            'url': url,
            'calidad': 'Sin verificar',
            'idioma': 'Latino',
            'source': 'archiveorg',
        }
    ]
