"""Catalogo publico de Argflix (Peliculas, Series, Cortos e Infantil)."""

import base64
import html
import json
import os
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import network
import source_switches
import tube_engine

BASE = 'https://www.argflix.com'
_DBSM_APP_ID = '22bef345-3c5b-4c18-b782-74d4085112ff'
_PAGE_SIZE = 50
_CACHE_TTL = 43200
_ERROR_COOLDOWN = 60

CAT_PELICULAS = '6683df184e5e9c08f4947a81'
CAT_SERIES = '6683df240bfc7150e6706fbd'
CAT_CORTOS = '6683df02ca2929e8314098de'
CAT_INFANTIL = '66d4af082ea7d4fa83ef85f8'
TARGET_CATEGORY_IDS = (CAT_PELICULAS, CAT_SERIES, CAT_CORTOS, CAT_INFANTIL)

# Mapeo estricto de etiquetas de Argflix a claves de genero de Vaquexflix.
# Nunca asignar 'animacion' por pertenecer a Infantil si falta etiqueta explicita.
_TAG_GENRE_MAP = {
    'accion': 'accion',
    'animacion': 'animacion',
    'aventura': 'aventura',
    'cienciaficcion': 'ciencia-ficcion',
    'ciencia ficcion': 'ciencia-ficcion',
    'comedia': 'comedia',
    'comedia dramatica': 'comedia',
    'comedia negra': 'comedia',
    'comedia romantica': 'romance',
    'crimen': 'crimen',
    'documental': 'documental',
    'drama': 'drama',
    'familia': 'familia',
    'familiar': 'familia',
    'fantastico': 'fantasia',
    'fantasia': 'fantasia',
    'historico': 'historia',
    'historia': 'historia',
    'misterio': 'misterio',
    'musical': 'musica',
    'policial': 'crimen',
    'romance': 'romance',
    'suspenso': 'suspense',
    'terror': 'terror',
    'western': 'western',
}

_PUBLIC_GENRES = {
    'peliculas': frozenset({'argentinas', 'cortos', 'familia', 'animacion'}),
    'series': frozenset({'argentinas', 'kids', 'familia', 'animacion'}),
}

_lock = threading.RLock()
_mem_cache = {'updated': 0.0, 'items': None}
_last_error_at = 0.0
_playlist_cache = {}
_playlist_lock = threading.RLock()
_YT_ID_RE = re.compile(r'^[a-zA-Z0-9_-]{11}$')
_VIMEO_RE = re.compile(r'vimeo\.com/(?:video/)?(\d+)', re.I)
_YEAR_LABEL_RE = re.compile(r'(?:a[nñ]o|estreno)\s*[:\-]?\s*((?:19|20)\d{2})\b', re.I)
_YEAR_PAREN_RE = re.compile(r'\(\s*((?:19|20)\d{2})\s*\)')


def _profile_cache_path():
    try:
        import xbmcvfs
        root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vaquexflix')
    except ImportError:
        root = ''
    if not root:
        root = os.path.join(
            os.environ.get('APPDATA', os.path.expanduser('~')),
            'Kodi', 'userdata', 'addon_data', 'plugin.video.vaquexflix')
    return os.path.join(root, 'argflix_catalog.json')


def _norm(text):
    value = ''.join(c for c in unicodedata.normalize('NFKD', str(text or '').lower())
                    if not unicodedata.combining(c))
    return ' '.join(re.findall(r'[^\W_]+', value, re.UNICODE))


def _wix_image(raw):
    if not isinstance(raw, str):
        return ''
    raw = raw.strip()
    if raw.startswith('wix:image://'):
        match = re.match(r'^wix:image://v1/([^/#]+)', raw)
        if match:
            media_id = match.group(1)
            return f'https://static.wixstatic.com/media/{media_id}/v1/fill/w_500,h_715,al_c,q_85/poster.jpg'
        return ''
    if raw.startswith(('https://', 'http://')):
        return raw
    return ''


def _extract_year(title_text, plain_text):
    for pattern in (_YEAR_PAREN_RE, _YEAR_LABEL_RE):
        match = pattern.search(title_text or '') or pattern.search((plain_text or '')[:400])
        if match:
            return match.group(1)
    return ''


def _normalize_media_entry(kind, raw_url, is_series_like):
    """Devuelve dict {'type': 'yt'|'yt_playlist'|'vimeo', 'url': ..., 'id': ...} o None."""
    if not isinstance(raw_url, str):
        return None
    cleaned = html.unescape(raw_url).strip()
    if not cleaned or 'manage.wix.com' in cleaned.lower():
        return None

    low = cleaned.lower()
    if 'vimeo.com' in low:
        match = _VIMEO_RE.search(cleaned)
        if not match:
            return None
        vid = match.group(1)
        h_match = re.search(r'[?&]h=([a-zA-Z0-9]+)', cleaned)
        url = f'https://vimeo.com/{vid}' + (f'?h={h_match.group(1)}' if h_match else '')
        return {'type': 'vimeo', 'id': vid, 'url': url}

    if not any(host in low for host in ('youtube.com', 'youtu.be', 'youtube-nocookie.com')):
        return None

    if not low.startswith(('http://', 'https://')):
        cleaned = 'https://' + cleaned.lstrip('/')

    list_match = re.search(r'[?&]list=([A-Za-z0-9_-]+)', cleaned)
    list_id = list_match.group(1) if list_match else ''
    vid = tube_engine.extract_video_id(cleaned)
    explicit_playlist = (
        kind in ('HTML', 'BUTTON')
        or '/playlist' in low
        or '/embed/videoseries' in low
        or (kind == 'IMAGE_LINK' and bool(list_id))
        or (is_series_like and bool(list_id))
    )
    if explicit_playlist and list_id:
        return {
            'type': 'yt_playlist',
            'id': list_id,
            'seed_id': vid if (vid and _YT_ID_RE.match(vid)) else '',
            'url': f'https://www.youtube.com/playlist?list={list_id}',
        }
    if vid and _YT_ID_RE.match(vid):
        return {'type': 'yt', 'id': vid, 'url': f'https://www.youtube.com/watch?v={vid}'}
    return None


def _walk_ricos_media(nodes, out):
    if not isinstance(nodes, list):
        return
    for node in nodes:
        if not isinstance(node, dict):
            continue
        ntype = node.get('type')
        if ntype == 'VIDEO':
            src = ((node.get('videoData') or {}).get('video') or {}).get('src') or {}
            raw = src.get('url') or src.get('id') or ''
            if raw:
                out.append(('VIDEO', raw))
        elif ntype == 'HTML':
            hdata = node.get('htmlData') or {}
            raw_html = html.unescape(hdata.get('html') or '')
            srcs = re.findall(r'src=["\']([^"\']+)["\']', raw_html, re.I)
            if not srcs and hdata.get('url'):
                srcs = [html.unescape(str(hdata['url']))]
            for src in srcs:
                out.append(('HTML', src))
        elif ntype == 'BUTTON':
            url = ((node.get('buttonData') or {}).get('link') or {}).get('url') or ''
            if url:
                out.append(('BUTTON', url))
        elif ntype == 'IMAGE':
            url = ((node.get('imageData') or {}).get('link') or {}).get('url') or ''
            if url:
                out.append(('IMAGE_LINK', url))
        if 'nodes' in node:
            _walk_ricos_media(node['nodes'], out)


def _season_from_title(title_text):
    match = re.search(r'\btemporada\s+(\d{1,2})\b', title_text or '', re.I)
    if match:
        return str(int(match.group(1)))
    return '1'


def _build_record(post_data, tag_labels):
    slug = (post_data.get('slug') or '').strip()
    raw_title = ' '.join(str(post_data.get('title') or '').split())
    if not slug or not raw_title:
        return None

    cat_ids = set(post_data.get('categories') or [])
    if not (cat_ids & set(TARGET_CATEGORY_IDS)):
        return None

    is_series_cat = CAT_SERIES in cat_ids
    is_cortos_cat = CAT_CORTOS in cat_ids
    is_infantil_cat = CAT_INFANTIL in cat_ids
    is_peliculas_cat = CAT_PELICULAS in cat_ids

    raw_nodes = []
    _walk_ricos_media((post_data.get('richContent') or {}).get('nodes'), raw_nodes)
    series_hint = is_series_cat or (is_infantil_cat and not is_peliculas_cat and not is_cortos_cat)

    media = []
    seen_media = set()
    for kind, raw_url in raw_nodes:
        entry = _normalize_media_entry(kind, raw_url, is_series_like=series_hint)
        if not entry:
            continue
        dedup_key = (entry['type'], entry['id'])
        if dedup_key in seen_media:
            continue
        seen_media.add(dedup_key)
        media.append(entry)

    if not media:
        return None

    has_playlist = any(m['type'] == 'yt_playlist' for m in media)
    if is_series_cat:
        is_serie = True
    elif is_infantil_cat and not is_peliculas_cat and not is_cortos_cat:
        is_serie = len(media) > 1 or has_playlist
    else:
        is_serie = False

    tag_names = [tag_labels[tid] for tid in (post_data.get('tags') or []) if tid in tag_labels]
    genre_keys = set()
    display_genres = []
    for tname in tag_names:
        norm_tag = _norm(tname)
        mapped = _TAG_GENRE_MAP.get(norm_tag)
        if mapped:
            genre_keys.add(mapped)
        if norm_tag == 'animacion' and 'Animación' not in display_genres:
            display_genres.append('Animación')
        elif tname not in display_genres and len(display_genres) < 4:
            display_genres.append(tname)

    if is_cortos_cat and not is_serie:
        genre_keys.add('cortos')
        if 'Cortometraje' not in display_genres:
            display_genres.insert(0, 'Cortometraje')
    if is_infantil_cat:
        if 'Infantil' not in display_genres:
            display_genres.insert(0, 'Infantil')
        if is_serie:
            genre_keys.update(('kids', 'familia', 'argentinas'))
        else:
            genre_keys.update(('familia', 'argentinas'))
    if is_peliculas_cat and not is_serie:
        genre_keys.add('argentinas')
    if is_series_cat:
        genre_keys.add('argentinas')
    if is_serie:
        genre_keys.add('argentinas')

    plot = ' '.join(str(post_data.get('plainContent') or post_data.get('excerpt') or '').split())
    year = _extract_year(raw_title, plot)
    cover = _wix_image(post_data.get('coverImage'))
    return {
        'title': raw_title,
        'slug': slug,
        'url': BASE + '/ver/' + urllib.parse.quote(slug, safe=''),
        'cover': cover,
        'plot': plot,
        'year': year,
        'is_serie': is_serie,
        'section': 'series' if is_serie else 'peliculas',
        'genres': display_genres,
        'genre_keys': sorted(genre_keys),
        'arg_cats': [
            name for cid, name in (
                (CAT_PELICULAS, 'peliculas'),
                (CAT_SERIES, 'series'),
                (CAT_CORTOS, 'cortos'),
                (CAT_INFANTIL, 'infantil'),
            ) if cid in cat_ids
        ],
        'media': media,
        'season_hint': _season_from_title(raw_title),
        'norm_title': _norm(raw_title),
        'norm_plot': _norm(plot),
        'norm_tags': _norm(' '.join(tag_names)),
    }


def _http_json(url, headers=None, timeout=8):
    req_headers = {'User-Agent': network.UA}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers)
    with network.abrir_url(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8', 'replace'))


def _fetch_catalog_remote():
    tokens = _http_json(BASE + '/_api/v1/access-tokens', timeout=8)
    auth = ((tokens.get('apps') or {}).get(_DBSM_APP_ID) or {}).get('instance')
    if not auth:
        raise network.ServidorNoDisponible('Argflix no entregó token de acceso público.')
    headers = {
        'Authorization': auth,
        'x-wix-brand': 'studio',
        'commonconfig': json.dumps({'brand': 'studio', 'host': 'VIEWER', 'BSI': ''}),
    }

    def query_page(collection, offset, limit, filt=None):
        q = {'paging': {'limit': limit, 'offset': offset}}
        if filt:
            q['filter'] = filt
        payload = json.dumps({'dataCollectionId': collection, 'query': q}, separators=(',', ':')).encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('ascii').rstrip('=')
        return _http_json(f'{BASE}/_api/cloud-data/v2/items/query?.r={b64}', headers=headers, timeout=10)

    # Cargar tags principales en paralelo con el primer bloque de posts
    tag_labels = {}
    post_filter = {'categories': {'$hasSome': list(TARGET_CATEGORY_IDS)}}

    def fetch_tags():
        out = {}
        for off in range(0, 2000, 100):
            res = query_page('Blog/Tags', off, 100)
            batch = res.get('dataItems') or []
            for entry in batch:
                data = entry.get('data') or {}
                if data.get('_id') and data.get('label'):
                    out[data['_id']] = data['label']
            if len(batch) < 100:
                break
        return out

    first_res = query_page('Blog/Posts', 0, _PAGE_SIZE, filt=post_filter)
    first_posts = first_res.get('dataItems') or []
    paging_meta = first_res.get('pagingMetadata') or {}

    all_raw_posts = list(first_posts)
    with ThreadPoolExecutor(max_workers=4) as pool:
        tag_future = pool.submit(fetch_tags)
        next_off = _PAGE_SIZE
        has_more = len(first_posts) >= _PAGE_SIZE and paging_meta.get('hasNext', True)
        while has_more and next_off < 5000:
            wave = [next_off + i * _PAGE_SIZE for i in range(4)]
            futures = {off: pool.submit(query_page, 'Blog/Posts', off, _PAGE_SIZE, post_filter) for off in wave}
            next_off += len(wave) * _PAGE_SIZE
            for off in wave:
                res = futures[off].result()
                batch = res.get('dataItems') or []
                all_raw_posts.extend(batch)
                if len(batch) < _PAGE_SIZE or not (res.get('pagingMetadata') or {}).get('hasNext', True):
                    has_more = False
                    break
        try:
            tag_labels = tag_future.result()
        except Exception:
            tag_labels = {}

    records = []
    seen_slugs = set()
    for raw_item in all_raw_posts:
        pdata = raw_item.get('data') or {}
        rec = _build_record(pdata, tag_labels)
        if rec and rec['slug'] not in seen_slugs:
            seen_slugs.add(rec['slug'])
            records.append(rec)
    return records


_CACHE_VERSION = 2


def _load_disk_cache():
    path = _profile_cache_path()
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if (isinstance(data, dict) and data.get('v') == _CACHE_VERSION
                and isinstance(data.get('items'), list)):
            return data
    except (OSError, ValueError, TypeError):
        pass
    return None


def _save_disk_cache(items):
    path = _profile_cache_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump({'v': _CACHE_VERSION, 'updated': time.time(), 'items': items}, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def _catalog():
    global _last_error_at
    now = time.time()
    with _lock:
        if _mem_cache['items'] is not None and now - _mem_cache['updated'] < _CACHE_TTL:
            return _mem_cache['items']
        disk = _load_disk_cache()
        if disk and now - float(disk.get('updated') or 0) < _CACHE_TTL:
            _mem_cache['updated'] = float(disk.get('updated') or now)
            _mem_cache['items'] = disk['items']
            return _mem_cache['items']
        if _mem_cache['items'] is not None and now - _last_error_at < _ERROR_COOLDOWN:
            return _mem_cache['items']
        if now - _last_error_at < _ERROR_COOLDOWN:
            if disk and disk.get('items'):
                return disk['items']
            return []
        try:
            records = _fetch_catalog_remote()
            _mem_cache['updated'] = time.time()
            _mem_cache['items'] = records
            _last_error_at = 0.0
            _save_disk_cache(records)
            return records
        except Exception as exc:
            _last_error_at = time.time()
            network.log_resolver(f'Argflix catalogo no disponible ({type(exc).__name__})')
            if _mem_cache['items'] is not None:
                return _mem_cache['items']
            if disk and disk.get('items'):
                return disk['items']
            raise network.ServidorNoDisponible('Argflix no pudo entregar su catálogo.') from exc


def _to_card(rec):
    return {
        'title': rec['title'],
        'original_title': rec['title'],
        'url': rec['url'],
        'cover': rec.get('cover') or '',
        'plot': rec.get('plot') or '',
        'year': rec.get('year') or '',
        'genres': list(rec.get('genres') or []),
        'is_serie': bool(rec.get('is_serie')),
        'section': rec.get('section') or ('series' if rec.get('is_serie') else 'peliculas'),
        'source': 'argflix',
    }


def owns(url):
    if not isinstance(url, str):
        return False
    host = (urllib.parse.urlsplit(url).hostname or '').lower()
    return host in ('argflix.com', 'www.argflix.com')


def supports_genre(section, genre):
    if section not in ('peliculas', 'series'):
        return False
    if source_switches.only_enabled('argflix'):
        return True
    if not genre:
        return False
    return genre.lower() in _PUBLIC_GENRES.get(section, ())


def search(query, section='all'):
    if not source_switches.enabled('argflix'):
        return []
    if section not in ('all', 'peliculas', 'series'):
        return []
    norm_q = _norm(query)
    if not norm_q:
        return []
    q_words = norm_q.split()
    try:
        records = _catalog()
    except network.ServidorNoDisponible:
        return []

    matches = []
    for rec in records:
        if section != 'all' and rec['section'] != section:
            continue
        nt = rec.get('norm_title') or _norm(rec['title'])
        ng = rec.get('norm_tags') or ''
        if (norm_q in nt or norm_q in ng
                or (len(q_words) > 1 and all(w in nt or w in ng for w in q_words))):
            matches.append(_to_card(rec))
    return matches


def page(section, number, genre=None, size=24):
    if not source_switches.enabled('argflix'):
        return [], False
    if section not in ('peliculas', 'series') or not isinstance(number, int) or number < 1:
        return [], False
    only_arg = source_switches.only_enabled('argflix')
    if not only_arg and not genre:
        # Excluido de TODO cuando convive con otras fuentes.
        return [], False

    genre_key = (genre or '').lower().strip()
    if not only_arg and not supports_genre(section, genre_key):
        return [], False

    records = _catalog()
    filtered = []
    for rec in records:
        if rec['section'] != section:
            continue
        if genre_key and genre_key not in (rec.get('genre_keys') or []):
            continue
        filtered.append(rec)

    start = (number - 1) * size
    cards = [_to_card(rec) for rec in filtered[start:start + size]]
    return cards, start + size < len(filtered)


def _find_record(item_or_series):
    url = (item_or_series or {}).get('url', '')
    if not owns(url):
        return None
    slug_part = urllib.parse.urlsplit(url).path
    match = re.search(r'/ver/([^/]+)', slug_part)
    if not match:
        return None
    slug = urllib.parse.unquote(match.group(1))
    for rec in _catalog():
        if rec['slug'] == slug:
            return rec
    return None


def _expand_playlist(list_id):
    with _playlist_lock:
        cached = _playlist_cache.get(list_id)
        if cached and time.monotonic() - cached[0] < 3600:
            return cached[1]
    _, videos = tube_engine.get_playlist_videos(list_id, limit=100)
    with _playlist_lock:
        _playlist_cache[list_id] = (time.monotonic(), list(videos or []))
    return list(videos or [])


def _series_video_entries(rec):
    entries = []
    seen_yt = set()
    seen_vimeo = set()
    media = rec.get('media') or []

    # Expandir primero playlists explicitas (suelen traer temporadas completas)
    for m in media:
        if m['type'] == 'yt_playlist':
            try:
                pl_vids = _expand_playlist(m['id'])
            except Exception:
                pl_vids = []
            for v in pl_vids:
                vid = v.get('id')
                if vid and vid not in seen_yt:
                    seen_yt.add(vid)
                    entries.append({
                        'title': v.get('title') or f'Episodio {len(entries) + 1}',
                        'video_url': f'https://www.youtube.com/watch?v={vid}',
                        'cover': v.get('cover') or rec.get('cover') or '',
                    })
            if not pl_vids and m.get('seed_id') and m['seed_id'] not in seen_yt:
                seen_yt.add(m['seed_id'])
                entries.append({
                    'title': f'Episodio {len(entries) + 1}',
                    'video_url': f"https://www.youtube.com/watch?v={m['seed_id']}",
                    'cover': rec.get('cover') or '',
                })

    for m in media:
        if m['type'] == 'yt' and m['id'] not in seen_yt:
            seen_yt.add(m['id'])
            entries.append({
                'title': f'Episodio {len(entries) + 1}',
                'video_url': m['url'],
                'cover': rec.get('cover') or '',
            })
        elif m['type'] == 'vimeo' and m['id'] not in seen_vimeo:
            seen_vimeo.add(m['id'])
            entries.append({
                'title': f'Episodio {len(entries) + 1}',
                'video_url': m['url'],
                'cover': rec.get('cover') or '',
            })
    return entries


def episodes(series):
    rec = _find_record(series)
    if not rec or not rec.get('is_serie'):
        return {}
    season = rec.get('season_hint') or '1'
    base_url = rec['url'].rstrip('/')
    raw_eps = _series_video_entries(rec)
    ep_list = []
    for idx, ep in enumerate(raw_eps, 1):
        ep_url = f'{base_url}/temporada/{season}/episodio/{idx}'
        ep_list.append({
            'title': ep['title'] or f'Episodio {idx}',
            'url': ep_url,
            'video_url': ep['video_url'],
            'season': season,
            'episode': str(idx),
            'cover': ep.get('cover') or rec.get('cover') or '',
            'series_title': rec['title'],
            'tmdb_id': (series or {}).get('tmdb_id'),
            'is_serie': True,
            'is_episode': True,
            'section': 'series',
            'source': 'argflix',
        })
    return {season: ep_list} if ep_list else {}


def _server_dict(host_label, url, origin_url):
    return {
        'nombre': f'{host_label} [Argflix]',
        'url': url,
        'origin_url': origin_url,
        'calidad': 'Sin verificar',
        'idioma': 'Latino',
        'source': 'argflix',
    }


def servers(item, series=None):
    root = series or item
    rec = _find_record(root)
    if not rec:
        return []

    if series or item.get('episode') is not None:
        if item.get('video_url') and owns(item.get('url', '')):
            label = 'Vimeo' if 'vimeo.com' in item['video_url'].lower() else 'YouTube'
            return [_server_dict(label, item['video_url'], item['url'])]
        season = str(item.get('season') or rec.get('season_hint') or '1')
        ep_num = str(item.get('episode') or '')
        grouped = episodes(rec)
        ep_list = grouped.get(season) or []
        match = next((ep for ep in ep_list if str(ep.get('episode')) == ep_num), None)
        if not match:
            return []
        label = 'Vimeo' if 'vimeo.com' in match['video_url'].lower() else 'YouTube'
        return [_server_dict(label, match['video_url'], item.get('url') or match['url'])]

    found = []
    media = rec.get('media') or []
    expanded_entries = []
    for m in media:
        if m['type'] == 'yt_playlist':
            try:
                for v in _expand_playlist(m['id']):
                    vid = v.get('id')
                    if vid:
                        expanded_entries.append(('YouTube', f'https://www.youtube.com/watch?v={vid}', v.get('title') or ''))
            except Exception:
                if m.get('seed_id'):
                    expanded_entries.append(('YouTube', f"https://www.youtube.com/watch?v={m['seed_id']}", ''))
        elif m['type'] == 'vimeo':
            expanded_entries.append(('Vimeo', m['url'], ''))
        elif m['type'] == 'yt':
            expanded_entries.append(('YouTube', m['url'], ''))

    seen_urls = set()
    total = len(expanded_entries)
    for idx, (host_lbl, media_url, part_title) in enumerate(expanded_entries, 1):
        if media_url in seen_urls:
            continue
        seen_urls.add(media_url)
        label = host_lbl
        if total > 1:
            label = f'{host_lbl} · {part_title}' if part_title else f'{host_lbl} (Parte {idx})'
        found.append(_server_dict(label, media_url, item.get('url') or rec['url']))

    if not found:
        raise network.ServidorNoDisponible('Argflix no publicó vídeo reproducible para esta ficha.')
    return found


def metadata(item):
    rec = _find_record(item)
    if not rec:
        return {}
    out = {}
    if rec.get('cover'):
        out['cover'] = rec['cover']
    if rec.get('plot'):
        out['plot'] = rec['plot']
        out['plot_language'] = 'es'
    if rec.get('year'):
        out['year'] = rec['year']
    if rec.get('genres'):
        out['genres'] = list(rec['genres'])
    return out
