"""Catálogo público de FrikiSeries; las URLs de vídeo se verifican al reproducir."""

import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlsplit

import network

BASE = 'https://www.frikiserie.com'
_cache = {}
_lock = threading.RLock()
_tmdb_cache = {}


def _image(url):
    """ImageKit's auto format can return AVIF/WebP, which Kodi may not decode."""
    if not isinstance(url, str):
        return ''
    if urlsplit(url).hostname == 'ik.imagekit.io':
        return url.split('?tr=', 1)[0] + '?tr=w-500,q-85,f-jpg'
    return url


def _tmdb(item):
    """Only attach a unique title and year match of the same media type."""
    import catalog_index
    import lolplus
    key = (item.get('title'), str(item.get('year') or '')[:4], bool(item.get('is_serie')))
    with _lock:
        if key in _tmdb_cache:
            return _tmdb_cache[key]
    try:
        candidates = lolplus.lolplus_catalog_search(item['title'], section='series' if key[2] else 'peliculas')
        name = catalog_index.normalize(item['title'])
        matches = [candidate for candidate in candidates
                   if catalog_index.normalize(candidate.get('title', '')) == name
                   and (not key[1].isdigit() or str(candidate.get('year') or '')[:4] == key[1])]
        result = matches[0] if len(matches) == 1 else {}
    except Exception as exc:
        network.log_resolver('FrikiSeries: TMDb no disponible ({})'.format(type(exc).__name__))
        return {}
    with _lock:
        _tmdb_cache[key] = result
    return result


def _enrich(item):
    match = _tmdb(item)
    if not match:
        return item
    enriched = dict(item, tmdb_id=match.get('tmdb_id'))
    for field in ('cover', 'plot', 'rating'):
        if match.get(field):
            enriched[field] = match[field]
    if match.get('plot'):
        enriched['plot_language'] = 'es'
    return enriched


def _data(name):
    with _lock:
        cached = _cache.get(name)
        if cached and time.monotonic() - cached[0] < 900:
            return cached[1]
    raw, _ = network.fetch_html(BASE + '/assets/data/' + name + '.json',
                                referer=BASE + '/', timeout=15)
    try:
        entries = json.loads(raw)[name]
    except (ValueError, TypeError, KeyError) as exc:
        raise network.ServidorNoDisponible('FrikiSeries no entregó un catálogo válido.') from exc
    if not isinstance(entries, list):
        raise network.ServidorNoDisponible('FrikiSeries no entregó un catálogo válido.')
    with _lock:
        _cache[name] = (time.monotonic(), entries)
    return entries


def owns(url):
    return urlsplit(url).hostname in ('frikiserie.com', 'www.frikiserie.com')


def search(query):
    needle = query.casefold().strip()
    if not needle:
        return []
    result = []
    for entry in _data('info'):
        if not isinstance(entry, dict) or needle not in str(entry.get('titulo', '')).casefold():
            continue
        slug = entry.get('slug')
        if not isinstance(slug, str) or not slug or '/' in slug:
            continue
        is_serie = entry.get('tipo') == 'serie'
        result.append({'title': entry['titulo'].strip(), 'url': BASE + '/lista-series/' + quote(slug)
                       if is_serie else BASE + '/ver-serie/' + quote(slug),
                       'cover': _image(entry.get('imagen')), 'plot': entry.get('descripcion') or '',
                       'year': str(entry.get('fecha') or ''), 'source': 'frikiserie',
                       'is_serie': is_serie, 'section': 'series' if is_serie else 'peliculas'})
    with ThreadPoolExecutor(max_workers=6) as pool:
        return list(pool.map(_enrich, result[:30])) + result[30:]


def page(section, number, size=24):
    if section not in ('series', 'peliculas') or number < 1:
        return [], False
    entries = _data('info')
    wanted = section == 'series'
    cards = []
    for entry in entries:
        if not isinstance(entry, dict) or (entry.get('tipo') == 'serie') != wanted:
            continue
        slug = entry.get('slug')
        if not isinstance(slug, str) or not slug or '/' in slug:
            continue
        cards.append({'title': str(entry.get('titulo') or '').strip(),
                      'url': BASE + ('/lista-series/' if wanted else '/ver-serie/') + quote(slug),
                      'cover': _image(entry.get('imagen')), 'plot': entry.get('descripcion') or '',
                      'year': str(entry.get('fecha') or ''), 'source': 'frikiserie',
                      'is_serie': wanted, 'section': section})
    start = (number - 1) * size
    with ThreadPoolExecutor(max_workers=6) as pool:
        visible = list(pool.map(_enrich, cards[start:start + size]))
    return visible, start + size < len(cards)


def episodes(series):
    if not owns(series.get('url', '')):
        return {}
    title = series.get('title', '').strip()
    grouped = {}
    for entry in _data('capitulos'):
        if not isinstance(entry, dict) or str(entry.get('serie', '')).strip() != title:
            continue
        season, number = entry.get('temporada'), entry.get('capitulo')
        if not str(season).isdigit() or not str(number).isdigit():
            continue
        season, number = str(int(season)), str(int(number))
        grouped.setdefault(season, []).append({
            'title': entry.get('titulo') or 'Episodio ' + number,
            'url': BASE + '/ver-serie/' + quote(urlsplit(series['url']).path.rsplit('/', 1)[-1])
                   + '/temporada/' + season + '/capitulo/' + number,
            'season': season, 'episode': number, 'cover': series.get('cover') or _image(entry.get('imagen')),
            'series_title': title,
            'tmdb_id': series.get('tmdb_id'),
            'is_serie': True, 'section': 'series', 'source': 'frikiserie'})
    return grouped


def servers(item, series=None):
    root = series or item
    title = (root.get('series_title') or root.get('title') or '').strip()
    season, number = item.get('season'), item.get('episode')
    if not title or (series and (season is None or number is None)):
        return []
    entries = _data('capitulos') if season is not None and number is not None else _data('info')
    found = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if season is not None and number is not None:
            if str(entry.get('serie', '')).strip() != title or str(entry.get('temporada')) != str(season) or str(entry.get('capitulo')) != str(number):
                continue
        elif str(entry.get('titulo', '')).strip() != title:
            continue
        url = entry.get('video')
        parsed = urlsplit(url) if isinstance(url, str) else None
        if not parsed or parsed.scheme not in ('http', 'https') or not parsed.hostname:
            continue
        found.append({'nombre': parsed.hostname + ' [FrikiSeries]', 'url': url,
                      'origin_url': item.get('url'), 'calidad': 'Sin verificar',
                      'idioma': 'Latino', 'source': 'frikiserie'})
    if not found:
        raise network.ServidorNoDisponible('FrikiSeries no publicó vídeo para esta ficha.')
    return found
