"""Loopback HLS adapter for TS segments wrapped in a small PNG image.

Only opaque, registered resource tokens are exposed; never an arbitrary URL relay.
Signed queries and upstream headers are preserved.
"""
import hashlib
import re
import secrets
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urljoin
from urllib.request import Request
import network

_CONTENT_TYPES = {
    'm3u8': 'application/vnd.apple.mpegurl',
    'ts': 'video/mp2t',
    'mpd': 'application/dash+xml',
}


def _content_type(kind):
    return _CONTENT_TYPES.get(kind, 'application/octet-stream')


def unwrap_ts(data):
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        return data
    offset = 8
    while offset + 12 <= min(len(data), 65536):
        size = int.from_bytes(data[offset:offset + 4], 'big')
        kind = data[offset + 4:offset + 8]
        offset += 12 + size
        if offset > 65536 or offset > len(data):
            break
        if kind == b'IEND':
            if offset + 376 < len(data) and all(data[offset + n * 188] == 0x47 for n in range(3)):
                return data[offset:]
            break
    raise ValueError('PNG resource does not contain verified MPEG-TS')


class HlsProxy:
    def __init__(self):
        self.resources = {}
        self.inline_bodies = {}
        self.reverse = {}
        self.lock = threading.Lock()
        self.active_clients = set()
        proxy = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass
            def finish(self):
                try:
                    super().finish()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass
                finally:
                    with proxy.lock:
                        proxy.active_clients.discard(self.connection)
            def do_HEAD(self):
                token = self.path.split('?', 1)[0].split('|', 1)[0].lstrip('/').split('.')[0]
                with proxy.lock:
                    resource = proxy.resources.get(token)
                if resource is None:
                    self.send_response(404)
                    self.send_header('Content-Length', '0')
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    try:
                        self.wfile.flush()
                    except Exception:
                        pass
                    self.close_connection = True
                    return
                _, _, kind = resource
                self.send_response(200)
                self.send_header('Content-Type', _content_type(kind))
                self.send_header('Content-Length', '0')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Connection', 'close')
                self.end_headers()
                try:
                    self.wfile.flush()
                except Exception:
                    pass
                self.close_connection = True
            def do_GET(self):
                with proxy.lock:
                    proxy.active_clients.add(self.connection)
                token = self.path.split('?', 1)[0].lstrip('/').split('.')[0]
                with proxy.lock:
                    resource = proxy.resources.get(token)
                    inline_body = proxy.inline_bodies.get(token)
                if resource is None:
                    try:
                        self.send_error(404)
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        pass
                    return
                url, headers, kind = resource
                try:
                    if inline_body is not None:
                        body = inline_body
                    else:
                        with network.abrir_url(Request(url, headers=headers), timeout=12) as response:
                            body = response.read(64 * 1024 * 1024 + 1)
                            final_url = response.geturl()
                        if len(body) > 64 * 1024 * 1024:
                            raise ValueError('Resource too large')
                        if kind == 'm3u8':
                            text = body.decode('utf-8-sig')
                            if not text.lstrip().startswith('#EXTM3U'):
                                raise ValueError('Invalid HLS manifest')
                            body = proxy.rewrite(text, final_url, headers).encode('utf-8')
                        elif kind == 'ts':
                            body = unwrap_ts(body)
                    total = len(body)
                    requested = self.headers.get('Range', '')
                    match = re.fullmatch(r'bytes=(\d+)-(\d*)', requested)
                    if match:
                        start = int(match.group(1))
                        end = min(int(match.group(2)) if match.group(2) else total-1, total-1)
                        if start > end:
                            self.send_error(416)
                            return
                        body = body[start:end+1]
                        self.send_response(206)
                        self.send_header('Content-Range', 'bytes {}-{}/{}'.format(start, end, total))
                    else:
                        self.send_response(200)
                    self.send_header('Content-Type', _content_type(kind))
                    self.send_header('Content-Length', str(len(body)))
                    self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    self.wfile.write(body)
                    self.close_connection = True
                except (BrokenPipeError, ConnectionResetError):
                    pass
                except Exception:
                    try:
                        self.send_error(502)
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        pass
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, name='VaquexflixHLS', daemon=True)
        self.thread.start()

    def register(self, url, headers, kind='m3u8'):
        key = (url, tuple(sorted(headers.items())), kind)
        with self.lock:
            token = self.reverse.get(key)
            if token is None:
                if len(self.resources) >= 20000:
                    raise ValueError('HLS resource limit')
                token = secrets.token_urlsafe(24)
                self.resources[token] = (url, dict(headers), kind)
                self.reverse[key] = token
        return 'http://127.0.0.1:{}/{}.{}'.format(self.server.server_port, token, kind)

    def register_content(self, content, headers=None, kind='mpd'):
        """Registra un manifiesto estático en memoria para servirlo por HTTP local."""
        body = content.encode('utf-8') if isinstance(content, str) else bytes(content)
        hdrs = dict(headers or {})
        digest = hashlib.sha256(body).hexdigest()
        key = ('inline://' + digest, tuple(sorted(hdrs.items())), kind)
        with self.lock:
            token = self.reverse.get(key)
            if token is None:
                if len(self.resources) >= 20000:
                    raise ValueError('HLS resource limit')
                token = secrets.token_urlsafe(24)
                self.resources[token] = (key[0], hdrs, kind)
                self.inline_bodies[token] = body
                self.reverse[key] = token
        return 'http://127.0.0.1:{}/{}.{}'.format(self.server.server_port, token, kind)

    def rewrite(self, text, base, headers):
        output = []
        variant = False
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                kind = 'm3u8' if variant else 'ts'
                line = self.register(urljoin(base, stripped), headers, kind)
                variant = False
            elif stripped.startswith('#'):
                kind = 'm3u8' if stripped.startswith(('#EXT-X-MEDIA:', '#EXT-X-I-FRAME-STREAM-INF:')) else 'bin'
                line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + self.register(urljoin(base, m.group(1)), headers, kind) + '"', line)
                if stripped.startswith('#EXT-X-STREAM-INF:'):
                    variant = True
            output.append(line)
        return '\n'.join(output) + '\n'

    def close(self):
        self.cancel_active()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        with self.lock:
            self.resources.clear()
            self.inline_bodies.clear()
            self.reverse.clear()

    def cancel_active(self):
        """Desbloquea a Kodi si espera un segmento durante PlayerControl(Stop)."""
        with self.lock:
            clients = list(self.active_clients)
        for client in clients:
            try:
                client.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


_proxy = None
_lock = threading.Lock()


def start(url, headers):
    global _proxy
    with _lock:
        if _proxy is None:
            _proxy = HlsProxy()
        return _proxy.register(url, headers)


def start_manifest(content, headers=None, kind='mpd'):
    """Expone un manifiesto estático (p. ej. MPD de YouTube) en el proxy global."""
    global _proxy
    with _lock:
        if _proxy is None:
            _proxy = HlsProxy()
        return _proxy.register_content(content, headers=headers, kind=kind)


def close():
    global _proxy
    with _lock:
        proxy, _proxy = _proxy, None
    if proxy is not None:
        proxy.close()


def cancel_active():
    with _lock:
        proxy = _proxy
    if proxy is not None:
        proxy.cancel_active()
