"""Listados publicados por las fuentes internas de LolPlus.

Se usan al aislar fuentes para no presentar fichas generales de TMDb como si
provinieran de un proveedor concreto.
"""
import html
import re
import unicodedata
from urllib.parse import quote, urljoin, urlsplit

import lolplus
import source_switches


_ROUTES = {
    'seriesmetro': {'series': '/', 'peliculas': '/'},
    'serieskao': {'series': '/series/populares', 'peliculas': '/peliculas/populares'},
    'seriesflix': {'series': '/'},
    'poseidon': {'series': '/series/estrenos', 'peliculas': '/peliculas/estrenos'},
    'cuevana': {'series': '/series/estrenos', 'peliculas': '/peliculas/estrenos'},
    'pelisplus': {'peliculas': '/peliculas/estrenos'},
    'pelisflixhd': {'series': '/', 'peliculas': '/'},
}
_QUERY = {
    'seriesmetro': '/?s=', 'serieskao': '/search?s=',
    'seriesflix': '/?s=', 'poseidon': '/search?q=',
    'cuevana': '/search?q=', 'pelisplus': '/search?s=',
    'pelisflixhd': '/?s=',
}


def _plain(value):
    text = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', value or ''))).strip()
    if 'Ã' in text:
        try:
            text = text.encode('latin-1').decode('utf-8')
        except (UnicodeError, ValueError):
            pass
    return text


def _tokens(value):
    value = unicodedata.normalize('NFKD', value.lower())
    value = ''.join(char for char in value if not unicodedata.combining(char))
    words = re.findall(r'[a-z0-9]+', value)
    return [word for word in words if len(word) >= 3] or words


def _cards(markup, key, section):
    base = lolplus.DOMAINS[key]
    if key == 'seriesmetro':
        raw = []
        for body in re.findall(r'<article\b[^>]*class="post[^\"]*"[^>]*>(.*?)</article>', markup, re.I | re.S):
            link = re.search(r'<a\b[^>]*href="([^"]+)"[^>]*class="lnk-blk"', body, re.I)
            title = re.search(r'<h2\b[^>]*class="entry-title"[^>]*>(.*?)</h2>', body, re.I | re.S)
            if link and title:
                raw.append((link.group(1), _plain(title.group(1)), body))
    else:
        raw = []
        for tag, href, body in re.findall(r'(<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>)(.*?)</a>',
                                          markup, re.I | re.S):
            title = ''
            if key == 'seriesflix':
                match = re.search(r'<div\b[^>]*class=["\']Title["\'][^>]*>(.*?)</div>', body, re.I | re.S)
                title = _plain(match.group(1)) if match else ''
            if key == 'pelisplus':
                match = re.search(r'<div\b[^>]*class=["\']listing-content["\'][^>]*>\s*<p>(.*?)</p>', body, re.I | re.S)
                title = _plain(match.group(1)) if match else ''
            if not title:
                image = re.search(r'<img\b[^>]*\balt=["\']([^"\']+)', body, re.I)
                title = _plain(image.group(1)) if image else ''
            if title.lower().startswith('poster '):
                title = title[7:].strip()
            if key == 'seriesflix' and title.lower().endswith(' serie'):
                title = title[:-6].strip()
            if title:
                raw.append((href, title, body))
    found = {}
    path_pattern = r'/serie/' if section == 'series' else r'/pelicula/'
    if key == 'cuevana':
        path_pattern = r'/ver-serie/' if section == 'series' else r'/ver-pelicula/'
    for href, title, body in raw:
        url = urljoin(base, html.unescape(href))
        parsed = urlsplit(url)
        if not re.search(path_pattern + r'[^/?#]+', parsed.path, re.I):
            continue
        if not parsed.hostname:
            continue
        if parsed.hostname.split('.')[-2:] != urlsplit(base).hostname.split('.')[-2:]:
            # Algunos portales cambian subdominio o TLD operativo sin alterar la marca.
            if key not in ('seriesflix', 'pelisflixhd') or key not in parsed.hostname:
                continue
        image = re.search(r'<img\b[^>]*\bsrc=["\']([^"\']+)', body, re.I)
        found[url] = {'title': title, 'url': url,
                      'cover': urljoin(base, html.unescape(image.group(1))) if image else '',
                      'source': source_switches.LABELS[key],
                      'is_serie': section == 'series', 'section': section}
    return list(found.values())


def page(key, section, number=1, query=None):
    if key not in _ROUTES or section not in _ROUTES[key] or not source_switches.enabled(key):
        return [], False
    if not isinstance(number, int) or number < 1:
        return [], False
    base = lolplus.DOMAINS[key]
    route = _QUERY[key] + quote(query) if query else _ROUTES[key][section]
    if number > 1 and not query:
        if key not in ('poseidon', 'cuevana'):
            return [], False
        route = route.rstrip('/') + '/page/' + str(number)
    url = urljoin(base, route)
    markup = lolplus.make_request(url, headers={'User-Agent': lolplus.DEFAULT_UA,
                                                 'Referer': base + '/'}, timeout=8)
    if not markup:
        return [], False
    items = _cards(markup, key, section)
    more = not query and key in ('poseidon', 'cuevana') and (
        '/page/' + str(number + 1)) in markup
    return items, more


def search(key, query):
    if key not in _ROUTES or not source_switches.enabled(key) or not query:
        return []
    base = lolplus.DOMAINS[key]
    url = urljoin(base, _QUERY[key] + quote(query))
    markup = lolplus.make_request(url, headers={'User-Agent': lolplus.DEFAULT_UA,
                                                 'Referer': base + '/'}, timeout=8)
    if not markup:
        return []
    terms = _tokens(query)
    return [item for section in _ROUTES[key] for item in _cards(markup, key, section)
            if terms and all(term in _tokens(item['title']) for term in terms)]
