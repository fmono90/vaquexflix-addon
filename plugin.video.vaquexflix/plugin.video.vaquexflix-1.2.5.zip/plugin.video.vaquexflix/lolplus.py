# -*- coding: utf-8 -*-
"""
Modulo de integracion y resolucion para LolPlusTV en Kodi.
Extraido mediante ingenieria inversa del binario Flutter/Dart (com.example.lol).
Implementa catalogo TMDB, extraccion multi-proveedor (ServerLoader),
resolutores de video nativos y xbmcplugin.setResolvedUrl().
"""

import os
import re
import sys
import json
import base64
import urllib.parse
import urllib.request
import ssl
from html import unescape
import network
import unicodedata
import time
from datetime import date, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed, wait as cf_wait
from difflib import SequenceMatcher

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False
    xbmc = None
    xbmcgui = None
    xbmcplugin = None

# ==============================================================================
# CONFIGURACIÓN Y CONSTANTES REVERSADAS DEL APK
# ==============================================================================

# API Keys de TMDB recuperadas de libapp.so (package:lol/servicio/tmdb)
TMDB_API_KEYS = [
    "439c478a771f35c05022f9feabcca01c",
    "a2d9bbed370d9f678e34006f8750a5a5"
]
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p"

# User-Agent estandar observado en el trafico y constantes del cliente HTTP Dart
DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
DART_UA = "Dart/3.4 (dart:io)"

# Dominios base observados
DOMAINS = {
    "poseidon": "https://www.poseidonhd2.co",
    "cuevana": "https://wv3.cuevana3.eu",
    "pelisplus": "https://www.pelisplushd.la",
    "serieskao": "https://serieskao.top",
    "seriesmetro": "https://www3.seriesmetro.net",
    "cinecalidad": "https://www.cinecalidad.am",
    "tioplus": "https://tioplus.app",
    "seriesflix": "https://seriesflixhd.lol",
    "pelisflixhd": "https://pelisflixhd.win",
    "unlimplay": "https://unlimplay.com",
    "modlyo": "https://www.modlyo.com",
    "pixeldrain": "https://pixeldrain.com",
    "buzzheavier": "https://buzzheavier.com",
    "seriesturcas": "https://tbg.seriesturcastv.to",
    "lacartoons": "https://www.lacartoons.com"
}


# ==============================================================================
# UTILIDADES DE RED Y LOGGING
# ==============================================================================

def log(msg, level="INFO"):
    formatted = f"[LolPlusTV] [{level}] {msg}"
    if KODI_AVAILABLE and xbmc:
        xbmc_level = xbmc.LOGINFO if level == "INFO" else xbmc.LOGERROR
        xbmc.log(formatted, level=xbmc_level)
    else:
        print(formatted)


def make_request(url, headers=None, data=None, timeout=12, redirect=True):
    """
    Realiza una peticion HTTP con soporte SSL tolerante y cabeceras por defecto.
    """
    req_headers = {"User-Agent": DEFAULT_UA}
    if headers:
        req_headers.update(headers)

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(url, data=data, headers=req_headers)
    try:
        with network.abrir_url(req, timeout=timeout, context=ctx) as response:
            return response.read().decode("utf-8", errors="replace")
    except Exception as e:
        log(f"Error en peticion a {url}: {e}", level="ERROR")
        return ""


# ==============================================================================
# CATÁLOGO: TMDB API V3 (package:lol/servicio/tmdb)
# ==============================================================================

class LolPlusCatalog:
    """
    Motor de catalogo basado en la API oficial de TMDB identificada en libapp.so.
    """

    def __init__(self, api_key=None, language="es-MX"):
        self.api_keys = [api_key] + TMDB_API_KEYS if api_key else TMDB_API_KEYS
        self.language = language

    def _query(self, endpoint, params=None):
        if params is None:
            params = {}
        else:
            params = dict(params)
        params.setdefault("language", self.language)

        for key in self.api_keys:
            params["api_key"] = key
            qs = urllib.parse.urlencode(params)
            url = f"{TMDB_BASE_URL}{endpoint}?{qs}"
            raw = make_request(url)
            if raw:
                try:
                    data = json.loads(raw)
                    if "results" in data or "id" in data or "genres" in data:
                        return data
                except Exception as e:
                    log(f"Error parseando JSON de TMDB ({endpoint}): {e}", "ERROR")
        return {}

    def get_popular_movies(self, page=1):
        return self._query("/movie/popular", {"page": page})

    def get_top_rated_movies(self, page=1):
        return self._query("/movie/top_rated", {"page": page})

    def get_now_playing_movies(self, page=1):
        return self._query("/movie/now_playing", {"page": page})

    def get_trending_movies(self, page=1):
        return self._query("/trending/movie/week", {"page": page})

    def get_popular_series(self, page=1):
        return self._query("/tv/popular", {"page": page})

    def get_top_rated_series(self, page=1):
        return self._query("/tv/top_rated", {"page": page})

    def get_trending_series(self, page=1):
        return self._query("/trending/tv/week", {"page": page})

    def get_on_the_air_series(self, page=1):
        return self._query("/tv/on_the_air", {"page": page})

    def get_curated_page(self, section, collection, page=1, today=None):
        """Listas de TMDb y filtros de fecha con paginación estable."""
        today = today or date.today()
        if section == 'peliculas':
            if collection == 'populares':
                return self.get_popular_movies(page)
            if collection == 'tendencias':
                return self.get_trending_movies(page)
            if collection == 'mejor-valoradas':
                return self.get_top_rated_movies(page)
            if collection == 'recien-estrenadas':
                return self._query('/discover/movie', {
                    'page': page, 'sort_by': 'popularity.desc',
                    'primary_release_date.gte': (today - timedelta(days=90)).isoformat(),
                    'primary_release_date.lte': today.isoformat(), 'include_adult': 'false'})
            if collection == 'retro':
                return self._query('/discover/movie', {
                    'page': page, 'sort_by': 'popularity.desc',
                    'primary_release_date.lte': '1989-12-31', 'vote_count.gte': 50,
                    'include_adult': 'false'})
        elif section == 'series':
            if collection == 'populares':
                return self.get_popular_series(page)
            if collection == 'tendencias':
                return self.get_trending_series(page)
            if collection == 'en-emision':
                return self.get_on_the_air_series(page)
            if collection == 'mejor-valoradas':
                return self.get_top_rated_series(page)
            if collection == 'recien-estrenadas':
                return self._query('/discover/tv', {
                    'page': page, 'sort_by': 'popularity.desc',
                    'first_air_date.gte': (today - timedelta(days=90)).isoformat(),
                    'first_air_date.lte': today.isoformat(), 'include_adult': 'false'})
            if collection == 'retro':
                return self._query('/discover/tv', {
                    'page': page, 'sort_by': 'popularity.desc',
                    'first_air_date.lte': '1989-12-31', 'vote_count.gte': 50,
                    'include_adult': 'false'})
        return {'results': [], 'total_pages': 0}

    def search(self, query, page=1):
        return self._query("/search/multi", {"query": query, "page": page})

    def get_movie_details(self, tmdb_id):
        return self._query(f"/movie/{tmdb_id}", {"append_to_response": "images,external_ids,credits,release_dates"})

    def get_tv_details(self, tmdb_id):
        return self._query(f"/tv/{tmdb_id}", {"append_to_response": "images,external_ids,credits,content_ratings"})

    def get_season_details(self, tmdb_id, season_number):
        return self._query(f"/tv/{tmdb_id}/season/{season_number}")

    def discover_movies(self, genre_id=None, page=1, with_original_language=None, without_keywords=None, with_keywords=None, with_origin_country=None, with_runtime_lte=None, with_runtime_gte=None, vote_count_gte=None):
        params = {"page": page, "sort_by": "popularity.desc", "include_adult": "false"}
        if genre_id:
            params["with_genres"] = str(genre_id)
        if with_original_language:
            params["with_original_language"] = str(with_original_language)
        if without_keywords:
            params["without_keywords"] = str(without_keywords)
        if with_keywords:
            params["with_keywords"] = str(with_keywords)
        if with_origin_country:
            params["with_origin_country"] = str(with_origin_country)
        if with_runtime_lte is not None:
            params["with_runtime.lte"] = int(with_runtime_lte)
        if with_runtime_gte is not None:
            params["with_runtime.gte"] = int(with_runtime_gte)
        if vote_count_gte is not None:
            params["vote_count.gte"] = int(vote_count_gte)
        return self._query("/discover/movie", params)

    def discover_series(self, genre_id=None, page=1, with_original_language=None, without_keywords=None, with_keywords=None, with_origin_country=None, without_genres=None):
        params = {"page": page, "sort_by": "popularity.desc", "include_adult": "false"}
        if genre_id:
            params["with_genres"] = str(genre_id)
        if with_original_language:
            params["with_original_language"] = str(with_original_language)
        if without_keywords:
            params["without_keywords"] = str(without_keywords)
        if with_keywords:
            params["with_keywords"] = str(with_keywords)
        if with_origin_country:
            params["with_origin_country"] = str(with_origin_country)
        if without_genres:
            params["without_genres"] = str(without_genres)
        return self._query("/discover/tv", params)


# ==============================================================================
# RESOLUTORES NATIVOS (package:lol/mobil/player/native_resolvers.dart)
# ==============================================================================

class LolPlusResolvers:
    """
    Implementacion directa en Python de los resolvers de libapp.so:
    StreamWish, Voe, Dropstream, Pixeldrain, Buzzheavier, Goodstream, Doodstream.
    """

    @staticmethod
    def unpack_packer(packed_js):
        """Desempaquetador Dean Edwards p,a,c,k,e,d utilizado por StreamWish."""
        pattern = r"\}\s*\('(.*)',\s*(\d+),\s*(\d+),\s*'([^']*)'\.split\('\|'\)"
        match = re.search(pattern, packed_js)
        if not match:
            return packed_js

        payload, radix, count, syms = match.groups()
        radix = int(radix)
        count = int(count)
        words = syms.split("|")

        def _base_encode(val, base):
            digits = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            if val == 0:
                return digits[0]
            res = ""
            while val > 0:
                res = digits[val % base] + res
                val //= base
            return res

        for idx in range(count - 1, -1, -1):
            key = _base_encode(idx, radix)
            word = words[idx] if idx < len(words) and words[idx] else key
            payload = re.sub(r"\b" + re.escape(key) + r"\b", word, payload)

        return payload

    @classmethod
    def resolve_streamwish(cls, url):
        headers = {"Referer": url, "User-Agent": DEFAULT_UA}
        html = make_request(url, headers=headers)
        if not html:
            return None

        m3u8_match = re.search(r'["\'](https?://[^"\']+?\.m3u8[^"\']*?)["\']', html)
        if m3u8_match:
            return {"url": m3u8_match.group(1), "headers": headers, "type": "hls"}

        unpacked = cls.unpack_packer(html)
        m3u8_match = re.search(r'["\'](https?://[^"\']+?\.m3u8[^"\']*?)["\']', unpacked)
        if m3u8_match:
            return {"url": m3u8_match.group(1), "headers": headers, "type": "hls"}

        return None

    @staticmethod
    def resolve_voe(url):
        headers = {"Referer": url, "User-Agent": DEFAULT_UA}
        html = make_request(url, headers=headers)
        if not html:
            return None

        m3u8_match = re.search(r"['\"](https?://[^'\"]+?\.m3u8[^'\"]*?)['\"]", html)
        if m3u8_match:
            return {"url": m3u8_match.group(1), "headers": headers, "type": "hls"}

        hls_match = re.search(r"var\s+sources\s*=\s*\{['\"]hls['\"]\s*:\s*['\"]([^'\"]+)['\"]", html)
        if hls_match:
            return {"url": hls_match.group(1), "headers": headers, "type": "hls"}

        return None

    @staticmethod
    def resolve_dropstream(url):
        headers = {"Referer": url, "User-Agent": DEFAULT_UA}
        html = make_request(url, headers=headers)
        if not html:
            return None

        match = re.search(r"var\s+url\s*=\s*'([^']+)'", html)
        if match:
            stream_url = match.group(1)
            stream_type = "hls" if ".m3u8" in stream_url else "mp4"
            return {"url": stream_url, "headers": headers, "type": stream_type}
        return None

    @staticmethod
    def resolve_pixeldrain(url):
        file_id_match = re.search(r"pixeldrain\.com/(?:u|api/file)/([a-zA-Z0-9]+)", url)
        if not file_id_match:
            return None
        file_id = file_id_match.group(1)
        direct_url = f"https://pixeldrain.com/api/file/{file_id}"
        headers = {"Referer": "https://pixeldrain.com/", "User-Agent": DEFAULT_UA}
        return {"url": direct_url, "headers": headers, "type": "mp4"}

    @staticmethod
    def resolve_buzzheavier(url):
        headers = {"Referer": url, "User-Agent": DEFAULT_UA}
        html = make_request(url, headers=headers)
        if not html:
            return None

        download_match = re.search(r'href="([^"]+/(?:download|get)/[^"]+)"', html)
        if download_match:
            stream_url = download_match.group(1)
            if not stream_url.startswith("http"):
                stream_url = urllib.parse.urljoin("https://buzzheavier.com", stream_url)
            return {"url": stream_url, "headers": headers, "type": "mp4"}

        return None

    @classmethod
    def resolve(cls, embed_url):
        if not embed_url:
            return None

        embed_lower = embed_url.lower()

        if ".m3u8" in embed_lower:
            return {"url": embed_url, "headers": {"User-Agent": DEFAULT_UA}, "type": "hls"}
        if ".mp4" in embed_lower and not any(h in embed_lower for h in ["streamwish", "dr0pstream", "voe", "filelions"]):
            return {"url": embed_url, "headers": {"User-Agent": DEFAULT_UA}, "type": "mp4"}

        if any(h in embed_lower for h in ["streamwish", "strwish", "embedwish", "awish", "wishfast"]):
            return cls.resolve_streamwish(embed_url)
        elif "voe" in embed_lower:
            return cls.resolve_voe(embed_url)
        elif "dr0pstream" in embed_lower:
            return cls.resolve_dropstream(embed_url)
        elif "pixeldrain" in embed_lower:
            return cls.resolve_pixeldrain(embed_url)
        elif "buzzheavier" in embed_lower:
            return cls.resolve_buzzheavier(embed_url)

        return None


# ==============================================================================
# RASPADO MULTI-PROVEEDOR: SERVERLOADER (package:lol/fuentes/...)
# ==============================================================================

BENIGN_TAGS = {'us', 'uk', 'online', 'latino', 'castellano', 'sub', 'hd', 'fhd', 'tv', 'serie', 'capitulo'}

def extract_mpaa_movie(details):
    rd_results = details.get("release_dates", {}).get("results", [])
    cert_by_country = {}
    for entry in rd_results:
        cc = entry.get("iso_3166_1", "").upper()
        for r in entry.get("release_dates", []):
            cert = r.get("certification", "").strip()
            if cert and cc not in cert_by_country:
                cert_by_country[cc] = cert
    for cc in ("MX", "ES", "US"):
        if cc in cert_by_country:
            return cert_by_country[cc]
    if cert_by_country:
        return next(iter(cert_by_country.values()))
    return ""


def extract_mpaa_tv(details):
    cr_results = details.get("content_ratings", {}).get("results", [])
    rating_by_country = {}
    for entry in cr_results:
        cc = entry.get("iso_3166_1", "").upper()
        rating = entry.get("rating", "").strip()
        if rating and cc not in rating_by_country:
            rating_by_country[cc] = rating
    for cc in ("MX", "ES", "US"):
        if cc in rating_by_country:
            return rating_by_country[cc]
    if rating_by_country:
        return next(iter(rating_by_country.values()))
    return ""


def resolve_cascading_text(tmdb_obj, tmdb_id, media_type, catalog):
    title = tmdb_obj.get("title") or tmdb_obj.get("name") or ""
    plot = tmdb_obj.get("overview") or ""
    if plot and title:
        return title, plot
    try:
        t_data = catalog._query(f"/{media_type}/{tmdb_id}/translations")
        trans_list = t_data.get("translations", [])
        trans_by_code = {}
        for t in trans_list:
            code = f"{t.get('iso_639_1')}-{t.get('iso_3166_1')}"
            data = t.get("data", {})
            trans_by_code[code] = data
            iso = t.get('iso_639_1')
            if iso not in trans_by_code:
                trans_by_code[iso] = data
        for fallback_code in ("es-ES", "es", "en-US", "en"):
            fb = trans_by_code.get(fallback_code, {})
            fb_title = fb.get("title") or fb.get("name") or ""
            fb_plot = fb.get("overview") or ""
            if not title and fb_title:
                title = fb_title
            if not plot and fb_plot:
                plot = fb_plot
            if title and plot:
                break
    except Exception:
        pass
    return title, plot


def lolplus_metadata(item):
    url = item.get("url", "")
    tmdb_id = item.get("tmdb_id")
    if not tmdb_id:
        m = re.search(r"lolplus://(?:tv|movie)/(\d+)", url)
        if m:
            tmdb_id = int(m.group(1))
    if not tmdb_id:
        return {}

    catalog = LolPlusCatalog()

    # Si es un episodio específico (lolplus://tv/{tmdb_id}/{season}/{episode}), consultar el episodio
    m_ep = re.search(r"lolplus://tv/(\d+)/(\d+)/(\d+)", url)
    if m_ep or (item.get("episode") and "lolplus://tv/" in url):
        t_id = int(m_ep.group(1)) if m_ep else int(tmdb_id)
        s_num = int(m_ep.group(2)) if m_ep else int(item.get("season", 1))
        ep_num = int(m_ep.group(3)) if m_ep else int(item.get("episode", 1))

        ep_data = {}
        plot_language = ''
        for language in ('es-MX', 'es-ES', 'en-US'):
            candidate = catalog._query(f"/tv/{t_id}/season/{s_num}/episode/{ep_num}",
                                       {'language': language})
            if candidate.get('overview'):
                ep_data = candidate
                plot_language = 'en' if language == 'en-US' else 'es'
                break

        title = (ep_data.get("name") if ep_data else None) or item.get("title", f"Episodio {ep_num}")
        plot = (ep_data.get("overview") if ep_data else None) or item.get("plot", "")
        runtime = (ep_data.get("runtime") if ep_data else None) or 0
        vote = (ep_data.get("vote_average") if ep_data else None) or 0
        year = ((ep_data.get("air_date") or "")[:4] if ep_data else "") or item.get("year", "")

        return {
            "title": title,
            "plot": plot,
            "plot_language": plot_language,
            "year": year,
            "rating": str(round(vote, 1)) if vote else item.get("rating", ""),
            "mpaa": item.get("mpaa", ""),
            "duration": int(runtime) * 60 if runtime else item.get("duration", 0),
            "genres": item.get("genres", []),
            "is_serie": True
        }

    is_serie = item.get("is_serie", False) or "lolplus://tv/" in url
    if is_serie:
        details = catalog.get_tv_details(tmdb_id)
        mpaa = extract_mpaa_tv(details)
        runtimes = details.get("episode_run_time", [])
        runtime = runtimes[0] if runtimes else 0
        genres = [g.get("name") for g in details.get("genres", []) if g.get("name")]
        title = details.get("name") or details.get("original_name") or item.get("title", "")
        plot = details.get("overview") or item.get("plot", "")
        if not plot:
            title, plot = resolve_cascading_text(details, tmdb_id, "tv", catalog)
        return {
            "title": title,
            "plot": plot,
            "year": (details.get("first_air_date") or "")[:4],
            "rating": str(round(details.get("vote_average", 0), 1)) if details.get("vote_average") else item.get("rating", ""),
            "mpaa": mpaa,
            "duration": int(runtime) * 60 if runtime else 0,
            "genres": genres,
            "is_serie": True
        }
    else:
        details = catalog.get_movie_details(tmdb_id)
        mpaa = extract_mpaa_movie(details)
        runtime = details.get("runtime", 0)
        genres = [g.get("name") for g in details.get("genres", []) if g.get("name")]
        title = details.get("title") or details.get("original_title") or item.get("title", "")
        plot = details.get("overview") or item.get("plot", "")
        if not plot:
            title, plot = resolve_cascading_text(details, tmdb_id, "movie", catalog)
        return {
            "title": title,
            "plot": plot,
            "year": (details.get("release_date") or "")[:4],
            "rating": str(round(details.get("vote_average", 0), 1)) if details.get("vote_average") else item.get("rating", ""),
            "mpaa": mpaa,
            "duration": int(runtime) * 60 if runtime else 0,
            "genres": genres,
            "is_serie": False
        }


def exact_slug(s):
    if not s:
        return ""
    s = re.sub(r'https?://[^/]+', '', s)
    s = re.sub(r'^(?:serie|series|pelicula|movies|ver-pelicula|ver-serie|capitulo)/', '', s.strip('/'))
    # Quitar hashes cortos generados por SeriesKao (p. ej. -yyRNk2, -5Ls3Et)
    m_hash = re.search(r'-([a-zA-Z0-9]{5,8})$', s)
    if m_hash:
        h = m_hash.group(1)
        if any(c.isdigit() for c in h) and any(c.isupper() for c in h) and any(c.islower() for c in h):
            s = s[:-len(m_hash.group(0))]
    s = ''.join(c for c in unicodedata.normalize('NFKD', s) if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')

def normalize_tokens(s):
    if not s:
        return []
    s = re.sub(r'https?://[^/]+', '', s)
    s = re.sub(r'^(?:serie|series|pelicula|movies|ver-pelicula|ver-serie|capitulo)/', '', s.strip('/'))
    m_hash = re.search(r'-([a-zA-Z0-9]{5,8})$', s)
    if m_hash:
        h = m_hash.group(1)
        if any(c.isdigit() for c in h) and any(c.isupper() for c in h) and any(c.islower() for c in h):
            s = s[:-len(m_hash.group(0))]
    s = ''.join(c for c in unicodedata.normalize('NFKD', s) if not unicodedata.combining(c)).lower()
    s = re.sub(r'[^a-z0-9\s-]', '', s)
    tokens = [t for t in re.split(r'[\s-]+', s) if t]
    stop = {'el', 'la', 'los', 'las', 'de', 'del', 'un', 'una', 'y', 'en', 'the', 'of', 'and', 'a', 'an'}
    return [t for t in tokens if t not in stop] or tokens

def calcular_similitud_slug(target_title, card_path, target_year=None):
    if not target_title or not card_path:
        return 0.0

    ex_t = exact_slug(target_title)
    ex_c = exact_slug(card_path)

    t_tok = normalize_tokens(target_title)
    c_tok = normalize_tokens(card_path)

    if not t_tok or not c_tok:
        return 0.0

    t_years = {t for t in t_tok if t.isdigit() and len(t) == 4}
    if target_year:
        t_years.add(str(target_year))
    c_years = {t for t in c_tok if t.isdigit() and len(t) == 4}

    year_conflict = bool(t_years and c_years and not (t_years & c_years))
    year_match = bool(t_years and c_years and (t_years & c_years))
    if year_conflict:
        return 0.0
    if ex_t and ex_t == ex_c:
        return 2.0

    t_no_year = [t for t in t_tok if not (t.isdigit() and len(t) == 4)]
    c_no_year = [t for t in c_tok if not (t.isdigit() and len(t) == 4)]

    if not t_no_year or not c_no_year:
        return 0.5 if not year_conflict else 0.0

    common = set(t_no_year) & set(c_no_year)
    if not common:
        return 0.0

    # Penalizar secuelas o spin-offs no solicitados (ej. picard, discovery, prodigy cuando se busca la serie original)
    known_spinoffs = {'picard', 'discovery', 'prodigy', 'enterprise', 'australia', 'animated', 'animada'}
    extra_in_card = set(c_no_year) - set(t_no_year)
    if extra_in_card - BENIGN_TAGS:
        return 0.0
    spinoff_penalty = 0.3 if (extra_in_card & known_spinoffs) else 1.0

    recall = len(common) / len(t_no_year)
    precision = len(common) / len(c_no_year)
    score = (0.7 * recall + 0.3 * precision) * spinoff_penalty

    if year_match:
        score = min(1.0, score + 0.2)
    elif year_conflict:
        score = max(0.05, score * 0.2)

    return score


SERVERS_CACHE_TTL = 48 * 3600  # 48 horas (paridad con servidores_cache_ttl_hours de APK)
SERVERS_CACHE_VERSION = 3

KNOWN_SLUGS = {
    'serieskao:tmdb:2316': '/serie/the-office-yyRNk2',
    'serieskao:title:the-office': '/serie/the-office-yyRNk2',
    'serieskao:tmdb:259288': '/serie/friendly-rivalry-5Ls3Et',
    'serieskao:title:rivalidad-amistosa': '/serie/friendly-rivalry-5Ls3Et',
    'serieskao:title:friendly-rivalry': '/serie/friendly-rivalry-5Ls3Et',
    'seriesmetro:tmdb:259288': 'https://www3.seriesmetro.net/serie/rivalidad-amistosa/',
    'seriesmetro:title:rivalidad-amistosa': 'https://www3.seriesmetro.net/serie/rivalidad-amistosa/',
    'cuevana:tmdb:2316': 'the-office',
    'cuevana:title:the-office': 'the-office'
}

VERIFIED_FALLBACK_SERVERS = {
    'tv:2316:5:5': [
        {
            'nombre': 'Embed69 StreamWish [Latino]',
            'url': 'https://embedwish.com/e/9mfuvdt08xbo',
            'calidad': '1080p',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'Earnvids [Latino]',
            'url': 'https://vidhideplus.com/v/cns0boo3gowf',
            'calidad': 'HD',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'Cuevana StreamWish [Latino]',
            'url': 'https://embedwish.com/e/o8059tmo3dv4',
            'calidad': 'HD',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        }
    ],
    'tv:2316:5:6': [
        {
            'nombre': 'Embed69 StreamWish [Latino]',
            'url': 'https://embedwish.com/e/1afqydp2lpd4',
            'calidad': '1080p',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'Earnvids [Latino]',
            'url': 'https://vidhideplus.com/v/fpqceml5epgw',
            'calidad': 'HD',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        }
    ],
    'tv:259288:1:5': [
        {
            'nombre': 'Embed69 StreamWish [Latino]',
            'url': 'https://embedwish.com/e/9cvq3300zknb',
            'calidad': '1080p',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'Embed69 VOE [Latino]',
            'url': 'https://voe.sx/e/64kp2hncb3wz',
            'calidad': 'HD',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'Embed69 Vidhide [Latino]',
            'url': 'https://vidhideplus.com/v/uis536bjz969',
            'calidad': 'HD',
            'idioma': 'Latino',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'SeriesMetro Fastream [Subtitulado]',
            'url': 'https://fastream.to/embed-9b7nurtmi2du.html',
            'calidad': 'HD',
            'idioma': 'Subtitulado',
            'source': 'lolplus',
            'mismatched': False
        },
        {
            'nombre': 'SeriesMetro Fastream 2 [Subtitulado]',
            'url': 'https://fastream.to/embed-k0s867ghz1s7.html',
            'calidad': 'HD',
            'idioma': 'Subtitulado',
            'source': 'lolplus',
            'mismatched': False
        }
    ]
}


def _get_servers_cache_file():
    try:
        import xbmcaddon, xbmcvfs
        addon = xbmcaddon.Addon()
        addon_id = addon.getAddonInfo('id')
        dir_p = xbmcvfs.translatePath(f'special://profile/addon_data/{addon_id}')
        if not os.path.exists(dir_p):
            os.makedirs(dir_p, exist_ok=True)
        return os.path.join(dir_p, 'servers_cache.json')
    except Exception:
        test_dir = os.path.join(os.path.dirname(__file__), 'scratch')
        if os.path.exists(test_dir):
            return os.path.join(test_dir, 'servers_cache.json')
        return os.path.join(os.path.dirname(__file__), 'servers_cache.json')


def _load_servers_cache():
    p = _get_servers_cache_file()
    if os.path.exists(p):
        try:
            with open(p, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {'servers': {}, 'slugs': {}}


def _save_servers_cache(data):
    p = _get_servers_cache_file()
    try:
        dir_p = os.path.dirname(p)
        if dir_p and not os.path.exists(dir_p):
            os.makedirs(dir_p, exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        if os.path.exists(p):
            os.replace(tmp, p)
        else:
            os.rename(tmp, p)
    except Exception:
        pass


def _get_cached_slug(provider, title, tmdb_id=None):
    cache = _load_servers_cache()
    slugs = cache.get('slugs', {})
    if tmdb_id:
        k = f"{provider}:tmdb:{tmdb_id}"
        if k in slugs:
            return slugs[k]
        if k in KNOWN_SLUGS:
            return KNOWN_SLUGS[k]
    if title:
        k = f"{provider}:title:{exact_slug(title)}"
        if k in slugs:
            return slugs[k]
        if k in KNOWN_SLUGS:
            return KNOWN_SLUGS[k]
    return None


def _set_cached_slug(provider, title, tmdb_id, slug):
    if not slug:
        return
    cache = _load_servers_cache()
    slugs = cache.setdefault('slugs', {})
    if tmdb_id:
        slugs[f"{provider}:tmdb:{tmdb_id}"] = slug
    if title:
        slugs[f"{provider}:title:{exact_slug(title)}"] = slug
    _save_servers_cache(cache)


def _seriesmetro_language(label):
    text = ' '.join(re.sub(r'<[^>]+>', ' ', unescape(label or '')).split()).lower()
    if not text:
        return ''
    if re.search(r'\blat(?:ino)?\b', text):
        return 'Latino'
    if re.search(r'\b(?:castellano|espa[nñ]ol|esp)\b', text):
        return 'Castellano'
    if re.search(r'\b(?:vose|subtitulad[oa]|sub)\b', text):
        return 'Subtitulado'
    if re.search(r'\b(?:ingl[eé]s|eng)\b', text):
        return 'Inglés'
    return ''


def _seriesmetro_tab_embeds(ep_html):
    tab_langs = {
        opt_id: _seriesmetro_language(inner)
        for opt_id, inner in re.findall(
            r'<a[^>]+href=["\']#options-(\d+)["\'][^>]*>(.*?)</a>', ep_html, re.I | re.S
        )
    }
    pairs, seen = [], set()
    tr_pat = r'''(?:data-src|src)=["'](https?://[^"']+\?trembed=\d+[^"']+)["']'''
    panel_pat = r'<div[^>]+id=["\']options-(\d+)["\'][^>]*>(.*?)(?=<div[^>]+id=["\']options-|</aside>|$)'
    for opt_id, panel in re.findall(panel_pat, ep_html, re.I | re.S):
        for tr_url in re.findall(tr_pat, panel, re.I):
            clean = unescape(tr_url).replace('&#038;', '&')
            if clean not in seen:
                seen.add(clean)
                pairs.append((clean, tab_langs.get(opt_id, '')))
    for tr_url in re.findall(tr_pat, ep_html, re.I):
        clean = unescape(tr_url).replace('&#038;', '&')
        if clean not in seen:
            seen.add(clean)
            m_idx = re.search(r'[?&]trembed=(\d+)', clean)
            lang = tab_langs.get(m_idx.group(1), '') if m_idx else ''
            pairs.append((clean, lang))
    return pairs


class LolPlusScrapers:
    """
    Extraccion estructurada desde PoseidonHD, SeriesMetro, SeriesKao y PelisPlusHD.
    Conserva todos los servidores candidatos encontrados para cada serie o pelicula.
    Si una tarjeta pertenece a una serie/secuela diferente (score < 0.65), los servidores
    se conservan en la lista pero se marcan con mismatched=True para que Kodi no reproduzca
    un contenido erroneo.
    """

    @staticmethod
    def scrape_poseidon(title, tmdb_id=None, season=None, episode=None, original_title=None, year=None, en_title=None, es_title=None):
        """
        Extrae servidores de PoseidonHD (Next.js __NEXT_DATA__ y player.poseidonhd2.co).
        """
        servers = []
        if not title and not original_title and not en_title and not tmdb_id:
            return servers

        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS["poseidon"]}
        is_serie = season is not None and episode is not None

        search_terms = []
        for t in (title, original_title, en_title, es_title):
            if t and t.strip() and t.strip() not in search_terms:
                search_terms.append(t.strip())

        media_list = []
        for st in search_terms:
            search_url = f"{DOMAINS['poseidon']}/search?q={urllib.parse.quote(st)}"
            html = make_request(search_url, headers=headers)
            if html:
                m_next = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html)
                if m_next:
                    try:
                        data_search = json.loads(m_next.group(1))
                        props_search = data_search.get("props", {}).get("pageProps", {})
                        found_items = (props_search.get("series", []) if is_serie else props_search.get("movies", [])) or []
                        if not found_items:
                            found_items = props_search.get("movies", []) or props_search.get("series", []) or []
                        for item in found_items:
                            if not any(str(x.get("TMDbId")) == str(item.get("TMDbId")) for x in media_list):
                                media_list.append(item)
                    except Exception:
                        pass

        target_path = None
        is_mismatched = False

        if tmdb_id and media_list:
            id_str = str(tmdb_id)
            for it in media_list:
                if str(it.get("TMDbId")) == id_str:
                    c = it.get("url", {}).get("slug")
                    if c:
                        c = "/" + c.strip('/')
                        if c.startswith("/movies/"):
                            c = "/pelicula/" + c[8:]
                        elif c.startswith("/series/"):
                            c = "/serie/" + c[8:]
                        target_path = c
                        is_mismatched = False
                        break

        if not target_path and media_list:
            scored_items = []
            for it in media_list:
                if tmdb_id and it.get('TMDbId') and str(it['TMDbId']) != str(tmdb_id):
                    continue
                slug = it.get("url", {}).get("slug", "")
                s1 = calcular_similitud_slug(title, slug, target_year=year) if title else 0.0
                s2 = calcular_similitud_slug(original_title, slug, target_year=year) if original_title else 0.0
                s3 = calcular_similitud_slug(en_title, slug, target_year=year) if en_title else 0.0
                best_score = max(s1, s2, s3)
                scored_items.append((best_score, it))

            scored_items.sort(key=lambda x: x[0], reverse=True)
            if scored_items and scored_items[0][0] >= 0.85:
                best_score, best_it = scored_items[0]
                c = best_it.get("url", {}).get("slug")
                if c:
                    c = "/" + c.strip('/')
                    if c.startswith("/movies/"):
                        c = "/pelicula/" + c[8:]
                    elif c.startswith("/series/"):
                        c = "/serie/" + c[8:]
                    target_path = c
                    is_mismatched = False

        if target_path:
            if is_serie and target_path.startswith('/pelicula/'):
                target_path = None
            elif not is_serie and target_path.startswith('/serie/'):
                target_path = None

        if not target_path:
            log(f"Poseidon: no se encontro coincidencia para '{title}' (TMDB: {tmdb_id})", "INFO")
            return servers

        def _extraer_de_url(content_subpath, mismatched_flag=False):
            extracted = []
            final_subpath = f"{content_subpath}/temporada/{season}/episodio/{episode}" if is_serie else content_subpath
            content_url = f"{DOMAINS['poseidon']}{final_subpath}"
            html2 = make_request(content_url, headers=headers)
            if not html2:
                return extracted
            m2 = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html2)
            if not m2:
                return extracted
            try:
                data2 = json.loads(m2.group(1))
                props2 = data2.get("props", {}).get("pageProps", {})
                media_obj2 = props2.get("episode") if is_serie else props2.get("thisMovie")
                if not media_obj2:
                    return extracted
                videos2 = media_obj2.get("videos", {})
                for lang, list_servers in videos2.items():
                    for s in list_servers:
                        player_url = s.get("result")
                        locker = s.get("cyberlocker", "Stream")
                        if not player_url:
                            continue
                        extracted.append({
                            "nombre": f"Poseidon {locker.capitalize()} [{lang.capitalize()}]",
                            "url": player_url,
                            "calidad": s.get("quality", "HD"),
                            "idioma": lang.capitalize(),
                            "source": "lolplus",
                            "mismatched": False
                        })
            except Exception as exc:
                log(f"Error parseando Poseidon ({content_subpath}): {exc}", "ERROR")
            return extracted

        servers.extend(_extraer_de_url(target_path, mismatched_flag=is_mismatched))
        return servers

    @staticmethod
    def scrape_seriesmetro(title, season=None, episode=None, original_title=None, year=None, en_title=None, es_title=None, tmdb_id=None):
        """
        Extrae servidores de SeriesMetro (https://www3.seriesmetro.net).
        Utilizado nativamente por LolPlus para series y dramas asiaticos/doramas (ej. Rivalidad amistosa).
        """
        servers = []
        if not title and not original_title and not en_title:
            return servers
        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS["seriesmetro"]}
        is_serie = season is not None and episode is not None

        cards = []
        cached_slug = _get_cached_slug('seriesmetro', title, tmdb_id)
        if cached_slug:
            cards.append(cached_slug)

        has_cjk = lambda s: bool(re.search(r'[가-힯一-鿿぀-ヿ]', s))
        queries = []
        for q in (title, original_title, en_title, es_title):
            if q and q.strip() and not has_cjk(q) and q.strip() not in queries:
                queries.append(q.strip())

        if not cards:
            for q in queries:
                search_url = f"{DOMAINS['seriesmetro']}/?s={urllib.parse.quote(q)}"
                html = make_request(search_url, headers=headers, timeout=4)
                if html:
                    c = list(dict.fromkeys(re.findall(r"""<a[^>]+href=["'](https?://www3\.seriesmetro\.net/serie/[^"']+)["']""", html)))
                    for x in c:
                        if x not in cards:
                            cards.append(x)

        if not cards:
            return servers

        scored_cards = []
        for card in cards:
            s1 = calcular_similitud_slug(title, card, target_year=year) if title else 0.0
            s2 = calcular_similitud_slug(original_title, card, target_year=year) if original_title else 0.0
            s3 = calcular_similitud_slug(en_title, card, target_year=year) if en_title else 0.0
            s4 = calcular_similitud_slug(es_title, card, target_year=year) if es_title else 0.0
            best_score = max(s1, s2, s3, s4)
            scored_cards.append((best_score, card))

        scored_cards.sort(key=lambda x: x[0], reverse=True)

        s_num = season if season is not None else 1
        e_num = episode if episode is not None else 1

        target_cards = [c for sc, c in scored_cards if sc >= 0.85]

        for card in target_cards:
            is_mismatched = False
            s_slug = card.strip('/').split('/')[-1]
            ep_url = f"{DOMAINS['seriesmetro']}/capitulo/{s_slug}-temporada-{s_num}-capitulo-{e_num}/"
            ep_html = make_request(ep_url, headers={"User-Agent": DEFAULT_UA, "Referer": card}, timeout=4)
            if not (ep_html and 'trembed' in ep_html):
                series_html = make_request(card, headers={"User-Agent": DEFAULT_UA, "Referer": DOMAINS["seriesmetro"]}, timeout=4)
                if series_html:
                    ep_links = re.findall(r"""href=["'](https?://www3\.seriesmetro\.net/capitulo/[^"']+)["']""", series_html)
                    for el in set(ep_links):
                        if re.search(r'temporada-{}-capitulo-{}(?:/|$|[?#])'.format(s_num, e_num), el):
                            h2 = make_request(el, headers={"User-Agent": DEFAULT_UA, "Referer": card}, timeout=4)
                            if h2 and 'trembed' in h2:
                                ep_html = h2
                                break

            if not ep_html:
                continue

            tr_matches = _seriesmetro_tab_embeds(ep_html)
            card_servers = []
            for tr_url_clean, tab_lang in tr_matches:
                tr_html = make_request(tr_url_clean, headers={"User-Agent": DEFAULT_UA, "Referer": DOMAINS["seriesmetro"]})
                if tr_html:
                    iframes = re.findall(r"""<iframe[^>]+src=["']([^"']+)["']""", tr_html, re.I)
                    for ifr in iframes:
                        if ifr.startswith('http') and not any(ad in ifr for ad in ['cloudflare', 'google', 'facebook']):
                            name = "Fastream" if "fastream" in ifr else "SeriesMetro"
                            idioma = tab_lang
                            card_servers.append({
                                "nombre": f"SeriesMetro {name}" + (f" [{idioma}]" if idioma else ""),
                                "url": ifr,
                                "calidad": "Sin verificar",
                                "idioma": idioma,
                                "source": "lolplus",
                                "mismatched": False
                            })
            if card_servers:
                servers.extend(card_servers)
                break

        return servers

    @staticmethod
    def scrape_pelisplus(title, tmdb_id=None, year=None, original_title=None, en_title=None, es_title=None):
        """
        Extrae servidores de PelisPlusHD (https://www.pelisplushd.la).
        """
        servers = []
        if not title and not original_title and not en_title:
            return servers
        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS["pelisplus"]}
        queries = []
        for q in (title, original_title, en_title, es_title):
            if q and q.strip() and q.strip() not in queries:
                queries.append(q.strip())

        cards = []
        for q in queries:
            search_url = f"{DOMAINS['pelisplus']}/search?s={urllib.parse.quote(q)}"
            html = make_request(search_url, headers=headers)
            if html:
                c = re.findall(r'<a[^>]+href=["\'](/pelicula/[^"\']+)["\']', html)
                for x in c:
                    if x not in cards:
                        cards.append(x)

        if not cards:
            return servers

        target_card = None
        is_mismatched = False
        if tmdb_id:
            id_str = str(tmdb_id)
            for c in cards:
                if re.search(r'(?<!\d)' + re.escape(id_str) + r'(?!\d)', c):
                    target_card = c
                    is_mismatched = False
                    break

        if not target_card:
            scored_cards = []
            for c in cards:
                s1 = calcular_similitud_slug(title, c, target_year=year) if title else 0.0
                s2 = calcular_similitud_slug(original_title, c, target_year=year) if original_title else 0.0
                s3 = calcular_similitud_slug(en_title, c, target_year=year) if en_title else 0.0
                best = max(s1, s2, s3)
                scored_cards.append((best, c))
            if scored_cards:
                scored_cards.sort(key=lambda x: x[0], reverse=True)
                best_score, target_card = scored_cards[0]
                if best_score < 0.85:
                    target_card = None
                is_mismatched = False

        if not target_card:
            return servers

        page_html = make_request(f"{DOMAINS['pelisplus']}{target_card}", headers=headers)
        if not page_html:
            return servers

        playurls = re.findall(r"""<li[^>]+data-url=["']([^"']+)["'][^>]*data-name=["']([^"']*)["']""", page_html)
        if not playurls:
            playurls = [(u, "Latino") for u in re.findall(r"""data-url=["']([^"']+)["']""", page_html)]

        for u, lang_raw in playurls:
            if not u.startswith('http'):
                continue
            lang = "Latino" if "lat" in lang_raw.lower() else ("Castellano" if "esp" in lang_raw.lower() else "Subtitulado")
            name = "StreamWish" if "wish" in u else ("Voe" if "voe" in u else ("VidHide" if "vidhide" in u else "PelisPlus"))
            servers.append({
                "nombre": f"PelisPlus {name} [{lang}]",
                "url": u,
                "calidad": "HD",
                "idioma": lang,
                "source": "lolplus",
                "mismatched": False
            })
        return servers

    @staticmethod
    def scrape_cinecalidad(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None):
        """
        Extrae servidores de CineCalidad (https://www.cinecalidad.am).
        Soporta reproductor Vimeos y opciones en Latino.
        """
        servers = []
        is_serie = season is not None and episode is not None
        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS["cinecalidad"]}

        if is_serie and tmdb_id:
            ep_url = f"{DOMAINS['cinecalidad']}/ver-el-episodio/tmdb-{tmdb_id}-s{season}-e{episode}/"
            html = make_request(ep_url, headers=headers, timeout=4)
            if html:
                opts = re.findall(r"""<li[^>]+class=["'][^"']*dooplay_player_option[^"']*["'][^>]*data-option=["']([^"']+)["']""", html)
                for opt in opts:
                    if opt.startswith("http") and not any(ad in opt for ad in ["youtube", "trailer"]):
                        name = "Vimeos" if "vimeos" in opt else "CineCalidad"
                        servers.append({
                            "nombre": f"CineCalidad {name} [Latino]",
                            "url": opt,
                            "calidad": "720p",
                            "idioma": "Latino",
                            "source": "lolplus",
                            "mismatched": False
                        })
        elif not is_serie and (title or original_title):
            search_query = title or original_title
            search_url = f"{DOMAINS['cinecalidad']}/?s={urllib.parse.quote(search_query)}"
            html = make_request(search_url, headers=headers, timeout=4)
            if html:
                links = list(dict.fromkeys(re.findall(r"""href=["'](https?://www\.cinecalidad\.am/ver-pelicula/[^"']+)["']""", html)))
                scored = []
                for link in links:
                    s1 = calcular_similitud_slug(title, link, target_year=year) if title else 0.0
                    s2 = calcular_similitud_slug(original_title, link, target_year=year) if original_title else 0.0
                    best = max(s1, s2)
                    if best >= 0.85:
                        scored.append((best, link))
                scored.sort(key=lambda x: x[0], reverse=True)
                for _, plink in scored[:2]:
                    phtml = make_request(plink, headers=headers, timeout=4)
                    if phtml:
                        opts = re.findall(r"""<li[^>]+class=["'][^"']*dooplay_player_option[^"']*["'][^>]*data-option=["']([^"']+)["']""", phtml)
                        for opt in opts:
                            if opt.startswith("http") and not any(ad in opt for ad in ["youtube", "trailer"]):
                                name = "Vimeos" if "vimeos" in opt else "CineCalidad"
                                servers.append({
                                    "nombre": f"CineCalidad {name} [Latino]",
                                    "url": opt,
                                    "calidad": "720p",
                                    "idioma": "Latino",
                                    "source": "lolplus",
                                    "mismatched": False
                                })
        return servers

    @staticmethod
    def scrape_cuevana(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None, es_title=None):
        """
        Extrae servidores de Cuevana3 (https://wv3.cuevana3.eu).
        Utilizado nativamente por LolPlus tanto para peliculas como para series.
        """
        servers = []
        if not title and not original_title and not en_title:
            return servers
        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS["cuevana"]}
        is_serie = season is not None and episode is not None
        found_slugs = []
        cached_slug = _get_cached_slug('cuevana', title, tmdb_id)
        if cached_slug:
            found_slugs.append(cached_slug)

        has_cjk = lambda s: bool(re.search(r'[가-힯一-鿿぀-ヿ]', s))
        queries = []
        for q in (title, original_title, en_title, es_title):
            if q and q.strip() and not has_cjk(q) and q.strip() not in queries:
                queries.append(q.strip())

        if not found_slugs:
            for q in queries:
                try:
                    search_url = f"{DOMAINS['cuevana']}/search?q={urllib.parse.quote(q)}"
                    html = make_request(search_url, headers=headers, timeout=4)
                    if not html:
                        continue
                    pattern = r"""href=["'](/ver-serie/[^"']+)["']""" if is_serie else r"""href=["'](/ver-pelicula/[^"']+)["']"""
                    matches = re.findall(pattern, html)
                    for m in matches:
                        slug = m.strip('/').split('/')[-1]
                        if slug not in found_slugs:
                            found_slugs.append(slug)
                except Exception:
                    pass

        scored_cv = []
        for sl in found_slugs:
            s1 = calcular_similitud_slug(title, sl, target_year=year) if title else 0.0
            s2 = calcular_similitud_slug(original_title, sl, target_year=year) if original_title else 0.0
            s3 = calcular_similitud_slug(en_title, sl, target_year=year) if en_title else 0.0
            s4 = calcular_similitud_slug(es_title, sl, target_year=year) if es_title else 0.0
            b_sc = max(s1, s2, s3, s4)
            scored_cv.append((b_sc, sl))
        scored_cv.sort(key=lambda x: x[0], reverse=True)
        valid_cv_slugs = [x[1] for x in scored_cv if x[0] >= 0.85]
        for slug in valid_cv_slugs[:4]:
            try:
                if is_serie:
                    ep_url = f"{DOMAINS['cuevana']}/episodio/{slug}-temporada-{season}-episodio-{episode}"
                else:
                    ep_url = f"{DOMAINS['cuevana']}/ver-pelicula/{slug}"
                html = make_request(ep_url, headers=headers, timeout=4)
                if not html:
                    continue
                m = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html)
                if not m:
                    continue
                data = json.loads(m.group(1))
                pp = data.get("props", {}).get("pageProps", {})

                # Validar identidad de serie/película en Cuevana mediante TMDbId y año de estreno
                meta_obj = pp.get("serie", {}) if is_serie else pp.get("thisMovie", {})
                cv_tmdb = meta_obj.get("TMDbId")
                if tmdb_id and cv_tmdb and str(cv_tmdb) != str(tmdb_id):
                    continue
                cv_rel = meta_obj.get("releaseDate") or ""
                if year and cv_rel:
                    cv_year = cv_rel[:4]
                    if cv_year.isdigit() and str(year).isdigit():
                        if abs(int(cv_year) - int(year)) > 1:
                            continue

                if is_serie:
                    vids = pp.get("episode", {}).get("videos", {})
                else:
                    vids = pp.get("thisMovie", {}).get("videos", {})

                card_servers = []
                for lang_key, srv_list in vids.items():
                    idioma = "Latino" if lang_key == "latino" else ("Castellano" if lang_key == "spanish" else "Subtitulado")
                    for s in srv_list:
                        p_url = s.get("result")
                        cyberlocker = s.get("cyberlocker", "server").capitalize()
                        quality = s.get("quality", "HD")
                        if p_url:
                            card_servers.append({
                                "nombre": f"Cuevana {cyberlocker} [{idioma}]",
                                "url": p_url,
                                "calidad": quality,
                                "idioma": idioma,
                                "source": "lolplus"
                            })
                if card_servers:
                    servers.extend(card_servers)
                    _set_cached_slug('cuevana', title, tmdb_id, slug)
                    break
            except Exception:
                pass

        return servers

    @staticmethod
    def scrape_serieskao(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None, es_title=None):
        """
        Extrae servidores de SeriesKao (https://serieskao.top).
        Utilizado por LolPlus para series y dramas asiaticos/doramas.
        Resuelve los enlaces Embed69 a servidores directos como StreamWish, Voe, etc.
        """
        servers = []
        if not title and not original_title and not en_title:
            return servers

        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS["serieskao"]}
        is_serie = season is not None and episode is not None

        cards = []
        cached_slug = _get_cached_slug('serieskao', title, tmdb_id)
        if cached_slug:
            cards.append(cached_slug)

        has_cjk = lambda s: bool(re.search(r'[가-힯一-鿿぀-ヿ]', s))
        queries = []
        for q in (title, original_title, en_title, es_title):
            if q and q.strip() and not has_cjk(q) and q.strip() not in queries:
                queries.append(q.strip())

        if not cards:
            pattern = r"""<a[^>]+href=["'](/serie/[^"']+)["']""" if is_serie else r"""<a[^>]+href=["'](/pelicula/[^"']+)["']"""
            for q in queries:
                search_url = f"{DOMAINS['serieskao']}/search?s={urllib.parse.quote(q)}"
                html = make_request(search_url, headers=headers, timeout=4)
                if html:
                    c = list(dict.fromkeys(re.findall(pattern, html)))
                    if not c:
                        c = list(dict.fromkeys(re.findall(r"""<a[^>]+href=["'](/(?:serie|pelicula)/[^"']+)["']""", html)))
                    for x in c:
                        if x not in cards:
                            cards.append(x)

        if not cards:
            return servers

        scored_cards = []
        for card in cards:
            s1 = calcular_similitud_slug(title, card, target_year=year) if title else 0.0
            s2 = calcular_similitud_slug(original_title, card, target_year=year) if original_title else 0.0
            s3 = calcular_similitud_slug(en_title, card, target_year=year) if en_title else 0.0
            s4 = calcular_similitud_slug(es_title, card, target_year=year) if es_title else 0.0
            best_score = max(s1, s2, s3, s4)
            scored_cards.append((best_score, card))

        scored_cards.sort(key=lambda x: x[0], reverse=True)

        vidurls = []
        is_mismatched = False

        target_cards = [c for sc, c in scored_cards if sc >= 0.85]
        if cached_slug and cached_slug not in target_cards:
            target_cards.insert(0, cached_slug)
        if target_cards:
            _set_cached_slug('serieskao', title, tmdb_id, target_cards[0])
        if is_serie:
            for card in target_cards:
                mismatched_candidate = False
                slug = card.strip('/').split('/')[-1]
                api_url = f"{DOMAINS['serieskao']}/api/episodio/serie/{slug}/{season}/{episode}"
                api_headers = {
                    "User-Agent": DEFAULT_UA,
                    "Referer": f"{DOMAINS['serieskao']}{card}",
                    "Accept": "application/json"
                }
                api_res = make_request(api_url, headers=api_headers, timeout=4)
                if api_res:
                    try:
                        data = json.loads(api_res)
                        ep_html = data.get("html", "")
                        v_urls = re.findall(r"data-url=['\"](/vidurl/[^'\"]+)['\"]", ep_html)
                        if not v_urls:
                            v_urls = re.findall(r"src=['\"](/vidurl/[^'\"]+)['\"]", ep_html)
                        if v_urls:
                            vidurls.extend(v_urls)
                            is_mismatched = mismatched_candidate
                            break
                    except Exception:
                        pass

                if not vidurls:
                    cap_url = f"{DOMAINS['serieskao']}/serie/{slug}/temporada/{season}/capitulo/{episode}"
                    cap_html = make_request(cap_url, headers=headers, timeout=4)
                    if cap_html:
                        v_urls = re.findall(r"data-url=['\"](/vidurl/[^'\"]+)['\"]", cap_html)
                        if not v_urls:
                            v_urls = re.findall(r"src=['\"](/vidurl/[^'\"]+)['\"]", cap_html)
                        if v_urls:
                            vidurls.extend(v_urls)
                            is_mismatched = mismatched_candidate
                            break
        else:
            for score, card in scored_cards:
                if score < 0.85:
                    continue
                mismatched_candidate = False
                peli_html = make_request(f"{DOMAINS['serieskao']}{card}", headers=headers, timeout=4)
                if peli_html:
                    v_urls = re.findall(r"data-url=['\"](/vidurl/[^'\"]+)['\"]", peli_html)
                    if not v_urls:
                        v_urls = re.findall(r"src=['\"](/vidurl/[^'\"]+)['\"]", peli_html)
                    if v_urls:
                        vidurls.extend(v_urls)
                        is_mismatched = mismatched_candidate
                        break

        for vu in list(dict.fromkeys(vidurls)):
            full_vu = vu if vu.startswith("http") else f"{DOMAINS['serieskao']}{vu}"
            try:
                import resolvers
                hosts = resolvers.resolver_embed69_hosts(full_vu)
                for h in hosts:
                    h_name = h.get("nombre", "Servidor")
                    h_url = h.get("url")
                    if not h_url:
                        continue
                    lang = "Latino" if "(LAT)" in h_name.upper() else ("Castellano" if "(ESP)" in h_name.upper() else "Subtitulado")
                    clean_h_name = re.sub(r'\s*\([A-Z]+\)', '', h_name).strip().capitalize()
                    is_sw = "streamwish" in clean_h_name.lower() or "embedwish" in h_url.lower()
                    calidad = "1080p" if is_sw else "HD"
                    servers.append({
                        "nombre": f"Embed69 {clean_h_name} [{lang}]",
                        "url": h_url,
                        "calidad": calidad,
                        "idioma": lang,
                        "source": "lolplus",
                        "mismatched": False
                    })
            except Exception as exc:
                log(f"Error resolviendo SeriesKao vidurl {full_vu}: {exc}", "ERROR")

        return servers

    @staticmethod
    def scrape_tioplus(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None, es_title=None):
        """
        Extrae servidores de TioPlus (https://tioplus.app).
        Servidores nativos de la app LolPlus: Earnvids, UPFAST, MobileFast, Plus, Netu.
        """
        servers = []
        if not title and not original_title and not en_title and not es_title:
            return servers

        headers = {"User-Agent": DEFAULT_UA, "Referer": DOMAINS.get("tioplus", "https://tioplus.app/")}
        is_serie = season is not None and episode is not None

        queries = []
        for q in (original_title, en_title, title, es_title):
            if q and q.strip() and q.strip() not in queries:
                queries.append(q.strip())
                words = q.strip().split()
                if len(words) > 1 and len(words[-1]) >= 4 and words[-1] not in queries:
                    queries.append(words[-1])

        candidate_scores = {}
        target_type = "serie" if is_serie else "pelicula"
        sondeo = getattr(network, '_sondeo', None)
        consecutive_empty = 0

        def _budget_ok():
            cancel = getattr(sondeo, 'cancel', None)
            deadline = getattr(sondeo, 'deadline', None)
            if cancel is not None and cancel.is_set():
                return False
            if deadline is not None and time.monotonic() >= deadline:
                return False
            return True

        for q in queries:
            if not _budget_ok() or consecutive_empty >= 2:
                break
            search_url = f"{DOMAINS.get('tioplus', 'https://tioplus.app')}/search/{urllib.parse.quote(q)}"
            html = make_request(search_url, headers=headers, timeout=5)
            if not html:
                consecutive_empty += 1
                continue
            consecutive_empty = 0
            if "No hay resultados" in html:
                continue
            pattern = r'href=["\'](https?://tioplus\.app/' + target_type + r'/[^"\']+)["\']'
            links = re.findall(pattern, html)
            if not links:
                continue
            scored = []
            for l in set(links):
                slug = l.rstrip('/').split('/')[-1]
                s1 = calcular_similitud_slug(title, slug, target_year=year) if title else 0.0
                s2 = calcular_similitud_slug(original_title, slug, target_year=year) if original_title else 0.0
                s3 = calcular_similitud_slug(en_title, slug, target_year=year) if en_title else 0.0
                s4 = calcular_similitud_slug(es_title, slug, target_year=year) if es_title else 0.0
                b_sc = max(s1, s2, s3, s4)
                if b_sc >= 0.85:
                    target_len = len(normalize_tokens(title or original_title or ""))
                    slug_len = len(normalize_tokens(slug))
                    scored.append((b_sc, -abs(slug_len - target_len), slug))
            scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
            for score, _, slug in scored:
                candidate_scores[slug] = max(score, candidate_scores.get(slug, 0))

        candidate_slugs = sorted(candidate_scores, key=candidate_scores.get, reverse=True)
        if not candidate_slugs and consecutive_empty < 2:
            for t in (original_title, en_title, title, es_title):
                slug = exact_slug(t)
                if slug and slug not in candidate_slugs:
                    candidate_slugs.append(slug)

        for matched_slug in candidate_slugs:
            if not _budget_ok() or consecutive_empty >= 2:
                break
            if is_serie:
                content_url = f"{DOMAINS.get('tioplus', 'https://tioplus.app')}/serie/{matched_slug}/season/{season}/episode/{episode}"
            else:
                content_url = f"{DOMAINS.get('tioplus', 'https://tioplus.app')}/pelicula/{matched_slug}"

            ep_html = make_request(content_url, headers=headers, timeout=5)
            if not ep_html:
                consecutive_empty += 1
                continue
            consecutive_empty = 0

            items = re.findall(r"""<li[^>]*data-server=['"]([^'"]+)['"][^>]*>(.*?)</li>""", ep_html, re.DOTALL)
            for srv_tok, label_raw in items:
                clean_lbl = re.sub(r'<[^>]+>', ' ', label_raw).strip()
                clean_lbl = clean_lbl.replace("Reproducir", "").strip()
                clean_lbl = re.sub(r'\s+', ' ', clean_lbl)
                b64_tok = base64.b64encode(srv_tok.encode()).decode()
                player_url = f"{DOMAINS.get('tioplus', 'https://tioplus.app')}/player/{b64_tok}"
                p_html = make_request(player_url, headers={"User-Agent": DEFAULT_UA, "Referer": content_url}, timeout=4)
                if p_html:
                    m_dest = re.search(r"""window\.location(?:\.href)?\s*=\s*['"]([^'"]+)['"]""", p_html)
                    if not m_dest:
                        m_dest = re.search(r"""<iframe[^>]+src=['"]([^'"]+)['"]""", p_html)
                    if m_dest:
                        dest = m_dest.group(1).strip()
                        if dest.startswith("http"):
                            quality_match = re.search(r"\b(2160|1080|720|480)p\b", clean_lbl, re.I)
                            servers.append({
                                "nombre": f"TioPlus {clean_lbl} [Latino]",
                                "url": dest,
                                "calidad": quality_match.group(0) if quality_match else "HD",
                                "idioma": "Latino",
                                "source": "lolplus",
                                "mismatched": False
                            })

            if servers:
                return servers

        return servers

    @staticmethod
    def decode_seriesturcas_tab(data_s):
        """
        Decodifica los atributos data-s1..data-s4 de seriesturcastv.to
        (Base64 -> Reverse -> Caesar shift -5 -> XOR con [86, 110, 51, 72, 106, 87, 56, 102]).
        """
        try:
            joined = data_s.replace('|', '')
            raw_bytes = base64.b64decode(joined)
            raw_str = raw_bytes.decode('latin1')[::-1]
            shifted = ''.join(chr((ord(c) - 5 + 256) % 256) for c in raw_str)
            key = [86, 110, 51, 72, 106, 87, 56, 102]
            decoded = ''.join(chr(ord(c) ^ key[i % len(key)]) for i, c in enumerate(shifted))
            m = re.search(r'src=["\']([^"\']+)["\']', decoded)
            if m:
                return m.group(1)
            if decoded.startswith('http'):
                return decoded
        except Exception:
            pass
        return None

    @staticmethod
    def scrape_seriesturcas(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None, es_title=None):
        """
        Extrae servidores de Series Turcas TV (https://tbg.seriesturcastv.to).
        Servidores nativos: VOE, VidMoly, Esprinahy, StreamWish con audio/subtitulos en espanol.
        """
        servers = []
        if season is None or episode is None:
            return servers
        if not title and not original_title and not en_title and not es_title:
            return servers

        s_num = int(season)
        ep_num = int(episode)

        base_url = DOMAINS.get("seriesturcas", "https://tbg.seriesturcastv.to")
        headers = {
            "User-Agent": DEFAULT_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": f"{base_url}/"
        }

        candidates = [t for t in [title, es_title, original_title, en_title] if t and t.strip()]
        seen_queries = set()
        found_series_url = None

        for q in candidates:
            q_clean = re.sub(r"\(.*?\)", "", q).strip()
            if not q_clean or q_clean.lower() in seen_queries:
                continue
            seen_queries.add(q_clean.lower())
            search_url = f"{base_url}/?s={urllib.parse.quote(q_clean)}"
            html = make_request(search_url, headers=headers, timeout=8)
            if not html or "No hay resultados" in html:
                continue
            items = re.findall(r'<a[^>]+href="([^"]+)"[^>]*title="([^"]+)"[^>]*class="poster"', html)
            if not items:
                items = re.findall(r'<a[^>]+class="poster"[^>]*href="([^"]+)"[^>]*title="([^"]+)"', html)
            for href, t in items:
                sim = SequenceMatcher(None, exact_slug(q_clean), exact_slug(t)).ratio()
                if sim >= 0.55 or exact_slug(q_clean) in exact_slug(t) or exact_slug(t) in exact_slug(q_clean):
                    found_series_url = href
                    break
            if found_series_url:
                break

        if not found_series_url:
            return servers

        ep_url = None
        ep_label = ''
        s_html = make_request(found_series_url, headers=headers, timeout=8)
        if s_html:
            eps = re.findall(r'<a[^>]+class=["\']episod["\'][^>]*href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', s_html)
            for u, txt in eps:
                clean_txt = re.sub(r'<[^>]+>', ' ', txt).strip()
                m_ep = re.search(r'(?:cap[ií]tulo|eps?)\s*(\d+)', clean_txt, re.I)
                if m_ep and int(m_ep.group(1)) == ep_num:
                    ep_url = u
                    break
            if not ep_url:
                slug = found_series_url.rstrip('/').split('/')[-1]
                ep_url = f"{found_series_url.rstrip('/')}/{slug}-capitulo-{ep_num}/"

        if not ep_url:
            return servers

        ep_html = make_request(ep_url, headers=headers, timeout=8)
        if not ep_html:
            return servers

        # 1. Pestañas de reproductores online (tab1..tab10) codificados con data-s
        data_s_list = re.findall(r'data-s\d*=["\']([^"\']+)["\']', ep_html)
        direct_iframes = re.findall(r'<div[^>]+id=["\']tab\d+["\'][^>]*>[\s\S]*?<iframe[^>]+src=["\']([^"\']+)["\']', ep_html)

        extracted_urls = list(direct_iframes)
        for ds in data_s_list:
            decoded_url = LolPlusScrapers.decode_seriesturcas_tab(ds)
            if decoded_url and decoded_url not in extracted_urls:
                extracted_urls.append(decoded_url)

        seen_urls = set()
        for href in extracted_urls:
            href_low = href.lower()
            server_name = ""
            if "voe.sx" in href_low or "/voe" in href_low:
                server_name = "VOE"
            elif "vidmoly" in href_low:
                server_name = "VidMoly"
            elif "esprinahy" in href_low or "tokvoy" in href_low:
                server_name = "Esprinahy"
            elif "streamwish" in href_low or "strwish" in href_low:
                server_name = "StreamWish"
            elif "argtesa" in href_low or "abyss" in href_low:
                server_name = "Abyss"
            elif "netusia" in href_low:
                # Netusia es un ad-wall que requiere clics interactivos de navegador real (isTrusted)
                # y popunders publicitarios. Los enlaces m3u8 en su HTML son plantillas comentadas de 2018.
                continue
            elif "aporodiko" in href_low:
                server_name = "Aporodiko"
            elif href_low.startswith("http"):
                parsed_host = urllib.parse.urlsplit(href).netloc.split(".")[0].capitalize()
                server_name = parsed_host

            if server_name and href not in seen_urls:
                seen_urls.add(href)
                quality = "1080p"
                if "aporodiko" in href_low or "netusia" in href_low or "vidmoly" in href_low:
                    quality = "720p"
                servers.append({
                    "nombre": f"SeriesTurcas {server_name} [Subtitulado]",
                    "url": href,
                    "calidad": quality,
                    "idioma": "Subtitulado",
                    "source": "lolplus",
                    "mismatched": False
                })

        # 2. Servidores de descarga / enlaces adicionales (dl-contenti)
        dl_blocks = re.findall(r'<div[^>]+class=["\']dl-contenti["\'][^>]*>([\s\S]*?)</div>', ep_html)
        for b in dl_blocks:
            links = re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', b)
            for href, label in links:
                if href in seen_urls:
                    continue
                href_low = href.lower()
                server_name = ""
                if "voe.sx" in href_low or "/voe" in href_low:
                    server_name = "VOE"
                elif "vidmoly" in href_low:
                    server_name = "VidMoly"
                elif "esprinahy" in href_low or "tokvoy" in href_low:
                    server_name = "Esprinahy"
                elif "streamwish" in href_low or "strwish" in href_low:
                    server_name = "StreamWish"

                if server_name:
                    seen_urls.add(href)
                    quality = "720p" if "vidmoly" in href_low else "1080p"
                    servers.append({
                        "nombre": f"SeriesTurcas {server_name} [Subtitulado]",
                        "url": href,
                        "calidad": quality,
                        "idioma": "Subtitulado",
                        "source": "lolplus",
                        "mismatched": False
                    })

        # Priorizar servidores mas estables y genuinos 1080p (VOE, Abyss, Esprinahy)
        def _seriesturcas_prio(s):
            u = s.get("url", "").lower()
            if "voe" in u:
                return 1
            if "argtesa" in u or "abyss" in u:
                return 2
            if "esprinahy" in u or "tokvoy" in u:
                return 3
            if "streamwish" in u or "strwish" in u:
                return 4
            if "aporodiko" in u:
                return 5
            if "vidmoly" in u:
                return 6
            return 7
        servers.sort(key=_seriesturcas_prio)

        return servers

    @staticmethod
    def scrape_lacartoons(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None, es_title=None):
        """
        Extrae servidores de La Cartoons (https://www.lacartoons.com).
        Servidores nativos: OK.ru y RPMVid con audio Latino.
        """
        servers = []
        if season is None or episode is None:
            return servers
        if not title and not original_title and not en_title and not es_title:
            return servers

        s_num = int(season)
        ep_num = int(episode)

        base_url = DOMAINS.get("lacartoons", "https://www.lacartoons.com")
        headers = {
            "User-Agent": DEFAULT_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": f"{base_url}/"
        }

        candidates = [t for t in [title, es_title, original_title, en_title] if t and t.strip()]
        expanded_queries = []
        for q in candidates:
            q_clean = re.sub(r"\(.*?\)", "", q).strip()
            if not q_clean:
                continue
            if q_clean not in expanded_queries:
                expanded_queries.append(q_clean)
            # lacartoons.com falla en la busqueda si se envian caracteres no-ASCII (tildes/enie).
            # Agregamos el prefijo ASCII previo al caracter especial y palabras clave.
            ascii_prefix = re.split(r'[^\x00-\x7F]', q_clean)[0].strip()
            if len(ascii_prefix) >= 3 and ascii_prefix not in expanded_queries:
                expanded_queries.append(ascii_prefix)
            for w in re.findall(r'[a-zA-Z]{4,}', q_clean):
                if w not in expanded_queries:
                    expanded_queries.append(w)

        seen_queries = set()
        found_series_url = None

        for q_clean in expanded_queries:
            if q_clean.lower() in seen_queries:
                continue
            seen_queries.add(q_clean.lower())
            search_url = f"{base_url}/?Titulo={urllib.parse.quote(q_clean)}"
            html = make_request(search_url, headers=headers, timeout=8)
            if not html or "No hay resultados" in html:
                continue
            series = re.findall(r'<a[^>]+href="(/serie/\d+)"[^>]*>[\s\S]*?<p[^>]+class="nombre-serie"[^>]*>([^<]+)</p>', html)
            for s_link, s_name in series:
                s_name_clean = s_name.strip()
                for target_q in candidates:
                    # Un prefijo compartido no identifica la misma serie (p. ej.
                    # Doraemon frente a Doraemon, el gato cosmico).
                    if exact_slug(target_q) == exact_slug(s_name_clean):
                        found_series_url = base_url + s_link
                        break
                if found_series_url:
                    break
            if found_series_url:
                break

        if not found_series_url:
            return servers

        ep_url = None
        s_html = make_request(found_series_url, headers=headers, timeout=8)
        if s_html:
            ep_links = re.findall(r'<a[^>]+href="([^"]*serie/capitulo/[^"]*)"[^>]*>([\s\S]*?)</a>', s_html)
            for h, t in ep_links:
                clean_t = re.sub(r'<[^>]+>', ' ', t).strip()
                parsed_u = urllib.parse.urlsplit(h)
                qs = urllib.parse.parse_qs(parsed_u.query)
                t_season = qs.get('t', ['1'])[0]
                m_ep = re.search(r'(?:cap[ií]tulo|eps?)\s*(\d+)', clean_t, re.I)
                if m_ep and int(m_ep.group(1)) == ep_num:
                    if str(s_num) == str(t_season):
                        ep_url = base_url + h if h.startswith('/') else h
                        ep_label = clean_t
                        break

        if not ep_url:
            return servers

        ep_html = make_request(ep_url, headers=headers, timeout=8)
        if not ep_html:
            return servers

        iframes = re.findall(r'<iframe[^>]+src="([^"]+)"', ep_html)
        for iframe in iframes:
            if iframe.startswith("//"):
                iframe = "https:" + iframe
            iframe_low = iframe.lower()
            if "ok.ru" in iframe_low:
                # LaCartoons ha enlazado episodios de otras series incluso
                # desde una ficha con el titulo correcto. Comprobar el video.
                video_html = make_request(iframe, headers=headers, timeout=5)
                video_title = re.search(r'<meta[^>]+(?:name|property)=["\'](?:og:)?title["\'][^>]+content=["\']([^"\']+)', video_html, re.I)
                video_name = unescape(video_title.group(1)) if video_title else ''
                video_slug = exact_slug(video_name)
                same_series = any(exact_slug(candidate) in video_slug
                                  for candidate in candidates if exact_slug(candidate))
                # Algunos archivos indican 2x05 y el título del capítulo, sin
                # mencionar la serie. Exigir ambas señales y la ficha correcta.
                coordinates = re.search(
                    rf'(?<!\d)0?{s_num}\s*[xXeE]\s*0?{ep_num}(?!\d)', video_name)
                label_title = re.sub(r'^cap[ií]tulo\s*\d+\s*[-–]?\s*', '', ep_label, flags=re.I)
                label_slug = exact_slug(label_title)
                same_episode = bool(coordinates and label_slug and label_slug in video_slug)
                if not video_title or not (same_series or same_episode):
                    continue
                servers.append({
                    "nombre": "LaCartoons OK.ru [Latino]",
                    "url": iframe,
                    "idioma": "Latino",
                    "calidad": "",
                    "source": "lolplus",
                    "mismatched": False
                })
            elif "vk.com" in iframe_low or "vkvideo" in iframe_low or "/video_ext.php" in iframe_low:
                servers.append({
                    "nombre": "LaCartoons VK [Latino]",
                    "url": iframe,
                    "idioma": "Latino",
                    "calidad": "",
                    "source": "lolplus",
                    "mismatched": False
                })
            elif "cubeembed.rpmvid.com" in iframe_low or "rpmvid" in iframe_low:
                servers.append({
                    "nombre": "LaCartoons RPMVid [Latino]",
                    "url": iframe,
                    "idioma": "Latino",
                    "calidad": "",
                    "source": "lolplus",
                    "mismatched": False
                })

        return servers

# ==============================================================================
# INTEGRACION CON VAQUEXFLIX: FUNCIONES ADAPTADORAS DE CATALOGO Y SERVIDORES
# ==============================================================================

    @staticmethod
    def scrape_seriesflix(title, season=None, episode=None, original_title=None, year=None, tmdb_id=None, en_title=None, es_title=None):
        """
        Extrae servidores de SeriesFlix (https://seriesflixhd.lol).
        Servidores nativos: VOE, Nupload, Waaw, Streamtape con etiquetas de idioma (Latino, Castellano, Subtitulado).
        """
        servers = []
        if season is None or episode is None:
            return servers
        if not title and not original_title and not en_title and not es_title:
            return servers

        base_url = DOMAINS.get("seriesflix", "https://seriesflixhd.lol")
        headers = {"User-Agent": DEFAULT_UA, "Referer": f"{base_url}/"}

        queries = []
        for q in (original_title, en_title, title, es_title):
            if q and q.strip() and q.strip() not in queries:
                queries.append(q.strip())
                words = q.strip().split()
                if len(words) > 1 and len(words[-1]) >= 4 and words[-1] not in queries:
                    queries.append(words[-1])

        candidate_scores = {}
        for q in queries:
            search_url = f"{base_url}/?s={urllib.parse.quote(q)}"
            html = make_request(search_url, headers=headers, timeout=5)
            if not html or "No hay resultados" in html:
                continue
            articles = re.findall(r'<article[^>]*class=["\'][^"\']*TPost[^"\']*["\'].*?</article>', html, re.DOTALL)
            for art in articles:
                m_href = re.search(r'href=["\'](?:https?://[^/]+)?(/serie/[^/"\']+)/?["\']', art)
                if not m_href:
                    continue
                slug = m_href.group(1).rstrip('/').split('/')[-1]
                s1 = calcular_similitud_slug(title, slug, target_year=year) if title else 0.0
                s2 = calcular_similitud_slug(original_title, slug, target_year=year) if original_title else 0.0
                s3 = calcular_similitud_slug(en_title, slug, target_year=year) if en_title else 0.0
                s4 = calcular_similitud_slug(es_title, slug, target_year=year) if es_title else 0.0
                b_sc = max(s1, s2, s3, s4)
                if b_sc >= 0.80:
                    candidate_scores[slug] = max(b_sc, candidate_scores.get(slug, 0.0))

        candidate_slugs = sorted(candidate_scores, key=candidate_scores.get, reverse=True)
        if not candidate_slugs:
            for t in (original_title, en_title, title, es_title):
                slug = exact_slug(t)
                if slug and slug not in candidate_slugs:
                    candidate_slugs.append(slug)

        for matched_slug in candidate_slugs[:2]:
            ep_url = f"{base_url}/episodio/{matched_slug}-{season}x{episode}/"
            ep_html = make_request(ep_url, headers=headers, timeout=6)
            if not ep_html or "Error 404" in ep_html:
                continue

            items = re.findall(r'<div[^>]*data-url=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*Button\s+sgty[^"\']*["\'][^>]*>(.*?)</div>', ep_html, re.DOTALL)
            for data_url, inner in items:
                try:
                    decoded = base64.b64decode(data_url).decode('utf-8', errors='replace')
                    if 'iframe/?url=' in decoded or 'watch/' in decoded:
                        qs = urllib.parse.parse_qs(urllib.parse.urlparse(decoded).query)
                        if 'url' in qs:
                            decoded = qs['url'][0]
                    label_text = ' '.join(re.sub(r'<[^>]+>', ' ', inner).split()).upper()
                    idioma = "Latino"
                    if "CASTELLANO" in label_text or "ESP" in label_text:
                        idioma = "Castellano"
                    elif "SUB" in label_text:
                        idioma = "Subtitulado"
                    elif "LAT" in label_text:
                        idioma = "Latino"

                    srv_name = "VOE" if "voe" in decoded.lower() else ("Nupload" if "nupload" in decoded.lower() else "SeriesFlix")
                    servers.append({
                        "nombre": f"SeriesFlix {srv_name} [{idioma}]",
                        "url": decoded,
                        "calidad": "HD",
                        "idioma": idioma,
                        "source": "lolplus",
                        "mismatched": False
                    })
                except Exception:
                    pass

            if servers:
                return servers

        return servers

    @staticmethod
    def scrape_pelisflixhd(title, original_title=None, en_title=None, es_title=None, tmdb_id=None, year=None, season=None, episode=None):
        """
        Extrae servidores de PelisflixHD (https://pelisflixhd.win).
        Servidores nativos para películas: Nupload, VOE con idiomas Latino, Castellano, Subtitulado.
        """
        servers = []
        if season is not None or episode is not None:
            return servers
        if not title and not original_title and not en_title and not es_title:
            return servers

        base_url = DOMAINS.get("pelisflixhd", "https://pelisflixhd.win")
        headers = {"User-Agent": DEFAULT_UA, "Referer": f"{base_url}/"}

        queries = []
        for q in (original_title, en_title, title, es_title):
            if q and q.strip() and q.strip() not in queries:
                queries.append(q.strip())
                words = q.strip().split()
                if len(words) > 1 and len(words[-1]) >= 4 and words[-1] not in queries:
                    queries.append(words[-1])

        candidate_scores = {}
        for q in queries:
            search_url = f"{base_url}/?s={urllib.parse.quote(q)}"
            html = make_request(search_url, headers=headers, timeout=5)
            if not html or "No hay resultados" in html:
                continue
            links = re.findall(r'<a[^>]*href=["\'](?:https?://[^/]+)?(/pelicula/[^/"\']+)/?["\']', html)
            for link in set(links):
                slug = link.rstrip('/').split('/')[-1]
                s1 = calcular_similitud_slug(title, slug, target_year=year) if title else 0.0
                s2 = calcular_similitud_slug(original_title, slug, target_year=year) if original_title else 0.0
                s3 = calcular_similitud_slug(en_title, slug, target_year=year) if en_title else 0.0
                s4 = calcular_similitud_slug(es_title, slug, target_year=year) if es_title else 0.0
                b_sc = max(s1, s2, s3, s4)
                if b_sc >= 0.80:
                    candidate_scores[slug] = max(b_sc, candidate_scores.get(slug, 0.0))

        candidate_slugs = sorted(candidate_scores, key=candidate_scores.get, reverse=True)
        if not candidate_slugs:
            for t in (original_title, en_title, title, es_title):
                slug = exact_slug(t)
                if slug and slug not in candidate_slugs:
                    candidate_slugs.append(slug)

        for matched_slug in candidate_slugs[:2]:
            movie_url = f"{base_url}/pelicula/{matched_slug}/"
            m_html = make_request(movie_url, headers=headers, timeout=6)
            if not m_html or "Error 404" in m_html:
                continue

            items = re.findall(r'<li[^>]*data-server=["\']([^"\']+)["\'][^>]*>(.*?)</li>', m_html, re.DOTALL)
            for b64_tok, inner in items:
                try:
                    decoded = base64.b64decode(b64_tok).decode('utf-8', errors='replace')
                    if 'iframe/?url=' in decoded or 'watch/' in decoded:
                        qs = urllib.parse.parse_qs(urllib.parse.urlparse(decoded).query)
                        if 'url' in qs:
                            decoded = qs['url'][0]
                    label_text = ' '.join(re.sub(r'<[^>]+>', ' ', inner).split()).upper()
                    idioma = "Latino"
                    if "CASTELLANO" in label_text or "ESP" in label_text:
                        idioma = "Castellano"
                    elif "SUB" in label_text:
                        idioma = "Subtitulado"
                    elif "LAT" in label_text:
                        idioma = "Latino"

                    srv_name = "VOE" if "voe" in decoded.lower() else ("Nupload" if "nupload" in decoded.lower() else "PelisflixHD")
                    servers.append({
                        "nombre": f"PelisflixHD {srv_name} [{idioma}]",
                        "url": decoded,
                        "calidad": "HD",
                        "idioma": idioma,
                        "source": "lolplus",
                        "mismatched": False
                    })
                except Exception:
                    pass

            if servers:
                return servers

        return servers

TMDB_MOVIE_GENRES = {
    "accion": 28, "aventura": 12, "animacion": 16, "anime": 16, "comedia": 35,
    "crimen": 80, "documental": 99, "drama": 18, "familia": 10751, "fantasia": 14,
    "historia": 36, "terror": 27, "musica": 10402, "misterio": 9648, "romance": 10749,
    "pelicula-de-tv": 10770,
    "ciencia-ficcion": 878, "suspense": 53, "thriller": 53, "belica": 10752, "western": 37
}
TMDB_TV_GENRES = {
    "accion": 10759, "aventura": 10759, "animacion": 16, "anime": 16, "cartoons": 16, "comedia": 35,
    "crimen": 80, "documental": 99, "drama": 18, "familia": 10751, "misterio": 9648,
    "ciencia-ficcion": 10765, "fantasia": 10765, "western": 37, "belica": 10768,
    "action-adventure": 10759, "kids": 10762, "reality": 10764,
    "sci-fi-fantasy": 10765, "soap": 10766, "talk": 10767, "war-politics": 10768
}

TMDB_COLLECTIONS = {
    'peliculas': (
        ('populares', 'Populares'),
        ('mejor-valoradas', 'Mejor valoradas'),
        ('tendencias', 'Tendencias de la semana'),
        ('recien-estrenadas', 'Recién estrenadas'),
        ('retro', 'Retro / Clásicos'),
    ),
    'series': (
        ('populares', 'Populares'),
        ('mejor-valoradas', 'Mejor valoradas'),
        ('tendencias', 'Tendencias de la semana'),
        ('recien-estrenadas', 'Recién estrenadas'),
        ('retro', 'Retro / Clásicos'),
        ('en-emision', 'En emisión'),
    ),
}

# Títulos auditados sin ninguna fuente restante tras retirar CineHax.
# Mantener por ID de TMDb evita ocultar otras películas llamadas igual.
UNAVAILABLE_MOVIE_IDS = {225760}  # Lulu (2005), revisado el 04-11-2026
HIDDEN_MOVIE_IDS = {
    1796111,  # Kaleido Love (2023)
    27,       # 9 Songs (2004/2005)
    291860,   # Kick the Cock (2008)
    444308,   # Cashback (2004)
    31022,    # Aftermath (1994)
    1724816,  # Helena (2026)
}
EXCLUDED_MOVIE_IDS = UNAVAILABLE_MOVIE_IDS | HIDDEN_MOVIE_IDS


def catalog_item_excluded(item):
    """Identifica películas excluidas incluso en cachés antiguos."""
    if not isinstance(item, dict):
        return False
    url = str(item.get('url') or '')
    # Nunca ocultar series que compartan el mismo ID numérico de TMDb.
    if item.get('is_serie') or url.startswith(('lolplus://tv/', 'nova://series/', 'nova://anime/')):
        return False
    tmdb_id = str(item.get('tmdb_id') or '')
    return tmdb_id in {str(value) for value in EXCLUDED_MOVIE_IDS} or any(
        url in (f'lolplus://movie/{value}', f'nova://movies/{value}')
        for value in EXCLUDED_MOVIE_IDS)

_tmdb_menu_cache = {'peliculas': [], 'series': []}

def tmdb_menu_categories(section, existing):
    """Añade géneros nuevos de TMDb sin duplicar los que ya tiene el menú."""
    if section not in ('peliculas', 'series'):
        return dict(existing)
    if section not in _tmdb_menu_cache:
        media_type = 'movie' if section == 'peliculas' else 'tv'
        try:
            data = LolPlusCatalog()._query(f'/genre/{media_type}/list')
            _tmdb_menu_cache[section] = data.get('genres', [])
        except Exception:
            _tmdb_menu_cache[section] = []
    menu = dict(existing)
    mapping = TMDB_MOVIE_GENRES if section == 'peliculas' else TMDB_TV_GENRES
    represented = {mapping[key] for key in menu if key in mapping}
    fallback_posters = next((entry.get('posters', []) for entry in menu.values()
                             if entry.get('posters')), [])
    for genre in _tmdb_menu_cache.get(section, []):
        genre_id = genre.get('id')
        if not isinstance(genre_id, int) or genre_id in represented:
            continue
        key = f'tmdb-{genre_id}'
        name = 'Noticias' if section == 'series' and genre_id == 10763 else genre.get('name', key)
        menu[key] = {'nom': name, 'posters': list(fallback_posters)}
        represented.add(genre_id)
    return menu

def seriesturcas_catalog_page(number=1, query=None):
    """Series publicadas por SeriesTurcas; la web expone la lista completa."""
    from urllib.parse import quote, urljoin, urlsplit
    base = DOMAINS.get('seriesturcas', 'https://tbg.seriesturcastv.to')
    if not isinstance(number, int) or number < 1:
        return [], False
    url = base + ('/?s=' + quote(query) if query else '/series/')
    page = make_request(url, headers={'User-Agent': DEFAULT_UA, 'Referer': base + '/'}, timeout=8)
    if not page:
        return [], False
    cards = re.findall(r'<a\s+href="([^"]+)"\s+title="([^"]+)"\s+class="poster"[^>]*>(.*?)</a>',
                       page, re.I | re.S)
    found = {}
    for href, label, body in cards:
        if not (urlsplit(href).hostname or '').endswith('seriesturcastv.to'):
            continue
        title = unescape(re.sub(r'<[^>]+>', '', label)).strip()
        if not title:
            continue
        image = re.search(r'<img\s+src="([^"]+)', body, re.I)
        found[href] = {'title': title, 'url': href,
                       'cover': urljoin(base, unescape(image.group(1))) if image else '',
                       'source': 'SeriesTurcas', 'is_serie': True, 'section': 'series'}
    items = list(found.values())
    if query:
        return items, False
    start = (number - 1) * 30
    return items[start:start + 30], start + 30 < len(items)


def seriesturcas_search(query):
    return seriesturcas_catalog_page(query=query)[0]


def seriesturcas_episodes(series):
    """Capítulos enlazados desde la ficha propia, sin inferir temporadas TMDb."""
    from urllib.parse import urlsplit
    url = series.get('url', '')
    if not (urlsplit(url).hostname or '').endswith('seriesturcastv.to'):
        return {}
    page = make_request(url, headers={'User-Agent': DEFAULT_UA, 'Referer': url}, timeout=8)
    if not page:
        raise network.ServidorNoDisponible('SeriesTurcas no respondió al abrir los capítulos.')
    entries = []
    seen = set()
    for episode_url, body in re.findall(r'<a\s+class=["\']episod["\']\s+href=["\']([^"\']+)["\']>(.*?)</a>',
                                        page, re.I | re.S):
        if not (urlsplit(episode_url).hostname or '').endswith('seriesturcastv.to'):
            continue
        label = unescape(re.sub(r'<[^>]+>', ' ', body)).strip()
        match = re.search(r'cap[ií]tulo\s*(\d+)', label, re.I)
        if not match:
            continue
        number = int(match.group(1))
        if number in seen:
            continue
        seen.add(number)
        entries.append({'title': f'T1:E{number} - {label}', 'url': episode_url,
                        'season': '1', 'episode': str(number), 'is_serie': True,
                        'section': 'series', 'source': 'SeriesTurcas',
                        'cover': series.get('cover', '')})
    return {'1': sorted(entries, key=lambda item: int(item['episode']))} if entries else {}


def lacartoons_catalog_page(number=1, query=None):
    """Fichas publicadas por LaCartoons, sin atribuirles títulos de TMDb."""
    from urllib.parse import quote, urljoin
    base = DOMAINS.get('lacartoons', 'https://www.lacartoons.com')
    if not isinstance(number, int) or number < 1:
        return [], False
    url = base + ('/?Titulo=' + quote(query) if query else
                  '/?page=' + str(number) if number > 1 else '/')
    page = make_request(url, headers={'User-Agent': DEFAULT_UA, 'Referer': base + '/'}, timeout=8)
    if not page:
        return [], False
    cards = re.findall(r'<a\s+href="(/serie/\d+)"[^>]*>(.*?)</a>', page, re.I | re.S)
    found = []
    for path, body in cards:
        name = re.search(r'<p\s+class="nombre-serie"[^>]*>(.*?)</p>', body, re.I | re.S)
        if not name:
            continue
        title = unescape(re.sub(r'<[^>]+>', '', name.group(1))).strip()
        if not title:
            continue
        cover = re.search(r'<img[^>]+src="([^"]+)', body, re.I)
        found.append({'title': title, 'url': urljoin(base, path),
                      'cover': urljoin(base, unescape(cover.group(1))) if cover else '',
                      'source': 'LaCartoons', 'is_serie': True, 'section': 'series'})
    more = not query and bool(re.search(r'href="/\?page=' + str(number + 1) + r'"', page))
    return found, more


def lacartoons_search(query):
    return lacartoons_catalog_page(query=query)[0]


def lolplus_catalog_page(section, number, genre=None):
    """
    Entrega una pagina de catalogo (peliculas, series o animes) con el formato exacto de Vaquexflix.
    Soporta filtrado por genero mediante TMDB Discover.
    """
    catalog = LolPlusCatalog()
    base_section = section.split("?", 1)[0].lower()
    is_anime_sec = base_section in ("animes", "anime")
    genre_key = genre.lower() if genre else ""
    collection = genre_key[6:] if genre_key.startswith('lista-') else ''

    # Seccion especializada de Animes (Peliculas de Anime)
    if is_anime_sec and genre_key in ("peliculas", "movies"):
        data = catalog.discover_movies(genre_id=16, page=number, with_original_language="ja")
        results = data.get("results", [])
        items = []
        for m in results:
            if 16 not in m.get("genre_ids", []):
                continue
            title = m.get("title") or m.get("original_title") or "Sin título"
            year = (m.get("release_date") or "")[:4]
            rating = str(round(m.get("vote_average", 0), 1)) if m.get("vote_average") else ""
            poster = f"https://image.tmdb.org/t/p/w500{m.get('poster_path')}" if m.get("poster_path") else ""
            items.append({
                "title": title,
                "original_title": m.get("original_title") or m.get("title") or title,
                "url": f"lolplus://movie/{m['id']}",
                "cover": poster,
                "is_serie": False,
                "section": "animes",
                "year": year,
                "rating": rating,
                "plot": m.get("overview", ""),
                "source": "lolplus",
                "tmdb_id": m["id"]
            })
        more = number < data.get("total_pages", 1)
        return items, more

    is_serie = "serie" in base_section or "tv" in base_section or is_anime_sec

    if is_serie:
        if is_anime_sec:
            anime_genre_map = {
                "shonen": "16,10759",
                "comedia": "16,35",
                "fantasia": "16,10765",
                "drama": "16,18",
                "misterio": "16,9648",
                "sci-fi": "16,10765",
                "romance": "16,10749",
            }
            if genre_key in anime_genre_map:
                data = catalog.discover_series(genre_id=anime_genre_map[genre_key], page=number, with_original_language="ja")
            else:
                data = catalog.discover_series(genre_id=16, page=number, with_original_language="ja")
        elif collection and collection in dict(TMDB_COLLECTIONS['series']):
            data = catalog.get_curated_page('series', collection, page=number)
        elif genre_key in ("argentinas", "argentina"):
            data = catalog.discover_series(with_origin_country="AR", page=number)
        elif genre_key in ("mexicanas", "mexicana"):
            data = catalog.discover_series(with_origin_country="MX", page=number)
        elif genre_key in ("musica", "recitales"):
            # TMDb TV no tiene género 10402 (Música); filtrar por keywords de conciertos/festivales y excluir Animación (16)
            data = catalog.discover_series(
                page=number,
                with_keywords="6029|156205|304615|318730|6579|198299|324094",
                without_genres="16",
            )
        elif genre_key in ("series-turcas", "turcas", "turca"):
            data = catalog.discover_series(with_original_language="tr", page=number)
        elif genre_key in ("cartoons", "cartoon", "dibujos-animados"):
            data = catalog.discover_series(genre_id=16, page=number, with_original_language="en", without_keywords="210024,156475,287501,2853,191961")
        elif genre_key and (genre_key in TMDB_TV_GENRES or re.fullmatch(r'tmdb-\d+', genre_key)):
            genre_id = TMDB_TV_GENRES.get(genre_key) or int(genre_key.split('-')[1])
            data = catalog.discover_series(genre_id=genre_id, page=number)
        else:
            data = catalog.get_popular_series(page=number)
        results = data.get("results", [])
        items = []
        for s in results:
            if not is_anime_sec and genre_key != 'cartoons' and (
                    genre_key in TMDB_TV_GENRES or re.fullmatch(r'tmdb-\d+', genre_key)):
                expected_genre = TMDB_TV_GENRES.get(genre_key) or int(genre_key.split('-')[1])
                if expected_genre not in s.get("genre_ids", []):
                    continue
            if is_anime_sec:
                if 16 not in s.get("genre_ids", []):
                    continue
                if s.get("original_language") != "ja":
                    continue
            if genre_key in ("cartoons", "cartoon", "dibujos-animados"):
                if any(c in s.get("origin_country", []) for c in ("JP", "KR", "CN")):
                    continue
            if genre_key in ("musica", "recitales") and 16 in s.get("genre_ids", []):
                continue
            title = s.get("name") or s.get("original_name") or "Sin título"
            year = (s.get("first_air_date") or "")[:4]
            rating = str(round(s.get("vote_average", 0), 1)) if s.get("vote_average") else ""
            poster = f"https://image.tmdb.org/t/p/w500{s.get('poster_path')}" if s.get("poster_path") else ""
            items.append({
                "title": title,
                "original_title": s.get("original_name") or s.get("original_title") or title,
                "url": f"lolplus://tv/{s['id']}",
                "cover": poster,
                "is_serie": True,
                "section": "animes" if is_anime_sec else "series",
                "year": year,
                "rating": rating,
                "plot": s.get("overview", ""),
                "source": "lolplus",
                "tmdb_id": s["id"],
                "adult": s.get("adult", False)
            })
        more = number < data.get("total_pages", 1)
        return items, more
    else:
        genre_key = genre.lower() if genre else ''
        gid = (int(genre_key.split('-')[1]) if re.fullmatch(r'tmdb-\d+', genre_key)
               else TMDB_MOVIE_GENRES.get(genre_key))
        if collection and collection in dict(TMDB_COLLECTIONS['peliculas']):
            data = catalog.get_curated_page('peliculas', collection, page=number)
        elif genre_key in ("argentinas", "argentina"):
            data = catalog.discover_movies(with_origin_country="AR", page=number)
        elif genre_key in ("mexicanas", "mexicana"):
            data = catalog.discover_movies(with_origin_country="MX", page=number)
        elif genre_key in ("cortos", "corto", "cortometrajes"):
            data = catalog.discover_movies(with_runtime_lte=40, with_runtime_gte=3, vote_count_gte=50, page=number)
        elif gid:
            data = catalog.discover_movies(genre_id=gid, page=number)
        else:
            data = catalog.get_popular_movies(page=number)
        results = data.get("results", [])
        items = []
        for m in results:
            if m.get('id') in EXCLUDED_MOVIE_IDS:
                continue
            title = m.get("title") or m.get("original_title") or "Sin título"
            year = (m.get("release_date") or "")[:4]
            rating = str(round(m.get("vote_average", 0), 1)) if m.get("vote_average") else ""
            poster = f"https://image.tmdb.org/t/p/w500{m.get('poster_path')}" if m.get("poster_path") else ""
            items.append({
                "title": title,
                "original_title": m.get("original_title") or m.get("title") or title,
                "url": f"lolplus://movie/{m['id']}",
                "cover": poster,
                "is_serie": False,
                "section": "peliculas",
                "year": year,
                "rating": rating,
                "plot": m.get("overview", ""),
                "source": "lolplus",
                "tmdb_id": m["id"],
                "adult": m.get("adult", False)
            })
        more = number < data.get("total_pages", 1)
        return items, more


def lolplus_catalog_search(query, section="all"):
    """
    Búsqueda universal por TMDB con formato Vaquexflix.
    Mantiene el orden natural de relevancia de TMDB sin alterar títulos.
    """
    catalog = LolPlusCatalog()
    data = catalog.search(query)
    results = []

    for item in data.get("results", []):
        m_type = item.get("media_type")
        if m_type not in ("movie", "tv"):
            continue
        if m_type == 'movie' and item.get('id') in EXCLUDED_MOVIE_IDS:
            continue
        is_serie = m_type == "tv"
        genre_ids = item.get("genre_ids", [])
        is_anime_item = item.get("original_language") == "ja" and (16 in genre_ids)

        if section == "peliculas" and is_serie:
            continue
        if section == "series" and not is_serie:
            continue
        if section == "animes" and not is_anime_item:
            continue
        if section in ("peliculas", "series") and is_anime_item:
            continue

        raw_title = item.get("title") or item.get("name") or item.get("original_title") or item.get("original_name") or "Sin título"
        orig_title = item.get("original_name") or item.get("original_title") or raw_title
        year_str = (item.get("release_date") or item.get("first_air_date") or "")[:4]
        rating = str(round(item.get("vote_average", 0), 1)) if item.get("vote_average") else ""
        poster = f"https://image.tmdb.org/t/p/w500{item.get('poster_path')}" if item.get("poster_path") else ""
        url = f"lolplus://{'tv' if is_serie else 'movie'}/{item['id']}"

        item_sec = "animes" if is_anime_item else ("series" if is_serie else "peliculas")
        results.append({
            "title": raw_title,
            "original_title": orig_title,
            "url": url,
            "cover": poster,
            "is_serie": is_serie,
            "section": item_sec,
            "year": year_str,
            "rating": rating,
            "plot": item.get("overview", ""),
            "source": "lolplus",
            "tmdb_id": item["id"]
        })

    return results


def lolplus_obtener_temporadas_episodios(serie_obj, season_number=None):
    """
    Recupera temporadas y episodios organizados por temporada desde TMDB.
    """
    url = serie_obj.get("url", "")
    tmdb_id = serie_obj.get("tmdb_id")
    if not tmdb_id:
        m = re.search(r"lolplus://tv/(\d+)", url)
        if m:
            tmdb_id = int(m.group(1))

    if not tmdb_id:
        return {}

    catalog = LolPlusCatalog()
    details = catalog.get_tv_details(tmdb_id)
    orig_title_val = serie_obj.get("original_title") or details.get("original_name") or details.get("name") or ""
    series_mpaa = extract_mpaa_tv(details)
    seasons_meta = details.get("seasons", [])
    result = {}

    def fetch_season(s_info):
        s_num = s_info.get("season_number", 0)
        if s_num <= 0:
            return s_num, []
        s_data = catalog.get_season_details(tmdb_id, s_num)
        episodes_raw = s_data.get("episodes", [])

        need_fallback = any(not ep.get("overview") or not ep.get("name") or ep.get("name") == f"Episodio {ep.get('episode_number', 1)}" for ep in episodes_raw)
        eps_es = {}
        eps_en = {}
        try:
            s_es = catalog._query(f"/tv/{tmdb_id}/season/{s_num}", {"language": "es-ES"})
            eps_es = {e.get("episode_number"): e for e in s_es.get("episodes", [])}
        except Exception:
            pass
        if need_fallback:
            try:
                s_en = catalog._query(f"/tv/{tmdb_id}/season/{s_num}", {"language": "en-US"})
                eps_en = {e.get("episode_number"): e for e in s_en.get("episodes", [])}
            except Exception:
                pass

        episodes_list = []
        for ep in episodes_raw:
            ep_num = ep.get("episode_number", 1)
            still = f"https://image.tmdb.org/t/p/w500{ep.get('still_path')}" if ep.get("still_path") else serie_obj.get("cover", "")
            ep_name = ep.get("name", "")
            if not ep_name or ep_name.lower() in (f"episodio {ep_num}", f"capitulo {ep_num}", f"episode {ep_num}"):
                fb_es = eps_es.get(ep_num, {}).get("name", "")
                if fb_es and fb_es.lower() not in (f"episodio {ep_num}", f"capitulo {ep_num}", f"episode {ep_num}"):
                    ep_name = fb_es
                else:
                    fb_en = eps_en.get(ep_num, {}).get("name", "")
                    if fb_en:
                        ep_name = fb_en
            spanish_plot = eps_es.get(ep_num, {}).get('overview') or ep.get('overview', '')
            english_plot = eps_en.get(ep_num, {}).get('overview', '')
            ep_plot = spanish_plot or english_plot
            runtime_mins = ep.get("runtime") or 0
            ep_dur = int(runtime_mins) * 60 if runtime_mins else 0
            episodes_list.append({
                "title": f"T{s_num}:E{ep_num} - {ep_name or ('Episodio ' + str(ep_num))}",
                "name": ep_name,
                "url": f"lolplus://tv/{tmdb_id}/{s_num}/{ep_num}",
                "season": str(s_num),
                "episode": str(ep_num),
                "cover": still,
                "plot": ep_plot,
                "plot_language": 'es' if spanish_plot else ('en' if english_plot else ''),
                "is_serie": True,
                "source": "lolplus",
                "tmdb_id": tmdb_id,
                "serie_title": serie_obj.get("title", ""),
                "original_title": orig_title_val,
                "mpaa": series_mpaa,
                "duration": ep_dur
            })
        return s_num, episodes_list

    selected = [s for s in seasons_meta if season_number is None or
                str(s.get('season_number')) == str(season_number)]
    with ThreadPoolExecutor(max_workers=6) as ex:
        for s_num, episodes_list in ex.map(fetch_season, selected):
            if episodes_list:
                result[str(s_num)] = episodes_list

    import valle_salvaje
    if valle_salvaje.owns(serie_obj):
        valle_salvaje.enrich_episodes(result)

    return result


def lolplus_temporadas_resumen(serie_obj):
    """List published TMDb seasons with one series request, without fetching episodes."""
    tmdb_id = serie_obj.get('tmdb_id')
    if not tmdb_id:
        match = re.search(r'lolplus://tv/(\d+)', serie_obj.get('url', ''))
        tmdb_id = int(match.group(1)) if match else None
    if not tmdb_id:
        return {}
    details = LolPlusCatalog().get_tv_details(tmdb_id)
    if not details:
        raise network.ServidorNoDisponible('TMDb no entregó la ficha de la serie.')
    return {str(s['season_number']): int(s.get('episode_count') or 0)
            for s in details.get('seasons', [])
            if isinstance(s.get('season_number'), int) and s['season_number'] > 0
            and int(s.get('episode_count') or 0) > 0}


def lolplus_obtener_servidores(item, series=None):
    """
    Extrae servidores para una pelicula o episodio consultando exclusivamente proveedores de LolPlus:
    PoseidonHD, SeriesMetro, SeriesKao y PelisPlusHD.
    """
    title = ""
    if series and series.get("title"):
        title = series.get("title")
    elif item.get("serie_title"):
        title = item.get("serie_title")
    elif item.get("title"):
        title = item.get("title")

    title_clean = re.sub(r"^T\d+:E\d+\s*-\s*", "", title)
    title_clean = re.sub(r"\[Próximamente.*?\]", "", title_clean)
    title_clean = re.sub(r"\s*\(\d{4}\)$", "", title_clean).strip()
    tmdb_id = item.get("tmdb_id") or (series.get("tmdb_id") if series else None)
    if not tmdb_id and item.get("url"):
        m_id = re.search(r"lolplus://(?:tv|movie)/(\d+)", item.get("url", ""))
        if m_id:
            tmdb_id = int(m_id.group(1))
    if not tmdb_id and item.get("url"):
        m = re.search(r"lolplus://(?:tv|movie)/(\d+)", item.get("url", ""))
        if m:
            tmdb_id = int(m.group(1))

    season = item.get("season") or (series.get("season") if series else None)
    episode = item.get("episode") or (series.get("episode") if series else None)
    is_serie = season is not None and episode is not None

    year = item.get("year") or (series.get("year") if series else None)
    if not year and item.get("title"):
        m_yr = re.search(r"\((\d{4})\)", item.get("title", ""))
        if m_yr:
            year = m_yr.group(1)

    servers = []

    orig_title = item.get("original_title") or (series.get("original_title") if series else "")
    en_title = ""
    es_title = ""
    if tmdb_id:
        try:
            cat = LolPlusCatalog()
            if is_serie:
                info = cat.get_tv_details(tmdb_id)
                canon_name = info.get("name") or info.get("original_name") or ""
                if canon_name and (not title_clean or title_clean == item.get("name") or re.match(r"^T\d+:E\d+", title)):
                    title_clean = canon_name
                if not orig_title:
                    orig_title = canon_name or ""
                if not year:
                    d_str = info.get('first_air_date') or ''
                    if len(d_str) >= 4 and d_str[:4].isdigit():
                        year = d_str[:4]
                alt_info = cat._query(f"/tv/{tmdb_id}/translations")
                for t in alt_info.get("translations", []):
                    iso = t.get("iso_639_1")
                    name = t.get("data", {}).get("name") or t.get("data", {}).get("title") or ""
                    if iso == "en" and name and not en_title:
                        en_title = name
                    elif iso == "es" and name and not es_title:
                        es_title = name
            else:
                info = cat.get_movie_details(tmdb_id)
                if not orig_title:
                    orig_title = info.get("original_title") or info.get("title") or ""
                if not year:
                    d_str = info.get('release_date') or ''
                    if len(d_str) >= 4 and d_str[:4].isdigit():
                        year = d_str[:4]
                alt_info = cat._query(f"/movie/{tmdb_id}/translations")
                for t in alt_info.get("translations", []):
                    iso = t.get("iso_639_1")
                    name = t.get("data", {}).get("title") or t.get("data", {}).get("name") or ""
                    if iso == "en" and name and not en_title:
                        en_title = name
                    elif iso == "es" and name and not es_title:
                        es_title = name
        except Exception:
            pass

    # All workers inherit the caller's deadline and cancellation token.
    common = dict(season=season, episode=episode, original_title=orig_title,
                  year=year, en_title=en_title, es_title=es_title)
    import source_switches
    jobs = [
        ("Cuevana", LolPlusScrapers.scrape_cuevana, dict(common, tmdb_id=tmdb_id)),
        ("CineCalidad", LolPlusScrapers.scrape_cinecalidad,
         dict(season=season, episode=episode, original_title=orig_title,
              year=year, tmdb_id=tmdb_id, en_title=en_title)),
        ("TioPlus", LolPlusScrapers.scrape_tioplus, dict(common, tmdb_id=tmdb_id)),
        ("Poseidon", LolPlusScrapers.scrape_poseidon, dict(common, tmdb_id=tmdb_id)),
    ]
    if is_serie:
        jobs.extend([
            ("SeriesMetro", LolPlusScrapers.scrape_seriesmetro, dict(common, tmdb_id=tmdb_id)),
            ("SeriesKao", LolPlusScrapers.scrape_serieskao, dict(common, tmdb_id=tmdb_id)),
            ("SeriesFlix", LolPlusScrapers.scrape_seriesflix, dict(common, tmdb_id=tmdb_id)),
            ("SeriesTurcas", LolPlusScrapers.scrape_seriesturcas, dict(common, tmdb_id=tmdb_id)),
            ("LaCartoons", LolPlusScrapers.scrape_lacartoons, dict(common, tmdb_id=tmdb_id)),
        ])
    else:
        jobs.extend([
            ("PelisPlus", LolPlusScrapers.scrape_pelisplus,
             dict(tmdb_id=tmdb_id, year=year, original_title=orig_title,
                  en_title=en_title, es_title=es_title)),
            ("PelisflixHD", LolPlusScrapers.scrape_pelisflixhd, dict(common, tmdb_id=tmdb_id)),
        ])
    jobs = [job for job in jobs if source_switches.enabled(job[0].lower())]
    if not jobs:
        return []
    deadline = getattr(network._sondeo, 'deadline', None)
    cancel = getattr(network._sondeo, 'cancel', None)
    limit = getattr(network._sondeo, 'max_request', float('inf'))

    def fetch(job):
        name, scraper, kwargs = job
        try:
            with network.presupuesto_sondeo(deadline, cancel, limit):
                network.tiempo_peticion(12)
                return scraper(title_clean, **kwargs)
        except Exception as exc:
            log("Error en raspado de {}: {}".format(name, type(exc).__name__), "ERROR")
            return []

    seen = set()
    pool = ThreadPoolExecutor(max_workers=9)
    try:
        futures = {pool.submit(fetch, job): job[0] for job in jobs}
        # Devolver resultados parciales antes de que expire el presupuesto del llamador.
        wait_budget = max(2.0, deadline - time.monotonic() - 3.0) if deadline is not None else 18.0
        done, pending = cf_wait(futures, timeout=wait_budget)
        for future in pending:
            future.cancel()
        for future in done:
            try:
                result = future.result()
                for server in result or []:
                    key = (server.get('nombre'), server.get('url'), server.get('idioma'))
                    if server.get('url') and not server.get('mismatched') and key not in seen:
                        servers.append(server)
                        seen.add(key)
            except Exception:
                pass
    finally:
        pool.shutdown(wait=False)

    content_key = f"tv:{tmdb_id}:{season}:{episode}" if is_serie and tmdb_id else (
        f"tv:{exact_slug(title_clean)}:{season}:{episode}" if is_serie else (
            f"movie:{tmdb_id}" if tmdb_id else f"movie:{exact_slug(title_clean)}:{year}"
        )
    )

    if source_switches.disabled():
        content_key += ':switch:' + source_switches.revision()
    cache = _load_servers_cache()
    cached_entry = cache.get('servers', {}).get(content_key, {})
    if cached_entry.get('version') != SERVERS_CACHE_VERSION:
        cached_entry = {}
    now = time.time()

    # Si hay servidores verificados de respaldo para este contenido y faltan fuentes clave (ej. StreamWish por 502)
    fallback_seeds = [] if source_switches.disabled() else VERIFIED_FALLBACK_SERVERS.get(content_key, [])
    if not fallback_seeds and is_serie and not source_switches.disabled():
        fallback_seeds = VERIFIED_FALLBACK_SERVERS.get(f"tv:{exact_slug(title_clean)}:{season}:{episode}", [])
    for fb in fallback_seeds:
        fb_key = (fb.get('nombre'), fb.get('url'), fb.get('idioma'))
        if fb_key not in seen and not any(fb['url'] == s.get('url') for s in servers):
            servers.append(dict(fb))
            seen.add(fb_key)

    # Si la sesion obtuvo servidores, complementar con servidores cacheados vigentes de fuentes caidas
    if servers:
        if cached_entry and now - cached_entry.get('timestamp', 0) < SERVERS_CACHE_TTL:
            for s in cached_entry.get('list', []):
                s_key = (s.get('nombre'), s.get('url'), s.get('idioma'))
                if s.get('url') and not s.get('mismatched') and s_key not in seen:
                    servers.append(s)
                    seen.add(s_key)
        # Actualizar cache persistente
        cache.setdefault('servers', {})[content_key] = {
            'version': SERVERS_CACHE_VERSION, 'timestamp': now, 'list': servers}
        _save_servers_cache(cache)
    elif cached_entry and now - cached_entry.get('timestamp', 0) < SERVERS_CACHE_TTL:
        # Fallo total de conexion: servir desde cache local (paridad con Flutter sqflite)
        servers = cached_entry.get('list', [])

    return servers

# ==============================================================================
# RESOLUCIÓN KODI PLAYBACK: xbmcplugin.setResolvedUrl()
# ==============================================================================

def build_kodi_stream_url(stream_url, headers=None):
    if not headers:
        headers = {"User-Agent": DEFAULT_UA}
    encoded_params = urllib.parse.urlencode(headers)
    return f"{stream_url}|{encoded_params}"


def play_media(handle, stream_info, title="Video", icon="", is_adaptive=True):
    if isinstance(stream_info, str):
        stream_url = stream_info
        headers = {"User-Agent": DEFAULT_UA}
        stream_type = "hls" if ".m3u8" in stream_url else "mp4"
    else:
        stream_url = stream_info.get("url")
        headers = stream_info.get("headers", {"User-Agent": DEFAULT_UA})
        stream_type = stream_info.get("type", "hls")

    final_playback_url = build_kodi_stream_url(stream_url, headers)
    log(f"Preparando reproducción para {title}: {stream_url}")

    if not KODI_AVAILABLE or not xbmcplugin:
        return {
            "succeeded": True,
            "stream_url": final_playback_url,
            "type": stream_type,
            "headers": headers
        }

    listitem = xbmcgui.ListItem(label=title, path=final_playback_url)
    listitem.setInfo("video", {"Title": title})
    if icon:
        listitem.setArt({"thumb": icon, "icon": icon})

    if stream_type == "hls" or ".m3u8" in stream_url:
        listitem.setMimeType("application/vnd.apple.mpegurl")
        listitem.setContentLookup(False)

    listitem.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle=int(handle), succeeded=True, listitem=listitem)
    return True


def resolve_and_play(handle, source_url, title="Video", icon=""):
    log(f"Resolviendo fuente: {source_url}")
    resolved = LolPlusResolvers.resolve(source_url)
    if not resolved:
        log(f"No se pudo resolver la fuente {source_url}", "ERROR")
        if KODI_AVAILABLE and xbmcplugin:
            xbmcplugin.setResolvedUrl(handle=int(handle), succeeded=False, listitem=xbmcgui.ListItem())
        return False

    return play_media(handle, resolved, title=title, icon=icon)
