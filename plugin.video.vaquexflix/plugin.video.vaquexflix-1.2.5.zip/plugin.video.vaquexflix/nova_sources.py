"""Enlaces de hosts conocidos publicados por el catálogo público de NOVA."""
import json
import hashlib
import ipaddress
import urllib.error
import re
import socket
import threading
import time
import urllib.parse
import urllib.request
import unicodedata

import network
import stream_metadata


API = 'https://syntorq.com/api/'
SUPPORTED_HOSTS = (
    'streamwish.to', 'hglink.to', 'morencius.com',
    'player.poseidonhd2.co', 'vidara.to', 'vidara.so',
    'embedwish.com', 'voe.sx', 'filemoon.sx', 'flaswish.com',
    'luluvido.com', 'vidhidepro.com', 'ok.ru',
    'mega.nz', 'www.mega.nz', 'yourupload.com', 'www.yourupload.com',
    'iframe.andromedans.live',
    'vimeos.net', 'www.vimeos.net',
    'mxdrop.to', 'mxdrop.click', 'mixdrop.top', 'mixdrop.to', 'mixdrop.co', 'mixdrop.ag',
    'mixdrop.is', 'mixdrop.bz', 'm1xdrop.bz',
    'uqload.vc', 'uqload.ws', 'uqload.com', 'uqload.to', 'uqload.net', 'uqload.io',
    'pelispedia.mov', 'www.pelispedia.mov',
    'goodstream.one', 'www.goodstream.one',
    'videoapp.zip', 'www.videoapp.zip', 'videoapp.mov', 'www.videoapp.mov',
    'moviesapi.to', 'www.moviesapi.to', 'vidspark.to',
    'modocine.com', 'www.modocine.com',
)
_page_cache = {}
_page_lock = threading.RLock()
COUNTRY_CODES = frozenset(('PE', 'MX', 'AR', 'CO', 'CL', 'EC', 'VE', 'BO', 'BR', 'ES', 'US', 'INT'))
CHANNEL_CATEGORIES = frozenset(('noticias', 'deportes', 'Deportes', 'peliculas',
                                'musica', 'infantil', 'documentales', 'entretenimiento',
                                'educacion', 'religioso', 'adultos', 'FAST', 'Live TV'))
_channel_cache = {}
_channel_lock = threading.RLock()


class ChannelSignalError(Exception):
    """Fallo comprobado al obtener o verificar una señal de TV."""


def _signal_error(exc):
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code == 402:
            return ChannelSignalError('Este canal requiere Premium del proveedor (HTTP 402)')
        if exc.code in (401, 403):
            return ChannelSignalError('Acceso a la señal rechazado (HTTP {})'.format(exc.code))
        if exc.code in (404, 410):
            return ChannelSignalError('Señal no encontrada (HTTP {})'.format(exc.code))
        return ChannelSignalError('Error del servidor de señal (HTTP {})'.format(exc.code))
    if isinstance(exc, (TimeoutError, urllib.error.URLError)):
        return ChannelSignalError('Tiempo de espera agotado al comprobar la señal')
    if isinstance(exc, ValueError):
        return ChannelSignalError('El enlace no entrega vídeo válido')
    return ChannelSignalError('No se pudo comprobar la señal')


def _number(value, maximum, allow_zero=False):
    text = str(value if value is not None else '')
    return text if text.isdecimal() and (allow_zero or int(text) > 0) and int(text) <= maximum else None


_NETMIRROR_PATH_RE = re.compile(
    r'^/api/netmirror/(?:movie|tv)/\d+/\d+/\d+/\d+p/\d+/?$'
)


def _hakunaymatata_video_url(parsed):
    """Permite CDN directos de vídeo en subdominios hakunaymatata sin aceptar subtítulos."""
    host = (parsed.hostname or '').lower().rstrip('.')
    if not (host == 'bcdnxw.hakunaymatata.com'
            or (host.endswith('.hakunaymatata.com') and not host.startswith('cacdn.'))):
        return False
    return (parsed.path or '').lower().endswith(('.mp4', '.m3u8'))


def _netmirror_url(parsed):
    """Permite rutas API de NetMirror en syntorq.com con estructura de TMDB/resolución válida."""
    host = (parsed.hostname or '').lower().rstrip('.')
    return host == 'syntorq.com' and bool(_NETMIRROR_PATH_RE.match(parsed.path or ''))


def _supported_url(value):
    if not isinstance(value, str) or len(value) > 2048:
        return False
    try:
        parsed = urllib.parse.urlsplit(value)
        host = (parsed.hostname or '').lower()
        return (parsed.scheme == 'https' and not parsed.username and not parsed.password
                and parsed.port in (None, 443)
                and (host in SUPPORTED_HOSTS
                     or _hakunaymatata_video_url(parsed)
                     or _netmirror_url(parsed)))
    except ValueError:
        return False


def _displayable_url(value):
    if not isinstance(value, str) or len(value) > 2048:
        return False
    try:
        parsed = urllib.parse.urlsplit(value)
        host = (parsed.hostname or '').lower()
        if not (parsed.scheme == 'https' and not parsed.username and not parsed.password
                and parsed.port in (None, 443) and re.fullmatch(r'[a-z0-9.-]+', host)
                and '.' in host and not host.endswith((
                    '.local', '.internal', '.localhost', '.test', '.invalid', '.example'))):
            return False
        try:
            return ipaddress.ip_address(host).is_global
        except ValueError:
            return True
    except ValueError:
        return False


def _request(path, opener=None, max_bytes=1024 * 1024):
    opener = opener or network.nueva_sesion()
    request = urllib.request.Request(API + path, headers={
        'User-Agent': network.UA, 'Accept': 'application/json'})
    with opener.open(request, timeout=8) as response:
        if not str(response.headers.get('Content-Type', '')).lower().startswith('application/json'):
            raise ValueError('La API no devolvió JSON')
        payload = response.read(max_bytes + 1)
    if len(payload) > max_bytes:
        raise ValueError('Respuesta demasiado grande')
    return json.loads(payload)


def _card(entry, kind):
    if not isinstance(entry, dict):
        return None
    nova_id = _number(entry.get('id'), 999999999)
    tmdb_id = _number(entry.get('tmdb_id'), 999999999)
    title = str(entry.get('title') or '').strip()[:200]
    if not nova_id or (not tmdb_id and kind != 'anime') or not title:
        return None
    if kind == 'movies' and tmdb_id:
        import lolplus
        if int(tmdb_id) in lolplus.EXCLUDED_MOVIE_IDS:
            return None
    anime_season = _anime_season(entry.get('base_slug') or entry.get('slug')) if kind == 'anime' else None
    anime_slug = str(entry.get('base_slug') or entry.get('slug') or '')
    franchise_match = re.search(r'(?<!\d)(20\d{2})(?!\d)', title + ' ' + anime_slug) if kind == 'anime' else None
    return {
        'title': title, 'url': 'nova://{}/{}'.format(kind, nova_id),
        'source': 'nova', 'nova_id': int(nova_id),
        'tmdb_id': int(tmdb_id) if tmdb_id else None,
        'is_serie': kind in ('series', 'anime'),
        'section': 'animes' if kind == 'anime' else 'series' if kind == 'series' else 'peliculas',
        'year': entry.get('year'), 'rating': entry.get('rating') or 0,
        'cover': entry.get('poster_url') or '', 'fanart': entry.get('backdrop_url') or '',
        'plot': entry.get('overview') or '', 'genres': entry.get('genres') or [],
        'language': entry.get('language') or '', 'source_site': entry.get('source_site') or '',
        'anime_season': anime_season,
        'franchise_year': franchise_match.group(1) if franchise_match else None,
    }


def _anime_season(value):
    match = re.search(r'-(\d+)(?:st|nd|rd|th)-season(?:-|$)', str(value or ''), re.I)
    return int(match.group(1)) if match else 1


def _episode_title(value, number):
    label = str(value or '').strip()
    if re.match(r'^episodio\s*{}\b'.format(re.escape(str(number))), label, re.I):
        return label
    return 'Episodio {}{}'.format(number, ' · ' + label if label else '')


def search(query, section='all', opener=None):
    query = str(query or '').strip()[:120]
    if not query:
        return []
    kinds = ('movies', 'series', 'anime') if section == 'all' else (
        ('series', 'anime') if section in ('anime', 'animes') else
        ('series',) if section == 'series' else ('movies',))
    found = []
    for kind in kinds:
        queries = [query]
        first = query.split()[0]
        if first != query:
            queries.append(first)
        seen = set()
        for term in queries:
            try:
                data = _request('{}/search?q={}'.format(kind, urllib.parse.quote(term)), opener)
                if not isinstance(data, list):
                    raise ValueError('Búsqueda inválida')
                for entry in data[:100]:
                    if section in ('anime', 'animes') and kind == 'series' and not any(
                            'anim' in str(g).lower() for g in entry.get('genres') or []):
                        continue
                    card = _card(entry, kind)
                    if card and card['url'] not in seen:
                        if section in ('anime', 'animes') and kind == 'series':
                            card['section'] = 'animes'
                        found.append(card)
                        seen.add(card['url'])
            except Exception as exc:
                network.log_resolver('NOVA: búsqueda no disponible ({})'.format(type(exc).__name__))
    if section in ('all', 'anime', 'animes') and '1/2' in query:
        seen = {card['url'] for card in found}
        for year in {str(card.get('year')) for card in found
                     if card.get('is_serie') and str(card.get('year') or '').isdigit()}:
            term = '{} ({})'.format(query.replace('1/2', '½'), year)
            try:
                data = _request('anime/search?q={}'.format(urllib.parse.quote(term)), opener)
                for entry in data[:100]:
                    card = _card(entry, 'anime')
                    if card and card['url'] not in seen:
                        found.append(card)
                        seen.add(card['url'])
            except Exception as exc:
                network.log_resolver('NOVA: búsqueda de anime no disponible ({})'.format(type(exc).__name__))
    return found


def _genre_name(value):
    aliases = {'tmdb-28': 'accion', 'tmdb-12': 'aventura', 'tmdb-16': 'animacion',
               'tmdb-35': 'comedia', 'tmdb-80': 'crimen', 'tmdb-99': 'documental',
               'tmdb-18': 'drama', 'tmdb-10751': 'familia', 'tmdb-14': 'fantasia',
               'tmdb-36': 'historia', 'tmdb-27': 'terror', 'tmdb-10402': 'musica',
               'tmdb-9648': 'misterio', 'tmdb-10749': 'romance', 'tmdb-878': 'ciencia ficcion',
               'tmdb-53': 'suspense', 'tmdb-10752': 'belica', 'tmdb-37': 'western'}
    value = aliases.get(value, value or '')
    value = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', ' ', value).strip()


def _catalog_batch(kind, batch, opener=None):
    key = (kind, batch)
    with _page_lock:
        cached = _page_cache.get(key)
        if opener is None and cached and time.monotonic() - cached[0] < 600:
            return cached[1]
    data = _request('{}/?skip={}&limit=100'.format(kind, batch * 100), opener)
    if not isinstance(data, list):
        raise ValueError('Página inválida')
    if opener is None:
        with _page_lock:
            _page_cache[key] = (time.monotonic(), data)
            if len(_page_cache) > 40:
                _page_cache.pop(next(iter(_page_cache)))
    return data


def page(section, number, genre=None, opener=None, preview=False):
    kind = 'anime' if section in ('anime', 'animes') else 'series' if section == 'series' else 'movies'
    number = _number(number, 10000)
    if not number:
        return [], False
    limit = 24
    if kind == 'anime':
        filters = {'shonen': ('genre', 'Shounen'), 'comedia': ('genre', 'Comedia'),
                   'fantasia': ('genre', 'Fantasía'), 'drama': ('genre', 'Drama'),
                   'misterio': ('genre', 'Misterio'), 'sci-fi': ('genre', 'Ciencia Ficción'),
                   'romance': ('genre', 'Romance'), 'peliculas': ('type', 'Pelicula')}
        if genre and genre not in filters:
            return [], False
        query = ''
        if genre:
            key, value = filters[genre]
            query = '&{}={}'.format(key, urllib.parse.quote(value))
        try:
            data = _request('anime/?skip={}&limit={}{}'.format((int(number) - 1) * limit,
                                                               limit, query), opener)
            if not isinstance(data, list):
                raise ValueError('Página de anime inválida')
            return [card for entry in data if (card := _card(entry, kind))], len(data) == limit
        except Exception as exc:
            network.log_resolver('NOVA: anime no disponible ({})'.format(type(exc).__name__))
            return [], False
    if not genre:
        try:
            data = _request('{}/?skip={}&limit={}'.format(kind, (int(number) - 1) * limit, limit), opener)
            if not isinstance(data, list):
                raise ValueError('Página inválida')
            return [card for entry in data if (card := _card(entry, kind))], len(data) == limit
        except Exception as exc:
            network.log_resolver('NOVA: catálogo no disponible ({})'.format(type(exc).__name__))
            return [], False
    target = _genre_name(genre)
    if not target:
        return [], False
    matches = []
    raw_limit = 100
    more = False
    try:
        for batch in range(2 if preview else 10):
            data = _catalog_batch(kind, batch, opener)
            for entry in data:
                if isinstance(entry, dict) and any(_genre_name(g) == target for g in entry.get('genres') or []):
                    card = _card(entry, kind)
                    if card:
                        matches.append(card)
            if len(data) < raw_limit:
                break
            more = batch < 9
            if len(matches) >= (3 if preview else int(number) * limit + 1):
                break
        start = 0 if preview else (int(number) - 1) * limit
        size = 3 if preview else limit
        return matches[start:start + size], len(matches) > start + size or more
    except Exception as exc:
        network.log_resolver('NOVA: categoría no disponible ({})'.format(type(exc).__name__))
        return [], False


def episodes(series, opener=None):
    if str(series.get('url', '')).startswith('nova://anime/'):
        return anime_episodes(series, opener=opener)
    nova_id = _number(series.get('nova_id'), 999999999)
    if not nova_id:
        return {}
    try:
        detail = _request('series/{}'.format(nova_id), opener, max_bytes=8 * 1024 * 1024)
        if not isinstance(detail, dict) or not isinstance(detail.get('seasons'), list):
            raise ValueError('Serie inválida')
    except Exception as exc:
        raise network.ServidorNoDisponible('NOVA no entregó los episodios ({})'.format(type(exc).__name__)) from exc
    result = {}
    for season in detail['seasons']:
        if not isinstance(season, dict) or _number(season.get('number'), 999, allow_zero=True) is None:
            continue
        season_num = str(season['number'])
        entries = []
        for episode in season.get('episodes') or []:
            if not isinstance(episode, dict) or not _number(episode.get('number'), 9999):
                continue
            ep_num = str(episode['number'])
            entries.append({
                'title': _episode_title(episode.get('title'), ep_num),
                'url': 'nova://episode/{}/{}/{}'.format(nova_id, season_num, ep_num),
                'source': 'nova', 'tmdb_id': series.get('tmdb_id'),
                'is_serie': True, 'season': season_num, 'episode': ep_num,
                'cover': episode.get('still_url') or series.get('cover', ''),
                'plot': episode.get('overview') or '',
            })
        if entries:
            result[season_num] = entries
    return result


def anime_episodes(series, opener=None):
    nova_id = _number(series.get('nova_id'), 999999999)
    if not nova_id:
        return {}
    entries = []
    season = _number(series.get('anime_season'), 99) or '1'
    try:
        for batch in range(50):
            data = _request('anime/{}/episodes?skip={}&limit=100'.format(nova_id, batch * 100),
                            opener, max_bytes=4 * 1024 * 1024)
            if not isinstance(data, list):
                raise ValueError('Episodios de anime inválidos')
            for episode in data:
                if not isinstance(episode, dict):
                    continue
                ep_num = _number(episode.get('episode_number'), 9999)
                if not ep_num:
                    continue
                entries.append({
                    'title': _episode_title(episode.get('title'), ep_num),
                    'url': 'nova://anime_episode/{}/{}'.format(nova_id, ep_num),
                    'source': 'nova', 'section': 'animes', 'nova_id': int(nova_id),
                    'tmdb_id': series.get('tmdb_id'), 'is_serie': True,
                    'season': season, 'episode': ep_num,
                    'cover': episode.get('thumbnail_url') or series.get('cover', ''),
                    'plot': '', 'anime_source_url': episode.get('source_url') or '',
                    'language': series.get('language') or '',
                })
            if len(data) < 100:
                break
        return {season: entries} if entries else {}
    except Exception as exc:
        raise network.ServidorNoDisponible('NOVA no entregó los episodios de anime ({})'.format(
            type(exc).__name__)) from exc


def _channel_card(entry):
    if not isinstance(entry, dict):
        return None
    channel_id = _number(entry.get('id'), 999999999)
    name = str(entry.get('name') or '').strip()[:120]
    if not channel_id or not name:
        return None
    country = str(entry.get('country_name') or entry.get('country') or '').strip()[:60]
    category = str(entry.get('category') or '').strip()[:60]
    return {'title': name, 'url': 'novatv://{}'.format(channel_id),
            'source': 'nova', 'cover': entry.get('logo_url') or '',
            'rating': 'PREMIUM' if entry.get('is_premium') else 'DIRECTO',
            'plot': 'TV en vivo · {}{}'.format(country, ' · ' + category if category else '')}


def channels(country='PE', opener=None):
    country = str(country or '').upper()
    if country not in COUNTRY_CODES:
        return []
    with _channel_lock:
        cached = _channel_cache.get(country)
        if opener is None and cached and time.monotonic() - cached[0] < 300:
            return list(cached[1])
    try:
        cards = []
        seen = set()
        for batch in range(6):
            data = _request('channels/?skip={}&limit=500&country={}'.format(batch * 500, country),
                            opener, max_bytes=2 * 1024 * 1024)
            if not isinstance(data, list):
                raise ValueError('Lista de canales inválida')
            for entry in data:
                card = _channel_card(entry)
                if card and card['url'] not in seen:
                    seen.add(card['url'])
                    cards.append(card)
            if len(data) < 500:
                break
        if opener is None:
            with _channel_lock:
                _channel_cache[country] = (time.monotonic(), cards)
        return cards
    except Exception as exc:
        network.log_resolver('NOVA TV: catálogo no disponible ({})'.format(type(exc).__name__))
        return []


def channels_by_category(category, opener=None):
    if category not in CHANNEL_CATEGORIES:
        return []
    try:
        cards = []
        seen = set()
        for batch in range(60):
            data = _request('channels/?skip={}&limit=100&category={}'.format(
                batch * 100, urllib.parse.quote(category)), opener, max_bytes=5 * 1024 * 1024)
            if not isinstance(data, list):
                raise ValueError('Lista de canales inválida')
            for entry in data:
                card = _channel_card(entry)
                if card and card['url'] not in seen:
                    seen.add(card['url'])
                    cards.append(card)
            if len(data) < 100:
                break
        return cards
    except Exception as exc:
        network.log_resolver('NOVA TV: categoría no disponible ({})'.format(type(exc).__name__))
        return []


def channels_page(page, country=None, opener=None):
    """Página del catálogo sin filtro; permite alcanzar países y géneros no listados."""
    if not isinstance(page, int) or not 0 <= page <= 300 or (country and country not in COUNTRY_CODES):
        return []
    try:
        path = 'channels/?skip={}&limit=100'.format(page * 100)
        if country:
            path += '&country=' + country
        data = _request(path, opener, max_bytes=5 * 1024 * 1024)
        if not isinstance(data, list):
            raise ValueError('Lista de canales inválida')
        cards = [card for entry in data if (card := _channel_card(entry))]
        prefix = 'nova_country_{}_page_'.format(country.lower()) if country else 'nova_page_'
        if page:
            cards.insert(0, {'title': '← PÁGINA ANTERIOR', 'url': 'tv://{}{}'.format(prefix, page - 1),
                             'rating': 'NAVEGAR', 'plot': 'Volver a la página anterior.'})
        if len(data) == 100 and page < 300:
            cards.append({'title': 'PÁGINA SIGUIENTE →', 'url': 'tv://{}{}'.format(prefix, page + 1),
                          'rating': 'NAVEGAR', 'plot': 'Ver más canales del catálogo.'})
        return cards
    except Exception as exc:
        network.log_resolver('NOVA TV: página {} no disponible ({})'.format(page, type(exc).__name__))
        return []


def search_channels(query, opener=None):
    query = str(query or '').strip()[:100]
    if not query:
        return []
    try:
        data = _request('search?q={}'.format(urllib.parse.quote(query)), opener)
        entries = data.get('channels') if isinstance(data, dict) else None
        if not isinstance(entries, list):
            raise ValueError('Búsqueda de canales inválida')
        return [card for entry in entries[:100] if (card := _channel_card(entry))]
    except Exception as exc:
        network.log_resolver('NOVA TV: búsqueda no disponible ({})'.format(type(exc).__name__))
        return []


def _public_channel_url(url):
    if not isinstance(url, str) or len(url) > 4096:
        return False
    try:
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
            return False
        port = parsed.port
        if port not in (None, 80, 443) and not (1024 <= port <= 65535):
            return False
        if not ('.m3u8' in parsed.path.lower() or parsed.path.lower().endswith('.ts')):
            return False
    except ValueError:
        return False
    try:
        address = ipaddress.ip_address(parsed.hostname)
        return address.is_global
    except ValueError:
        host = parsed.hostname or ''
        if not (re.fullmatch(r'[A-Za-z0-9.-]+', host) and '.' in host and
                not host.endswith(('.local', '.internal'))):
            return False
        if port in (None, 80, 443):
            return True
        try:
            addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            return bool(addresses) and all(ipaddress.ip_address(item[4][0]).is_global
                                           for item in addresses)
        except (OSError, ValueError):
            return False


def _public_hls(url):
    return _public_channel_url(url) and '.m3u8' in urllib.parse.urlsplit(url).path.lower()


def _probe_ts_or_manifest(url, stream, session, deadline, probe):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('Tiempo de sondeo agotado')
    request = urllib.request.Request(url, headers={
        'User-Agent': urllib.parse.unquote(stream.partition('User-Agent=')[2]),
        'Range': 'bytes=0-1023'})
    with session.open(request, timeout=min(4, remaining)) as response:
        sample = response.read(1024)
    if sample.lstrip(b'\xef\xbb\xbf \r\n').startswith(b'#EXTM3U'):
        probe(stream, session, deadline)
        return stream + '&ext=.m3u8'
    if len(sample) >= 564 and sample[0] == sample[188] == sample[376] == 0x47:
        return stream
    raise ValueError('El enlace TS no entregó vídeo MPEG-TS ni un manifiesto HLS')


CHANNEL_REPAIR_URLS = {
    # 288900: America Television Peru (API entrega iframe web https://www.americatv.com.pe/envivo sin HLS)
    '288900': [
        'http://190.93.224.42/AMERICA-TV/index.m3u8',
        'http://lpaelectronics.com:80/live/MAG1J99LK5/cposjTfgAh/30574.ts',
        'http://bestrktv.xyz:80/live/GGAUWUZNFP3TYXF/NC4sHzFvhb/30574.ts',
    ],
}


def channel_stream(channel_url, opener=None, probe=None, raise_on_failure=False):
    """Obtiene enlace nuevo por ID y exige un primer segmento accesible."""
    parsed = urllib.parse.urlsplit(channel_url)
    channel_id = _number(parsed.netloc, 999999999) if parsed.scheme == 'novatv' else None
    if not channel_id:
        return None
    try:
        data = _request('channels/stream/{}'.format(channel_id), opener)
        if not isinstance(data, dict):
            raise ValueError('Respuesta de canal inválida')
    except Exception as exc:
        network.log_resolver('NOVA TV: canal {} sin respuesta de API ({} {})'.format(
            channel_id, type(exc).__name__, getattr(exc, 'code', '')))
        if raise_on_failure:
            raise _signal_error(exc) from exc
        return None
    ua = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'
    urls = [data.get('primary_url')]
    urls.extend(entry.get('url') if isinstance(entry, dict) else entry
                for entry in (data.get('backup_urls') or [])[:20])
    if str(channel_id) in CHANNEL_REPAIR_URLS:
        urls.extend(CHANNEL_REPAIR_URLS[str(channel_id)])
    urls = list(dict.fromkeys(urls))
    probe = probe or stream_metadata.inspect_stream
    deadline = time.monotonic() + 15
    session = opener or network.nueva_sesion()
    failures = []
    compatible = 0
    for url in urls:
        if time.monotonic() >= deadline:
            break
        if not _public_channel_url(url):
            continue
        compatible += 1
        stream = url + '|User-Agent=' + urllib.parse.quote(ua, safe='')
        try:
            if urllib.parse.urlsplit(url).path.lower().endswith('.ts'):
                return _probe_ts_or_manifest(url, stream, session, deadline, probe)
            probe(stream, session, deadline)
            return stream
        except Exception as exc:
            failures.append(exc)
            network.log_resolver('NOVA TV: canal {} candidato {} sin segmento ({} {})'.format(
                channel_id, urllib.parse.urlsplit(url).hostname, type(exc).__name__,
                getattr(exc, 'code', '')))
    if raise_on_failure:
        if not compatible:
            raise ChannelSignalError('Enlace sin HLS compatible; pendiente de reparación')
        if time.monotonic() >= deadline or any(isinstance(exc, (TimeoutError, urllib.error.URLError))
                                               for exc in failures):
            raise ChannelSignalError('Tiempo de espera agotado al comprobar la señal')
        if failures:
            raise _signal_error(failures[-1])
        raise ChannelSignalError('Sin señal verificable en este momento')
    return None


def servers(item, series=None, opener=None):
    """Consulta una ficha exacta; la calidad del backend nunca se da por verificada."""
    root = series or item
    if item.get('anime_source_url') or str(item.get('url', '')).startswith('nova://anime_episode/'):
        return anime_servers(item, series=series, opener=opener)
    tmdb_id = _number(root.get('tmdb_id') or item.get('tmdb_id'), 999999999)
    if not tmdb_id:
        return []
    if series:
        season = _number(item.get('season'), 999, allow_zero=True)
        episode = _number(item.get('episode'), 9999)
        if season is None or not episode:
            return []
        path = 'sources/tv/{}/{}/{}'.format(tmdb_id, season, episode)
    else:
        path = 'sources/movie/{}'.format(tmdb_id)
    paths = [path]
    vod_path = _vod_sources_path(tmdb_id, item, series)
    if vod_path:
        paths.append(vod_path)
    entries = []
    for candidate_path in paths:
        try:
            data = _request(candidate_path, opener, max_bytes=4 * 1024 * 1024)
            if not isinstance(data, dict) or not isinstance(data.get('sources'), list):
                raise ValueError('Lista de fuentes inválida')
            entries.extend(data['sources'])
        except Exception as exc:
            network.log_resolver('NOVA: consulta de fuentes no disponible ({}, {})'.format(
                'VOD' if candidate_path != path else 'base', type(exc).__name__))
    incorrect_urls = set()
    if not series and tmdb_id == '1284046':
        # NOVA atribuye a Onslaught (2026) dos embeds que también publica
        # para Annihilation (2018). Comparar las URL originales, no el host.
        known_wrong = {
            '4a479490b0b3', '650a4f42b763', 'c2efe3880853',
        }
        older_urls = set()
        try:
            older = _request('sources/movie/300668', opener, max_bytes=4 * 1024 * 1024)
            if isinstance(older, dict) and isinstance(older.get('sources'), list):
                older_urls = {x.get('embed_url') for x in older['sources'] if isinstance(x, dict)}
        except Exception as exc:
            network.log_resolver('NOVA: comparación de películas homónimas no disponible ({})'.format(
                type(exc).__name__))
        incorrect_urls = {x.get('embed_url') for x in entries if isinstance(x, dict)
                          and str(x.get('provider') or '').lower() == 'flixlatam'
                          and (x.get('embed_url') in older_urls or
                               hashlib.sha256(str(x.get('embed_url') or '').encode()).hexdigest()[:12] in known_wrong)}
    return _server_cards(entries, incorrect_urls=incorrect_urls)


def _vod_sources_path(tmdb_id, item, series=None):
    root = series or item
    title = str(root.get('original_title') or root.get('title') or '').strip()[:200]
    if not title:
        return ''
    params = {'title': title}
    year = str(root.get('year') or '')[:4]
    if year.isdecimal() and 1880 <= int(year) <= 2100:
        params['year'] = year
    imdb_id = str(root.get('imdb_id') or '')
    if re.fullmatch(r'tt\d{7,10}', imdb_id):
        params['imdb_id'] = imdb_id
    language = str(root.get('language') or '')[:24]
    if language and re.fullmatch(r'[\w -]+', language):
        params['language'] = language
    if series:
        params['is_anime'] = 'true' if root.get('section') in ('animes', 'anime') else 'false'
        endpoint = 'vod/sources/tv/{}/{}/{}'.format(tmdb_id, item['season'], item['episode'])
    else:
        endpoint = 'vod/sources/movie/{}'.format(tmdb_id)
    return endpoint + '?' + urllib.parse.urlencode(params)


def _server_cards(entries, incorrect_urls=None):
    found = []
    seen = set()
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        url = entry.get('embed_url')
        if not _displayable_url(url) or url in seen:
            continue
        seen.add(url)
        provider = re.sub(r'[^\w .-]', '', str(entry.get('provider') or 'Fuente'))[:32].strip()
        host = urllib.parse.urlsplit(url).hostname
        language = re.sub(r'[^\w .-]', '', str(entry.get('language') or ''))[:24].strip()
        supported = _supported_url(url)
        incorrect = url in (incorrect_urls or ())
        source_quality = stream_metadata.extract_cam_tag(entry.get('quality'), strict_ts=True)
        card = {
            'nombre': 'NOVA {} {}{}{}'.format(
                provider, host, ' [{}]'.format(language) if language else '',
                ' [Contenido cruzado]' if incorrect else
                '' if supported else ' [Pendiente de reparar]'),
            'url': url, 'source': 'nova', 'provider': provider,
            'origin_url': entry.get('origin_url') or url,
            'idioma': language, 'calidad': 'Sin verificar',
            'resolver_status': 'ready' if supported and not incorrect else 'pending',
            'resolver_error': ('Contenido cruzado: este enlace también figura en Aniquilación (2018); '
                               'la película de este servidor requiere revisión.'
                               if incorrect else '' if supported else
                               'Pendiente de reparar: no hay resolutor verificado para este enlace'),
        }
        if source_quality:
            card['source_quality'] = source_quality
        found.append(card)
    return found


def anime_servers(item, series=None, opener=None):
    root = series or item
    tmdb_id = _number(root.get('tmdb_id') or item.get('tmdb_id'), 999999999)
    season = _number(item.get('season'), 999, allow_zero=True)
    episode = _number(item.get('episode'), 9999)
    if season is None or not episode:
        return []
    entries = []
    if tmdb_id:
        for path in ('sources/anime/{}/{}/{}'.format(tmdb_id, season, episode),
                     'sources/tv/{}/{}/{}'.format(tmdb_id, season, episode)):
            try:
                data = _request(path, opener, max_bytes=4 * 1024 * 1024)
                if isinstance(data, dict) and isinstance(data.get('sources'), list):
                    entries.extend(data['sources'])
            except urllib.error.HTTPError as exc:
                if exc.code != 404:
                    network.log_resolver('NOVA: fuentes de anime no disponibles (HTTP {})'.format(exc.code))
            except Exception as exc:
                network.log_resolver('NOVA: fuentes de anime no disponibles ({})'.format(type(exc).__name__))
        if series:
            vod_path = _vod_sources_path(tmdb_id, item, series)
            if vod_path:
                try:
                    data = _request(vod_path, opener, max_bytes=4 * 1024 * 1024)
                    if isinstance(data, dict) and isinstance(data.get('sources'), list):
                        entries.extend(data['sources'])
                except Exception as exc:
                    network.log_resolver('NOVA: VOD de anime no disponible ({})'.format(type(exc).__name__))
    source_url = item.get('anime_source_url') or ''
    parsed = urllib.parse.urlsplit(source_url)
    host = (parsed.hostname or '').lower()
    if _displayable_url(source_url) and parsed.path.startswith('/ver/'):
        import anime
        try:
            if host == 'tioanime.com':
                extra = anime.tioanime_servidores(source_url)
            elif host == 'latanime.org':
                extra = anime.latanime_servidores(source_url)
            else:
                extra = []
            for server in extra:
                entries.append({'provider': server.get('nombre') or host,
                                'embed_url': server.get('url'),
                                'origin_url': source_url,
                                'language': root.get('language') or item.get('language') or ''})
        except Exception as exc:
            network.log_resolver('NOVA: scraper de anime no disponible ({})'.format(type(exc).__name__))
    found = _server_cards(entries)
    if not found and _displayable_url(source_url):
        found = _server_cards([{'provider': host or 'anime', 'embed_url': source_url,
                                'origin_url': source_url,
                                'language': root.get('language') or item.get('language') or ''}])
    return found
