"""Sondeo acotado de metadatos HLS/MP4, sin dependencias nativas ni Kodi."""
import hashlib
import queue
import re
import struct
import threading
import time
from urllib.parse import parse_qsl, urljoin
from urllib.request import Request


def cache_key(url):
    return hashlib.sha256(url.encode('utf-8')).hexdigest()


def item_key(item, series=None):
    root = series or item or {}
    current = item or {}
    tmdb_id = str(current.get('tmdb_id') or root.get('tmdb_id') or '').strip()
    season = current.get('season')
    episode = current.get('episode')
    if tmdb_id:
        if season is not None and episode is not None:
            return f'tmdb:{tmdb_id}:s{season}:e{episode}'
        return f'tmdb:{tmdb_id}'
    url = str(current.get('url') or root.get('url') or '').split('?', 1)[0].rstrip('/')
    return f'url:{url}' if url else ''


def has_verified_cache(meta, current_item_key='', max_age=86400):
    if not isinstance(meta, dict) or not meta.get('playable') or meta.get('error'):
        return False
    if not (meta.get('heights') or meta.get('label')):
        return False
    saved_item = meta.get('item_key')
    if current_item_key and saved_item != current_item_key:
        return False
    return (time.time() - (meta.get('updated') or 0)) <= max_age


def language(code='', name=''):
    code, name = code.lower(), name.lower()
    if 'latino' in name or code in ('es-419', 'es-mx', 'es-ar', 'es-co', 'lat'):
        return 'LAT'
    if 'castellano' in name or code == 'es-es':
        return 'ESP'
    aliases = {'es': 'ES', 'spa': 'ES', 'esp': 'ES', 'en': 'ENG', 'eng': 'ENG',
               'pt': 'POR', 'por': 'POR', 'ja': 'JPN', 'jpn': 'JPN', 'fr': 'FRA',
               'fra': 'FRA', 'fre': 'FRA', 'de': 'DEU', 'deu': 'DEU', 'ger': 'DEU'}
    if code in ('', 'und', 'unknown', 'zxx'):
        return 'Idioma no indicado'
    return aliases.get(code, aliases.get(code.split('-')[0], code.upper()))


def _hls_attributes(line):
    return dict((k, v.strip('"')) for k, v in
                re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,\r\n]+)', line))


def _normalize_height(width, height):
    if width >= 1920 or height >= 1080 or (width >= 1600 and height >= 720):
        return 1080
    return height


_CAM_TAG_RE = re.compile(
    r'(?<![A-Za-z0-9])(HD[-_.\s]?CAM|CAM[-_.]?RIP|CAM|HD[-_.\s]?TS|TS[-_.]?RIP|TELESYNC|TELECINE|SCREENER|DVDSCR|WORKPRINT)(?![A-Za-z0-9])',
    re.I,
)
_HOST_LIKE_RE = re.compile(r'\b[a-z0-9-]+(?:\.[a-z0-9-]+)+\b', re.I)


def extract_cam_tag(text, strict_ts=False):
    """Detecta avisos de captura no final (CAM/TS/SCR) ignorando TLDs .cam."""
    if not text or not isinstance(text, str):
        return ''
    cleaned = _HOST_LIKE_RE.sub(' ', text.strip())
    if strict_ts and text.strip().upper() in ('TS', 'TC'):
        return text.strip().upper()
    match = _CAM_TAG_RE.search(cleaned)
    if not match:
        match = _CAM_TAG_RE.search(text.strip()) if strict_ts else None
    if not match:
        return ''
    token = re.sub(r'[-_.\s]+', '', match.group(1)).upper()
    if token == 'CAMRIP':
        return 'CAM'
    if token in ('TSRIP', 'TELESYNC'):
        return 'TS'
    if token in ('DVDSCR', 'SCREENER'):
        return 'SCR'
    return token


def cam_tag(server=None, meta=None):
    server = server if isinstance(server, dict) else {}
    meta = meta if isinstance(meta, dict) else {}
    return (
        extract_cam_tag(meta.get('release_tag', ''), strict_ts=True)
        or extract_cam_tag(server.get('source_quality', ''), strict_ts=True)
        or extract_cam_tag(server.get('nombre', ''), strict_ts=False)
    )


def _extract_filename_tag(response):
    hdrs = getattr(response, 'headers', None)
    if not hdrs or not hasattr(hdrs, 'get'):
        return ''
    disp = hdrs.get('Content-Disposition', '')
    if not isinstance(disp, str) or not disp:
        return ''
    match = re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)\"?", disp, re.I)
    name = match.group(1) if match else disp
    name = re.sub(r'\.(?:mp4|mkv|m3u8|webm|avi|ts|txt)$', '', name.strip(), flags=re.I)
    return extract_cam_tag(name, strict_ts=True)


def _parse_ext_x_map(playlist_text):
    items, seen = [], set()
    for line in playlist_text.splitlines():
        stripped = line.strip()
        if not stripped.startswith('#EXT-X-MAP:'):
            continue
        attrs = _hls_attributes(stripped)
        uri = (attrs.get('URI') or '').strip()
        if not uri:
            continue
        byte_range = None
        raw_range = (attrs.get('BYTERANGE') or '').strip()
        if raw_range:
            match = re.fullmatch(r'(\d+)(?:@(\d+))?', raw_range)
            if match:
                length = int(match.group(1))
                offset = int(match.group(2)) if match.group(2) is not None else 0
                if length > 0:
                    byte_range = (offset, offset + length - 1)
        entry = (uri, byte_range)
        if entry not in seen:
            seen.add(entry)
            items.append(entry)
    return items


def _parse_init_segment(data):
    for kind, payload in boxes(data):
        if kind == b'moov':
            return parse_moov(payload)
    return {}


def parse_hls(text):
    heights, audio, groups = set(), [], set()
    for line in text.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            attrs = _hls_attributes(line)
            match = re.fullmatch(r'(\d+)x(\d+)', attrs.get('RESOLUTION', ''))
            if match:
                w, h = int(match.group(1)), int(match.group(2))
                heights.add(_normalize_height(w, h))
            if attrs.get('AUDIO'):
                groups.add(attrs['AUDIO'])
    for line in text.splitlines():
        if not line.startswith('#EXT-X-MEDIA:'):
            continue
        attrs = _hls_attributes(line)
        if attrs.get('TYPE') != 'AUDIO' or (groups and attrs.get('GROUP-ID') not in groups):
            continue
        channel = attrs.get('CHANNELS', '').split('/')[0]
        track = {'language': language(attrs.get('LANGUAGE', ''), attrs.get('NAME', '')),
                 'channels': int(channel) if channel.isdigit() else 0}
        if track not in audio:
            audio.append(track)
    return {'heights': sorted(heights), 'audio': audio}


def boxes(data):
    offset = 0
    while offset + 8 <= len(data):
        size, kind = struct.unpack_from('>I4s', data, offset)
        header = 8
        if size == 1:
            if offset + 16 > len(data):
                return
            size = struct.unpack_from('>Q', data, offset + 8)[0]
            header = 16
        if size == 0:
            size = len(data) - offset
        if size < header or offset + size > len(data):
            return
        yield kind, data[offset + header:offset + size]
        offset += size


def parse_moov(data):
    heights, audio = set(), []
    for kind, track in boxes(data):
        if kind != b'trak':
            continue
        children = dict(boxes(track))
        mdia = dict(boxes(children.get(b'mdia', b'')))
        handler = mdia.get(b'hdlr', b'')[8:12]
        if handler == b'vide':
            header = children.get(b'tkhd', b'')
            width, height = 0, 0
            if len(header) >= 84:
                width = struct.unpack('>I', header[-8:-4])[0] >> 16
                height = struct.unpack('>I', header[-4:])[0] >> 16
            if not height:
                minf = dict(boxes(mdia.get(b'minf', b'')))
                stbl = dict(boxes(minf.get(b'stbl', b'')))
                stsd = stbl.get(b'stsd', b'')
                for _, entry in boxes(stsd[8:]):
                    if len(entry) >= 28:
                        width, height = struct.unpack_from('>HH', entry, 24)
                        if height:
                            break
            if height:
                heights.add(_normalize_height(width, height))
        elif handler == b'soun':
            mdhd = mdia.get(b'mdhd', b'')
            lang_offset = 32 if mdhd[:1] == b'\x01' else 20
            code = ''
            if len(mdhd) >= lang_offset + 2:
                packed = struct.unpack_from('>H', mdhd, lang_offset)[0]
                if packed:
                    code = ''.join(chr(((packed >> shift) & 31) + 96) for shift in (10, 5, 0))
                    if not re.fullmatch(r'[a-z]{3}', code):
                        code = ''
            minf = dict(boxes(mdia.get(b'minf', b'')))
            stbl = dict(boxes(minf.get(b'stbl', b'')))
            stsd = stbl.get(b'stsd', b'')
            channels = 0
            for _, entry in boxes(stsd[8:]):
                if len(entry) >= 18:
                    channels = struct.unpack_from('>H', entry, 16)[0]
                    break
            audio.append({'language': language(code), 'channels': channels})
    return {'heights': sorted(heights), 'audio': audio}


def _inspect_transport_stream(data):
    """Verify TS packets and read PMT languages and video SPS when present."""
    packets = [data[i:i + 188] for i in range(0, len(data) - 187, 188)
               if data[i] == 0x47]
    if len(packets) < 3:
        raise ValueError('No se recibió un transporte MPEG-TS válido')
    payloads = {}
    for packet in packets:
        pid = ((packet[1] & 0x1f) << 8) | packet[2]
        control = (packet[3] >> 4) & 3
        if control not in (1, 3):
            continue
        offset = 4
        if control == 3:
            offset += 1 + packet[4]
        if offset >= 188:
            continue
        payloads.setdefault(pid, []).append((bool(packet[1] & 0x40), packet[offset:]))

    def table(pid, expected):
        for start, payload in payloads.get(pid, []):
            if not start or not payload:
                continue
            offset = 1 + payload[0]
            body = payload[offset:]
            if len(body) >= 3 and body[0] == expected:
                size = ((body[1] & 15) << 8) | body[2]
                if len(body) >= 3 + size:
                    return body[:3 + size]
        return b''

    pat = table(0, 0)
    pmt_pid = None
    if pat:
        for offset in range(8, len(pat) - 4, 4):
            if pat[offset:offset + 2] != b'\0\0':
                pmt_pid = ((pat[offset + 2] & 31) << 8) | pat[offset + 3]
                break
    pmt = table(pmt_pid, 2) if pmt_pid is not None else b''
    video_pids = []
    audio = []
    if pmt and len(pmt) >= 16:
        offset = 12 + (((pmt[10] & 15) << 8) | pmt[11])
        end = len(pmt) - 4
        while offset + 5 <= end:
            kind = pmt[offset]
            pid = ((pmt[offset + 1] & 31) << 8) | pmt[offset + 2]
            length = ((pmt[offset + 3] & 15) << 8) | pmt[offset + 4]
            desc = pmt[offset + 5:offset + 5 + length]
            if kind in (0x02, 0x1b, 0x24):
                video_pids.append((pid, kind))
            if kind in (0x03, 0x04, 0x0f, 0x11, 0x81):
                code = ''
                cursor = 0
                while cursor + 2 <= len(desc):
                    size = desc[cursor + 1]
                    if desc[cursor] == 0x0a and size >= 3:
                        code = desc[cursor + 2:cursor + 5].decode('ascii', 'ignore')
                        break
                    cursor += size + 2
                audio.append({'language': language(code) if code else 'No indicado', 'channels': 0})
            offset += 5 + length
    if not pat or not pmt or not video_pids or not any(payloads.get(pid) for pid, _ in video_pids):
        raise ValueError('El TS no contiene una pista de vídeo verificable')
    heights = []
    for pid, kind in video_pids:
        body = b''.join(chunk for _, chunk in payloads.get(pid, []))
        for match in re.finditer(b'\x00\x00\x01', body):
            nal = body[match.end():match.end() + 160]
            try:
                height = _ts_sps_height(nal, kind)
            except (ValueError, IndexError):
                height = 0
            if height:
                heights.append(height)
                break
        if heights:
            break
    result = {'label': 'Vídeo verificado', 'audio': audio}
    if heights:
        result['heights'] = [heights[0]]
        result.pop('label')
    return result


def _ts_sps_height(nal, kind):
    """Read coded dimensions from H.264/H.265 SPS; return zero if unsupported."""
    if not nal or not ((kind == 0x1b and nal[0] & 31 == 7) or
                       (kind == 0x24 and (nal[0] >> 1) & 63 == 33)):
        return 0
    prefix = 1 if kind == 0x1b else 2
    raw = bytearray()
    for byte in nal[prefix:]:
        if len(raw) >= 2 and raw[-2:] == b'\0\0' and byte == 3:
            continue
        raw.append(byte)

    class Bits:
        def __init__(self):
            self.pos = 0
        def read(self, count):
            if self.pos + count > len(raw) * 8:
                raise ValueError('SPS incompleto')
            value = 0
            for _ in range(count):
                value = (value << 1) | ((raw[self.pos // 8] >> (7 - self.pos % 8)) & 1)
                self.pos += 1
            return value
        def ue(self):
            zeros = 0
            while not self.read(1):
                zeros += 1
                if zeros > 31:
                    raise ValueError('SPS inválido')
            return (1 << zeros) - 1 + self.read(zeros)

    bits = Bits()
    if kind == 0x24:
        bits.read(4)
        layers = bits.read(3)
        bits.read(1)
        bits.read(96)  # general profile_tier_level
        subprofiles = [bits.read(1) for _ in range(layers)]
        sublevels = [bits.read(1) for _ in range(layers)]
        if layers:
            bits.read((8 - layers) * 2)
        for profile, level in zip(subprofiles, sublevels):
            if profile:
                bits.read(88)
            if level:
                bits.read(8)
        bits.ue()
        chroma = bits.ue()
        if chroma == 3:
            bits.read(1)
        width, height = bits.ue(), bits.ue()
        if bits.read(1):
            left, right, top, bottom = (bits.ue() for _ in range(4))
            height -= (2 if chroma == 1 else 1) * (top + bottom)
        return height if 100 <= height <= 4320 and width >= height else 0
    profile = bits.read(8)
    bits.read(16)
    bits.ue()
    chroma = 1
    if profile in (100, 110, 122, 244, 44, 83, 86, 118, 128):
        chroma = bits.ue()
        if chroma == 3:
            bits.read(1)
        bits.ue()
        bits.ue()
        bits.read(1)
        if bits.read(1):
            return 0  # scaling lists: do not guess dimensions
    bits.ue()
    poc = bits.ue()
    if poc == 0:
        bits.ue()
    elif poc == 1:
        bits.read(1)
        bits.ue()
        bits.ue()
        for _ in range(bits.ue()):
            bits.ue()
    bits.ue()
    bits.read(1)
    width = (bits.ue() + 1) * 16
    height = (bits.ue() + 1) * 16
    frame_only = bits.read(1)
    if not frame_only:
        height *= 2
        bits.read(1)
    bits.read(1)
    if bits.read(1):
        left, right, top, bottom = (bits.ue() for _ in range(4))
        height -= (2 if chroma == 1 else 1) * (2 - frame_only) * (top + bottom)
    return height if 100 <= height <= 4320 and width >= height else 0


def inspect_stream(stream, opener, deadline):
    url, _, options = stream.partition('|')
    headers = {k.lstrip('!'): v for k, v in parse_qsl(options)
               if k.lstrip('!').lower() not in ('ext', 'verifypeer', 'range')}
    release_hints = {'tag': extract_cam_tag(url.split('?', 1)[0].rsplit('/', 1)[-1].rsplit('.', 1)[0])}

    def read_range(offset, count):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Tiempo de sondeo agotado')
        request = Request(url, headers=dict(headers, Range='bytes={}-{}'.format(offset, offset + count - 1)))
        with opener.open(request, timeout=min(4, remaining)) as response:
            if not release_hints['tag']:
                release_hints['tag'] = _extract_filename_tag(response)
            if offset:
                content_range = response.headers.get('Content-Range', '')
                if response.status != 206 or not content_range.startswith('bytes {}-'.format(offset)):
                    raise ValueError('El servidor no permite leer metadatos por rangos')
            return response.read(count)

    initial = read_range(0, 65536)
    if len(initial) >= 188 * 3 and all(initial[pos] == 0x47 for pos in (0, 188, 376)):
        return _inspect_transport_stream(initial)
    windows = [(0, initial)]

    def read_at(offset, count):
        for start, data in windows:
            if start <= offset and offset + count <= start + len(data):
                return data[offset-start:offset-start+count]
        if len(windows) >= 12:
            raise ValueError('Limite de metadatos alcanzado')
        data = read_range(offset, max(65536, count))
        windows.append((offset, data))
        return data[:count]

    def atoms(start, end):
        for _ in range(64):
            if start + 8 > end:
                break
            raw = read_at(start, 16)
            if len(raw) < 8:
                break
            size, kind = struct.unpack_from('>I4s', raw)
            header = 8
            if size == 1:
                if len(raw) < 16:
                    break
                size, header = struct.unpack_from('>Q', raw, 8)[0], 16
            if size < header or start + size > end:
                break
            yield kind, start + header, start + size
            start += size

    def sparse_moov(start, end):
        # Las tablas de muestras pueden ocupar megabytes: saltarlas y leer
        # solamente dimensiones, lenguaje y la descripcion del primer codec.
        tracks = bytearray()
        make_box = lambda kind, data: struct.pack('>I4s', len(data) + 8, kind) + data
        for kind, track_start, track_end in atoms(start, end):
            if kind != b'trak':
                continue
            track = bytearray()
            for child, a, b in atoms(track_start, track_end):
                if child == b'tkhd':
                    track.extend(make_box(child, read_at(a, min(b-a, 104))))
                elif child == b'mdia':
                    mdia = bytearray()
                    for field, c, d in atoms(a, b):
                        if field in (b'mdhd', b'hdlr'):
                            mdia.extend(make_box(field, read_at(c, min(d-c, 40))))
                        elif field == b'minf':
                            for node, e, f in atoms(c, d):
                                if node != b'stbl':
                                    continue
                                for sample, g, h in atoms(e, f):
                                    if sample == b'stsd' and h-g >= 34:
                                        first = read_at(g, 34)
                                        description = first[:8] + make_box(first[12:16], first[16:34])
                                        mdia.extend(make_box(b'minf', make_box(b'stbl', make_box(b'stsd', description))))
                                        break
                    track.extend(make_box(b'mdia', bytes(mdia)))
            tracks.extend(make_box(b'trak', bytes(track)))
        return parse_moov(bytes(tracks))
    if initial.lstrip(b'\xef\xbb\xbf \r\n').startswith(b'#EXTM3U'):
        # Una lista truncada no permite afirmar cuales son todas las pistas.
        text = initial.decode('utf-8-sig', 'replace')
        if len(initial) == 65536:
            raise ValueError('El manifiesto está truncado; no se pudo verificar el vídeo')
        metadata = parse_hls(text)
        def fetch(resource, count=65536, byte_range=None):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Tiempo de sondeo agotado')
            if byte_range is not None:
                range_header = 'bytes={}-{}'.format(byte_range[0], byte_range[1])
                read_count = max(count, byte_range[1] + 1)
            else:
                range_header = 'bytes=0-{}'.format(max(1023, count - 1))
                read_count = count
            req = Request(resource, headers=dict(headers, Range=range_header))
            with opener.open(req, timeout=min(4, remaining)) as response:
                if not release_hints['tag']:
                    release_hints['tag'] = _extract_filename_tag(response)
                data = response.read(read_count)
                if byte_range is not None and getattr(response, 'status', None) == 200 and len(data) > byte_range[0]:
                    data = data[byte_range[0]:byte_range[1] + 1]
                return data if byte_range is not None else data[:count], response.geturl()

        variants = []
        lines = text.splitlines()
        for index, line in enumerate(lines[:-1]):
            if line.startswith('#EXT-X-STREAM-INF:'):
                attrs = _hls_attributes(line)
                match = re.fullmatch(r'(\d+)x(\d+)', attrs.get('RESOLUTION', ''))
                height = _normalize_height(int(match.group(1)), int(match.group(2))) if match else 0
                bw_raw = attrs.get('BANDWIDTH', '')
                bw = int(bw_raw) if bw_raw.isdigit() else 0
                next_uri = next((lines[j].strip() for j in range(index + 1, min(index + 4, len(lines)))
                                 if lines[j].strip() and not lines[j].strip().startswith('#')), '')
                if next_uri:
                    variants.append((height, bw, urljoin(url, next_uri)))
        candidates = sorted(variants, reverse=True)[:3] if variants else [(0, 0, url)]
        for height, _, candidate in candidates:
            try:
                playlist, playlist_url = fetch(candidate) if variants else (initial, url)
                playlist_text = playlist.decode('utf-8-sig', 'replace')
                if not playlist_text.lstrip().startswith('#EXTM3U'):
                    continue
                maps = _parse_ext_x_map(playlist_text)
                segment = next((line.strip() for line in playlist_text.splitlines()
                                if line.strip() and not line.startswith('#')), '')
                if not segment:
                    continue
                init_meta = {}
                for map_uri, map_range in maps:
                    sample, _ = fetch(urljoin(playlist_url, map_uri), 65536, byte_range=map_range)
                    if not sample or sample.lstrip().lower().startswith((b'<html', b'<!doctype')):
                        raise ValueError('El segmento no contiene video')
                    if not init_meta.get('heights') or not init_meta.get('audio'):
                        parsed = _parse_init_segment(sample)
                        if parsed.get('heights') and not init_meta.get('heights'):
                            init_meta['heights'] = parsed['heights']
                        if parsed.get('audio') and not init_meta.get('audio'):
                            init_meta['audio'] = parsed['audio']
                seg_sample, _ = fetch(urljoin(playlist_url, segment), 32)
                if not seg_sample or seg_sample.lstrip().lower().startswith((b'<html', b'<!doctype')):
                    raise ValueError('El segmento no contiene video')
                if variants and height:
                    metadata['heights'] = [height]
                elif not metadata.get('heights') and init_meta.get('heights'):
                    metadata['heights'] = init_meta['heights']
                if not metadata.get('audio') and init_meta.get('audio'):
                    metadata['audio'] = init_meta['audio']
                if release_hints['tag']:
                    metadata['release_tag'] = release_hints['tag']
                return metadata
            except Exception:
                continue
        raise ValueError('El manifiesto no tiene segmentos accesibles')
    if len(initial) < 8 or initial[4:8] not in (b'ftyp', b'moov', b'free', b'wide'):
        raise ValueError('No se recibió un archivo de video')
    offset = 0
    # Saltar mdat por su longitud; nunca descargar el cuerpo del video.
    for _ in range(16):
        header = initial[offset:offset+16] if offset + 16 <= len(initial) else read_range(offset, 16)
        if len(header) < 8:
            break
        size, kind = struct.unpack_from('>I4s', header)
        header_size = 8
        if size == 1:
            if len(header) < 16:
                break
            size, header_size = struct.unpack_from('>Q', header, 8)[0], 16
        if size < header_size:
            break
        if kind == b'moov':
            if size > 2 * 1024 * 1024:
                info = sparse_moov(offset + header_size, offset + size)
            elif offset + size <= len(initial):
                info = parse_moov(initial[offset + header_size:offset + size])
            else:
                info = parse_moov(read_range(offset + header_size, size - header_size))
            if release_hints['tag']:
                info['release_tag'] = release_hints['tag']
            return info
        offset += size
    return {'release_tag': release_hints['tag']} if release_hints['tag'] else {}


def quality_label(metadata):
    if metadata.get('label', '').startswith('Multirresolucion:'):
        return metadata['label']
    heights = metadata.get('heights', [])
    if not heights:
        return metadata.get('label', '')
    return ('Multirresolucion: ' if len(heights) > 1 else '') + ' / '.join('{}p'.format(h) for h in heights)


def audio_label(metadata, server):
    tracks = metadata.get('audio', [])
    if tracks:
        values = []
        for track in tracks:
            text = track['language']
            channels = track.get('channels', 0)
            if channels == 1:
                text += ' (mono)'
            elif channels == 2:
                text += ' (estéreo)'
            elif channels:
                text += ' ({} canales)'.format(channels)
            if text not in values:
                values.append(text)
        return ('Audio multiple: ' if len(tracks) > 1 else 'Audio: ') + ' / '.join(values)
    if server.get('language') or server.get('idioma'):
        return 'Audio: {} (fuente)'.format(server.get('language') or server['idioma'])
    name = server.get('nombre', '').lower()
    for token, label in (('lat', 'LAT'), ('latino', 'LAT'), ('esp', 'ESP'), ('eng', 'ENG')):
        if re.search(r'\b' + token + r'\b', name):
            return 'Audio: {} (fuente)'.format(label)
    if re.search(r'\bsub\b', name):
        return 'Subtitulado (fuente); audio no indicado'
    return 'Audio no indicado'


class Scanner:
    """Pool de workers reutilizables; resultados tardios no modifican la UI ni disco."""
    def __init__(self, resolver, opener_factory, quality_lookup, budget_context, workers=10):
        self.resolver, self.opener_factory = resolver, opener_factory
        self.quality_lookup, self.budget_context = quality_lookup, budget_context
        self.jobs = queue.Queue()
        self.lock = threading.Lock()
        self.closed = threading.Event()
        self.cancellations = set()
        self.cache, self.streams, self.inflight = {}, {}, set()
        for _ in range(max(1, int(workers or 1))):
            threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        while not self.closed.is_set():
            try:
                url, key, deadline, cancel = self.jobs.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                if time.monotonic() >= deadline or cancel.is_set():
                    continue
                with self.budget_context(deadline, cancel):
                    stream = self.resolver(url)
                    if cancel.is_set() or self.closed.is_set():
                        continue
                    if not stream:
                        with self.lock:
                            self.cache[key] = {'scanned': True, 'updated': time.time(),
                                               'error': 'No disponible: el servidor no entregó vídeo'}
                        continue
                    try:
                        # Respetar la opción TLS explícita que recibirá Kodi.
                        # Algunos CDN de OK.ru sirven MP4 con un certificado
                        # incompleto, aunque el vídeo se reproduce en Kodi.
                        insecure = bool(re.search(r'(?:^|[|&])verifypeer=false(?:&|$)', stream, re.I))
                        opener = self.opener_factory(verify_tls=False) if insecure else self.opener_factory()
                        details = inspect_stream(stream, opener, deadline)
                        result = {'updated': time.time(), 'scanned': True, 'playable': True}
                        result.update(details)
                        if not result.get('heights'):
                            result['label'] = self.quality_lookup(stream.split('|')[0])
                    except Exception as exc:
                        result = {'updated': time.time(), 'scanned': True,
                                  'error': 'No disponible: ' + str(exc)}
                    with self.lock:
                        if cancel.is_set() or self.closed.is_set():
                            continue
                        self.cache[key] = result
                        if result.get('playable'):
                            self.streams[key] = (time.monotonic(), stream)
            except Exception as exc:
                # Una caida durante el sondeo no convierte el enlace en invalido.
                if not cancel.is_set():
                    with self.lock:
                        self.cache[key] = {'scanned': True, 'updated': time.time(),
                                           'error': 'No disponible: ' + str(exc)[:160]}
            finally:
                with self.lock:
                    self.inflight.discard(key)
                self.jobs.task_done()

    def scan(self, servers, stored=None, seconds=15, progress=None):
        keys = [cache_key(s['url']) for s in servers]
        unique_keys = list(dict.fromkeys(keys))
        deadline = time.monotonic() + seconds
        cancel = threading.Event()
        with self.lock:
            if self.closed.is_set():
                return {}
            self.cancellations.add(cancel)
            self.streams = {k: v for k, v in self.streams.items() if time.monotonic() - v[0] < 90}
            if len(self.cache) > 256:
                keep = sorted(self.cache, key=lambda k: self.cache[k].get('updated', 0), reverse=True)[:256]
                self.cache = {k: self.cache[k] for k in keep}
            seen_keys = set()
            for server, key in zip(servers, keys):
                if key in seen_keys:
                    continue
                seen_keys.add(key)
                if server.get('resolver_status') == 'pending':
                    self.cache[key] = {'scanned': True, 'updated': time.time(),
                                       'error': server.get('resolver_error') or 'Pendiente de reparar'}
                    continue
                if key not in self.inflight:
                    self.cache.pop(key, None)
                    self.streams.pop(key, None)
                    self.jobs.put_nowait((server['url'], key, deadline, cancel))
                    self.inflight.add(key)
        total = len(unique_keys)
        try:
            while time.monotonic() < deadline and not self.closed.is_set():
                with self.lock:
                    count = sum(key not in self.inflight for key in unique_keys)
                if progress and progress(count, total) is False:
                    break
                if count == total:
                    break
                self.closed.wait(min(0.1, max(0, deadline - time.monotonic())))
        finally:
            cancel.set()
            with self.lock:
                self.cancellations.discard(cancel)
        with self.lock:
            return {key: dict(self.cache[key]) for key in keys if key in self.cache}

    def resolved(self, url):
        with self.lock:
            stamp, stream = self.streams.get(cache_key(url), (0, None))
        return stream if time.monotonic() - stamp < 90 else None

    def close(self):
        self.closed.set()
        with self.lock:
            for cancel in self.cancellations:
                cancel.set()
