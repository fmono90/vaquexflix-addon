# -*- coding: utf-8 -*-
"""
tv_epg.py - Proveedor de Guía Electrónica de Programación (EPG) para Vaquexflix.
Descarga y almacena en caché la guía horaria oficial de televisión para mostrar
en tiempo real qué programa se está emitiendo en cada canal y cuál será el siguiente.
"""

import os
import re
import json
import time
import urllib.request
import threading
from datetime import datetime

_EPG_URL = "https://www.tdtchannels.com/epg/TV.json"
_EPG_LOCK = threading.Lock()
_EPG_DATA = None
_EPG_CACHE_FILE = None
_CARGANDO_EPG = False

ALIAS_CANALES = {
    'la1': 'la1', 'la 1': 'la1', 'la 1 hd': 'la1', 'tve1': 'la1',
    'la2': 'la2', 'la 2': 'la2', 'la 2 hd': 'la2', 'tve2': 'la2',
    'antena3': '13', 'antena 3': '13',
    'cuatro': 'cuatro', 'cuatro hd': 'cuatro',
    'telecinco': 'telecinco', 'tele 5': 'telecinco', 't5': 'telecinco',
    'lasexta': 'sexta', 'la sexta': 'sexta',
    'teledeporte': 'tdp', 'tdp': 'tdp',
    '24h': '24horas', '24 horas': '24horas', 'canal 24 horas': '24horas',
    'gol play': 'gol', 'gol': 'gol', 'gol television': 'gol',
    'clan': 'clan', 'boing': 'boing', 'fdf': 'fdf', 'energy': 'energy',
    'divinity': 'divinity', 'be mad': 'bemad', 'bemad': 'bemad',
    'dmax': 'dmax', 'trece': '13', '13 tv': '13', 'dkiss': 'dkiss', 'ten': 'ten',
    'telemadrid': 'telemadrid', 'la otra': 'laotra', 'tv3': 'tv3',
    'canal sur': 'canalsura', 'aragon tv': 'aragontv', 'real madrid tv': 'rmtv',
    'euronews': 'euronews', 'dw': 'dw', 'dw espanol': 'dw', 'france 24': 'france24',
    'telesur': 'telesur', 'cnn': 'cnne', 'cnn en espanol': 'cnne'
}


def _get_cache_path():
    global _EPG_CACHE_FILE
    if _EPG_CACHE_FILE:
        return _EPG_CACHE_FILE
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cache')
    try:
        import xbmcvfs, xbmcaddon
        prof = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if prof and not prof.startswith('special://'):
            base = os.path.join(prof, 'cache')
    except Exception:
        pass
    os.makedirs(base, exist_ok=True)
    _EPG_CACHE_FILE = os.path.join(base, 'tv_epg_cache.json')
    return _EPG_CACHE_FILE


def init_epg_cache(userdata_dir):
    """Inicializa la ruta de caché local para el EPG."""
    global _EPG_CACHE_FILE
    if not os.path.exists(userdata_dir):
        try:
            os.makedirs(userdata_dir, exist_ok=True)
        except Exception:
            pass
    _EPG_CACHE_FILE = os.path.join(userdata_dir, 'tv_epg_cache.json')
    threading.Thread(target=_actualizar_epg_segundo_plano, daemon=True).start()


def _cargar_epg_disco():
    """Carga los datos de EPG desde disco si tienen menos de 24 horas."""
    global _EPG_DATA
    cache_f = _get_cache_path()
    if not cache_f or not os.path.exists(cache_f):
        return None
    try:
        with open(cache_f, 'r', encoding='utf-8') as f:
            data = json.load(f)
        ts = data.get('_ts', 0)
        # TTL de 24 horas (86400 segundos)
        if (time.time() - ts) < 86400 and 'canales' in data:
            _EPG_DATA = data['canales']
            return _EPG_DATA
    except Exception:
        pass
    return None


def _guardar_epg_disco(canales_list):
    """Guarda los datos de EPG en disco de forma atómica."""
    cache_f = _get_cache_path()
    if not cache_f:
        return
    tmp = cache_f + '.tmp'
    try:
        data = {
            '_ts': time.time(),
            'canales': canales_list
        }
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, cache_f)
    except Exception:
        pass


def _actualizar_epg_segundo_plano():
    """Descarga la guía EPG en hilo secundario."""
    global _EPG_DATA, _CARGANDO_EPG
    if _CARGANDO_EPG:
        return
    _CARGANDO_EPG = True

    try:
        cached = _cargar_epg_disco()
        if cached:
            return

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        req = urllib.request.Request(_EPG_URL, headers=headers)
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            if isinstance(data, list):
                with _EPG_LOCK:
                    _EPG_DATA = data
                _guardar_epg_disco(data)
    except Exception:
        pass
    finally:
        _CARGANDO_EPG = False


def _normalizar_nombre(nombre):
    """Normaliza el nombre del canal eliminando sufijos comunes para mejor coincidencia."""
    s = nombre.lower().strip()
    s = re.sub(r'\(.*?\)', '', s)
    for drop in ['.tv', 'rtve', 'tve', ' hd', ' españa', ' tv', ' television', ' televisión', ' de ', ' canal ']:
        s = s.replace(drop, ' ')
    clean = ''.join(c for c in s if c.isalnum())
    return clean


def _buscar_canal_epg(canal_nombre):
    """Localiza el registro del canal en los datos del EPG."""
    global _EPG_DATA
    if not _EPG_DATA:
        _cargar_epg_disco()
    if not _EPG_DATA:
        if not _CARGANDO_EPG:
            threading.Thread(target=_actualizar_epg_segundo_plano, daemon=True).start()
        return None

    nombre_norm = _normalizar_nombre(canal_nombre)
    if not nombre_norm:
        return None

    alias_target = ALIAS_CANALES.get(canal_nombre.lower().strip()) or ALIAS_CANALES.get(nombre_norm)

    with _EPG_LOCK:
        lista = _EPG_DATA

    # Pase 1: Coincidencia por alias directo
    if alias_target:
        for ch in lista:
            ch_n = _normalizar_nombre(ch.get('name', ''))
            if ch_n == alias_target or ch_n.startswith(alias_target):
                return ch

    # Pase 2: Coincidencia por nombre exacto o prefijo
    for ch in lista:
        ch_n = _normalizar_nombre(ch.get('name', ''))
        if ch_n and (ch_n == nombre_norm or ch_n.startswith(nombre_norm) or nombre_norm.startswith(ch_n)):
            return ch

    return None


def obtener_info_epg(canal_nombre):
    """
    Busca la programación actual y siguiente para un canal dado.
    Retorna un texto formateado para inyectar en la sinopsis del canal.
    """
    ch = _buscar_canal_epg(canal_nombre)
    if not ch:
        return None

    ahora_ts = int(time.time())
    events = ch.get('events', [])
    for i, ev in enumerate(events):
        hi = ev.get('hi', 0)
        hf = ev.get('hf', 0)
        if hi <= ahora_ts <= hf:
            sig = events[i + 1] if (i + 1) < len(events) else None
            t_ini = datetime.fromtimestamp(hi).strftime('%H:%M')
            t_fin = datetime.fromtimestamp(hf).strftime('%H:%M')
            titulo_actual = ev.get('t', 'Programa en emisión')
            desc_actual = ev.get('d', '')

            ahora_linea = f"[AHORA {t_ini} - {t_fin}] {titulo_actual}"
            luego_linea = ""
            if sig:
                s_ini = datetime.fromtimestamp(sig.get('hi', 0)).strftime('%H:%M')
                luego_linea = f"\n[A CONTINUACIÓN {s_ini}] {sig.get('t', '')}"

            bloque_epg = f"{ahora_linea}{luego_linea}"
            if desc_actual:
                return f"{bloque_epg}\n\n{desc_actual}"
            return bloque_epg

    return None


def obtener_programa_actual(canal_nombre):
    """Retorna una cadena concisa con el título del programa en emisión para toasts y OSD."""
    ch = _buscar_canal_epg(canal_nombre)
    if not ch:
        return ""

    ahora_ts = int(time.time())
    events = ch.get('events', [])
    for ev in events:
        hi = ev.get('hi', 0)
        hf = ev.get('hf', 0)
        if hi <= ahora_ts <= hf:
            t_ini = datetime.fromtimestamp(hi).strftime('%H:%M')
            tit = ev.get('t', '')
            return f"[{t_ini}] {tit}" if tit else ""
    return ""
