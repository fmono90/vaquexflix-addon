"""
Módulo de integración para los episodios de Valle Salvaje desde YouTube.
Fuentes integradas:
  1. @ValleSalvajeAr (UCBCrcPs4eOjqJUxw7pxP61Q) -> Canales T1 (1-120), T2 (121-240), T4 (421-522+)
  2. @aorv_toor (UCsGeLc_mmRd_6hChhreAGfA) -> Episodios adicionales T2/T3 (188-270)
  3. @RayenGuzmán-k6v (UCRQ04pk-mNzyLKwEa1n2D1w) -> Episodios adicionales T3/T4 (276-318, 400-450)
  4. @japanallvlog (UCue1gjbXHotozKDG0T5PPHg) -> Episodios adicionales T3/T4 (390-418, 430-432)
  5. @Asjsjjeks (UCcAivQEPXkf3vQ5PWK0_Tsg) -> Episodios adicionales T3 (284-305, omitiendo partes 1)
  6. @vallesal1 (UCTcIpB_waiTRkX-4bFyta6Q) -> Episodios adicionales T2/T3 (201-389)
  7. @suspirossalvajes (UCT87-giDv-igJOYKmKRn0Qw) -> Episodios adicionales T3 (241-374)
Proporciona servidores de reproducción directa y carátulas reales mapeadas por capítulo.
"""

import json
import os
import re
import threading
import time
import unicodedata

TMDB_ID = 242874

CHANNELS = {
    "valle_salvaje_ar": {
        "id": "UCBCrcPs4eOjqJUxw7pxP61Q",
        "nombre": "YouTube [Valle Salvaje]",
        "url": "https://www.youtube.com/@ValleSalvajeAr/videos",
    },
    "aorv_toor": {
        "id": "UCsGeLc_mmRd_6hChhreAGfA",
        "nombre": "YouTube [aorv_toor]",
        "url": "https://www.youtube.com/@aorv_toor/videos",
    },
    "rayen_guzman": {
        "id": "UCRQ04pk-mNzyLKwEa1n2D1w",
        "nombre": "YouTube [Rayen Guzmán]",
        "url": "https://www.youtube.com/@RayenGuzm%C3%A1n-k6v/videos",
    },
    "japanallvlog": {
        "id": "UCue1gjbXHotozKDG0T5PPHg",
        "nombre": "YouTube [japanallvlog]",
        "url": "https://www.youtube.com/@japanallvlog/videos",
    },
    "asjsjjeks": {
        "id": "UCcAivQEPXkf3vQ5PWK0_Tsg",
        "nombre": "YouTube [Asjsjjeks]",
        "url": "https://www.youtube.com/@Asjsjjeks/videos",
        "omit_filter": r"\b(?:parte|part)\s*1\b",
    },
    "vallesal1": {
        "id": "UCTcIpB_waiTRkX-4bFyta6Q",
        "nombre": "YouTube [vallesal1]",
        "url": "https://www.youtube.com/@vallesal1/videos",
    },
    "suspirossalvajes": {
        "id": "UCT87-giDv-igJOYKmKRn0Qw",
        "nombre": "YouTube [Suspiros Salvajes]",
        "url": "https://www.youtube.com/@suspirossalvajes/videos",
    }
}

_LOCK = threading.RLock()
_CHANNEL_MAPS = {k: {} for k in CHANNELS}
_LAST_SYNC = {k: 0 for k in CHANNELS}
_SYNC_INTERVAL = 900  # 15 minutos entre comprobaciones de nuevos vídeos

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SEED_FILE = os.path.join(BASE_DIR, "resources", "valle_salvaje_seed.json")
CACHE_FILE = os.path.join(BASE_DIR, "cache", "valle_salvaje.json")


def _normalizar_texto(texto):
    if not texto:
        return ""
    texto = unicodedata.normalize("NFKD", str(texto))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"[^\w\s]", " ", texto.lower()).strip()


def owns(item_or_series):
    """Comprueba si un elemento o serie pertenece a Valle Salvaje."""
    if not item_or_series or not isinstance(item_or_series, dict):
        return False
    tmdb = item_or_series.get("tmdb_id")
    if tmdb is not None:
        try:
            if int(tmdb) == TMDB_ID:
                return True
        except (ValueError, TypeError):
            pass
    url = str(item_or_series.get("url") or "")
    if f"/tv/{TMDB_ID}" in url or f"/{TMDB_ID}/" in url or url.endswith(f"/{TMDB_ID}"):
        return True
    for key in ("title", "serie_title", "original_title", "name"):
        val = item_or_series.get(key)
        if val and "valle salvaje" in _normalizar_texto(val):
            return True
    return False


def extract_chapter(item):
    """
    Extrae el número absoluto de capítulo de un episodio de Valle Salvaje.
    Soporta extracción por título/nombre ('Episodio 522', 'Capítulo 120', 'Valle Salvaje 250')
    y cálculo por temporada/episodio de TMDb.
    """
    if not item or not isinstance(item, dict):
        return 0
    name_str = f"{item.get('name', '')} {item.get('title', '')}"
    m = re.search(r"(?:episod(?:e|io)|cap[ií]tulo|cap\.?|ep\.?|valle\s+salvaje|valle)(?:\s+completo)?\s*#?\s*(\d+)", name_str, re.IGNORECASE)
    if not m:
        m = re.search(r"\b(\d{1,4})\b", name_str)
    if m:
        try:
            return int(m.group(1))
        except (ValueError, TypeError):
            pass

    try:
        s = int(item.get("season") or 1)
        ep = int(item.get("episode") or 0)
    except (ValueError, TypeError):
        return 0

    if s == 1:
        return ep
    if s == 2:
        return ep if ep > 120 else 120 + ep
    if s == 3:
        return ep if ep > 240 else 240 + ep
    if s == 4:
        return ep if ep > 420 else 420 + ep
    return ep


def _cargar_mapa_inicial():
    """Carga los episodios iniciales desde el archivo semilla y la caché persistente."""
    global _CHANNEL_MAPS
    with _LOCK:
        if any(_CHANNEL_MAPS.values()):
            return

        def _merge_data(data):
            if not isinstance(data, dict):
                return
            if any(k in CHANNELS for k in data):
                for ch_k in CHANNELS:
                    ch_dict = data.get(ch_k) or {}
                    if isinstance(ch_dict, dict):
                        for ep_k, vid_v in ch_dict.items():
                            try:
                                _CHANNEL_MAPS[ch_k][int(ep_k)] = str(vid_v).strip()
                            except (ValueError, TypeError):
                                pass
            else:
                for ep_k, vid_v in data.items():
                    try:
                        _CHANNEL_MAPS["valle_salvaje_ar"][int(ep_k)] = str(vid_v).strip()
                    except (ValueError, TypeError):
                        pass

        if os.path.exists(SEED_FILE):
            try:
                with open(SEED_FILE, "r", encoding="utf-8") as f:
                    _merge_data(json.load(f))
            except Exception:
                pass

        if os.path.exists(CACHE_FILE):
            try:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    _merge_data(json.load(f))
            except Exception:
                pass


def _guardar_cache():
    """Guarda los mapas de canales actualizados en cache/valle_salvaje.json."""
    with _LOCK:
        try:
            os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
            serializable = {}
            for ch_k, m in _CHANNEL_MAPS.items():
                serializable[ch_k] = {str(k): v for k, v in sorted(m.items())}
            tmp = CACHE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(serializable, f, indent=2)
            os.replace(tmp, CACHE_FILE)
        except Exception:
            pass


def sync_recent(channel_key=None, limit=35, force=False):
    """
    Sincroniza los últimos vídeos publicados en los canales de YouTube.
    Actualiza el mapa de episodios con cualquier capítulo nuevo.
    """
    global _LAST_SYNC
    now = time.time()
    _cargar_mapa_inicial()

    targets = [channel_key] if channel_key and channel_key in CHANNELS else list(CHANNELS.keys())
    nuevos_total = 0

    import tube_engine

    for ch_k in targets:
        with _LOCK:
            if not force and (now - _LAST_SYNC[ch_k]) < _SYNC_INTERVAL:
                continue
            _LAST_SYNC[ch_k] = now

        cid = CHANNELS[ch_k]["id"]
        omit = CHANNELS[ch_k].get("omit_filter")
        try:
            _, videos = tube_engine.get_channel_videos(cid, limit=limit)
        except Exception:
            videos = []

        if not videos:
            continue

        with _LOCK:
            ch_map = _CHANNEL_MAPS[ch_k]
            for vid in videos:
                vid_id = vid.get("id") or ""
                title = vid.get("title") or ""
                if not vid_id or not title:
                    continue
                t_lower = title.lower()
                if ch_k != "vallesal1" and "valle" not in t_lower and "salvaje" not in t_lower and "v.s" not in t_lower:
                    continue
                if "avance" in t_lower or "parte final" in t_lower:
                    continue
                if omit and re.search(omit, title, re.IGNORECASE):
                    continue

                if "viernes 21 noviembre" in t_lower:
                    num = 301
                else:
                    m_dash = re.match(r"^([23])-?(\d{2})\b", title.strip())
                    if m_dash:
                        num = int(m_dash.group(1)) * 100 + int(m_dash.group(2))
                    else:
                        m = re.search(r"(?:episodio|cap[ií]tulo|cap\.?|ep\.?|valle\s+salvaje|valle)(?:\s+completo)?\s*#?\s*(\d+)", title, re.IGNORECASE)
                        if not m:
                            m = re.search(r"\b(\d{1,4})\b", title)
                        num = int(m.group(1)) if m else None

                if num:
                    try:
                        if num not in ch_map:
                            ch_map[num] = vid_id
                            nuevos_total += 1
                    except (ValueError, TypeError):
                        pass

    if nuevos_total > 0:
        _guardar_cache()

    return nuevos_total > 0


def get_videos_for_chapter(chapter_number, allow_sync=False):
    """
    Obtiene todos los vídeos de YouTube disponibles para un capítulo en los 7 canales,
    retornando lista de tuplas (channel_key, server_name, video_id).
    Por defecto es una consulta pura en memoria (instantánea, cero llamadas de red).
    """
    _cargar_mapa_inicial()
    try:
        ch = int(chapter_number)
    except (ValueError, TypeError):
        return []

    found = []
    max_known = 0
    with _LOCK:
        for ch_k, m in _CHANNEL_MAPS.items():
            if m:
                max_known = max(max_known, max(m.keys()))
            if ch in m:
                found.append((ch_k, CHANNELS[ch_k]["nombre"], m[ch]))

    if not found and ch > max_known and allow_sync:
        sync_recent(force=False)
        with _LOCK:
            for ch_k, m in _CHANNEL_MAPS.items():
                if ch in m:
                    found.append((ch_k, CHANNELS[ch_k]["nombre"], m[ch]))

    return found


def get_cover_for_chapter(chapter_number):
    """
    Obtiene la URL de carátula/miniatura real de YouTube para un número de capítulo.
    Consulta pura en memoria (instantánea, cero llamadas de red).
    Prioriza el canal oficial y si no existe busca en las fuentes alternativas.
    """
    videos = get_videos_for_chapter(chapter_number, allow_sync=False)
    if videos:
        # Priorizar valle_salvaje_ar si está disponible, de lo contrario la primera fuente
        for ch_k, _, vid_id in videos:
            if ch_k == "valle_salvaje_ar":
                return f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg"
        return f"https://i.ytimg.com/vi/{videos[0][2]}/hqdefault.jpg"
    return ""


def enrich_season_episodes(episodes):
    """
    Inyecta la carátula real del episodio de YouTube en cada ítem de una temporada
    cuando la carátula actual esté vacía o sea el póster genérico de la serie.
    """
    if not episodes or not isinstance(episodes, list):
        return episodes
    for ep in episodes:
        if not isinstance(ep, dict):
            continue
        ch = extract_chapter(ep)
        if ch:
            thumb = get_cover_for_chapter(ch)
            if thumb:
                ep["cover"] = thumb
    return episodes


def enrich_episodes(episodes_by_season):
    """
    Enriquece el diccionario completo de temporadas con las carátulas reales de episodios.
    """
    if not isinstance(episodes_by_season, dict):
        return episodes_by_season
    for season_eps in episodes_by_season.values():
        enrich_season_episodes(season_eps)
    return episodes_by_season


def servers(item, series=None):
    """
    Devuelve la lista de servidores de YouTube (uno por cada canal que tenga el vídeo)
    para el episodio solicitado de Valle Salvaje.
    """
    root = series or item
    if not owns(root):
        return []

    ch = extract_chapter(item)
    if not ch:
        return []

    results = []
    for _, srv_nombre, vid_id in get_videos_for_chapter(ch, allow_sync=True):
        results.append({
            "nombre": srv_nombre,
            "url": f"https://www.youtube.com/watch?v={vid_id}",
            "calidad": "Sin verificar",
            "idioma": "Castellano",
            "source": "valle_salvaje"
        })

    return results
