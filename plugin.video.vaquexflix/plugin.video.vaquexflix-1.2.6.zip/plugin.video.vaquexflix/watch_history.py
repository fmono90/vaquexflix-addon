"""Historial por episodio, presentado como catalogo de series."""
import re


def key(url):
    return url.split('?')[0].rstrip('/')


def series_title(title):
    title = re.sub(r'^T\d+:E\d+\s*-\s*', '', title, flags=re.I)
    return re.sub(r'\s+\d+x\d+\s*$', '', title, flags=re.I).strip()


def parent(url, entry):
    if entry.get('series', {}).get('url'):
        res = dict(entry['series'])
        if not res.get('cover'):
            res['cover'] = entry.get('series', {}).get('cover') or entry.get('cover', '')
        return res
    base = re.split(r'/temporada-\d+', url)[0]
    cover = entry.get('series', {}).get('cover') or entry.get('cover', '')
    item = {'url': base, 'title': series_title(entry.get('title', 'Serie')),
            'cover': cover, 'plot': '', 'is_serie': True}
    if base == url:
        # FuegoCine usa URLs sin relacion estructural con la serie.
        item['legacy_episode'] = url
    return item


def recent(history, series=False):
    result, seen = [], {}
    ordered = sorted(history.items(), key=lambda pair: pair[1].get('updated', 0), reverse=True)
    # Los registros antiguos no tienen fecha; conservar su orden mas reciente.
    if not any(h.get('updated') for h in history.values()):
        ordered = list(reversed(list(history.items())))
    for url, entry in ordered:
        if (
            entry.get('is_youtube') or
            entry.get('is_tv') or
            entry.get('is_live') or
            'youtube.com' in url or
            'googlevideo.com' in url or
            url.startswith('tube://') or
            url.startswith('tv://')
        ):
            continue
        is_series = entry.get('is_serie', '/temporada-' in url or '/episodio-' in url)
        if bool(is_series) != series:
            continue
        if series:
            item = parent(url, entry)
            identity = ('legacy', item['title'].casefold()) if item.get('legacy_episode') else key(item['url'])
        else:
            item = dict(entry, url=url, is_serie=False)
            year = str(entry.get('year') or '')[:4]
            name = re.sub(r'\W+', '', str(entry.get('title') or '').casefold())
            identity = ('movie', name, year) if name and year.isdigit() else key(url)
        if identity in seen:
            existing = result[seen[identity]]
            if not series and existing.get('tmdb_id') and item.get('tmdb_id') and (
                    str(existing['tmdb_id']) != str(item['tmdb_id'])):
                identity = key(url)
            else:
                if url not in existing['history_keys']:
                    existing['history_keys'].append(url)
                if not series:
                    variants = existing.setdefault('variants', [
                        {k: v for k, v in existing.items() if k not in ('variants', 'history_keys')}])
                    known = {variant.get('url') for variant in variants}
                    for variant in entry.get('variants') or [item]:
                        variant = dict(variant)
                        variant.setdefault('url', url)
                        if variant['url'] not in known:
                            variants.append(variant)
                            known.add(variant['url'])
                continue
        if identity in seen:
            continue
        seen[identity] = len(result)
        item['history_keys'] = [u for u, h in history.items() if
            (series and h.get('is_serie') and
             (key(parent(u, h)['url']) == key(item['url']) or
              (item.get('legacy_episode') and parent(u, h)['title'].casefold() == item['title'].casefold())))
            or (not series and key(u) == key(url))]
        result.append(item)
    return result


def entry_for(history, item):
    urls = {key(item.get('url', ''))}
    urls.update(key(v.get('url', '')) for v in item.get('variants', []))
    matches = [(index, entry) for index, (url, entry) in enumerate(history.items()) if key(url) in urls]
    return max(matches, key=lambda pair: (pair[1].get('updated', 0), pair[0]))[1] if matches else {}


def resume_text(history, url):
    entry = entry_for(history, url) if isinstance(url, dict) else history.get(key(url), {})
    seconds = int(entry.get('time', 0))
    if seconds <= 0:
        return ''
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    stamp = '{:02d}:{:02d}:{:02d}'.format(hours, minutes, seconds) if hours else '{:02d}:{:02d}'.format(minutes, seconds)
    return '[COLOR yellow]Seguir viendo - {}[/COLOR]'.format(stamp)
