"""Public protocol constants from the authorized LG client; no account credentials."""
import base64
import json
import math
import struct
import os
import sys
_vendor_lib = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'lib')
if _vendor_lib not in sys.path:
    sys.path.insert(0, _vendor_lib)
try:
    from Cryptodome.Cipher import DES3
    from Cryptodome.Util.Padding import pad, unpad
except ImportError:
    from Crypto.Cipher import DES3
    from Crypto.Util.Padding import pad, unpad

KEY = bytes.fromhex('e7af1ed7de1ffddd7bd3fe37ebdffde9ef3fe1ae39edfeb8')

def encode(body):
    raw = json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return base64.b64encode(DES3.new(KEY, DES3.MODE_ECB).encrypt(pad(raw, 8))).hex().encode('ascii')

def decode(wire):
    cipher = base64.b64decode(bytes.fromhex(wire.decode('ascii') if isinstance(wire,bytes) else wire), validate=True)
    return json.loads(unpad(DES3.new(KEY, DES3.MODE_ECB).decrypt(cipher), 8).decode('utf-8'))

def sign_live(token, moment):
    data = ('token=%s&sign2_method=sign_o3&instance=0&start_moment=%s' % (token, moment)).encode()
    data += bytes.fromhex('73616c74333333333d34980d0a1532c9c3821708c0')
    bits = len(data) * 8
    data += b'\x80'
    data += b'\0' * ((56-len(data)) % 64) + struct.pack('<Q', bits)
    state = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
    shifts = [7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21]
    first = [10,11,12,13,14,15,6,7,8,9,0,1,2,3,4,5]
    for offset in range(0, len(data), 64):
        words = struct.unpack('<16I', data[offset:offset+64])
        a,b,c,d = state
        for i in range(64):
            if i < 16: f,g = (b&c)|(~b&d), first[i]
            elif i < 32: f,g = (d&b)|(~d&c), (5*i+1)%16
            elif i < 48: f,g = b^c^d, (3*i+5)%16
            else: f,g = c^(b|~d), (7*i)%16
            constant={42:0xd46f3085,45:0xe6bd99e5,54:0xffecc47d,62:0x2da7d2bb}.get(i,int(abs(math.sin(i+1))*4294967296))
            value = (a+f+constant+words[g]) & 0xffffffff
            shift = shifts[(i//16)*4+i%4]
            rotated = ((value<<shift)|(value>>(32-shift))) & 0xffffffff
            a,d,c,b = d,c,b,(b+rotated)&0xffffffff
        state = [(x+y)&0xffffffff for x,y in zip(state,[a,b,c,d])]
    return struct.pack('<4I', *state).hex()
